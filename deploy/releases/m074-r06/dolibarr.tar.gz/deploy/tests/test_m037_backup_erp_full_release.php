<?php

$root = dirname(__DIR__, 2);
$helper = file_get_contents($root.'/deploy/tools/chinaplanetos_backup_erp_m037_full_release.sh');
$sudoers = file_get_contents($root.'/deploy/config/codex-deploy-backup-erp-m037-full-release.sudoers');
$installer = file_get_contents($root.'/deploy/tools/install_backup_erp_m037_full_release_helper.sh');
$productionHelper = file_get_contents($root.'/deploy/tools/chinaplanetos_production_m037_full_release.sh');
$productionInstaller = file_get_contents($root.'/deploy/tools/install_production_m037_full_release_helper.sh');
$authenticatedRouteTest = file_get_contents($root.'/deploy/tests/test_m037_authenticated_session.php');
$runtimeManifest = file($root.'/deploy/releases/m037-runtime-files.txt', FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
$supportManifest = file($root.'/deploy/releases/m037-support-files.txt', FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);

function m037Assert($condition, $message)
{
    if (!$condition) {
        fwrite(STDERR, "M037_RELEASE_TEST=FAIL REASON=".$message.PHP_EOL);
        exit(1);
    }
}

m037Assert(is_string($helper) && is_string($sudoers) && is_string($installer) && is_string($productionHelper) && is_string($productionInstaller) && is_string($authenticatedRouteTest), 'release helper, sudoers, installer, production helper, production installer, or authenticated route test is unreadable');
m037Assert(count($runtimeManifest) === 52, 'runtime allowlist count is not 52');
m037Assert(count($supportManifest) === 17, 'support allowlist count is not 17');
$sortedRuntime = $runtimeManifest;
$sortedSupport = $supportManifest;
sort($sortedRuntime, SORT_STRING);
sort($sortedSupport, SORT_STRING);
m037Assert($runtimeManifest === $sortedRuntime && count($runtimeManifest) === count(array_unique($runtimeManifest)), 'runtime allowlist is not sorted and unique');
m037Assert($supportManifest === $sortedSupport && count($supportManifest) === count(array_unique($supportManifest)), 'support allowlist is not sorted and unique');
foreach (array_merge($runtimeManifest, $supportManifest) as $relative) {
    m037Assert(is_file($root.'/'.$relative) && !is_link($root.'/'.$relative), 'allowlisted file missing or symbolic: '.$relative);
}

foreach (array(
    "readonly RUNTIME_COMMIT='806df74a0f90ecf8d10c4627707c36d313001a82'",
    "readonly ARTIFACT_SHA='c0e5741f45018302983d6449a2e2392571162fbcd636e1484148f4dc932906e5'",
    "readonly TARGET_CONTAINER='erp-staging-dolibarr-1'",
    "readonly TARGET_DB_CONTAINER='erp-staging-mariadb-1'",
    "readonly TARGET_MAILPIT_CONTAINER='erp-staging-mailpit-1'",
    "readonly TARGET_VOLUME='erp-staging_erp-staging_custom'",
    "readonly TARGET_HTTP='http://127.0.0.1:18088'",
    "docker port \"\$TARGET_CONTAINER\" 80/tcp",
    "docker port \"\$TARGET_MAILPIT_CONTAINER\" 1025/tcp",
    "docker port \"\$TARGET_MAILPIT_CONTAINER\" 8025/tcp",
    'ARTIFACT_ALLOWLIST_MISMATCH',
    'ARTIFACT_SYMLINK_FORBIDDEN',
    'ARTIFACT_TYPE_FORBIDDEN',
    'ARTIFACT_TAR_METADATA_UNSUPPORTED',
    'ARTIFACT_EXTRACT_METADATA_UNSUPPORTED',
    'ARTIFACT_COPY=$(mktemp /root/m037-artifact.',
    'capture_schema_prestate',
    'verify_schema_prestate',
    'restore_database_backup',
    'finalize_full_database_restore',
    'authenticated_route_checks',
    'authenticated_route_output_is_valid',
    'emit_authenticated_route_diagnostic',
    'current_runtime_admin_route_diagnostic',
    'M037_STAGING_DIAGNOSTIC_ADMIN_CURRENT_RUNTIME=PASS',
    'M037_STAGING_AUTH_DIAGNOSTIC=FAIL',
    'OUTPUT_SHA256=',
    "current_runtime_admin_route_diagnostic || die 'CURRENT_RUNTIME_ADMIN_DIAGNOSTIC_FAILED'",
    'AUTH_ADMIN_ROUTES',
    'AUTH_EXTERNAL_ROUTES',
    'M037_AUTH_ROUTE_',
    'M037_AUTH_ROUTE_EXTERNAL_ADMIN_DASHBOARD=DENIED',
    'EXTERNAL_ADMIN_ROUTE_NOT_DENIED',
    "save_state 'APPLY_IN_PROGRESS'",
    "save_state 'APPLY_FAILED_ROLLBACK_FAILED'",
    'M037_STAGING_AUTO_FULL_BACKUP_ROLLBACK=PASS',
    "save_state 'ROLLED_BACK'",
    'ROLLBACK_FAILED_PRESTATE_RECOVERY_RETAINED',
    'ROLLBACK_FAILED_DEPLOYED_STATE_REAPPLIED',
    'automatic_rollback',
    'M037_STAGING_AUTO_ROLLBACK_VERIFY=PASS',
    'create_database_backup',
    'M037_STAGING_APPLY=PASS',
    'M037_STAGING_VERIFY=PASS',
    'M037_STAGING_RUNTIME_FAIL=',
    'ANONYMOUS_ROUTE_CONTENT',
    '--max-filesize "$MAX_ROUTE_BODY_BYTES"',
    'ROUTE_BODY_TOO_LARGE',
    'curl_rc -eq 63',
    'name="username"',
    'name="password"',
) as $needle) m037Assert(strpos($helper, $needle) !== false, 'helper contract missing '.$needle);
foreach (array(
    'com.docker.compose.project',
    'service_owner=$(docker exec "$TARGET_CONTAINER"',
    "target_owner\" == '0:0' || \"\$target_owner\" == \"\$service_owner",
    'STAGING_INBOX_METADATA_INVALID',
    'STAGING_TARGET_DISK_LOW',
    'STAGING_INBOX_DISK_LOW',
    'verify_code_backup_restored',
    'verify_schema_prestate',
    'ROLLBACK_FAILED_REAPPLY_VERIFY_FAILED',
    'test_customer_portal_scope_integration.php',
    'test_unified_admin_shell.php',
    'cp -a /var/www/html/custom "$CANDIDATE_REMOTE/custom"',
    'chmod 0755 "$CANDIDATE_REMOTE" "$CANDIDATE_REMOTE/deploy" "$CANDIDATE_REMOTE/deploy/tests"',
    'chmod 0644 "$CANDIDATE_REMOTE/deploy/tests/test_m037_authenticated_session.php"',
    'AUTH_CONTEXT_DIR="/tmp/m037-auth-context-$$"',
    'mkdir -m 0700 "$AUTH_CONTEXT_DIR"',
    'chown www-data:www-data "$AUTH_CONTEXT_DIR"',
    'new_auth_context_token',
    'od -An -N32 -tx1 /dev/urandom',
    '--issue "$role" "$route" "$token"',
    '--render "$role" "$route" "$token"',
    'M037_AUTH_CONTEXT_ISSUED=PASS',
    'AUTH_CONTEXT_NOT_CONSUMED',
    "output_class='CHILD_SCRIPT_UNREADABLE'",
    "output_class='PERMISSION_DENIED'",
    "output_class='PHP_FATAL_ERROR'",
) as $needle) m037Assert(strpos($helper, $needle) !== false, 'staging guard missing '.$needle);
m037Assert(strpos($helper, "/^\\\\//") === false && strpos($helper, "\\\\.env") === false, 'archive parser contains non-portable double escaping');
m037Assert(strpos($helper, 'M037_AUTH_COOKIE') === false && strpos($helper, '--cookie') === false, 'authenticated cookie leaves the in-process route test');
m037Assert(strpos($helper, 'echo "$output"') === false, 'authenticated diagnostic can print raw captured output');
foreach (array(
    'const M037_AUTH_POSITIVE_ROUTE_COUNT = 14;',
    "'external_denied' => array(",
    "'admin_dashboard' => '/custom/chinaplanetcustomercenter/admin_dashboard.php'",
    "u.entity IN (\".getEntity('user').\")",
    'COALESCE(u.fk_soc,0)=0',
    'COALESCE(u.fk_soc,0)>0',
    "\$mode === '--issue'",
    "\$mode === '--render'",
    "getenv('M037_AUTH_CONTEXT_DIR')",
    "preg_match('/^[a-f0-9]{64}$/D'",
    "fopen(\$contextPath, 'x+b')",
    "@unlink(\$contextPath)",
    'M037_AUTH_CONTEXT_ISSUED=PASS',
    'CHILD_CONTEXT_CONSUME_FAILED',
    "'UNEXPECTED_REDIRECT'",
    "'EMPTY_RESPONSE'",
    "'ROUTE_ANCHOR_MISSING'",
    "'PARENT_BOOTSTRAP_FATAL_ERROR'",
    "'PARENT_BOOTSTRAP_DOLIBARR_ERROR'",
    "'PARENT_BOOTSTRAP_EARLY_EXIT'",
    "'PARENT_BOOTSTRAP_OUTPUT'",
    'REASON=ROLE_QUERY_FAILED',
    '" CANDIDATES=".$candidateCount',
    '" OUTPUT_SHA256=".hash(\'sha256\', $body)',
    'M037_AUTH_ROUTE_EXTERNAL_ADMIN_DASHBOARD=DENIED',
) as $needle) m037Assert(strpos($authenticatedRouteTest, $needle) !== false, 'authenticated route contract missing '.$needle);
m037Assert(strpos($authenticatedRouteTest, 'M037_AUTH_CHILD_LOGIN') === false && strpos($authenticatedRouteTest, 'M037_AUTH_CHILD_TOKEN') === false, 'authenticated child identity leaks through argv or environment');
m037Assert(strpos($authenticatedRouteTest, 'proc_open') === false && strpos($authenticatedRouteTest, 'proc_close') === false && strpos($authenticatedRouteTest, 'proc_terminate') === false, 'authenticated route test still depends on proc functions');
m037Assert(strpos($authenticatedRouteTest, 'php://stdin') === false, 'authenticated context still depends on an in-process child stdin pipe');
m037Assert(strpos($authenticatedRouteTest, '" WHERE u.entity=".(int) $conf->entity') === false, 'authenticated user lookup bypasses Dolibarr user entity sharing');
m037Assert(strpos($authenticatedRouteTest, 'fwrite(STDERR, $stdout)') === false && strpos($authenticatedRouteTest, 'fwrite(STDERR, $stderr)') === false, 'authenticated route test can print raw child output');

foreach (array('vision_erp','vision_db','vision-os_','erp.visiontrading.biz','production-m') as $forbidden) {
    m037Assert(stripos($helper, $forbidden) === false, 'production identifier leaked into staging helper');
}
m037Assert(strpos($helper, "grep -E '^STATE_(RELEASE|STATUS|RUNTIME_COMMIT|ARTIFACT_SHA|CODE_BACKUP|CODE_BACKUP_SHA|ABSENT_LIST|ABSENT_LIST_SHA|DB_BACKUP|DB_BACKUP_SHA|SCHEMA_PRESTATE_SHA|DEPLOYED_AT)='") !== false, 'status output is not a strict non-secret allowlist');

$allowedCommands = array('compare','preflight','apply','verify','rollback','status');
foreach ($allowedCommands as $command) {
    $line = 'codex-deploy ALL=(root) NOPASSWD: /usr/local/sbin/chinaplanetos-backup-erp-m037-full-release-deploy '.$command;
    m037Assert(substr_count($sudoers, $line) === 1, 'sudoers missing exact '.$command.' command');
}
m037Assert(count(array_filter(explode("\n", trim($sudoers)))) === count($allowedCommands), 'sudoers contains an unexpected command');
m037Assert(strpos($installer, "readonly HELPER_SHA='83119faf9ea6b72ca5420ee859ae5b8d66f59b7d2674050146e1ae840cc4e85f'") !== false, 'installer helper checksum is not pinned');
m037Assert(strpos($installer, "readonly PREVIOUS_HELPER_SHA='bb9bf731da6f2d7d109ccf608d6fa0b0314f5654e9f668df015b35f2750d624a'") !== false, 'installer previous helper checksum is not pinned');
m037Assert(strpos($installer, "readonly SUDOERS_SHA='815e0040fce5ebe2fa77f840a3811e3733db995c3bf4360c39fa105c4d4deab1'") !== false, 'installer sudoers checksum is not pinned');
m037Assert(hash_file('sha256', $root.'/deploy/tools/chinaplanetos_backup_erp_m037_full_release.sh') === '83119faf9ea6b72ca5420ee859ae5b8d66f59b7d2674050146e1ae840cc4e85f', 'pinned helper checksum does not match helper bytes');
m037Assert(hash_file('sha256', $root.'/deploy/config/codex-deploy-backup-erp-m037-full-release.sudoers') === '815e0040fce5ebe2fa77f840a3811e3733db995c3bf4360c39fa105c4d4deab1', 'pinned sudoers checksum does not match sudoers bytes');
m037Assert(strpos($installer, 'private_root=$(mktemp -d /root/m037-helper-install.') !== false, 'installer does not use a root-owned immutable input copy');
m037Assert(strpos($installer, 'install -o root -g root -m 0600 "$SOURCE_HELPER" "$private_helper"') !== false, 'installer helper input is not copied once before validation');
m037Assert(strpos($installer, "PRODUCTION_ACCESSED=NO") !== false, 'installer production boundary is not explicit');

foreach (array(
    "readonly RUNTIME_COMMIT='806df74a0f90ecf8d10c4627707c36d313001a82'",
    "readonly ARTIFACT_SHA='c0e5741f45018302983d6449a2e2392571162fbcd636e1484148f4dc932906e5'",
    'M037_PRODUCTION_RUNTIME_FAIL=',
    'M037_PRODUCTION_AUTO_FULL_BACKUP_ROLLBACK=PASS',
) as $needle) m037Assert(strpos($productionHelper, $needle) !== false, 'production helper contract missing '.$needle);
m037Assert(hash_file('sha256', $root.'/deploy/tools/chinaplanetos_production_m037_full_release.sh') === '13f7e2462d68449a53f593f841f8afd4141432450907e984ab7475fa0161d65f', 'pinned production helper checksum does not match helper bytes');
m037Assert(strpos($productionInstaller, "readonly HELPER_SHA='13f7e2462d68449a53f593f841f8afd4141432450907e984ab7475fa0161d65f'") !== false, 'production installer helper checksum is not pinned');
m037Assert(strpos($productionInstaller, "readonly PREVIOUS_HELPER_SHA='0bdec24f6e48feb86adbf4d12fe570209ce62fd02445a085b9d69be1e7ed6539'") !== false, 'production installer previous helper checksum is not pinned');
m037Assert(strpos($productionInstaller, '[[ "$existing_helper_sha" == "$HELPER_SHA" || "$existing_helper_sha" == "$PREVIOUS_HELPER_SHA" ]]') !== false, 'production installer does not constrain helper migration');
m037Assert(strpos($productionInstaller, 'DEPLOY_EXECUTED=NO PRODUCTION_ACCESSED=NO') !== false, 'production installer boundary is not explicit');

echo "M037_RELEASE_TEST=PASS RUNTIME_FILES=52 SUPPORT_FILES=17 COMMANDS=6 PRODUCTION=FORBIDDEN".PHP_EOL;
