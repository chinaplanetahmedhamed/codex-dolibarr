<?php
/** Focused standalone tests: php tests/test-packer.php */

require_once dirname( __DIR__ ) . '/includes/class-b2bclp-packer.php';

$tests = 0;

function b2bclp_assert( $condition, $message ) {
	global $tests;
	$tests++;
	if ( ! $condition ) {
		throw new RuntimeException( 'Assertion failed: ' . $message );
	}
}

function b2bclp_container( array $overrides = array() ) {
	return array_merge(
		array(
			'id' => 'test', 'length' => 100, 'width' => 100, 'height' => 100,
			'max_payload' => 1000, 'volume_margin_percent' => 0, 'weight_margin_percent' => 0,
		),
		$overrides
	);
}

function b2bclp_line( array $overrides = array() ) {
	return array_merge(
		array(
			'line_key' => 'A', 'cartons' => 1, 'units_per_carton' => 12,
			'length' => 50, 'width' => 50, 'height' => 50,
			'net_weight' => 8, 'gross_weight' => 10,
			'orientations' => array( 'LWH' ), 'stackable' => true, 'max_stack' => 2,
		),
		$overrides
	);
}

// Exact grid packing, totals, full support stacking, and estimate flag.
$result = B2BCLP_Packer::pack( array( b2bclp_line( array( 'cartons' => 8 ) ) ), b2bclp_container() );
b2bclp_assert( $result['success'], 'eight 50cm cubes fit in a 100cm cube' );
b2bclp_assert( 8 === count( $result['placements'] ), 'all eight placements returned' );
b2bclp_assert( 96 === $result['totals']['units'], 'units total uses units per carton' );
b2bclp_assert( 80.0 === $result['totals']['gross_weight'], 'gross total calculated' );
b2bclp_assert( 64.0 === $result['totals']['net_weight'], 'net total calculated' );
b2bclp_assert( 1.0 === $result['totals']['cbm'], 'CBM calculated from centimetres' );
b2bclp_assert( true === $result['estimate'], 'plan is explicitly an estimate' );
b2bclp_assert( isset( $result['packing_input']['container']['maxPayload'] ), 'worker input is included for off-main-thread agreement checks' );

// Allowed orientation makes an otherwise dimensionally impossible carton fit.
$no_rotation = B2BCLP_Packer::pack(
	array( b2bclp_line( array( 'length' => 40, 'width' => 30, 'height' => 60, 'orientations' => array( 'LWH' ) ) ) ),
	b2bclp_container( array( 'length' => 60, 'width' => 40, 'height' => 30 ) )
);
$rotation = B2BCLP_Packer::pack(
	array( b2bclp_line( array( 'length' => 40, 'width' => 30, 'height' => 60, 'orientations' => array( 'HLW' ) ) ) ),
	b2bclp_container( array( 'length' => 60, 'width' => 40, 'height' => 30 ) )
);
b2bclp_assert( ! $no_rotation['success'] && 'cannot_place' === $no_rotation['unpacked'][0]['reason'], 'disallowed rotation does not fit' );
b2bclp_assert( $rotation['success'] && 'HLW' === $rotation['placements'][0]['orientation'], 'allowed rotation fits' );

// Legacy stack flags are intentionally ignored; every carton can be stacked.
$unlimited_stack = B2BCLP_Packer::pack(
	array( b2bclp_line( array( 'cartons' => 3, 'stackable' => false, 'max_stack' => 1 ) ) ),
	b2bclp_container( array( 'length' => 50, 'width' => 50, 'height' => 150 ) )
);
b2bclp_assert( $unlimited_stack['success'], 'legacy stack restrictions do not prevent loading' );
b2bclp_assert( 3 === $unlimited_stack['totals']['placed_cartons'], 'all tiers are available up to container height' );

// Gross, not net, controls payload; weight margin reduces usable payload.
$weight = B2BCLP_Packer::pack(
	array( b2bclp_line( array( 'cartons' => 2, 'net_weight' => 40, 'gross_weight' => 50, 'length' => 20, 'width' => 20, 'height' => 20 ) ) ),
	b2bclp_container( array( 'max_payload' => 100, 'weight_margin_percent' => 10 ) )
);
b2bclp_assert( ! $weight['success'] && 'payload_limit' === $weight['unpacked'][0]['reason'], 'gross weight and safety margin control payload' );
b2bclp_assert( 'payload' === $weight['reason'], 'public reason is stable for cart validation' );
b2bclp_assert( 90.0 === $weight['limits']['usable_payload'], 'usable payload applies margin' );

// Volume margin is independent of physical dimensional fit.
$volume = B2BCLP_Packer::pack(
	array( b2bclp_line( array( 'cartons' => 8 ) ) ),
	b2bclp_container( array( 'volume_margin_percent' => 10 ) )
);
b2bclp_assert( ! $volume['success'] && 'volume_limit' === $volume['unpacked'][0]['reason'], 'volume safety margin enforced' );
b2bclp_assert( 0.9 === $volume['limits']['usable_cbm'], 'usable CBM applies margin' );

// Operational CBM may be lower than geometric internal volume.
$operational_volume = B2BCLP_Packer::pack(
	array( b2bclp_line( array( 'cartons' => 7 ) ) ),
	b2bclp_container( array( 'capacity_cbm' => 0.75 ) )
);
b2bclp_assert( ! $operational_volume['success'] && 'volume_limit' === $operational_volume['unpacked'][0]['reason'], 'configured operational CBM controls usable capacity' );
b2bclp_assert( 0.75 === $operational_volume['limits']['usable_cbm'], 'operational CBM is reported as usable capacity' );

// A load can be below CBM and payload limits yet be dimensionally unpackable.
$dimensional = B2BCLP_Packer::pack(
	array( b2bclp_line( array( 'length' => 101, 'width' => 1, 'height' => 1, 'gross_weight' => 1, 'net_weight' => 1 ) ) ),
	b2bclp_container()
);
b2bclp_assert( ! $dimensional['success'], 'dimensionally impossible load rejected despite tiny volume' );
b2bclp_assert( 'cannot_place' === $dimensional['unpacked'][0]['reason'], 'dimensional failure has explicit reason' );

// Mixed lines prioritize heavy cartons and remain byte-for-byte deterministic.
$mixed_lines = array(
	b2bclp_line( array( 'line_key' => 'light', 'cartons' => 2, 'length' => 50, 'width' => 50, 'height' => 50, 'gross_weight' => 5, 'net_weight' => 4 ) ),
	b2bclp_line( array( 'line_key' => 'heavy', 'cartons' => 1, 'length' => 50, 'width' => 50, 'height' => 50, 'gross_weight' => 20, 'net_weight' => 18 ) ),
);
$mixed_a = B2BCLP_Packer::pack( $mixed_lines, b2bclp_container() );
$mixed_b = B2BCLP_Packer::pack( $mixed_lines, b2bclp_container() );
b2bclp_assert( 'heavy' === $mixed_a['placements'][0]['line_key'], 'heavy carton placed first' );
b2bclp_assert( serialize( $mixed_a ) === serialize( $mixed_b ), 'identical input produces identical output' );

// Automatic recommendation sorts by capacity and skips disabled containers.
$recommended = B2BCLP_Packer::recommend(
	array( b2bclp_line( array( 'cartons' => 2 ) ) ),
	array(
		'large' => b2bclp_container( array( 'id' => 'large', 'label' => 'Large', 'length' => 150 ) ),
		'tiny-disabled' => b2bclp_container( array( 'id' => 'tiny-disabled', 'enabled' => false, 'length' => 40 ) ),
		'small' => b2bclp_container( array( 'id' => 'small', 'label' => 'Small', 'length' => 50, 'width' => 50, 'height' => 50 ) ),
	),
	'auto'
);
b2bclp_assert( $recommended['ok'], 'automatic recommendation finds a fitting enabled container' );
b2bclp_assert( 'large' === $recommended['recommended_container'], 'smallest fitting container selected after smaller failure' );
b2bclp_assert( 'Large' === $recommended['container']['label'], 'normalized selected container retains label' );
b2bclp_assert( 2 === count( $recommended['considered_containers'] ), 'disabled container is not considered' );

// Enabled 20GP -> 40HQ recommendation progression; 40GP is not offered.
$iso_containers = array(
	'20gp' => array( 'id' => '20gp', 'length' => 589.8, 'width' => 235.2, 'height' => 239.3, 'capacity_cbm' => 28, 'payload' => 28180 ),
	'40hq' => array( 'id' => '40hq', 'length' => 1203.2, 'width' => 235.2, 'height' => 269.8, 'capacity_cbm' => 68, 'payload' => 28600 ),
);
$auto_20 = B2BCLP_Packer::recommend( array( b2bclp_line( array( 'length' => 100, 'width' => 100, 'height' => 100 ) ) ), $iso_containers );
$auto_40hq = B2BCLP_Packer::recommend( array( b2bclp_line( array( 'length' => 600, 'width' => 100, 'height' => 100, 'orientations' => array( 'LWH' ) ) ) ), $iso_containers );
$auto_hq = B2BCLP_Packer::recommend( array( b2bclp_line( array( 'length' => 600, 'width' => 100, 'height' => 250, 'orientations' => array( 'LWH' ) ) ) ), $iso_containers );
b2bclp_assert( '20gp' === $auto_20['recommended_container'], 'small load recommends 20GP' );
b2bclp_assert( '40hq' === $auto_40hq['recommended_container'], 'long load progresses directly to enabled 40HQ' );
b2bclp_assert( '40hq' === $auto_hq['recommended_container'], 'tall long load progresses to 40HQ' );

// Large repeated-carton loads must not repeat identical failed searches. This
// reproduces the live 1,000-carton container-switch timeout fixed in 1.0.1.
$large_started = microtime( true );
$large_auto = B2BCLP_Packer::recommend(
	array( b2bclp_line( array( 'cartons' => 1000, 'length' => 40, 'width' => 30, 'height' => 20 ) ) ),
	$iso_containers
);
$large_elapsed = microtime( true ) - $large_started;
b2bclp_assert( $large_auto['ok'] && 1000 === count( $large_auto['placements'] ), '1,000-carton recommendation completes with every carton placed' );
b2bclp_assert( $large_elapsed < 15, '1,000-carton recommendation stays below the web request timeout budget' );

$explicit = B2BCLP_Packer::recommend(
	array( b2bclp_line() ),
	array( 'small' => b2bclp_container( array( 'id' => 'small', 'label' => 'Small' ) ) ),
	'small'
);
b2bclp_assert( ! $explicit['automatic'] && 'small' === $explicit['container']['id'], 'manual container selection is honored' );

// Missing weights are valid: dimensions still drive 3D placement and payload totals use zero known weight.
$missing_weight = B2BCLP_Packer::pack(
	array( b2bclp_line( array( 'net_weight' => 0, 'gross_weight' => 0 ) ) ),
	b2bclp_container()
);
b2bclp_assert( $missing_weight['ok'], 'dimensioned carton with unknown weight remains loadable' );
b2bclp_assert( 0.0 === $missing_weight['totals']['gross_weight'], 'unknown weight does not invent payload' );

// Direct CBM without dimensions reserves operational volume and uses an explicit aggregate visual.
$cbm_only = B2BCLP_Packer::recommend_flexible(
	array( array( 'line_key' => 'cbm', 'quantity' => 2, 'units_per_carton' => 5, 'cbm_per_carton' => 0.2, 'gross_weight' => 0 ) ),
	array( 'small' => b2bclp_container( array( 'id' => 'small', 'capacity_cbm' => 0.3 ) ), 'large' => b2bclp_container( array( 'id' => 'large', 'capacity_cbm' => 1.0, 'length' => 150 ) ) )
);
b2bclp_assert( $cbm_only['ok'] && 'large' === $cbm_only['recommended_container'], 'CBM-only cargo advances to the smallest suitable container' );
b2bclp_assert( 0.4 === $cbm_only['totals']['cbm'], 'direct carton CBM is included in totals' );
b2bclp_assert( 'aggregate_volume' === $cbm_only['visual_mode'] && ! empty( $cbm_only['placements'][0]['visual_only'] ), 'CBM-only plan is visibly marked as aggregate' );

$hybrid = B2BCLP_Packer::pack_flexible(
	array( b2bclp_line(), array( 'line_key' => 'cbm', 'quantity' => 1, 'units_per_carton' => 1, 'cbm_per_carton' => 0.1, 'gross_weight' => 0 ) ),
	b2bclp_container()
);
b2bclp_assert( $hybrid['ok'] && 'hybrid_volume' === $hybrid['visual_mode'], 'mixed dimensional and CBM-only cargo remains valid with hybrid visual labeling' );
b2bclp_assert( 0.225 === $hybrid['totals']['cbm'], 'hybrid plan combines geometric and direct CBM' );

// Invalid quantities and invalid weights fail closed.
$invalid_quantity = false;
try {
	B2BCLP_Packer::pack( array( b2bclp_line( array( 'cartons' => 1.5 ) ) ), b2bclp_container() );
} catch ( InvalidArgumentException $error ) {
	$invalid_quantity = true;
}
b2bclp_assert( $invalid_quantity, 'fractional carton quantities rejected' );

$invalid_weight = false;
try {
	B2BCLP_Packer::pack( array( b2bclp_line( array( 'net_weight' => 11, 'gross_weight' => 10 ) ) ), b2bclp_container() );
} catch ( InvalidArgumentException $error ) {
	$invalid_weight = true;
}
b2bclp_assert( $invalid_weight, 'gross weight below net rejected' );

fwrite( STDOUT, "OK ({$tests} assertions)\n" );
