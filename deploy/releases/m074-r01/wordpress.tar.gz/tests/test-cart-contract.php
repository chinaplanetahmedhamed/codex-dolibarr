<?php
/** Standalone contract tests for cart validation and immutable snapshots. */

define( 'ABSPATH', __DIR__ . '/' );
$GLOBALS['b2bclp_notices'] = array();
$GLOBALS['b2bclp_meta'] = array(
	'_b2bclp_units_per_carton' => '12', '_b2bclp_carton_length' => '40', '_b2bclp_carton_width' => '30',
	'_b2bclp_carton_height' => '20', '_b2bclp_carton_net_weight' => '8', '_b2bclp_carton_gross_weight' => '9',
	'_b2bclp_orientations' => array( 'lwh' ), '_b2bclp_stackable' => 'no', '_b2bclp_max_stack' => '1', '_b2bclp_packing_approved' => 'yes',
);

function __( $s ) { return $s; }
function esc_html__( $s ) { return $s; }
function wc_add_notice( $message, $type ) { $GLOBALS['b2bclp_notices'][] = array( $type, $message ); }
function get_post_meta( $id, $key, $single ) { return $GLOBALS['b2bclp_meta'][ $key ] ?? ''; }
function wp_generate_uuid4() { return '00000000-0000-4000-8000-000000000001'; }
function wc_get_product( $id ) { return new B2BCLP_Fake_Product(); }
function is_admin() { return false; }
function wp_doing_ajax() { return false; }

final class B2BCLP_Fake_Product {
	public function get_sku() { return 'SKU-1'; }
	public function get_name() { return 'Test carton'; }
	public function get_price() { return '5'; }
}

final class B2BCLP_Mutable_Product {
	public $price = 5.0;
	public function get_price() { return $this->price; }
	public function set_price( $price ) { $this->price = (float) $price; }
}

final class B2BCLP_Fake_Cart {
	public $cart_contents;
	public function __construct( $contents ) { $this->cart_contents = $contents; }
	public function get_cart() { return $this->cart_contents; }
}

require_once dirname( __DIR__ ) . '/includes/class-b2bclp-cart.php';

$assertions = 0;
function b2bclp_assert( $condition, $message ) {
	global $assertions;
	$assertions++;
	if ( ! $condition ) { fwrite( STDERR, "FAIL: {$message}\n" ); exit( 1 ); }
}

b2bclp_assert( B2BCLP_Cart::validate_add( true, 1, 2, 0 ), 'valid whole-carton quantity accepted' );
b2bclp_assert( ! B2BCLP_Cart::validate_add( true, 1, 1.5, 0 ), 'fractional carton rejected' );
b2bclp_assert( ! B2BCLP_Cart::validate_add( true, 1, 0, 0 ), 'zero cartons rejected' );

$cart_data = B2BCLP_Cart::add_snapshot( array(), 1, 0, 2 );
$snapshot = $cart_data[ B2BCLP_Cart::LINE_SNAPSHOT ];
b2bclp_assert( 12 === $snapshot['units_per_carton'], 'unit count captured' );
b2bclp_assert( true === $snapshot['stackable'] && 0 === $snapshot['max_stack'], 'all cartons snapshot as stackable without a tier limit' );
b2bclp_assert( 9.0 === $snapshot['gross_weight'], 'gross weight captured for payload validation' );
b2bclp_assert( 5.0 === $snapshot['unit_price'] && 60.0 === $snapshot['carton_price'], 'per-piece price is snapshotted and multiplied by units per carton' );
b2bclp_assert( 30.0 === B2BCLP_Cart::carton_price( 2.5, 12 ), 'carton price helper multiplies piece price by carton units' );
$priced_product = new B2BCLP_Mutable_Product();
$fake_cart = new B2BCLP_Fake_Cart( array( 'line-1' => array( 'data' => $priced_product, 'quantity' => 3, '_b2bclp_unit_price' => 5.0, B2BCLP_Cart::LINE_SNAPSHOT => $snapshot ) ) );
B2BCLP_Cart::apply_carton_prices( $fake_cart );
b2bclp_assert( 60.0 === $priced_product->get_price(), 'WooCommerce line price is converted from piece price to one-carton price' );
B2BCLP_Cart::apply_carton_prices( $fake_cart );
b2bclp_assert( 60.0 === $priced_product->get_price(), 'repeated totals calculations do not multiply the carton price twice' );
$request_totals = B2BCLP_Cart::request_totals_from_lines( array(
	array( 'quantity' => 4, B2BCLP_Cart::LINE_SNAPSHOT => array( 'units_per_carton' => 12 ) ),
	array( 'quantity' => 3, B2BCLP_Cart::LINE_SNAPSHOT => array( 'units_per_carton' => 20, 'packing_complete' => false ) ),
) );
b2bclp_assert( 7 === $request_totals['cartons'] && 108 === $request_totals['units'], 'request totals include loadable and packing-incomplete cart lines' );
b2bclp_assert( true === $request_totals['units_complete'], 'piece total is complete when every line has units per carton' );
$unknown_units_totals = B2BCLP_Cart::request_totals_from_lines( array( array( 'quantity' => 2, B2BCLP_Cart::LINE_SNAPSHOT => array( 'units_per_carton' => 0 ) ) ) );
b2bclp_assert( false === $unknown_units_totals['units_complete'] && 2 === $unknown_units_totals['missing_units_cartons'], 'unknown piece counts are identified without removing cartons' );
$estimated_dimensions = B2BCLP_Cart::estimated_dimensions_from_cbm( 0.096 );
$estimated_cbm = $estimated_dimensions['length'] * $estimated_dimensions['width'] * $estimated_dimensions['height'] / 1000000;
b2bclp_assert( abs( 0.096 - $estimated_cbm ) < 0.000001, 'CBM-only visual dimensions preserve the carton volume' );
b2bclp_assert( abs( 1.6 - $estimated_dimensions['length'] / $estimated_dimensions['height'] ) < 0.000001 && abs( 1.2 - $estimated_dimensions['width'] / $estimated_dimensions['height'] ) < 0.000001, 'CBM-only cartons use the stable 1.6 by 1.2 by 1 visual ratio' );
b2bclp_assert( isset( $snapshot['external_line_id'], $snapshot['captured_at_gmt'] ), 'stable ID and capture time recorded' );

$GLOBALS['b2bclp_meta']['_b2bclp_units_per_carton'] = '99';
$GLOBALS['b2bclp_meta']['_b2bclp_carton_gross_weight'] = '999';
b2bclp_assert( 12 === $snapshot['units_per_carton'] && 9.0 === $snapshot['gross_weight'] && 60.0 === $snapshot['carton_price'], 'snapshot remains immutable after product edits' );

$GLOBALS['b2bclp_meta']['_b2bclp_packing_approved'] = '';
$GLOBALS['b2bclp_meta']['_b2bclp_orientations'] = array();
$automatic_data = B2BCLP_Cart::add_snapshot( array(), 1, 0, 1 );
b2bclp_assert( true === $automatic_data[ B2BCLP_Cart::LINE_SNAPSHOT ]['packing_complete'] && true === $automatic_data[ B2BCLP_Cart::LINE_SNAPSHOT ]['approved'], 'old approval state no longer blocks otherwise complete packing data' );
b2bclp_assert( 6 === count( $automatic_data[ B2BCLP_Cart::LINE_SNAPSHOT ]['orientations'] ), 'missing legacy orientations default to all six rotations' );

$GLOBALS['b2bclp_meta']['_b2bclp_packing_approved'] = 'yes';
$GLOBALS['b2bclp_meta']['_b2bclp_units_per_carton'] = '10';
$GLOBALS['b2bclp_meta']['_b2bclp_carton_length'] = '';
$GLOBALS['b2bclp_meta']['_b2bclp_carton_width'] = '';
$GLOBALS['b2bclp_meta']['_b2bclp_carton_height'] = '';
$GLOBALS['b2bclp_meta']['_b2bclp_carton_cbm'] = '0.045';
$GLOBALS['b2bclp_meta']['_b2bclp_carton_net_weight'] = '';
$GLOBALS['b2bclp_meta']['_b2bclp_carton_gross_weight'] = '';
$cbm_data = B2BCLP_Cart::add_snapshot( array(), 1, 0, 3 );
$cbm_snapshot = $cbm_data[ B2BCLP_Cart::LINE_SNAPSHOT ];
b2bclp_assert( true === $cbm_snapshot['packing_complete'], 'direct CBM makes an approved profile calculation-ready without dimensions' );
b2bclp_assert( 0.045 === $cbm_snapshot['cbm_per_carton'] && false === $cbm_snapshot['has_dimensions'], 'direct CBM and volume-only status are snapshotted' );
b2bclp_assert( false === $cbm_snapshot['weight_known'] && 0.0 === $cbm_snapshot['gross_weight'], 'missing weight is snapshotted without blocking' );

echo "OK ({$assertions} assertions)\n";
