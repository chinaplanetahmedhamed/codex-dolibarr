'use strict';

const fs = require('fs');
const vm = require('vm');
const source = fs.readFileSync(require('path').join(__dirname, '../assets/js/packer-worker.js'), 'utf8');
let listener;
let result;
const sandbox = { self: { addEventListener: (_name, fn) => { listener = fn; }, postMessage: message => { result = message; } } };
vm.runInNewContext(source, sandbox);

function pack(payload) {
    result = null;
    listener({ data: { type: 'pack', requestId: 1, payload } });
    if (!result || result.type !== 'result') { throw new Error('Worker did not return a result'); }
    return JSON.parse(JSON.stringify(result.result));
}

const base = {
    container: { id: 'test', length: 100, width: 100, height: 100, maxPayload: 1000, volumeMargin: 0, weightMargin: 0 },
    items: [{ id: 'a', name: 'A', quantity: 2, length: 50, width: 50, height: 50, grossWeight: 10, allowedOrientations: ['lwh'], stackable: true, maxStack: 2 }]
};
const first = pack(base);
const second = pack(base);
if (!first.valid || first.placements.length !== 2) { throw new Error('Expected two cartons to pack'); }
if (JSON.stringify(first) !== JSON.stringify(second)) { throw new Error('Worker output is not deterministic'); }

const dimensional = pack({ container: base.container, items: [{ id: 'too-long', quantity: 1, length: 101, width: 1, height: 1, grossWeight: 1, allowedOrientations: ['lwh'] }] });
if (dimensional.valid || dimensional.unpacked.length !== 1) { throw new Error('Dimensionally unpackable carton was accepted'); }

const overweight = pack({ container: { ...base.container, maxPayload: 5 }, items: base.items });
if (overweight.valid || !overweight.payloadExceeded) { throw new Error('Gross payload overflow was accepted'); }

const unlimitedStack = pack({
    container: { ...base.container, length: 50, width: 50, height: 100 },
    items: [{ ...base.items[0], quantity: 2, stackable: false, maxStack: 1 }]
});
if (!unlimitedStack.valid || unlimitedStack.placements.length !== 2) { throw new Error('Legacy stack limit was still enforced'); }

const operationalVolume = pack({
    container: { ...base.container, capacityCbm: 0.75 },
    items: [{ ...base.items[0], quantity: 7 }]
});
if (operationalVolume.valid || !operationalVolume.volumeExceeded || operationalVolume.totals.usableVolume !== 750000) {
    throw new Error('Operational CBM capacity was not enforced');
}

console.log('OK (worker deterministic, dimensional, payload, unlimited-stack and operational-CBM cases)');
