<?php
/** Dependency-free signature contract tests for the headless B2B REST API. */

define( 'ABSPATH', __DIR__ . '/' );
require_once dirname( __DIR__ ) . '/includes/class-b2bclp-rest.php';

$assertions = 0;
function b2bclp_rest_assert( $condition, $message ) {
	global $assertions;
	$assertions++;
	if ( ! $condition ) { fwrite( STDERR, "FAIL: {$message}\n" ); exit( 1 ); }
}

$body = '{"lines":[{"productId":10,"cartons":2}]}';
$secret = '12345678901234567890123456789012';
$now = 1775325600;
$signature = 'sha256=' . hash_hmac( 'sha256', $now . '.' . $body, $secret );

b2bclp_rest_assert( B2BCLP_REST::verify_signature_value( $body, (string) $now, $signature, $secret, $now ), 'valid request signature accepted' );
b2bclp_rest_assert( ! B2BCLP_REST::verify_signature_value( $body . 'x', (string) $now, $signature, $secret, $now ), 'tampered body rejected' );
b2bclp_rest_assert( ! B2BCLP_REST::verify_signature_value( $body, (string) ( $now - 301 ), $signature, $secret, $now ), 'stale timestamp rejected' );
b2bclp_rest_assert( ! B2BCLP_REST::verify_signature_value( $body, 'invalid', $signature, $secret, $now ), 'invalid timestamp rejected' );
b2bclp_rest_assert( '_b2bclp_packing_snapshot' === B2BCLP_REST::LINE_SNAPSHOT, 'REST requests reuse the native line snapshot key' );
b2bclp_rest_assert( '_b2bclp_loading_plan' === B2BCLP_REST::ORDER_SNAPSHOT, 'REST requests reuse the native loading plan key' );

$rest_source = file_get_contents( dirname( __DIR__ ) . '/includes/class-b2bclp-rest.php' );
b2bclp_rest_assert( false === strpos( $rest_source, '$variation->is_purchasable()' ), 'quote-only variations are not filtered by WooCommerce price' );
b2bclp_rest_assert( false !== strpos( $rest_source, "'publish' === \$variation->get_status()" ), 'only published variations are exposed to the public catalogue' );
b2bclp_rest_assert( false !== strpos( $rest_source, '! $parent->is_visible()' ), 'signed plans cannot request products hidden from the public catalogue' );
b2bclp_rest_assert( false !== strpos( $rest_source, "'publish' !== \$product->get_status()" ), 'signed plans reject unpublished variations' );
b2bclp_rest_assert( false === strpos( $rest_source, "'/request'" ), 'React quotation flow has no duplicate WooCommerce order endpoint' );
b2bclp_rest_assert( false === strpos( $rest_source, 'wc_create_order(' ), 'headless REST layer never creates a WooCommerce order' );
b2bclp_rest_assert( false !== strpos( $rest_source, "'lineId' => \$line['line_id']" ), 'request-unique line identifiers are preserved' );
b2bclp_rest_assert( false !== strpos( $rest_source, "'calculationReady'" ), 'authoritative readiness is explicit' );
b2bclp_rest_assert( false !== strpos( $rest_source, "'missingFields'" ), 'missing packing fields are explicit' );
b2bclp_rest_assert( false !== strpos( $rest_source, 'woocommerce-Price-amount' ) && false !== strpos( $rest_source, 'get_current_user_id()' ), 'public price requires an anonymous rendered Woo/B2BKing amount entitlement' );
b2bclp_rest_assert( false === strpos( $rest_source, "'' !== trim( wp_strip_all_tags( (string) \$product->get_price_html() ) )" ), 'login-to-view text cannot be treated as public pricing' );

$profile_method = new ReflectionMethod( B2BCLP_REST::class, 'public_profile' );
$incomplete = $profile_method->invoke( null, array( 'complete' => false ) );
b2bclp_rest_assert( null === $incomplete['unitsPerCarton'] && null === $incomplete['cbmPerCarton'] && null === $incomplete['grossWeightKg'], 'unknown packing values remain null' );
b2bclp_rest_assert( false === $incomplete['calculationReady'], 'incomplete product remains excluded from calculation' );
b2bclp_rest_assert( array( 'unitsPerCarton', 'cbmPerCarton', 'grossWeightKg', 'packingComplete' ) === $incomplete['missingFields'], 'missing fields are exact and ordered' );
$fractional = $profile_method->invoke( null, array( 'units_per_carton' => 12.5, 'cbm_per_carton' => 0.08, 'carton_gross_weight' => 10, 'complete' => true ) );
b2bclp_rest_assert( null === $fractional['unitsPerCarton'] && false === $fractional['calculationReady'], 'fractional pieces per carton are rejected rather than truncated' );

$fixture = json_decode( file_get_contents( __DIR__ . '/cpo_catalog_order_v2.fixture.json' ), true );
$invalid_fixture = json_decode( file_get_contents( __DIR__ . '/cpo_catalog_order_v2.invalid.fixture.json' ), true );
b2bclp_rest_assert( is_array( $fixture ) && 'catalog_order' === $fixture['request_type'] && 2 === $fixture['schema_version'], 'shared v2 fixture has the frozen contract identity' );
$fixture_lines = $fixture['details']['lines'];
b2bclp_rest_assert( 2 === count( $fixture_lines ) && $fixture_lines[0]['productId'] === $fixture_lines[1]['productId'], 'duplicate product rows remain distinct in shared fixture' );
b2bclp_rest_assert( $fixture_lines[0]['lineId'] !== $fixture_lines[1]['lineId'], 'fixture line identifiers are request-unique' );
b2bclp_rest_assert( true === $fixture_lines[0]['calculationReady'] && false === $fixture_lines[1]['calculationReady'], 'fixture separates calculated and review-only rows' );
b2bclp_rest_assert( null === $fixture_lines[1]['unitsPerCarton'] && null === $fixture_lines[1]['cbmPerCarton'] && null === $fixture_lines[1]['grossWeightKg'], 'fixture never converts unknown packing to zero' );
b2bclp_rest_assert( $fixture_lines[1]['missingFields'] === $fixture['details']['packing_plan']['excludedItems'][0]['missingFields'], 'fixture exclusion explains exact missing fields' );
b2bclp_rest_assert( 'cpo.catalog-order.v2' === $invalid_fixture['contract'] && 3 === count( $invalid_fixture['cases'] ), 'shared invalid v2 fixture is present' );
b2bclp_rest_assert( 12.5 === $invalid_fixture['cases'][0]['unitsPerCarton'] && 'reject' === $invalid_fixture['cases'][0]['expected'], 'shared fractional packing case is frozen as reject' );

echo "OK ({$assertions} assertions)\n";
