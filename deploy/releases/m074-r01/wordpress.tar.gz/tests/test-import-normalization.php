<?php
/** Standalone normalization test for operational Chinese/English order sheets. */

define( 'ABSPATH', __DIR__ );
define( 'HOUR_IN_SECONDS', 3600 );
function __( $text ) { return $text; }
function sanitize_file_name( $value ) { return basename( $value ); }
function sanitize_text_field( $value ) { return trim( (string) $value ); }
function wp_generate_uuid4() { return 'test-import-id'; }
function wc_get_product_id_by_sku() { return 0; }

final class B2BCLP_Product_Fields {
	const ORIENTATIONS = array( 'lwh', 'lhw', 'wlh', 'whl', 'hlw', 'hwl' );
	public static function sanitize_profile( $raw ) {
		$profile = array(
			'units_per_carton' => (int) ( $raw['units_per_carton'] ?? 0 ),
			'carton_length' => (float) ( $raw['carton_length'] ?? 0 ),
			'carton_width' => (float) ( $raw['carton_width'] ?? 0 ),
			'carton_height' => (float) ( $raw['carton_height'] ?? 0 ),
			'carton_net_weight' => (float) ( $raw['carton_net_weight'] ?? 0 ),
			'carton_gross_weight' => (float) ( $raw['carton_gross_weight'] ?? 0 ),
			'allowed_orientations' => self::ORIENTATIONS,
		);
		$profile['complete'] = $profile['units_per_carton'] > 0 && $profile['carton_length'] > 0 && $profile['carton_width'] > 0 && $profile['carton_height'] > 0 && $profile['carton_gross_weight'] > 0;
		return $profile;
	}
}

final class B2BCLP_Settings {
	public static function containers() {
		return array(
			'20gp' => array( 'id' => '20gp', 'label' => '20GP', 'length' => 589.8, 'width' => 235.2, 'height' => 239.3, 'capacity_cbm' => 28, 'payload' => 28180, 'volume_margin' => 0, 'weight_margin' => 5 ),
			'40hq' => array( 'id' => '40hq', 'label' => '40HQ', 'length' => 1203.2, 'width' => 235.2, 'height' => 269.8, 'capacity_cbm' => 68, 'payload' => 28600, 'volume_margin' => 0, 'weight_margin' => 5 ),
		);
	}
}

require_once dirname( __DIR__ ) . '/includes/class-b2bclp-import.php';

$rows = array(
	array( '', '', '', '', '', '', '1USD=rmb', '', '', '', '', '', '', '', '' ),
	array( '箱号', '图片', 'pack', '', '', "品名\nProduct Name", 'PRICE RMB', 'QTY', 'TOTAL RMB', '件数', '单间数量PCS', 'CM', '', 'KG', '' ),
	array( '1--46', '', '', 'Clutch line', 'POP', '比亚乔 离合线', '5.8', '2300', '13340', '46', '50', '0.0507', '2.3322', '20', '920' ),
	array( '47', '', '', 'Missing data', 'NO', '缺少体积', '1', '10', '10', '1', '10', '', '', '', '' ),
	array( '', '', '', '', '', '33000定金', '', '', '223526', '47', '', '', '2.3322', '', '920' ),
);

$import = B2BCLP_Import::normalize_rows( $rows, 'messy.xlsx' );
$plan   = B2BCLP_Import::calculate_plan( $import['items'], 'auto' );
$checks = array(
	count( $import['items'] ) === 1,
	count( $import['errors'] ) === 1,
	$import['items'][0]['source'] === 'summary',
	$import['items'][0]['volume_only'] === true,
	abs( $import['items'][0]['cbm_per_carton'] - 0.0507 ) < 0.000001,
	$import['items'][0]['quantity'] === 46,
	$import['summary_totals']['cartons'] === 47,
	abs( $import['summary_totals']['cbm'] - 2.3322 ) < 0.000001,
	isset( $import['items'][0]['import_summary'] ),
	$plan['visual_mode'] === 'aggregate_volume',
	count( $plan['placements'] ) === 1,
	$plan['placements'][0]['visual_only'] === true,
	$plan['placements'][0]['length'] > 0,
);
foreach ( $checks as $index => $passed ) {
	if ( ! $passed ) {
		fwrite( STDERR, 'FAIL assertion ' . ( $index + 1 ) . "\n" );
		exit( 1 );
	}
}

$azmy_rows = array(
	array( 'Packing List' ),
	array(),
	array( 'Item Name', 'Code', 'QTY (Pcs)', 'Pcs/Box', 'Total N.W. (Kgs)', 'G.W. KG/Box', 'Total G.W Kgs', 'Boxes', 'Box Size (mm)', 'CBM/Box', 'Total CBM' ),
	array( 'stainless profile', '087', '9000', '20', '7920', '18.2', '8190', '450', '85*60*2820', '0.014382', '6.4719' ),
	array( '', '', '9000', '', '', '', '8190', '450', '', '', '6.4719' ),
);
$azmy = B2BCLP_Import::normalize_rows( $azmy_rows, 'azmy.xlsx' );
$more_checks = array(
	$azmy['header_row'] === 3,
	$azmy['confidence'] === 100,
	count( $azmy['items'] ) === 1,
	$azmy['items'][0]['quantity'] === 450,
	abs( $azmy['items'][0]['length'] - 8.5 ) < 0.0001,
	abs( $azmy['items'][0]['height'] - 282 ) < 0.0001,
	$azmy['summary_totals']['cartons'] === 450,
	abs( $azmy['summary_totals']['cbm'] - 6.4719 ) < 0.0001,
);
foreach ( $more_checks as $index => $passed ) {
	if ( ! $passed ) {
		fwrite( STDERR, 'FAIL AZMY assertion ' . ( $index + 1 ) . "\n" );
		exit( 1 );
	}
}
echo 'OK (' . ( count( $checks ) + count( $more_checks ) ) . " assertions)\n";
