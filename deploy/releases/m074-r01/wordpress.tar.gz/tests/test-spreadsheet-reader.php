<?php
/** Standalone CSV/XLSX reader smoke tests. */

require_once dirname( __DIR__ ) . '/includes/class-b2bclp-spreadsheet-reader.php';

$assertions = 0;
function b2bclp_reader_assert( $condition, $message ) {
	global $assertions;
	$assertions++;
	if ( ! $condition ) {
		fwrite( STDERR, "FAIL: {$message}\n" );
		exit( 1 );
	}
}

$csv = tempnam( sys_get_temp_dir(), 'b2bclp-csv-' );
file_put_contents( $csv, "SKU;Product Name;Cartons\nABC-1;Test product;12\n" );
$rows = B2BCLP_Spreadsheet_Reader::read( $csv, 'csv' );
$book = B2BCLP_Spreadsheet_Reader::read_workbook( $csv, 'csv' );
unlink( $csv );
b2bclp_reader_assert( 2 === count( $rows ), 'CSV row count' );
b2bclp_reader_assert( 'SKU' === $rows[0][0], 'CSV header' );
b2bclp_reader_assert( 'ABC-1' === $rows[1][0], 'CSV SKU' );
b2bclp_reader_assert( '12' === $rows[1][2], 'CSV numeric text' );
b2bclp_reader_assert( isset( $book['CSV'] ) && 2 === count( $book['CSV'] ), 'CSV workbook wrapper' );

$xlsx = dirname( __DIR__ ) . '/assets/templates/b2bclp-import-template.xlsx';
b2bclp_reader_assert( is_file( $xlsx ), 'Bundled XLSX template exists' );
$rows = B2BCLP_Spreadsheet_Reader::read( $xlsx, 'xlsx' );
b2bclp_reader_assert( count( $rows ) >= 2, 'XLSX row count' );
b2bclp_reader_assert( 10 === count( $rows[0] ), 'XLSX header count' );
b2bclp_reader_assert( 'TEMP-001' === $rows[1][0], 'XLSX shared or inline string' );
b2bclp_reader_assert( '100' === $rows[1][2], 'XLSX numeric cell' );
$book = B2BCLP_Spreadsheet_Reader::read_workbook( $xlsx, 'xlsx' );
b2bclp_reader_assert( count( $book ) >= 1, 'XLSX workbook exposes named sheets' );

echo "OK ({$assertions} assertions)\n";
