# Verification

These dependency-free checks run without a WordPress database:

```sh
php tests/test-packer.php
php tests/test-cart-contract.php
php tests/test-rest-contract.php
php tests/test-spreadsheet-reader.php
php tests/test-import-normalization.php
php tests/test-product-data.php
node tests/worker-smoke.js
find . -name '*.php' -print0 | xargs -0 -n1 php -l
```

Before production use, run the manual acceptance matrix on a staging site with the
site's exact WordPress/WooCommerce/theme/extensions stack. Cover simple and variable
products, mixed carts, 20GP→40GP→40HQ recommendation, volume/payload/dimensional
failure, incomplete profiles, fractional/tampered quantity requests, coupons/taxes,
order emails, HPOS, mobile and RTL. Compare the AJAX plan to the stored order JSON and
confirm that later product/config edits do not alter the order snapshot.
