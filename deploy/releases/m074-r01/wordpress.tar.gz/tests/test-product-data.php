<?php
/** Standalone XLSX writer and alternate-header mapping tests. */

define( 'ABSPATH', __DIR__ );
define( 'HOUR_IN_SECONDS', 3600 );
function __( $text ) { return $text; }
function esc_xml( $value ) { return htmlspecialchars( (string) $value, ENT_XML1 | ENT_QUOTES, 'UTF-8' ); }
function absint( $value ) { return abs( (int) $value ); }
function wc_clean( $value ) { return trim( (string) $value ); }
function wc_format_decimal( $value, $precision = 6 ) { return number_format( (float) $value, $precision, '.', '' ); }

require_once dirname( __DIR__ ) . '/includes/class-b2bclp-spreadsheet-reader.php';
require_once dirname( __DIR__ ) . '/includes/class-b2bclp-spreadsheet-writer.php';
require_once dirname( __DIR__ ) . '/includes/class-b2bclp-product-bulk.php';
require_once dirname( __DIR__ ) . '/includes/class-b2bclp-product-fields.php';

$assertions = 0;
function b2bclp_product_assert( $condition, $message ) {
	global $assertions;
	$assertions++;
	if ( ! $condition ) { fwrite( STDERR, "FAIL: {$message}\n" ); exit( 1 ); }
}

$aliases = array(
	'Item Code' => 'sku', 'Product Name' => 'name', 'Wholesale Price' => 'b2b_regular_price', 'PCS/BOX' => 'units_per_carton',
	'Box Length cm' => 'carton_length', 'Box Width cm' => 'carton_width', 'Box Height cm' => 'carton_height',
	'CBM per Carton' => 'carton_cbm', '每箱方数' => 'carton_cbm',
	'Net Weight KG' => 'carton_net_weight', 'Gross Weight KG' => 'carton_gross_weight',
);
foreach ( $aliases as $header => $field ) { b2bclp_product_assert( $field === B2BCLP_Product_Bulk::auto_field( $header ), $header . ' mapping' ); }

$path = tempnam( sys_get_temp_dir(), 'b2bclp-product-' );
B2BCLP_Spreadsheet_Writer::create( $path, array( 'Products' => array( array( 'Product ID', 'SKU', 'Units per Carton' ), array( 15, 'ABC-15', 24 ) ), 'Instructions' => array( array( 'Keep Product ID unchanged.' ) ) ) );
$book = B2BCLP_Spreadsheet_Reader::read_workbook( $path, 'xlsx' );
unlink( $path );
b2bclp_product_assert( isset( $book['Products'], $book['Instructions'] ), 'two named worksheets' );
b2bclp_product_assert( 'Product ID' === $book['Products'][0][0], 'header preserved' );
b2bclp_product_assert( '15' === $book['Products'][1][0], 'numeric product ID preserved' );
b2bclp_product_assert( 'ABC-15' === $book['Products'][1][1], 'SKU preserved' );
b2bclp_product_assert( 'Keep Product ID unchanged.' === $book['Instructions'][0][0], 'instructions preserved' );
$automatic = B2BCLP_Product_Fields::sanitize_profile( array( 'units_per_carton' => 24, 'carton_length' => 40, 'carton_width' => 30, 'carton_height' => 20 ) );
b2bclp_product_assert( 'yes' === $automatic['approved'] && true === $automatic['complete'], 'worker-entered sufficient packing data is accepted without approval' );
b2bclp_product_assert( B2BCLP_Product_Fields::ORIENTATIONS === $automatic['allowed_orientations'], 'missing orientation input defaults to all six rotations' );
$legacy_no = B2BCLP_Product_Fields::sanitize_profile( array( 'units_per_carton' => 24, 'carton_cbm' => 0.024, 'packing_approved' => 'no' ) );
b2bclp_product_assert( 'yes' === $legacy_no['approved'] && true === $legacy_no['complete'], 'legacy no-approval flag no longer blocks valid packing data' );
$legacy_rotation = B2BCLP_Product_Fields::sanitize_profile( array( 'units_per_carton' => 24, 'carton_length' => 40, 'carton_width' => 30, 'carton_height' => 20, 'orientations' => 'lwh' ) );
b2bclp_product_assert( B2BCLP_Product_Fields::ORIENTATIONS === $legacy_rotation['allowed_orientations'], 'legacy orientation values become unrestricted during the upgrade' );
$restricted = B2BCLP_Product_Fields::sanitize_profile( array( 'units_per_carton' => 24, 'carton_length' => 40, 'carton_width' => 30, 'carton_height' => 20, 'orientations' => 'lwh,hwl', 'orientation_customized' => true ) );
b2bclp_product_assert( array( 'lwh', 'hwl' ) === $restricted['allowed_orientations'], 'explicit exceptional rotation restrictions remain editable' );
echo "OK ({$assertions} assertions)\n";
