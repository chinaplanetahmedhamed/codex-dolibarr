=== B2B Container Loading Planner for WooCommerce ===
Contributors: b2bclp
Tags: woocommerce, b2b, container, carton, loading
Requires at least: 6.4
Tested up to: 7.0
Requires PHP: 7.4
Stable tag: 2.0.0
License: GPLv2 or later

Carton-based B2B order requests with deterministic 3D container loading estimates.

== Description ==

Adds automatically accepted packing profiles to simple products and variations, whole-carton ordering,
configurable 20GP/40GP/40HQ capacities, automatic recommendation, manual switching,
server-authoritative validation, a responsive 3D estimate, an offline request gateway,
and immutable line/order loading snapshots.

The planner supports rectangular cartons only. It does not model pallets, irregular or
dangerous cargo, load securing, centre of gravity, or axle loads. Every estimate requires
operational confirmation.

== Installation ==

1. Upload and activate the plugin ZIP in WordPress.
2. Ensure WooCommerce is active.
3. Review WooCommerce > Container Loading.
4. Complete the packing profile for each purchasable product/variation.
5. Enable the B2B request gateway under WooCommerce payment settings.

== Data and compatibility ==

Order and line snapshots are stored through WooCommerce CRUD APIs and are HPOS compatible.
Stable UUIDs and schema-versioned JSON metadata are included for future integrations.
No external service, payment processor, or Dolibarr integration is used.

== Changelog ==

= 2.0.0 =
* Freeze the headless loading-plan contract as `cpo.catalog-order.v2` with request-unique line identifiers.
* Keep incomplete packing rows in quotation requests while excluding them from CBM, weight, capacity, and 3D calculations.
* Remove the duplicate headless WooCommerce request/order endpoint; React submits the authoritative snapshot through the secure Node gateway to Dolibarr.
* Apply customer-safe B2BKing price visibility without inferring hidden or member-only values.

= 1.9.4 =
* Expose enabled published variations without prices to the headless B2B quote catalogue.

= 1.9.3 =
* Fixes empty category sanitization on the public catalog REST endpoint.

= 1.9.2 =
* Normalize filtered WooCommerce product-category results before building the public catalog response.

= 1.9.1 =
* Isolate WooCommerce catalog query, mapping, and taxonomy runtime failures so one bad record cannot crash the public B2B API.

= 1.9.0 =
* Add a versioned headless B2B REST API for paginated public catalog data and server-authoritative loading plans.
* Add a signed server-to-server review-request endpoint with timestamp validation and idempotency protection.
* Create pending WooCommerce review requests with immutable carton, price, and loading-plan snapshots.
* Keep private WooCommerce credentials and customer-specific pricing out of the browser.

= 1.8.0 =
* Remove the manager packing-approval checkbox and automatically accept worker-entered packing data.
* Default new and legacy carton profiles to all six rotation orientations while retaining exceptional per-carton restrictions.
* Make existing cart snapshots calculation-ready whenever their immutable units and carton volume are sufficient, regardless of their old approval flag.
* Remove Packing Approved from round-trip product exports and automatically approve packing data imported or created by staff.

= 1.7.0 =
* Draw CBM-only cartons individually using estimated dimensions with a consistent 1.6:1.2:1 ratio and exact source CBM.
* Keep CBM-only dimensional placement explicitly labeled as a visual estimate.
* Move the cart loading calculator into a sticky right-hand column matching the B2B bulk-order page, with mobile stacking.

= 1.6.3 =
* Make the calculator headline carton and piece totals include every requested cart line, including products excluded from 3D loading.
* Show a separate count of cartons included in the loading calculation when packing data is missing.
* Add total cartons and total pieces to WooCommerce cart and checkout totals.
* Add total pieces beside the B2BKing cart amount and carton count.

= 1.6.2 =
* Decode WooCommerce currency entities before JavaScript formatting so symbols such as yen display as ¥ instead of &yen;.

= 1.6.1 =
* Show live total price beside total units on product pages.
* Make the B2BKing bulk form explicitly use carton quantities in its display.
* Show piece price, carton count, total pieces, and carton-based total in each B2BKing row.
* Show selected total cartons, pieces, and price without modifying B2BKing core files.

= 1.6.0 =
* Keep WooCommerce and B2BKing catalog prices as per-piece prices while customers order positive whole carton quantities.
* Calculate one-carton price as piece price multiplied by Units per Carton, then let WooCommerce calculate carton quantity, taxes, coupons, totals, and refunds.
* Store immutable per-piece and per-carton prices in each request line snapshot and show both values in the cart and order metadata.

= 1.5.0 =
* Accept a direct CBM-per-carton value when carton length, width, and height are unavailable.
* Make net and gross carton weights optional; payload figures use known weights only and show customer, staff, email, and print warnings when weight is missing.
* Preserve deterministic 3D validation for dimensioned cartons while representing CBM-only cargo as an explicitly unverified aggregate visual block.
* Add Carton CBM to product/variation admin fields and the round-trip bulk product XLSX/CSV mapper.

= 1.4.1 =
* Default every product-data export row to all six carton orientations and Packing Approved = yes, so staff only need to edit exceptional restrictions.
* Keep Packing Complete read-only and calculated from the actual required carton data after import.
* Allow products without complete packing data in B2B requests while excluding them from container CBM, weight, and 3D placement totals with a clear warning and immutable line snapshot.

= 1.4.0 =
* Added WooCommerce > Product Packing Data for round-trip product, variation, price, category, B2BKing price, and carton-profile maintenance.
* Export all products, a category, or individually selected products to a styled XLSX workbook with immutable Product IDs and optional variation rows.
* Import the plugin workbook or supplier XLSX/CSV files through automatic header recognition and a manual field-mapping screen.
* Preview exact old-to-new changes, reject ambiguous names, duplicate SKUs, invalid packing values, unknown categories, and invalid orientations before any update.
* Preserve blank fields, update only selected valid rows, and record the importing user and time on updated products.

= 1.3.0 =
* Scan every XLSX worksheet and let staff choose which detected cargo sheets belong to the calculation.
* Show detected header row, semantic columns, cargo-row count, and interpretation confidence before calculation.
* Understand common mixed packing-list patterns including combined millimetre carton sizes, text-suffixed totals, repeated blank product names, and English/Chinese operational headers.
* Apply workbook footer totals independently per selected sheet so multi-sheet calculations do not overwrite one another.

= 1.2.1 =
* Added a proportional, rotatable aggregate cargo block for volume/weight-only imports, with explicit visual-only labeling.
* Increased the company import limit to 256 MB and added smart operational-sheet headers and workbook footer totals.

= 1.2.0 =
* Added a company-only Excel/CSV container planner under WooCommerce.
* Existing SKUs use approved WooCommerce packing profiles; unknown complete rows calculate as temporary cargo.
* Added reviewed creation of selected unknown rows as hidden, unpublished WooCommerce draft products.
* Added live 20GP/40HQ switching, row-level validation, upload limits, nonces, capabilities, and a downloadable Excel template.
* Accepts files up to 256 MB while ignoring embedded product images, detects title/header rows in operational spreadsheets, and supports CBM/weight-only estimates when carton dimensions are unavailable.
* Volume/weight-only imports render a rotatable aggregate cargo block proportional to used CBM, clearly labeled as a visualization rather than validated carton placement.

= 1.1.0 =
* Add a B2BKing bulk-order page with a responsive sticky loading calculator.
* Refresh container CBM and payload automatically after B2BKing AJAX additions.
* Show a useful empty-cart container estimate before the customer starts ordering.

= 1.0.2 =
* Use operational capacities of 28 CBM for 20GP and 68 CBM for 40HQ.
* Disable 40GP by default and recommend directly between 20GP and 40HQ.
* Treat every carton as stackable without a tier limit.
* Clarify total cargo, loaded, usable-container, and unallocated CBM figures.

= 1.0.1 =
* Keep container drawings and capacity figures synchronized after manual switching.
* Improve large-cart packing performance and avoid oversized WooCommerce sessions.
* Add easier rotation and zoom controls, perspective shading, and container dimensions.
* Group identical unpacked cartons into compact, readable summaries.

= 1.0.0 =
* Initial release.
