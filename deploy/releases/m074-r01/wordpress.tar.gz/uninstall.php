<?php
defined( 'WP_UNINSTALL_PLUGIN' ) || exit;

// Operational/order snapshots are intentionally retained. Remove configuration only
// when an administrator explicitly opts into deletion before uninstalling.
if ( 'yes' === get_option( 'b2bclp_delete_settings_on_uninstall', 'no' ) ) {
	delete_option( 'b2bclp_settings' );
	delete_option( 'b2bclp_delete_settings_on_uninstall' );
}
