<?php
/**
 * Plugin Name: B2B Container Loading Planner for WooCommerce
 * Description: Carton-based B2B ordering with deterministic container loading estimates and immutable order snapshots.
 * Version: 2.0.0
 * Requires at least: 6.4
 * Requires PHP: 7.4
 * WC requires at least: 8.5
 * WC tested up to: 10.9
 * Author: B2B Container Loading Planner
 * Text Domain: b2b-container-loading-planner
 * Domain Path: /languages
 * License: GPL-2.0-or-later
 */

defined( 'ABSPATH' ) || exit;

define( 'B2BCLP_VERSION', '2.0.0' );
define( 'B2BCLP_FILE', __FILE__ );
define( 'B2BCLP_PATH', plugin_dir_path( __FILE__ ) );
define( 'B2BCLP_URL', plugin_dir_url( __FILE__ ) );

require_once B2BCLP_PATH . 'includes/class-b2bclp-settings.php';
require_once B2BCLP_PATH . 'includes/class-b2bclp-packer.php';
require_once B2BCLP_PATH . 'includes/class-b2bclp-product-fields.php';
require_once B2BCLP_PATH . 'includes/class-b2bclp-cart.php';
require_once B2BCLP_PATH . 'includes/class-b2bclp-rest.php';
require_once B2BCLP_PATH . 'includes/class-b2bclp-order-display.php';
require_once B2BCLP_PATH . 'includes/class-b2bclp-spreadsheet-reader.php';
require_once B2BCLP_PATH . 'includes/class-b2bclp-spreadsheet-writer.php';
require_once B2BCLP_PATH . 'includes/class-b2bclp-import.php';
require_once B2BCLP_PATH . 'includes/class-b2bclp-product-bulk.php';

final class B2BCLP_Plugin {
	public static function init() {
		add_action( 'init', array( __CLASS__, 'load_textdomain' ) );

		if ( ! class_exists( 'WooCommerce' ) ) {
			add_action( 'admin_notices', array( __CLASS__, 'woocommerce_required' ) );
			return;
		}
		require_once B2BCLP_PATH . 'includes/class-b2bclp-gateway.php';

		B2BCLP_Settings::init();
		B2BCLP_Product_Fields::init();
		B2BCLP_Cart::init();
		B2BCLP_REST::init();
		B2BCLP_Order_Display::init();
		B2BCLP_Import::init();
		B2BCLP_Product_Bulk::init();
		B2BCLP_Gateway_Loader::init();
	}

	public static function load_textdomain() {
		load_plugin_textdomain( 'b2b-container-loading-planner', false, dirname( plugin_basename( __FILE__ ) ) . '/languages' );
	}

	public static function woocommerce_required() {
		if ( current_user_can( 'activate_plugins' ) ) {
			echo '<div class="notice notice-error"><p>' . esc_html__( 'B2B Container Loading Planner requires WooCommerce to be installed and active.', 'b2b-container-loading-planner' ) . '</p></div>';
		}
	}

	public static function declare_compatibility() {
		if ( class_exists( '\\Automattic\\WooCommerce\\Utilities\\FeaturesUtil' ) ) {
			\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'custom_order_tables', __FILE__, true );
		}
	}
}

add_action( 'before_woocommerce_init', array( 'B2BCLP_Plugin', 'declare_compatibility' ) );
add_action( 'plugins_loaded', array( 'B2BCLP_Plugin', 'init' ) );
