<?php
/**
 * Deterministic axis-aligned rectangular carton packing estimator.
 *
 * This class intentionally has no WordPress dependencies so that the same input
 * can be evaluated from cart validation, REST/AJAX handlers, order submission,
 * and command-line tests.
 *
 * @package B2B_Container_Loading_Planner
 */

defined( 'ABSPATH' ) || define( 'B2BCLP_PACKER_STANDALONE', true );

/**
 * A conservative, deterministic extreme-point bin packer.
 *
 * Measurements are centimetres and kilograms. Coordinates are returned in cm.
 * This is an estimate; it is not a cargo-securing or axle-load calculation.
 */
final class B2BCLP_Packer {

	const EPSILON = 0.000001;

	/** @var string[] */
	private static $orientation_names = array( 'LWH', 'LHW', 'WLH', 'WHL', 'HLW', 'HWL' );

	/**
	 * Pack cartons into one container.
	 *
	 * Container keys: length/internal_length, width/internal_width,
	 * height/internal_height, max_payload, volume_margin_percent and
	 * weight_margin_percent.
	 *
	 * Line keys: cartons/quantity, units_per_carton, length/carton_length,
	 * width/carton_width, height/carton_height, net_weight/carton_net_weight,
	 * gross_weight/carton_gross_weight, orientations/allowed_orientations,
	 * Cartons are treated as stackable without a tier limit.
	 *
	 * @param array $items     Packing line definitions.
	 * @param array $container Container definition.
	 * @param array $options   Reserved; supports estimate_label override.
	 * @return array<string,mixed>
	 * @throws InvalidArgumentException For invalid container or line data.
	 */
	public static function pack( array $items, array $container, array $options = array() ) {
		$container = self::normalize_container( $container );
		$cartons   = self::expand_lines( $items );

		usort( $cartons, array( __CLASS__, 'compare_cartons' ) );

		$physical_cbm  = ( $container['length'] * $container['width'] * $container['height'] ) / 1000000;
		$operational_cbm = $container['capacity_cbm'] > 0 ? min( $physical_cbm, $container['capacity_cbm'] ) : $physical_cbm;
		$usable_cbm    = $operational_cbm * ( 1 - ( $container['volume_margin_percent'] / 100 ) );
		$usable_weight = $container['max_payload'] * ( 1 - ( $container['weight_margin_percent'] / 100 ) );

		$placements       = array();
		$unpacked          = array();
		$points            = array( array( 'x' => 0.0, 'y' => 0.0, 'z' => 0.0 ) );
		$placed_cbm        = 0.0;
		$placed_net        = 0.0;
		$placed_gross      = 0.0;
		$total_cbm         = 0.0;
		$total_net         = 0.0;
		$total_gross       = 0.0;
		$total_units       = 0;
		$unpacked_reasons  = array();
		$unplaceable_types = array();

		foreach ( $cartons as $carton ) {
			$total_cbm   += $carton['cbm'];
			$total_net   += $carton['net_weight'];
			$total_gross += $carton['gross_weight'];
			$total_units += $carton['units_per_carton'];

			$reason = '';
			if ( $placed_gross + $carton['gross_weight'] > $usable_weight + self::EPSILON ) {
				$reason = 'payload_limit';
			} elseif ( $placed_cbm + $carton['cbm'] > $usable_cbm + self::EPSILON ) {
				$reason = 'volume_limit';
			}

			$best = null;
			$type_signature = self::carton_type_signature( $carton );
			if ( '' === $reason ) {
				if ( isset( $unplaceable_types[ $type_signature ] ) ) {
					$reason = 'cannot_place';
				} else {
					$best = self::find_placement( $carton, $points, $placements, $container );
					if ( null === $best ) {
						$reason = 'cannot_place';
						// No placement was added, so the state is unchanged. Every later
						// carton with the same geometry/constraints will fail identically.
						$unplaceable_types[ $type_signature ] = true;
					}
				}
			}

			if ( null === $best ) {
				$unpacked[] = self::unpacked_carton( $carton, $reason );
				$unpacked_reasons[ $reason ] = true;
				continue;
			}

			$placement = array_merge(
				array(
					'line_key'         => $carton['line_key'],
					'carton_key'       => $carton['carton_key'],
					'carton_index'     => $carton['carton_index'],
					'product_id'       => $carton['product_id'],
					'variation_id'     => $carton['variation_id'],
					'sku'              => $carton['sku'],
					'name'             => $carton['name'],
					'units_per_carton' => $carton['units_per_carton'],
					'net_weight'       => $carton['net_weight'],
					'gross_weight'     => $carton['gross_weight'],
					'cbm'              => $carton['cbm'],
					'stackable'        => $carton['stackable'],
					'max_stack'        => $carton['max_stack'],
				),
				$best
			);

			$placements[]  = $placement;
			$unplaceable_types = array();
			$placed_cbm   += $carton['cbm'];
			$placed_net   += $carton['net_weight'];
			$placed_gross += $carton['gross_weight'];
			$points         = self::update_points( $points, $placement, $placements, $container );
		}

		$violations = array_keys( $unpacked_reasons );
		sort( $violations, SORT_STRING );

		$capacity = array(
			'physical_cbm' => self::round_measure( $physical_cbm ),
			'operational_cbm' => self::round_measure( $operational_cbm ),
			'volume'       => self::round_measure( $usable_cbm ),
			'payload'      => self::round_measure( $usable_weight ),
		);
		$used = array(
			'volume'       => self::round_measure( $placed_cbm ),
			'net_weight'   => self::round_measure( $placed_net ),
			'gross_weight' => self::round_measure( $placed_gross ),
		);
		$remaining = array(
			'volume'  => self::round_measure( max( 0, $usable_cbm - $placed_cbm ) ),
			'payload' => self::round_measure( max( 0, $usable_weight - $placed_gross ) ),
		);
		$success = empty( $unpacked );
		$reason  = $success ? '' : self::public_reason( $violations );
		$packing_input = self::worker_input( $items, $container );

		return array(
			'ok'             => $success,
			'reason'         => $reason,
			'success'        => empty( $unpacked ),
			'estimate'       => true,
			'estimate_label' => isset( $options['estimate_label'] ) ? (string) $options['estimate_label'] : 'Estimated loading plan — operational confirmation required.',
			'container'      => $container,
			'limits'         => array(
				'physical_cbm'   => self::round_measure( $physical_cbm ),
				'operational_cbm' => self::round_measure( $operational_cbm ),
				'usable_cbm'     => self::round_measure( $usable_cbm ),
				'max_payload'   => self::round_measure( $container['max_payload'] ),
				'usable_payload' => self::round_measure( $usable_weight ),
			),
			'placements'     => $placements,
			'unpacked'       => $unpacked,
			'violations'     => $violations,
			'warnings'       => $violations,
			'capacity'       => $capacity,
			'used'           => $used,
			'remaining'      => $remaining,
			'packing_input'  => $packing_input,
			'totals'         => array(
				'cartons'           => count( $cartons ),
				'placed_cartons'    => count( $placements ),
				'unpacked_cartons'  => count( $unpacked ),
				'units'             => $total_units,
				'cbm'               => self::round_measure( $total_cbm ),
				'net_weight'        => self::round_measure( $total_net ),
				'gross_weight'      => self::round_measure( $total_gross ),
				'placed_cbm'        => self::round_measure( $placed_cbm ),
				'placed_net_weight' => self::round_measure( $placed_net ),
				'placed_gross_weight' => self::round_measure( $placed_gross ),
				'remaining_cbm'     => self::round_measure( max( 0, $usable_cbm - $placed_cbm ) ),
				'remaining_payload' => self::round_measure( max( 0, $usable_weight - $placed_gross ) ),
			),
		);
	}

	/**
	 * Choose and pack the smallest enabled container, or pack an explicit one.
	 *
	 * @param array  $items      Carton type lines.
	 * @param array  $containers Container definitions. Associative keys may be IDs.
	 * @param string $selected   Container ID, or "auto".
	 * @return array<string,mixed>
	 */
	public static function recommend( array $items, array $containers, $selected = 'auto' ) {
		$enabled = array();
		foreach ( $containers as $key => $container ) {
			if ( ! is_array( $container ) || ( isset( $container['enabled'] ) && ! self::to_bool( $container['enabled'] ) ) ) {
				continue;
			}
			if ( ! isset( $container['id'] ) || '' === (string) $container['id'] ) {
				$container['id'] = (string) $key;
			}
			$enabled[] = $container;
		}

		if ( empty( $enabled ) ) {
			return array(
				'ok' => false, 'success' => false, 'reason' => 'no_enabled_container',
				'placements' => array(), 'unpacked' => array(), 'considered_containers' => array(),
			);
		}

		$automatic = 'auto' === (string) $selected || '' === (string) $selected;
		if ( ! $automatic ) {
			$matching = array_values(
				array_filter(
					$enabled,
					function ( $container ) use ( $selected ) {
						return (string) $container['id'] === (string) $selected;
					}
				)
			);
			if ( empty( $matching ) ) {
				return array(
					'ok' => false, 'success' => false, 'reason' => 'container_unavailable',
					'placements' => array(), 'unpacked' => array(), 'considered_containers' => array(),
				);
			}
			$enabled = $matching;
		} else {
			usort( $enabled, array( __CLASS__, 'compare_containers' ) );
		}

		$considered = array();
		$last       = null;
		foreach ( $enabled as $container ) {
			$plan         = self::pack( $items, $container );
			$considered[] = array(
				'id' => $plan['container']['id'], 'ok' => $plan['ok'], 'reason' => $plan['reason'],
			);
			$last = $plan;
			if ( $plan['ok'] || ! $automatic ) {
				break;
			}
		}

		$last['automatic']              = $automatic;
		$last['recommended_container']  = $last['container']['id'];
		$last['considered_containers']  = $considered;
		return $last;
	}

	/**
	 * Recommend a container for mixed lines where some cartons have CBM but no dimensions.
	 * Dimensioned lines retain deterministic 3D validation; CBM-only lines reserve
	 * operational volume and are represented by an explicitly visual-only block.
	 */
	public static function recommend_flexible( array $items, array $containers, $selected = 'auto' ) {
		$has_cbm_only = false;
		foreach ( $items as $item ) {
			if ( is_array( $item ) && ! self::line_has_dimensions( $item ) && self::line_cbm( $item ) > 0 ) {
				$has_cbm_only = true;
				break;
			}
		}
		if ( ! $has_cbm_only ) {
			return self::recommend( $items, $containers, $selected );
		}

		$enabled = array();
		foreach ( $containers as $key => $container ) {
			if ( ! is_array( $container ) || ( isset( $container['enabled'] ) && ! self::to_bool( $container['enabled'] ) ) ) {
				continue;
			}
			if ( ! isset( $container['id'] ) || '' === (string) $container['id'] ) {
				$container['id'] = (string) $key;
			}
			$enabled[] = $container;
		}
		if ( ! $enabled ) {
			return array( 'ok' => false, 'success' => false, 'reason' => 'no_enabled_container', 'placements' => array(), 'unpacked' => array(), 'considered_containers' => array() );
		}

		$automatic = 'auto' === (string) $selected || '' === (string) $selected;
		if ( $automatic ) {
			usort( $enabled, array( __CLASS__, 'compare_containers' ) );
		} else {
			$enabled = array_values( array_filter( $enabled, function ( $container ) use ( $selected ) { return (string) $container['id'] === (string) $selected; } ) );
			if ( ! $enabled ) {
				return array( 'ok' => false, 'success' => false, 'reason' => 'container_unavailable', 'placements' => array(), 'unpacked' => array(), 'considered_containers' => array() );
			}
		}

		$considered = array();
		$last = null;
		foreach ( $enabled as $container ) {
			$plan = self::pack_flexible( $items, $container );
			$considered[] = array( 'id' => $plan['container']['id'], 'ok' => $plan['ok'], 'reason' => $plan['reason'] );
			$last = $plan;
			if ( $plan['ok'] || ! $automatic ) {
				break;
			}
		}
		$last['automatic'] = $automatic;
		$last['recommended_container'] = $last['container']['id'];
		$last['considered_containers'] = $considered;
		return $last;
	}

	/** Pack dimensional cartons and reserve capacity for CBM-only cartons. */
	public static function pack_flexible( array $items, array $container ) {
		$dimensional = array();
		$cbm_only = array();
		foreach ( $items as $item ) {
			if ( ! is_array( $item ) ) {
				throw new InvalidArgumentException( 'Packing lines must be arrays.' );
			}
			if ( self::line_has_dimensions( $item ) ) {
				$dimensional[] = $item;
			} elseif ( self::line_cbm( $item ) > 0 ) {
				$cbm_only[] = $item;
			} else {
				throw new InvalidArgumentException( 'Each packing line requires complete dimensions or CBM per carton.' );
			}
		}
		if ( ! $cbm_only ) {
			return self::pack( $items, $container );
		}

		$plan = self::pack( $dimensional, $container );
		$aggregate_cbm = 0.0;
		$aggregate_net = 0.0;
		$aggregate_gross = 0.0;
		$aggregate_cartons = 0;
		$aggregate_units = 0;
		foreach ( $cbm_only as $index => $item ) {
			$quantity = self::positive_integer( self::first( $item, array( 'cartons', 'quantity', 'carton_quantity' ) ), 'carton quantity' );
			$units = self::positive_integer( self::first( $item, array( 'units_per_carton', 'units' ), 1 ), 'units per carton' );
			$cbm = self::positive_number( self::line_cbm( $item ), 'carton CBM' );
			$net = self::nonnegative_number( self::first( $item, array( 'net_weight', 'carton_net_weight' ), 0 ), 'carton net weight' );
			$gross = self::nonnegative_number( self::first( $item, array( 'gross_weight', 'carton_gross_weight' ), 0 ), 'carton gross weight' );
			if ( $gross > 0 && $gross + self::EPSILON < $net ) {
				throw new InvalidArgumentException( 'Carton gross weight cannot be less than net weight.' );
			}
			$aggregate_cartons += $quantity;
			$aggregate_units += $quantity * $units;
			$aggregate_cbm += $quantity * $cbm;
			$aggregate_net += $quantity * $net;
			$aggregate_gross += $quantity * $gross;
		}

		$total_cbm = (float) ( $plan['totals']['cbm'] ?? 0 ) + $aggregate_cbm;
		$total_gross = (float) ( $plan['totals']['gross_weight'] ?? 0 ) + $aggregate_gross;
		$usable_cbm = (float) ( $plan['capacity']['volume'] ?? 0 );
		$usable_payload = (float) ( $plan['capacity']['payload'] ?? 0 );
		$volume_ok = $total_cbm <= $usable_cbm + self::EPSILON;
		$payload_ok = $total_gross <= $usable_payload + self::EPSILON;
		$dimension_ok = ! empty( $plan['ok'] );
		$ok = $dimension_ok && $volume_ok && $payload_ok;
		if ( ! $dimension_ok ) {
			$reason = $plan['reason'];
		} elseif ( ! $volume_ok && ! $payload_ok ) {
			$reason = 'multiple_limits';
		} elseif ( ! $volume_ok ) {
			$reason = 'volume';
		} elseif ( ! $payload_ok ) {
			$reason = 'payload';
		} else {
			$reason = '';
		}

		$plan['ok'] = $ok;
		$plan['success'] = $ok;
		$plan['reason'] = $reason;
		$plan['totals']['cartons'] += $aggregate_cartons;
		$plan['totals']['units'] += $aggregate_units;
		$plan['totals']['cbm'] = self::round_measure( $total_cbm );
		$plan['totals']['net_weight'] = self::round_measure( (float) $plan['totals']['net_weight'] + $aggregate_net );
		$plan['totals']['gross_weight'] = self::round_measure( $total_gross );
		$plan['totals']['remaining_cbm'] = self::round_measure( max( 0, $usable_cbm - $total_cbm ) );
		$plan['totals']['remaining_payload'] = self::round_measure( max( 0, $usable_payload - $total_gross ) );
		$plan['used']['volume'] = self::round_measure( $total_cbm );
		$plan['used']['net_weight'] = $plan['totals']['net_weight'];
		$plan['used']['gross_weight'] = $plan['totals']['gross_weight'];
		$plan['remaining']['volume'] = $plan['totals']['remaining_cbm'];
		$plan['remaining']['payload'] = $plan['totals']['remaining_payload'];
		$plan['dimension_validation'] = false;
		$plan['visual_mode'] = $dimensional ? 'hybrid_volume' : 'aggregate_volume';
		$plan['aggregate_cbm'] = self::round_measure( $aggregate_cbm );
		if ( ! $dimensional ) {
			$plan['packing_input'] = null;
		}

		$fill_ratio = $usable_cbm > 0 ? min( 1, max( 0, $aggregate_cbm / $usable_cbm ) ) : 0;
		if ( $fill_ratio > 0 ) {
			$plan['placements'][] = array(
				'x' => (float) $plan['container']['length'] * 0.02,
				'y' => (float) $plan['container']['width'] * 0.02,
				'z' => (float) $plan['container']['height'] * 0.02,
				'length' => (float) $plan['container']['length'] * 0.96 * $fill_ratio,
				'width' => (float) $plan['container']['width'] * 0.96,
				'height' => (float) $plan['container']['height'] * 0.96,
				'line_key' => 'aggregate-cbm-only-volume',
				'name' => 'Aggregate CBM-only cargo',
				'carton_index' => 1,
				'color' => '#f59e0b',
				'visual_only' => true,
			);
		}
		return $plan;
	}

	private static function line_has_dimensions( array $line ) {
		return (float) self::first( $line, array( 'length', 'carton_length' ), 0 ) > 0
			&& (float) self::first( $line, array( 'width', 'carton_width' ), 0 ) > 0
			&& (float) self::first( $line, array( 'height', 'carton_height' ), 0 ) > 0;
	}

	private static function line_cbm( array $line ) {
		return (float) self::first( $line, array( 'cbm_per_carton', 'carton_cbm', 'cbm' ), 0 );
	}

	/** Sort by physical volume, payload, then stable ID. */
	private static function compare_containers( $a, $b ) {
		$a_volume = (float) self::first( $a, array( 'length', 'internal_length' ), 0 ) * (float) self::first( $a, array( 'width', 'internal_width' ), 0 ) * (float) self::first( $a, array( 'height', 'internal_height' ), 0 );
		$b_volume = (float) self::first( $b, array( 'length', 'internal_length' ), 0 ) * (float) self::first( $b, array( 'width', 'internal_width' ), 0 ) * (float) self::first( $b, array( 'height', 'internal_height' ), 0 );
		if ( abs( $a_volume - $b_volume ) > self::EPSILON ) {
			return $a_volume < $b_volume ? -1 : 1;
		}
		$a_payload = (float) self::first( $a, array( 'max_payload', 'payload' ), 0 );
		$b_payload = (float) self::first( $b, array( 'max_payload', 'payload' ), 0 );
		if ( abs( $a_payload - $b_payload ) > self::EPSILON ) {
			return $a_payload < $b_payload ? -1 : 1;
		}
		return strcmp( isset( $a['id'] ) ? (string) $a['id'] : '', isset( $b['id'] ) ? (string) $b['id'] : '' );
	}

	/** @return array<string,mixed> */
	private static function normalize_container( array $container ) {
		$normalized = array(
			'id'                    => isset( $container['id'] ) ? (string) $container['id'] : '',
			'name'                  => isset( $container['name'] ) ? (string) $container['name'] : ( isset( $container['label'] ) ? (string) $container['label'] : '' ),
			'label'                 => isset( $container['label'] ) ? (string) $container['label'] : ( isset( $container['name'] ) ? (string) $container['name'] : ( isset( $container['id'] ) ? (string) $container['id'] : '' ) ),
			'length'                => self::positive_number( self::first( $container, array( 'length', 'internal_length' ) ), 'container length' ),
			'width'                 => self::positive_number( self::first( $container, array( 'width', 'internal_width' ) ), 'container width' ),
			'height'                => self::positive_number( self::first( $container, array( 'height', 'internal_height' ) ), 'container height' ),
			'max_payload'           => self::positive_number( self::first( $container, array( 'max_payload', 'payload' ) ), 'container payload' ),
			'capacity_cbm'          => self::nonnegative_number( self::first( $container, array( 'capacity_cbm', 'operational_cbm', 'usable_capacity_cbm' ), 0 ), 'container operational capacity' ),
			'volume_margin_percent' => self::margin( self::first( $container, array( 'volume_margin_percent', 'volume_margin', 'volume_safety_margin' ), 0 ), 'volume margin' ),
			'weight_margin_percent' => self::margin( self::first( $container, array( 'weight_margin_percent', 'weight_margin', 'weight_safety_margin' ), 0 ), 'weight margin' ),
		);

		return $normalized;
	}

	/** @return array<int,array<string,mixed>> */
	private static function expand_lines( array $lines ) {
		$cartons = array();
		foreach ( array_values( $lines ) as $line_index => $line ) {
			if ( ! is_array( $line ) ) {
				throw new InvalidArgumentException( 'Packing lines must be arrays.' );
			}

			$quantity = self::positive_integer( self::first( $line, array( 'cartons', 'quantity', 'carton_quantity' ) ), 'carton quantity' );
			$length   = self::positive_number( self::first( $line, array( 'length', 'carton_length' ) ), 'carton length' );
			$width    = self::positive_number( self::first( $line, array( 'width', 'carton_width' ) ), 'carton width' );
			$height   = self::positive_number( self::first( $line, array( 'height', 'carton_height' ) ), 'carton height' );
			$net      = self::nonnegative_number( self::first( $line, array( 'net_weight', 'carton_net_weight' ), 0 ), 'carton net weight' );
			$gross    = self::nonnegative_number( self::first( $line, array( 'gross_weight', 'carton_gross_weight' ), 0 ), 'carton gross weight' );

			if ( $gross > 0 && $gross + self::EPSILON < $net ) {
				throw new InvalidArgumentException( 'Carton gross weight cannot be less than net weight.' );
			}

			$line_key  = isset( $line['line_key'] ) ? (string) $line['line_key'] : ( isset( $line['id'] ) ? (string) $line['id'] : ( isset( $line['cart_item_key'] ) ? (string) $line['cart_item_key'] : 'line-' . $line_index ) );
			$stackable = true;
			$max_stack = PHP_INT_MAX;

			$base = array(
				'line_key'         => $line_key,
				'product_id'       => isset( $line['product_id'] ) ? (int) $line['product_id'] : 0,
				'variation_id'     => isset( $line['variation_id'] ) ? (int) $line['variation_id'] : 0,
				'sku'              => isset( $line['sku'] ) ? (string) $line['sku'] : '',
				'name'             => isset( $line['name'] ) ? (string) $line['name'] : ( isset( $line['product_name'] ) ? (string) $line['product_name'] : '' ),
				'units_per_carton' => self::positive_integer( self::first( $line, array( 'units_per_carton', 'units' ), 1 ), 'units per carton' ),
				'length'           => $length,
				'width'            => $width,
				'height'           => $height,
				'net_weight'       => $net,
				'gross_weight'     => $gross,
				'cbm'              => ( $length * $width * $height ) / 1000000,
				'orientations'     => self::orientations( $line ),
				'stackable'        => $stackable,
				'max_stack'        => $max_stack,
			);

			for ( $i = 1; $i <= $quantity; $i++ ) {
				$cartons[] = array_merge(
					$base,
					array(
						'carton_index' => $i,
						'carton_key'   => $line_key . ':' . $i,
					)
				);
			}
		}

		return $cartons;
	}

	private static function carton_type_signature( array $carton ) {
		return implode(
			'|',
			array(
				sprintf( '%.6F', $carton['length'] ),
				sprintf( '%.6F', $carton['width'] ),
				sprintf( '%.6F', $carton['height'] ),
				implode( ',', $carton['orientations'] ),
				$carton['stackable'] ? '1' : '0',
				(string) $carton['max_stack'],
			)
		);
	}

	/** Deterministic: large first, then heavy, then stable identifiers/index. */
	private static function compare_cartons( $a, $b ) {
		$keys = array( 'cbm', 'gross_weight' );
		foreach ( $keys as $key ) {
			if ( abs( $a[ $key ] - $b[ $key ] ) > self::EPSILON ) {
				return ( $a[ $key ] > $b[ $key ] ) ? -1 : 1;
			}
		}
		$a_side = max( $a['length'], $a['width'], $a['height'] );
		$b_side = max( $b['length'], $b['width'], $b['height'] );
		if ( abs( $a_side - $b_side ) > self::EPSILON ) {
			return $a_side > $b_side ? -1 : 1;
		}
		$line_compare = strcmp( $a['line_key'], $b['line_key'] );
		return 0 !== $line_compare ? $line_compare : ( $a['carton_index'] - $b['carton_index'] );
	}

	/** @return array<string,mixed>|null */
	private static function find_placement( array $carton, array $points, array $placements, array $container ) {
		$orientations = self::oriented_dimensions( $carton );
		$best         = null;
		$best_score   = null;

		foreach ( $points as $point ) {
			$point_best       = null;
			$point_best_score = null;
			foreach ( $orientations as $orientation ) {
				$candidate = array(
					'x'           => $point['x'],
					'y'           => $point['y'],
					'z'           => $point['z'],
					'length'      => $orientation['length'],
					'width'       => $orientation['width'],
					'height'      => $orientation['height'],
					'orientation' => $orientation['orientation'],
				);

				if ( ! self::within_container( $candidate, $container ) || self::overlaps_any( $candidate, $placements ) ) {
					continue;
				}

				$stack_level = self::supported_stack_level( $candidate, $carton, $placements );
				if ( false === $stack_level ) {
					continue;
				}
				$candidate['stack_level'] = $stack_level;

				// Bottom/back/left placement, then prefer the lowest resulting extents.
				$score = array(
					$candidate['z'],
					$candidate['y'],
					$candidate['x'],
					$candidate['z'] + $candidate['height'],
					$candidate['y'] + $candidate['width'],
					$candidate['x'] + $candidate['length'],
					$candidate['orientation'],
				);
				if ( null === $point_best_score || self::compare_scores( $score, $point_best_score ) < 0 ) {
					$point_best       = $candidate;
					$point_best_score = $score;
				}
			}

			// Point ordering is the primary score, so later points cannot win once
			// any orientation fits here. This keeps common large loads near O(n^2).
			if ( null !== $point_best ) {
				$best       = $point_best;
				$best_score = $point_best_score;
				break;
			}
		}

		return $best;
	}

	/** @return int|false */
	private static function supported_stack_level( array $candidate, array $carton, array $placements ) {
		if ( $candidate['z'] <= self::EPSILON ) {
			return 1;
		}

		$base_area  = $candidate['length'] * $candidate['width'];
		$covered    = 0.0;
		$max_level  = 0;
		$supporters = array();

		foreach ( $placements as $placement ) {
			if ( abs( ( $placement['z'] + $placement['height'] ) - $candidate['z'] ) > self::EPSILON ) {
				continue;
			}
			$x_overlap = min( $candidate['x'] + $candidate['length'], $placement['x'] + $placement['length'] ) - max( $candidate['x'], $placement['x'] );
			$y_overlap = min( $candidate['y'] + $candidate['width'], $placement['y'] + $placement['width'] ) - max( $candidate['y'], $placement['y'] );
			if ( $x_overlap > self::EPSILON && $y_overlap > self::EPSILON ) {
				$covered      += $x_overlap * $y_overlap;
				$max_level     = max( $max_level, (int) $placement['stack_level'] );
				$supporters[]  = $placement;
			}
		}

		if ( $covered + self::EPSILON < $base_area || empty( $supporters ) ) {
			return false;
		}

		$level = $max_level + 1;
		if ( $level > $carton['max_stack'] ) {
			return false;
		}
		foreach ( $supporters as $supporter ) {
			if ( ! $supporter['stackable'] || $level > $supporter['max_stack'] ) {
				return false;
			}
		}

		return $level;
	}

	/** @return array<int,array<string,mixed>> */
	private static function update_points( array $points, array $new, array $placements, array $container ) {
		$points[] = array( 'x' => $new['x'] + $new['length'], 'y' => $new['y'], 'z' => $new['z'] );
		$points[] = array( 'x' => $new['x'], 'y' => $new['y'] + $new['width'], 'z' => $new['z'] );
		$points[] = array( 'x' => $new['x'], 'y' => $new['y'], 'z' => $new['z'] + $new['height'] );

		$unique = array();
		foreach ( $points as $point ) {
			if ( abs( $point['x'] - $new['x'] ) <= self::EPSILON && abs( $point['y'] - $new['y'] ) <= self::EPSILON && abs( $point['z'] - $new['z'] ) <= self::EPSILON ) {
				continue;
			}
			if ( $point['x'] < -self::EPSILON || $point['y'] < -self::EPSILON || $point['z'] < -self::EPSILON ||
				$point['x'] >= $container['length'] - self::EPSILON || $point['y'] >= $container['width'] - self::EPSILON || $point['z'] >= $container['height'] - self::EPSILON ) {
				continue;
			}
			// Existing points were already checked against every prior placement.
			// Only the newly placed carton can invalidate them now. Checking the
			// full placement list here made large carts O(n^3).
			if ( self::point_inside_box( $point, $new ) ) {
				continue;
			}
			$key            = sprintf( '%.6F:%.6F:%.6F', $point['x'], $point['y'], $point['z'] );
			$unique[ $key ] = array( 'x' => (float) $point['x'], 'y' => (float) $point['y'], 'z' => (float) $point['z'] );
		}

		$points = array_values( $unique );
		usort( $points, array( __CLASS__, 'compare_points' ) );
		return $points;
	}

	private static function point_inside_box( array $point, array $box ) {
		return $point['x'] > $box['x'] + self::EPSILON && $point['x'] < $box['x'] + $box['length'] - self::EPSILON &&
			$point['y'] > $box['y'] + self::EPSILON && $point['y'] < $box['y'] + $box['width'] - self::EPSILON &&
			$point['z'] > $box['z'] + self::EPSILON && $point['z'] < $box['z'] + $box['height'] - self::EPSILON;
	}

	private static function point_inside_any( array $point, array $placements ) {
		foreach ( $placements as $box ) {
			if ( $point['x'] > $box['x'] + self::EPSILON && $point['x'] < $box['x'] + $box['length'] - self::EPSILON &&
				$point['y'] > $box['y'] + self::EPSILON && $point['y'] < $box['y'] + $box['width'] - self::EPSILON &&
				$point['z'] > $box['z'] + self::EPSILON && $point['z'] < $box['z'] + $box['height'] - self::EPSILON ) {
				return true;
			}
		}
		return false;
	}

	private static function within_container( array $box, array $container ) {
		return $box['x'] + $box['length'] <= $container['length'] + self::EPSILON &&
			$box['y'] + $box['width'] <= $container['width'] + self::EPSILON &&
			$box['z'] + $box['height'] <= $container['height'] + self::EPSILON;
	}

	private static function overlaps_any( array $box, array $placements ) {
		foreach ( $placements as $other ) {
			if ( $box['x'] < $other['x'] + $other['length'] - self::EPSILON && $box['x'] + $box['length'] > $other['x'] + self::EPSILON &&
				$box['y'] < $other['y'] + $other['width'] - self::EPSILON && $box['y'] + $box['width'] > $other['y'] + self::EPSILON &&
				$box['z'] < $other['z'] + $other['height'] - self::EPSILON && $box['z'] + $box['height'] > $other['z'] + self::EPSILON ) {
				return true;
			}
		}
		return false;
	}

	/** @return array<int,array<string,mixed>> */
	private static function oriented_dimensions( array $carton ) {
		$axis = array( 'L' => $carton['length'], 'W' => $carton['width'], 'H' => $carton['height'] );
		$out  = array();
		$seen = array();
		foreach ( $carton['orientations'] as $name ) {
			$key = sprintf( '%.6F:%.6F:%.6F', $axis[ $name[0] ], $axis[ $name[1] ], $axis[ $name[2] ] );
			if ( isset( $seen[ $key ] ) ) {
				continue;
			}
			$seen[ $key ] = true;
			$out[]        = array(
				'orientation' => $name,
				'length'      => $axis[ $name[0] ],
				'width'       => $axis[ $name[1] ],
				'height'      => $axis[ $name[2] ],
			);
		}
		return $out;
	}

	/** @return string[] */
	private static function orientations( array $line ) {
		$value = self::first( $line, array( 'orientations', 'allowed_orientations' ), null );
		if ( null === $value ) {
			$value = isset( $line['allow_rotation'] ) && self::to_bool( $line['allow_rotation'] ) ? self::$orientation_names : array( 'LWH' );
		}
		if ( is_string( $value ) ) {
			$value = preg_split( '/[\s,|]+/', strtoupper( trim( $value ) ) );
		}
		if ( ! is_array( $value ) ) {
			throw new InvalidArgumentException( 'Allowed orientations must be an array or delimited string.' );
		}
		$value = array_values( array_unique( array_map( 'strtoupper', array_map( 'strval', $value ) ) ) );
		$value = array_values( array_intersect( self::$orientation_names, $value ) );
		if ( empty( $value ) ) {
			throw new InvalidArgumentException( 'At least one valid carton orientation is required.' );
		}
		return $value;
	}

	/** @return array<string,mixed> */
	private static function unpacked_carton( array $carton, $reason ) {
		return array(
			'line_key'         => $carton['line_key'],
			'carton_key'       => $carton['carton_key'],
			'carton_index'     => $carton['carton_index'],
			'product_id'       => $carton['product_id'],
			'variation_id'     => $carton['variation_id'],
			'sku'              => $carton['sku'],
			'name'             => $carton['name'],
			'units_per_carton' => $carton['units_per_carton'],
			'net_weight'       => $carton['net_weight'],
			'gross_weight'     => $carton['gross_weight'],
			'cbm'              => $carton['cbm'],
			'reason'           => (string) $reason,
		);
	}

	/** Map internal detail codes to the stable cart-validation reason. */
	private static function public_reason( array $violations ) {
		if ( 1 !== count( $violations ) ) {
			return 'multiple_limits';
		}
		$map = array(
			'payload_limit' => 'payload',
			'volume_limit'  => 'volume',
			'cannot_place'  => 'dimensions',
		);
		return isset( $map[ $violations[0] ] ) ? $map[ $violations[0] ] : $violations[0];
	}

	/** Build camelCase aliases consumed by the optional browser Web Worker. */
	private static function worker_input( array $items, array $container ) {
		$worker_items = array();
		foreach ( $items as $item ) {
			if ( ! is_array( $item ) ) {
				continue;
			}
			$copy = $item;
			$copy['allowedOrientations'] = self::orientations( $item );
			$copy['grossWeight'] = self::first( $item, array( 'gross_weight', 'carton_gross_weight' ), 0 );
			$copy['maxStack']    = self::first( $item, array( 'max_stack' ), PHP_INT_MAX );
			$worker_items[]      = $copy;
		}
		return array(
			'items'     => $worker_items,
			'container' => array(
				'id'           => $container['id'],
				'length'       => $container['length'],
				'width'        => $container['width'],
				'height'       => $container['height'],
				'maxPayload'   => $container['max_payload'],
				'capacityCbm'  => $container['capacity_cbm'],
				'volumeMargin' => $container['volume_margin_percent'],
				'weightMargin' => $container['weight_margin_percent'],
			),
		);
	}

	private static function compare_points( $a, $b ) {
		return self::compare_scores( array( $a['z'], $a['y'], $a['x'] ), array( $b['z'], $b['y'], $b['x'] ) );
	}

	private static function compare_scores( array $a, array $b ) {
		foreach ( $a as $index => $value ) {
			$other = $b[ $index ];
			if ( is_string( $value ) ) {
				$comparison = strcmp( $value, $other );
				if ( 0 !== $comparison ) {
					return $comparison;
				}
			} elseif ( abs( $value - $other ) > self::EPSILON ) {
				return $value < $other ? -1 : 1;
			}
		}
		return 0;
	}

	private static function first( array $source, array $keys, $default = null ) {
		foreach ( $keys as $key ) {
			if ( array_key_exists( $key, $source ) ) {
				return $source[ $key ];
			}
		}
		return $default;
	}

	private static function positive_number( $value, $label ) {
		if ( ! is_numeric( $value ) || ! is_finite( (float) $value ) || (float) $value <= 0 ) {
			throw new InvalidArgumentException( ucfirst( $label ) . ' must be a positive number.' );
		}
		return (float) $value;
	}

	private static function nonnegative_number( $value, $label ) {
		if ( ! is_numeric( $value ) || ! is_finite( (float) $value ) || (float) $value < 0 ) {
			throw new InvalidArgumentException( ucfirst( $label ) . ' must be zero or a positive number.' );
		}
		return (float) $value;
	}

	private static function positive_integer( $value, $label ) {
		if ( ! is_numeric( $value ) || (int) $value != $value || (int) $value <= 0 ) { // phpcs:ignore WordPress.PHP.StrictComparisons.LooseComparison
			throw new InvalidArgumentException( ucfirst( $label ) . ' must be a positive whole number.' );
		}
		return (int) $value;
	}

	private static function margin( $value, $label ) {
		if ( ! is_numeric( $value ) || ! is_finite( (float) $value ) || (float) $value < 0 || (float) $value >= 100 ) {
			throw new InvalidArgumentException( ucfirst( $label ) . ' must be between 0 and less than 100 percent.' );
		}
		return (float) $value;
	}

	private static function to_bool( $value ) {
		if ( is_string( $value ) ) {
			return in_array( strtolower( $value ), array( '1', 'true', 'yes', 'on' ), true );
		}
		return (bool) $value;
	}

	private static function round_measure( $value ) {
		return round( (float) $value, 6 );
	}
}
