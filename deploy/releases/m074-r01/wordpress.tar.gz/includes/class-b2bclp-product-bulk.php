<?php
/** Round-trip WooCommerce product and carton-data export/import with column mapping. */

defined( 'ABSPATH' ) || exit;

final class B2BCLP_Product_Bulk {
	const PAGE_SLUG = 'b2bclp-product-data';
	const TTL       = 2 * HOUR_IN_SECONDS;
	const MAX_ROWS  = 50000;

	private static $messages = array();
	private static $errors   = array();

	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'menu' ), 62 );
		add_action( 'admin_init', array( __CLASS__, 'handle_page_actions' ) );
		add_action( 'admin_post_b2bclp_product_export', array( __CLASS__, 'export' ) );
		add_action( 'admin_post_b2bclp_product_apply', array( __CLASS__, 'apply' ) );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'assets' ) );
	}

	public static function menu() {
		add_submenu_page( 'woocommerce', __( 'Product Packing Data', 'b2b-container-loading-planner' ), __( 'Product Packing Data', 'b2b-container-loading-planner' ), 'manage_woocommerce', self::PAGE_SLUG, array( __CLASS__, 'render' ) );
	}

	public static function assets( $hook ) {
		if ( 'woocommerce_page_' . self::PAGE_SLUG !== $hook ) {
			return;
		}
		wp_enqueue_style( 'woocommerce_admin_styles' );
		wp_enqueue_script( 'wc-enhanced-select' );
		wp_enqueue_style( 'b2bclp-import', B2BCLP_URL . 'assets/css/admin-import.css', array(), B2BCLP_VERSION );
	}

	public static function handle_page_actions() {
		if ( ! is_admin() || ! current_user_can( 'manage_woocommerce' ) ) {
			return;
		}
		if ( ! empty( $_POST['b2bclp_product_upload'] ) ) {
			self::upload();
		} elseif ( ! empty( $_POST['b2bclp_product_preview'] ) ) {
			self::preview();
		}
	}

	public static function export() {
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_die( esc_html__( 'You do not have permission to export product data.', 'b2b-container-loading-planner' ) );
		}
		check_admin_referer( 'b2bclp_product_export', 'b2bclp_product_export_nonce' );
		$scope       = isset( $_POST['scope'] ) ? sanitize_key( wp_unslash( $_POST['scope'] ) ) : 'all';
		$category_id = isset( $_POST['category_id'] ) ? absint( $_POST['category_id'] ) : 0;
		$product_ids = isset( $_POST['product_ids'] ) ? array_filter( array_map( 'absint', (array) wp_unslash( $_POST['product_ids'] ) ) ) : array();
		$group_id    = self::valid_group_id( isset( $_POST['group_id'] ) ? absint( $_POST['group_id'] ) : 0 );
		$include_variations = ! empty( $_POST['include_variations'] );

		$args = array( 'limit' => -1, 'status' => array( 'publish', 'private', 'draft', 'pending' ), 'orderby' => 'ID', 'order' => 'ASC', 'return' => 'objects' );
		if ( 'products' === $scope ) {
			if ( ! $product_ids ) {
				wp_die( esc_html__( 'Select at least one product to export.', 'b2b-container-loading-planner' ) );
			}
			$args['include'] = $product_ids;
		} elseif ( 'category' === $scope ) {
			$term = get_term( $category_id, 'product_cat' );
			if ( ! $term || is_wp_error( $term ) ) {
				wp_die( esc_html__( 'Select a valid product category.', 'b2b-container-loading-planner' ) );
			}
			$args['category'] = array( $term->slug );
		}

		$products = wc_get_products( $args );
		$expanded = array();
		foreach ( $products as $product ) {
			$expanded[ $product->get_id() ] = $product;
			if ( $include_variations && $product->is_type( 'variable' ) ) {
				foreach ( $product->get_children() as $variation_id ) {
					$variation = wc_get_product( $variation_id );
					if ( $variation ) {
						$expanded[ $variation_id ] = $variation;
					}
				}
			}
		}
		if ( ! $expanded ) {
			wp_die( esc_html__( 'No products matched the export selection.', 'b2b-container-loading-planner' ) );
		}

		$headers = array_values( self::export_headers() );
		$rows = array( $headers );
		foreach ( $expanded as $product ) {
			$rows[] = self::export_row( $product, $group_id );
		}
		$instructions = array(
			array( __( 'B2B Product and Packing Data', 'b2b-container-loading-planner' ) ),
			array( __( 'Edit the Products sheet, keep Product ID unchanged, then upload the workbook under WooCommerce > Product Packing Data.', 'b2b-container-loading-planner' ) ),
			array( __( 'Product ID matches products even when SKU is empty. Variable-product packing belongs on each variation row.', 'b2b-container-loading-planner' ) ),
			array( __( 'Enter either all three carton dimensions (cm) or Carton CBM. Dimensions enable 3D placement; direct CBM is accepted as a volume-only estimate.', 'b2b-container-loading-planner' ) ),
			array( __( 'Carton net and gross weight are optional. Missing gross weight is excluded from payload totals and shown as a warning.', 'b2b-container-loading-planner' ) ),
			array( __( 'All six carton orientations are enabled automatically. Change only exceptional rows that have rotation restrictions.', 'b2b-container-loading-planner' ) ),
			array( __( 'Blank editable cells keep their existing WooCommerce value during import.', 'b2b-container-loading-planner' ) ),
		);
		$temp = wp_tempnam( 'b2bclp-product-data.xlsx' );
		try {
			B2BCLP_Spreadsheet_Writer::create( $temp, array( 'Products' => $rows, 'Instructions' => $instructions ) );
			header( 'Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' );
			header( 'Content-Disposition: attachment; filename="b2b-product-packing-data-' . gmdate( 'Y-m-d-His' ) . '.xlsx"' );
			header( 'Content-Length: ' . filesize( $temp ) );
			readfile( $temp ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_readfile
		} finally {
			if ( is_file( $temp ) ) {
				unlink( $temp ); // phpcs:ignore WordPress.WP.AlternativeFunctions.unlink_unlink
			}
		}
		exit;
	}

	private static function upload() {
		check_admin_referer( 'b2bclp_product_upload', 'b2bclp_product_upload_nonce' );
		$file = isset( $_FILES['b2bclp_product_file'] ) ? $_FILES['b2bclp_product_file'] : array(); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		if ( empty( $file['tmp_name'] ) || UPLOAD_ERR_OK !== (int) ( $file['error'] ?? UPLOAD_ERR_NO_FILE ) ) {
			self::$errors[] = __( 'Choose a valid XLSX or CSV product-data file.', 'b2b-container-loading-planner' );
			return;
		}
		if ( (int) ( $file['size'] ?? 0 ) < 1 || (int) $file['size'] > B2BCLP_Import::MAX_FILE_BYTES ) {
			self::$errors[] = __( 'The import file must be smaller than 256 MB.', 'b2b-container-loading-planner' );
			return;
		}
		$name = sanitize_file_name( wp_unslash( $file['name'] ) );
		$extension = strtolower( pathinfo( $name, PATHINFO_EXTENSION ) );
		if ( ! in_array( $extension, array( 'xlsx', 'csv' ), true ) ) {
			self::$errors[] = __( 'Only .xlsx and .csv files are supported.', 'b2b-container-loading-planner' );
			return;
		}
		try {
			$workbook = B2BCLP_Spreadsheet_Reader::read_workbook( $file['tmp_name'], $extension );
			$best = array();
			foreach ( $workbook as $sheet_name => $rows ) {
				if ( count( $rows ) > self::MAX_ROWS ) {
					throw new RuntimeException( sprintf( __( 'Sheet %s exceeds the 50,000-row product import limit.', 'b2b-container-loading-planner' ), $sheet_name ) );
				}
				$header_index = self::detect_header( $rows );
				$headers = $rows[ $header_index ] ?? array();
				$score = count( array_filter( array_map( array( __CLASS__, 'auto_field' ), $headers ) ) );
				if ( ! $best || $score > $best['score'] ) {
					$best = compact( 'sheet_name', 'rows', 'header_index', 'headers', 'score' );
				}
			}
			if ( ! $best || $best['score'] < 1 ) {
				throw new RuntimeException( __( 'No recognizable product columns were found. Upload a file with Product ID, SKU, or Product Name.', 'b2b-container-loading-planner' ) );
			}
			$best['filename'] = $name;
			$best['group_id'] = self::valid_group_id( isset( $_POST['group_id'] ) ? absint( $_POST['group_id'] ) : 0 );
			if ( ! $best['group_id'] ) {
				foreach ( $best['headers'] as $column => $header ) {
					$key = trim( preg_replace( '/[^\p{L}\p{N}]+/u', '_', strtolower( (string) $header ) ), '_' );
					if ( in_array( $key, array( 'b2b_group_id', 'b2bking_group_id' ), true ) ) {
						$best['group_id'] = self::valid_group_id( absint( $best['rows'][ $best['header_index'] + 1 ][ $column ] ?? 0 ) );
						break;
					}
				}
			}
			$best['auto_map'] = array_map( array( __CLASS__, 'auto_field' ), $best['headers'] );
			set_transient( self::key( 'upload' ), $best, self::TTL );
			delete_transient( self::key( 'preview' ) );
			self::$messages[] = sprintf( __( 'File read successfully. Review the column mapping for sheet “%s”.', 'b2b-container-loading-planner' ), $best['sheet_name'] );
		} catch ( Exception $exception ) {
			self::$errors[] = $exception->getMessage();
		}
	}

	private static function preview() {
		check_admin_referer( 'b2bclp_product_mapping', 'b2bclp_product_mapping_nonce' );
		$upload = get_transient( self::key( 'upload' ) );
		if ( ! is_array( $upload ) ) {
			self::$errors[] = __( 'Upload the product-data file again before mapping it.', 'b2b-container-loading-planner' );
			return;
		}
		$mapping = isset( $_POST['mapping'] ) ? array_map( 'sanitize_key', (array) wp_unslash( $_POST['mapping'] ) ) : array();
		$allowed = array_keys( self::fields() );
		$used = array();
		foreach ( $mapping as $index => $field ) {
			if ( '' !== $field && ( ! in_array( $field, $allowed, true ) || isset( $used[ $field ] ) ) ) {
				$mapping[ $index ] = '';
			} elseif ( '' !== $field ) {
				$used[ $field ] = true;
			}
		}
		if ( ! isset( $used['product_id'] ) && ! isset( $used['sku'] ) && ! isset( $used['name'] ) ) {
			self::$errors[] = __( 'Map at least one identity field: Product ID, SKU, or Product Name.', 'b2b-container-loading-planner' );
			return;
		}
		$group_id = self::valid_group_id( isset( $_POST['group_id'] ) ? absint( $_POST['group_id'] ) : ( $upload['group_id'] ?? 0 ) );
		$preview = array( 'filename' => $upload['filename'], 'sheet_name' => $upload['sheet_name'], 'mapping' => $mapping, 'group_id' => $group_id, 'rows' => array() );
		$data_rows = array_slice( $upload['rows'], $upload['header_index'] + 1 );
		foreach ( $data_rows as $offset => $row ) {
			$values = array();
			foreach ( $mapping as $index => $field ) {
				if ( '' !== $field && isset( $row[ $index ] ) && '' !== trim( (string) $row[ $index ] ) ) {
					$values[ $field ] = trim( (string) $row[ $index ] );
				}
			}
			if ( ! $values ) {
				continue;
			}
			$preview['rows'][] = self::prepare_row( $values, $offset + $upload['header_index'] + 2, $group_id );
		}
		set_transient( self::key( 'preview' ), $preview, self::TTL );
		self::$messages[] = sprintf( __( 'Preview ready: %1$d rows, %2$d rows can be updated.', 'b2b-container-loading-planner' ), count( $preview['rows'] ), count( array_filter( $preview['rows'], function ( $row ) { return empty( $row['errors'] ); } ) ) );
	}

	public static function apply() {
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_die( esc_html__( 'You do not have permission to update products.', 'b2b-container-loading-planner' ) );
		}
		check_admin_referer( 'b2bclp_product_apply', 'b2bclp_product_apply_nonce' );
		$preview = get_transient( self::key( 'preview' ) );
		$selected = isset( $_POST['rows'] ) ? array_map( 'absint', (array) wp_unslash( $_POST['rows'] ) ) : array();
		if ( ! is_array( $preview ) || ! $selected ) {
			wp_safe_redirect( add_query_arg( array( 'page' => self::PAGE_SLUG, 'b2bclp_updated' => 0 ), admin_url( 'admin.php' ) ) );
			exit;
		}
		$updated = 0;
		$failed  = 0;
		foreach ( $selected as $index ) {
			$row = $preview['rows'][ $index ] ?? array();
			if ( empty( $row['product_id'] ) || ! empty( $row['errors'] ) ) {
				$failed++;
				continue;
			}
			$product = wc_get_product( $row['product_id'] );
			if ( ! $product ) {
				$failed++;
				continue;
			}
			try {
				self::apply_values( $product, $row['values'], (int) $preview['group_id'] );
				$updated++;
			} catch ( Exception $exception ) {
				$failed++;
			}
		}
		delete_transient( self::key( 'preview' ) );
		wp_safe_redirect( add_query_arg( array( 'page' => self::PAGE_SLUG, 'b2bclp_updated' => $updated, 'b2bclp_failed' => $failed ), admin_url( 'admin.php' ) ) );
		exit;
	}

	private static function prepare_row( array $values, $row_number, $group_id ) {
		$errors = array();
		$product = self::match_product( $values, $errors );
		if ( $product ) {
			if ( isset( $values['sku'] ) && '' !== $values['sku'] ) {
				$other = wc_get_product_id_by_sku( wc_clean( $values['sku'] ) );
				if ( $other && (int) $other !== $product->get_id() ) {
					$errors[] = __( 'SKU belongs to another product.', 'b2b-container-loading-planner' );
				}
			}
			self::validate_values( $values, $product, $group_id, $errors );
		}
		return array( 'row_number' => $row_number, 'product_id' => $product ? $product->get_id() : 0, 'current_name' => $product ? $product->get_name() : '', 'current_sku' => $product ? $product->get_sku() : '', 'values' => $values, 'changes' => $product ? self::changes( $product, $values, $group_id ) : array(), 'errors' => $errors );
	}

	private static function match_product( array $values, array &$errors ) {
		if ( ! empty( $values['product_id'] ) ) {
			$product = wc_get_product( absint( $values['product_id'] ) );
			if ( $product ) {
				return $product;
			}
			$errors[] = __( 'Product ID was not found.', 'b2b-container-loading-planner' );
			return false;
		}
		if ( ! empty( $values['sku'] ) ) {
			$id = wc_get_product_id_by_sku( wc_clean( $values['sku'] ) );
			if ( $id ) {
				return wc_get_product( $id );
			}
			$errors[] = __( 'SKU was not found.', 'b2b-container-loading-planner' );
			return false;
		}
		if ( ! empty( $values['name'] ) ) {
			global $wpdb;
			$ids = $wpdb->get_col( $wpdb->prepare( "SELECT ID FROM {$wpdb->posts} WHERE post_title = %s AND post_type IN ('product','product_variation') AND post_status NOT IN ('trash','auto-draft') LIMIT 2", sanitize_text_field( $values['name'] ) ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
			if ( 1 === count( $ids ) ) {
				return wc_get_product( (int) $ids[0] );
			}
			$errors[] = count( $ids ) > 1 ? __( 'Product name is ambiguous; map Product ID or SKU.', 'b2b-container-loading-planner' ) : __( 'Product name was not found.', 'b2b-container-loading-planner' );
		}
		return false;
	}

	private static function validate_values( array $values, $product, $group_id, array &$errors ) {
		$integer_fields = array( 'units_per_carton' );
		$decimal_fields = array( 'regular_price', 'b2b_regular_price', 'b2b_sale_price', 'carton_length', 'carton_width', 'carton_height', 'carton_cbm', 'carton_net_weight', 'carton_gross_weight' );
		foreach ( $integer_fields as $field ) {
			if ( isset( $values[ $field ] ) && ( ! ctype_digit( $values[ $field ] ) || (int) $values[ $field ] < 1 ) ) {
				$errors[] = sprintf( __( '%s must be a positive whole number.', 'b2b-container-loading-planner' ), self::fields()[ $field ] );
			}
		}
		foreach ( $decimal_fields as $field ) {
			if ( isset( $values[ $field ] ) && ( ! is_numeric( str_replace( ',', '', $values[ $field ] ) ) || (float) str_replace( ',', '', $values[ $field ] ) < 0 ) ) {
				$errors[] = sprintf( __( '%s must be a non-negative number.', 'b2b-container-loading-planner' ), self::fields()[ $field ] );
			}
		}
		if ( isset( $values['orientations'] ) ) {
			$orientations = array_filter( array_map( 'trim', explode( ',', strtolower( $values['orientations'] ) ) ) );
			if ( ! $orientations || array_diff( $orientations, B2BCLP_Product_Fields::ORIENTATIONS ) ) {
				$errors[] = __( 'Allowed Orientations contains an invalid code.', 'b2b-container-loading-planner' );
			}
		}
		if ( isset( $values['categories'] ) && ! $product->is_type( 'variation' ) ) {
			foreach ( self::category_tokens( $values['categories'] ) as $category ) {
				if ( ! get_term_by( 'name', $category, 'product_cat' ) && ! get_term_by( 'slug', sanitize_title( $category ), 'product_cat' ) ) {
					$errors[] = sprintf( __( 'Category “%s” does not exist.', 'b2b-container-loading-planner' ), $category );
				}
			}
		}
		if ( ( isset( $values['b2b_regular_price'] ) || isset( $values['b2b_sale_price'] ) ) && ! $group_id ) {
			$errors[] = __( 'Choose a B2BKing group before importing B2B prices.', 'b2b-container-loading-planner' );
		}
		$profile = B2BCLP_Product_Fields::get_profile( $product );
		$dimension_values = array(
			isset( $values['carton_length'] ) ? (float) $values['carton_length'] : (float) ( $profile['carton_length'] ?? 0 ),
			isset( $values['carton_width'] ) ? (float) $values['carton_width'] : (float) ( $profile['carton_width'] ?? 0 ),
			isset( $values['carton_height'] ) ? (float) $values['carton_height'] : (float) ( $profile['carton_height'] ?? 0 ),
		);
		$dimension_count = count( array_filter( $dimension_values, function ( $value ) { return $value > 0; } ) );
		if ( $dimension_count > 0 && $dimension_count < 3 ) {
			$errors[] = __( 'Enter all three carton dimensions, or leave all three empty and use Carton CBM.', 'b2b-container-loading-planner' );
		}
		$net = isset( $values['carton_net_weight'] ) ? (float) $values['carton_net_weight'] : (float) ( $profile['carton_net_weight'] ?? 0 );
		$gross = isset( $values['carton_gross_weight'] ) ? (float) $values['carton_gross_weight'] : (float) ( $profile['carton_gross_weight'] ?? 0 );
		if ( $gross > 0 && $gross < $net ) {
			$errors[] = __( 'Carton gross weight cannot be lower than carton net weight.', 'b2b-container-loading-planner' );
		}
	}

	private static function apply_values( $product, array $values, $group_id ) {
		if ( isset( $values['sku'] ) ) { $product->set_sku( wc_clean( $values['sku'] ) ); }
		if ( isset( $values['name'] ) ) { $product->set_name( sanitize_text_field( $values['name'] ) ); }
		if ( isset( $values['description'] ) ) { $product->set_description( wp_kses_post( $values['description'] ) ); }
		if ( isset( $values['regular_price'] ) ) { $product->set_regular_price( wc_format_decimal( $values['regular_price'] ) ); }
		if ( isset( $values['categories'] ) && ! $product->is_type( 'variation' ) ) { $product->set_category_ids( self::category_ids( $values['categories'] ) ); }

		$packing_fields = array( 'units_per_carton', 'carton_length', 'carton_width', 'carton_height', 'carton_cbm', 'carton_net_weight', 'carton_gross_weight', 'orientations' );
		$has_packing = (bool) array_intersect( array_keys( $values ), $packing_fields );
		if ( $has_packing ) {
			$current = B2BCLP_Product_Fields::get_profile( $product );
			$raw = array(
				'units_per_carton'   => $values['units_per_carton'] ?? $current['units_per_carton'],
				'carton_length'      => $values['carton_length'] ?? $current['carton_length'],
				'carton_width'       => $values['carton_width'] ?? $current['carton_width'],
				'carton_height'      => $values['carton_height'] ?? $current['carton_height'],
				'carton_cbm'         => $values['carton_cbm'] ?? $current['carton_cbm'],
				'carton_net_weight'  => $values['carton_net_weight'] ?? $current['carton_net_weight'],
				'carton_gross_weight'=> $values['carton_gross_weight'] ?? $current['carton_gross_weight'],
				'orientations'       => $values['orientations'] ?? $current['allowed_orientations'],
				'orientation_customized' => isset( $values['orientations'] ) || ! empty( $current['orientation_customized'] ),
				'packing_approved'   => 'yes',
			);
			$profile = B2BCLP_Product_Fields::sanitize_profile( $raw );
			foreach ( array( 'units_per_carton', 'carton_length', 'carton_width', 'carton_height', 'carton_cbm', 'carton_net_weight', 'carton_gross_weight' ) as $field ) {
				$product->update_meta_data( '_b2bclp_' . $field, $profile[ $field ] );
			}
			$product->update_meta_data( '_b2bclp_orientations', $profile['allowed_orientations'] );
			$product->update_meta_data( '_b2bclp_orientation_customized', $profile['orientation_customized'] ? 'yes' : 'no' );
			$product->update_meta_data( '_b2bclp_packing_approved', $profile['approved'] );
			$product->update_meta_data( '_b2bclp_packing_complete', $profile['complete'] ? 'yes' : 'no' );
		}
		if ( $group_id && isset( $values['b2b_regular_price'] ) ) { $product->update_meta_data( 'b2bking_regular_product_price_group_' . $group_id, wc_format_decimal( $values['b2b_regular_price'] ) ); }
		if ( $group_id && isset( $values['b2b_sale_price'] ) ) { $product->update_meta_data( 'b2bking_sale_product_price_group_' . $group_id, wc_format_decimal( $values['b2b_sale_price'] ) ); }
		$product->update_meta_data( '_b2bclp_last_bulk_imported_at', gmdate( 'c' ) );
		$product->update_meta_data( '_b2bclp_last_bulk_imported_by', get_current_user_id() );
		$product->save();
	}

	private static function export_row( $product, $group_id ) {
		$profile = B2BCLP_Product_Fields::get_profile( $product );
		$category_product = $product->is_type( 'variation' ) ? wc_get_product( $product->get_parent_id() ) : $product;
		$categories = $category_product ? wp_get_post_terms( $category_product->get_id(), 'product_cat', array( 'fields' => 'names' ) ) : array();
		return array(
			$product->get_id(), $product->get_parent_id(), $product->get_type(), $product->get_sku(),
			$product->get_name(), $product->get_description(), implode( ' | ', is_wp_error( $categories ) ? array() : $categories ),
			self::number_or_blank( $product->get_regular_price() ), $group_id ?: '',
			$group_id ? self::number_or_blank( $product->get_meta( 'b2bking_regular_product_price_group_' . $group_id, true ) ) : '',
			$group_id ? self::number_or_blank( $product->get_meta( 'b2bking_sale_product_price_group_' . $group_id, true ) ) : '',
			(int) $profile['units_per_carton'] > 0 ? (int) $profile['units_per_carton'] : '',
			self::number_or_blank( $profile['carton_length'] ), self::number_or_blank( $profile['carton_width'] ), self::number_or_blank( $profile['carton_height'] ),
			self::number_or_blank( $profile['carton_cbm'] ), self::number_or_blank( $profile['carton_net_weight'] ), self::number_or_blank( $profile['carton_gross_weight'] ),
			implode( ',', $profile['allowed_orientations'] ), $profile['complete'] ? 'yes' : 'no',
		);
	}

	private static function number_or_blank( $value ) { return '' === (string) $value ? '' : (float) $value; }

	private static function category_ids( $value ) {
		$ids = array();
		foreach ( self::category_tokens( $value ) as $name ) {
			if ( '' === $name ) { continue; }
			$term = get_term_by( 'name', $name, 'product_cat' );
			if ( ! $term ) { $term = get_term_by( 'slug', sanitize_title( $name ), 'product_cat' ); }
			if ( $term ) { $ids[] = (int) $term->term_id; }
		}
		return array_values( array_unique( $ids ) );
	}

	private static function category_tokens( $value ) {
		return array_values( array_filter( array_map( 'trim', preg_split( '/\s*[|,]\s*/', (string) $value ) ) ) );
	}

	private static function changes( $product, array $values, $group_id ) {
		$profile = B2BCLP_Product_Fields::get_profile( $product );
		$current = array(
			'sku' => $product->get_sku(), 'name' => $product->get_name(), 'description' => $product->get_description(), 'regular_price' => $product->get_regular_price(),
			'b2b_regular_price' => $group_id ? $product->get_meta( 'b2bking_regular_product_price_group_' . $group_id, true ) : '', 'b2b_sale_price' => $group_id ? $product->get_meta( 'b2bking_sale_product_price_group_' . $group_id, true ) : '',
			'units_per_carton' => $profile['units_per_carton'], 'carton_length' => $profile['carton_length'], 'carton_width' => $profile['carton_width'], 'carton_height' => $profile['carton_height'], 'carton_cbm' => $profile['carton_cbm'], 'carton_net_weight' => $profile['carton_net_weight'], 'carton_gross_weight' => $profile['carton_gross_weight'], 'orientations' => implode( ',', $profile['allowed_orientations'] ),
		);
		$categories = wp_get_post_terms( $product->get_id(), 'product_cat', array( 'fields' => 'names' ) );
		$current['categories'] = implode( ' | ', is_wp_error( $categories ) ? array() : $categories );
		$changes = array();
		foreach ( $values as $field => $value ) {
			if ( in_array( $field, array( 'product_id' ), true ) || ! array_key_exists( $field, $current ) ) { continue; }
			if ( 'categories' === $field && $product->is_type( 'variation' ) ) { continue; }
			$before = trim( (string) $current[ $field ] );
			$after  = trim( (string) $value );
			if ( in_array( $field, array( 'regular_price', 'b2b_regular_price', 'b2b_sale_price', 'carton_length', 'carton_width', 'carton_height', 'carton_cbm', 'carton_net_weight', 'carton_gross_weight' ), true ) && is_numeric( $before ) && is_numeric( $after ) ) {
				$same = abs( (float) $before - (float) $after ) < 0.000001;
			} else {
				$same = $before === $after;
			}
			if ( ! $same ) { $changes[] = ( self::fields()[ $field ] ?? $field ) . ': ' . ( '' === $before ? '—' : $before ) . ' → ' . ( '' === $after ? '—' : $after ); }
		}
		return $changes;
	}

	private static function detect_header( array $rows ) {
		$best_index = 0; $best_score = -1;
		foreach ( array_slice( $rows, 0, 30, true ) as $index => $row ) {
			$score = count( array_filter( array_map( array( __CLASS__, 'auto_field' ), $row ) ) );
			if ( $score > $best_score ) { $best_score = $score; $best_index = (int) $index; }
		}
		return $best_index;
	}

	public static function auto_field( $header ) {
		$key = trim( preg_replace( '/[^\p{L}\p{N}]+/u', '_', strtolower( (string) $header ) ), '_' );
		$aliases = array(
			'product_id' => array( 'product_id', 'id', 'woocommerce_id', '商品id' ), 'sku' => array( 'sku', 'product_sku', 'code', 'item_code', '货号', '产品编号' ), 'name' => array( 'name', 'product_name', 'item_name', '品名', '产品名称' ), 'description' => array( 'description', 'product_description', '描述' ), 'categories' => array( 'category', 'categories', 'product_category', '分类' ), 'regular_price' => array( 'regular_price', 'price', 'retail_price', '价格' ), 'b2b_regular_price' => array( 'b2b_price', 'b2b_regular_price', 'wholesale_price', '批发价' ), 'b2b_sale_price' => array( 'b2b_sale_price', 'wholesale_sale_price' ), 'units_per_carton' => array( 'units_per_carton', 'pcs_box', 'pcs_per_box', 'qty_carton', '每箱数量' ), 'carton_length' => array( 'carton_length_cm', 'carton_length', 'box_length_cm', '箱长' ), 'carton_width' => array( 'carton_width_cm', 'carton_width', 'box_width_cm', '箱宽' ), 'carton_height' => array( 'carton_height_cm', 'carton_height', 'box_height_cm', '箱高' ), 'carton_net_weight' => array( 'carton_net_weight_kg', 'carton_net_weight', 'net_weight_kg', '箱净重' ), 'carton_gross_weight' => array( 'carton_gross_weight_kg', 'carton_gross_weight', 'gross_weight_kg', '箱毛重' ), 'orientations' => array( 'allowed_orientations', 'orientations' ),
		);
		$aliases['carton_cbm'] = array( 'carton_cbm_m3', 'carton_cbm', 'cbm_per_carton', 'cbm_carton', 'cbm_box', '每箱方数', 'حجم_الكرتون' );
		foreach ( $aliases as $field => $values ) { if ( in_array( $key, $values, true ) ) { return $field; } }
		return '';
	}

	private static function export_headers() {
		return array( 'product_id' => 'Product ID', 'parent_id' => 'Parent ID', 'type' => 'Product Type', 'sku' => 'SKU', 'name' => 'Name', 'description' => 'Description', 'categories' => 'Categories', 'regular_price' => 'Regular Price', 'group_id' => 'B2B Group ID', 'b2b_regular_price' => 'B2B Regular Price', 'b2b_sale_price' => 'B2B Sale Price', 'units_per_carton' => 'Units per Carton', 'carton_length' => 'Carton Length (cm)', 'carton_width' => 'Carton Width (cm)', 'carton_height' => 'Carton Height (cm)', 'carton_cbm' => 'Carton CBM (m³)', 'carton_net_weight' => 'Carton Net Weight (kg)', 'carton_gross_weight' => 'Carton Gross Weight (kg)', 'orientations' => 'Allowed Orientations', 'packing_complete' => 'Calculation Ready (read only)' );
	}

	private static function fields() {
		return array( 'carton_cbm' => __( 'Carton CBM (m³)', 'b2b-container-loading-planner' ) ) + self::base_fields();
	}

	private static function base_fields() {
		return array( 'product_id' => __( 'Product ID', 'b2b-container-loading-planner' ), 'sku' => __( 'SKU', 'b2b-container-loading-planner' ), 'name' => __( 'Product Name', 'b2b-container-loading-planner' ), 'description' => __( 'Description', 'b2b-container-loading-planner' ), 'categories' => __( 'Categories', 'b2b-container-loading-planner' ), 'regular_price' => __( 'Regular Price', 'b2b-container-loading-planner' ), 'b2b_regular_price' => __( 'B2B Regular Price', 'b2b-container-loading-planner' ), 'b2b_sale_price' => __( 'B2B Sale Price', 'b2b-container-loading-planner' ), 'units_per_carton' => __( 'Units per Carton', 'b2b-container-loading-planner' ), 'carton_length' => __( 'Carton Length (cm)', 'b2b-container-loading-planner' ), 'carton_width' => __( 'Carton Width (cm)', 'b2b-container-loading-planner' ), 'carton_height' => __( 'Carton Height (cm)', 'b2b-container-loading-planner' ), 'carton_net_weight' => __( 'Carton Net Weight (kg)', 'b2b-container-loading-planner' ), 'carton_gross_weight' => __( 'Carton Gross Weight (kg)', 'b2b-container-loading-planner' ), 'orientations' => __( 'Allowed Orientations', 'b2b-container-loading-planner' ) );
	}

	private static function groups() { return get_posts( array( 'post_type' => 'b2bking_group', 'post_status' => 'publish', 'numberposts' => -1, 'orderby' => 'title', 'order' => 'ASC' ) ); }
	private static function valid_group_id( $id ) { return $id && 'b2bking_group' === get_post_type( $id ) ? (int) $id : 0; }
	private static function key( $type ) { return 'b2bclp_product_' . $type . '_' . get_current_user_id(); }

	public static function render() {
		if ( ! current_user_can( 'manage_woocommerce' ) ) { return; }
		if ( isset( $_GET['b2bclp_updated'] ) ) { self::$messages[] = sprintf( __( '%1$d products updated; %2$d rows failed.', 'b2b-container-loading-planner' ), absint( $_GET['b2bclp_updated'] ), absint( $_GET['b2bclp_failed'] ?? 0 ) ); } // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$upload = get_transient( self::key( 'upload' ) );
		$preview = get_transient( self::key( 'preview' ) );
		$groups = self::groups();
		$categories = get_terms( array( 'taxonomy' => 'product_cat', 'hide_empty' => false ) );
		$categories = is_wp_error( $categories ) ? array() : $categories;
		?>
		<div class="wrap b2bclp-import-admin"><h1><?php esc_html_e( 'Product and Packing Data', 'b2b-container-loading-planner' ); ?></h1><p><?php esc_html_e( 'Export products with their IDs and current values, edit the spreadsheet, then map and preview every change before updating WooCommerce.', 'b2b-container-loading-planner' ); ?></p>
		<?php foreach ( self::$messages as $message ) : ?><div class="notice notice-success"><p><?php echo esc_html( $message ); ?></p></div><?php endforeach; ?><?php foreach ( self::$errors as $error ) : ?><div class="notice notice-error"><p><?php echo esc_html( $error ); ?></p></div><?php endforeach; ?>
		<div class="b2bclp-bulk-cards"><section><h2><?php esc_html_e( '1. Export products', 'b2b-container-loading-planner' ); ?></h2><form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>"><input type="hidden" name="action" value="b2bclp_product_export"><?php wp_nonce_field( 'b2bclp_product_export', 'b2bclp_product_export_nonce' ); ?>
		<p><label><input type="radio" name="scope" value="all" checked> <?php esc_html_e( 'All products', 'b2b-container-loading-planner' ); ?></label> &nbsp; <label><input type="radio" name="scope" value="category"> <?php esc_html_e( 'One category', 'b2b-container-loading-planner' ); ?></label> &nbsp; <label><input type="radio" name="scope" value="products"> <?php esc_html_e( 'Selected products', 'b2b-container-loading-planner' ); ?></label></p>
		<p><label><?php esc_html_e( 'Category', 'b2b-container-loading-planner' ); ?><br><select name="category_id"><option value="0">—</option><?php foreach ( $categories as $term ) : ?><option value="<?php echo esc_attr( $term->term_id ); ?>"><?php echo esc_html( $term->name ); ?></option><?php endforeach; ?></select></label></p>
		<p><label><?php esc_html_e( 'Products', 'b2b-container-loading-planner' ); ?><br><select class="wc-product-search" multiple="multiple" style="width:100%" name="product_ids[]" data-placeholder="<?php esc_attr_e( 'Search for products…', 'woocommerce' ); ?>" data-action="woocommerce_json_search_products_and_variations"></select></label></p>
		<p><label><?php esc_html_e( 'B2BKing price group', 'b2b-container-loading-planner' ); ?><br><?php self::group_select( $groups, 0 ); ?></label></p><p><label><input type="checkbox" name="include_variations" value="1" checked> <?php esc_html_e( 'Include every variation', 'b2b-container-loading-planner' ); ?></label></p><?php submit_button( __( 'Export editable Excel file', 'b2b-container-loading-planner' ), 'primary', 'submit', false ); ?></form></section>
		<section><h2><?php esc_html_e( '2. Upload edited or supplier file', 'b2b-container-loading-planner' ); ?></h2><form method="post" enctype="multipart/form-data"><?php wp_nonce_field( 'b2bclp_product_upload', 'b2bclp_product_upload_nonce' ); ?><p><input type="file" name="b2bclp_product_file" accept=".xlsx,.csv" required></p><p><label><?php esc_html_e( 'B2BKing price group for mapped B2B price columns', 'b2b-container-loading-planner' ); ?><br><?php self::group_select( $groups, 0 ); ?></label></p><?php submit_button( __( 'Upload and map columns', 'b2b-container-loading-planner' ), 'secondary', 'b2bclp_product_upload', false ); ?></form></section></div>
		<?php if ( is_array( $upload ) ) : ?><section class="b2bclp-mapping"><h2><?php esc_html_e( '3. Map spreadsheet columns', 'b2b-container-loading-planner' ); ?></h2><p><?php echo esc_html( sprintf( __( 'File: %1$s — Sheet: %2$s — Header row: %3$d', 'b2b-container-loading-planner' ), $upload['filename'], $upload['sheet_name'], $upload['header_index'] + 1 ) ); ?></p><form method="post"><?php wp_nonce_field( 'b2bclp_product_mapping', 'b2bclp_product_mapping_nonce' ); ?><input type="hidden" name="group_id" value="<?php echo esc_attr( $upload['group_id'] ); ?>"><table class="widefat striped"><thead><tr><th><?php esc_html_e( 'Spreadsheet column', 'b2b-container-loading-planner' ); ?></th><th><?php esc_html_e( 'Example', 'b2b-container-loading-planner' ); ?></th><th><?php esc_html_e( 'WooCommerce field', 'b2b-container-loading-planner' ); ?></th></tr></thead><tbody><?php foreach ( $upload['headers'] as $index => $header ) : ?><tr><td><strong><?php echo esc_html( $header ?: sprintf( __( 'Column %d', 'b2b-container-loading-planner' ), $index + 1 ) ); ?></strong></td><td><?php echo esc_html( $upload['rows'][ $upload['header_index'] + 1 ][ $index ] ?? '' ); ?></td><td><select name="mapping[<?php echo esc_attr( $index ); ?>]"><option value=""><?php esc_html_e( 'Ignore', 'b2b-container-loading-planner' ); ?></option><?php foreach ( self::fields() as $field => $label ) : ?><option value="<?php echo esc_attr( $field ); ?>" <?php selected( $upload['auto_map'][ $index ] ?? '', $field ); ?>><?php echo esc_html( $label ); ?></option><?php endforeach; ?></select></td></tr><?php endforeach; ?></tbody></table><?php submit_button( __( 'Preview changes', 'b2b-container-loading-planner' ), 'primary', 'b2bclp_product_preview' ); ?></form></section><?php endif; ?>
		<?php if ( is_array( $preview ) ) : ?><section class="b2bclp-preview"><h2><?php esc_html_e( '4. Review and apply', 'b2b-container-loading-planner' ); ?></h2><form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>"><input type="hidden" name="action" value="b2bclp_product_apply"><?php wp_nonce_field( 'b2bclp_product_apply', 'b2bclp_product_apply_nonce' ); ?><div class="b2bclp-import-table-wrap"><table class="widefat striped"><thead><tr><th></th><th><?php esc_html_e( 'Row', 'b2b-container-loading-planner' ); ?></th><th><?php esc_html_e( 'Matched product', 'b2b-container-loading-planner' ); ?></th><th><?php esc_html_e( 'SKU', 'b2b-container-loading-planner' ); ?></th><th><?php esc_html_e( 'Proposed changes', 'b2b-container-loading-planner' ); ?></th><th><?php esc_html_e( 'Status', 'b2b-container-loading-planner' ); ?></th></tr></thead><tbody><?php foreach ( $preview['rows'] as $index => $row ) : ?><tr><td><?php if ( empty( $row['errors'] ) && ! empty( $row['changes'] ) ) : ?><input type="checkbox" name="rows[]" value="<?php echo esc_attr( $index ); ?>" checked><?php endif; ?></td><td><?php echo esc_html( $row['row_number'] ); ?></td><td><?php echo esc_html( $row['current_name'] ?: '—' ); ?><?php if ( $row['product_id'] ) : ?> (#<?php echo esc_html( $row['product_id'] ); ?>)<?php endif; ?></td><td><?php echo esc_html( $row['current_sku'] ?: '—' ); ?></td><td><?php echo esc_html( $row['changes'] ? implode( '; ', $row['changes'] ) : __( 'No changes detected', 'b2b-container-loading-planner' ) ); ?></td><td><?php echo $row['errors'] ? '<span class="b2bclp-status-error">' . esc_html( implode( ' ', $row['errors'] ) ) . '</span>' : '<span class="b2bclp-status-ok">' . esc_html__( 'Ready', 'b2b-container-loading-planner' ) . '</span>'; ?></td></tr><?php endforeach; ?></tbody></table></div><?php submit_button( __( 'Update selected products', 'b2b-container-loading-planner' ), 'primary', 'submit', false ); ?></form></section><?php endif; ?></div>
		<?php
	}

	private static function group_select( $groups, $selected ) {
		echo '<select name="group_id"><option value="0">' . esc_html__( 'No B2B price group', 'b2b-container-loading-planner' ) . '</option>';
		foreach ( $groups as $group ) { echo '<option value="' . esc_attr( $group->ID ) . '" ' . selected( $selected, $group->ID, false ) . '>' . esc_html( $group->post_title ) . '</option>'; }
		echo '</select>';
	}
}
