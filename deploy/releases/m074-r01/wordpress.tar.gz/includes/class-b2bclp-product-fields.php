<?php
/**
 * Product and variation packing-profile fields.
 *
 * @package B2B_Container_Loading_Planner
 */

defined( 'ABSPATH' ) || exit;

/**
 * Adds and persists carton packing data on products and variations.
 */
final class B2BCLP_Product_Fields {

	/** Product meta prefix. */
	const PREFIX = '_b2bclp_';

	/** Supported carton orientation codes. */
	const ORIENTATIONS = array( 'lwh', 'lhw', 'wlh', 'whl', 'hlw', 'hwl' );

	/** Register hooks. */
	public static function init() {
		add_filter( 'woocommerce_product_data_tabs', array( __CLASS__, 'add_product_data_tab' ) );
		add_action( 'woocommerce_product_data_panels', array( __CLASS__, 'render_product_data_panel' ) );
		add_action( 'woocommerce_admin_process_product_object', array( __CLASS__, 'save_product' ) );
		add_action( 'woocommerce_product_after_variable_attributes', array( __CLASS__, 'render_variation_fields' ), 10, 3 );
		add_action( 'woocommerce_save_product_variation', array( __CLASS__, 'save_variation' ), 10, 2 );
	}

	/**
	 * Add the packing tab.
	 *
	 * @param array $tabs Product-data tabs.
	 * @return array
	 */
	public static function add_product_data_tab( $tabs ) {
		$tabs['b2bclp_packing'] = array(
			'label'    => __( 'Carton packing', 'b2b-container-loading-planner' ),
			'target'   => 'b2bclp_packing_product_data',
			'class'    => array( 'show_if_simple', 'show_if_variable' ),
			'priority' => 65,
		);

		return $tabs;
	}

	/** Render simple-product/default packing fields. */
	public static function render_product_data_panel() {
		global $post;

		if ( ! $post instanceof WP_Post ) {
			return;
		}

		$product = wc_get_product( $post->ID );
		if ( ! $product ) {
			return;
		}

		$profile = self::get_profile( $product );
		?>
		<div id="b2bclp_packing_product_data" class="panel woocommerce_options_panel hidden">
			<div class="options_group">
				<p class="form-field"><strong><?php esc_html_e( 'Carton packing profile', 'b2b-container-loading-planner' ); ?></strong><br>
					<span class="description"><?php esc_html_e( 'For variable products, enter the saleable packing profile on every variation. Parent values may be used as defaults by integrations, but do not make a variation complete.', 'b2b-container-loading-planner' ); ?></span>
				</p>
				<?php self::render_fields( $profile ); ?>
			</div>
		</div>
		<?php
	}

	/**
	 * Render variation packing fields.
	 *
	 * @param int     $loop           Loop index.
	 * @param array   $variation_data Variation data.
	 * @param WP_Post $variation      Variation post.
	 */
	public static function render_variation_fields( $loop, $variation_data, $variation ) {
		$product = wc_get_product( $variation->ID );
		if ( ! $product ) {
			return;
		}

		$profile = self::get_profile( $product );
		?>
		<div class="b2bclp-variation-packing" style="clear:both;border-top:1px solid #eee;padding-top:10px">
			<p class="form-row form-row-full"><strong><?php esc_html_e( 'Carton packing profile', 'b2b-container-loading-planner' ); ?></strong></p>
			<?php self::render_fields( $profile, $loop ); ?>
		</div>
		<?php
	}

	/**
	 * Render fields using WooCommerce admin helpers.
	 *
	 * @param array    $profile Current profile.
	 * @param int|null $loop    Variation loop, or null for a product.
	 */
	private static function render_fields( $profile, $loop = null ) {
		$is_variation = null !== $loop;
		$id_suffix    = $is_variation ? '_' . absint( $loop ) : '';
		$name_suffix  = $is_variation ? '[' . absint( $loop ) . ']' : '';
		$wrapper      = $is_variation ? 'form-row form-row-first' : '';
		$fields       = array(
			'units_per_carton'  => array( 'label' => __( 'Units per carton', 'b2b-container-loading-planner' ), 'type' => 'number', 'step' => '1', 'min' => '1' ),
			'carton_length'      => array( 'label' => __( 'Carton length (cm)', 'b2b-container-loading-planner' ), 'type' => 'number', 'step' => '0.01', 'min' => '0.01' ),
			'carton_width'       => array( 'label' => __( 'Carton width (cm)', 'b2b-container-loading-planner' ), 'type' => 'number', 'step' => '0.01', 'min' => '0.01' ),
			'carton_height'      => array( 'label' => __( 'Carton height (cm)', 'b2b-container-loading-planner' ), 'type' => 'number', 'step' => '0.01', 'min' => '0.01' ),
			'carton_cbm'         => array( 'label' => __( 'CBM per carton (m³)', 'b2b-container-loading-planner' ), 'type' => 'number', 'step' => '0.000001', 'min' => '0.000001' ),
			'carton_net_weight'  => array( 'label' => __( 'Carton net weight (kg)', 'b2b-container-loading-planner' ), 'type' => 'number', 'step' => '0.001', 'min' => '0' ),
			'carton_gross_weight'=> array( 'label' => __( 'Carton gross weight (kg, optional)', 'b2b-container-loading-planner' ), 'type' => 'number', 'step' => '0.001', 'min' => '0' ),
		);

		foreach ( $fields as $key => $field ) {
			woocommerce_wp_text_input(
				array(
					'id'                => self::PREFIX . $key . $id_suffix,
					'name'              => self::PREFIX . $key . $name_suffix,
					'label'             => $field['label'],
					'value'             => $profile[ $key ],
					'type'              => $field['type'],
					'wrapper_class'     => $wrapper,
					'custom_attributes' => array( 'step' => $field['step'], 'min' => $field['min'] ),
				)
			);
			$wrapper = $is_variation ? ( 'form-row form-row-first' === $wrapper ? 'form-row form-row-last' : 'form-row form-row-first' ) : '';
		}

		$orientation_labels = self::orientation_labels();
		?>
		<p class="form-field <?php echo $is_variation ? 'form-row form-row-full' : ''; ?>">
			<label><?php esc_html_e( 'Allowed orientations', 'b2b-container-loading-planner' ); ?></label>
			<span class="b2bclp-orientations">
			<?php foreach ( $orientation_labels as $code => $label ) : ?>
				<label style="display:inline-block;margin-inline-end:12px">
					<input type="checkbox" name="<?php echo esc_attr( self::PREFIX . 'orientations' . $name_suffix ); ?>[]" value="<?php echo esc_attr( $code ); ?>" <?php checked( in_array( $code, $profile['allowed_orientations'], true ) ); ?>>
					<?php echo esc_html( $label ); ?>
				</label>
			<?php endforeach; ?>
			</span>
			<span class="description"><?php esc_html_e( 'All six directions are enabled by default. Uncheck only the directions forbidden for an exceptional carton.', 'b2b-container-loading-planner' ); ?></span>
		</p>
		<p class="form-field <?php echo $is_variation ? 'form-row form-row-full' : ''; ?>">
			<label><?php esc_html_e( 'Completeness', 'b2b-container-loading-planner' ); ?></label>
			<strong><?php echo $profile['complete'] ? esc_html__( 'Complete', 'b2b-container-loading-planner' ) : esc_html__( 'Incomplete', 'b2b-container-loading-planner' ); ?></strong>
			<span class="description"><?php esc_html_e( 'Calculated when saved. Units/carton and either complete dimensions or direct CBM are required. Weight is optional and missing values are shown as warnings.', 'b2b-container-loading-planner' ); ?></span>
		</p>
		<?php
	}

	/** Save product fields. */
	public static function save_product( $product ) {
		if ( ! $product instanceof WC_Product ) {
			return;
		}

		self::save_profile( $product, null );
	}

	/**
	 * Save variation fields.
	 *
	 * @param int $variation_id Variation ID.
	 * @param int $loop         Loop index.
	 */
	public static function save_variation( $variation_id, $loop ) {
		$product = wc_get_product( $variation_id );
		if ( $product instanceof WC_Product_Variation ) {
			self::save_profile( $product, absint( $loop ) );
		}
	}

	/**
	 * Sanitize and save one profile.
	 *
	 * @param WC_Product $product Product object.
	 * @param int|null   $loop    Variation loop.
	 */
	private static function save_profile( $product, $loop ) {
		$raw = array();
		foreach ( array( 'units_per_carton', 'carton_length', 'carton_width', 'carton_height', 'carton_cbm', 'carton_net_weight', 'carton_gross_weight', 'orientations' ) as $key ) {
			$post_key = self::PREFIX . $key;
			$value    = isset( $_POST[ $post_key ] ) ? wp_unslash( $_POST[ $post_key ] ) : null; // phpcs:ignore WordPress.Security.NonceVerification.Missing -- WooCommerce verifies the product/variation save nonce.
			$raw[ $key ] = null === $loop ? $value : ( is_array( $value ) && array_key_exists( $loop, $value ) ? $value[ $loop ] : null );
		}

		if ( null === $raw['orientations'] ) {
			$raw['orientations'] = $product->get_meta( self::PREFIX . 'orientations', true );
		}
		$raw['orientation_customized'] = true;
		$raw['packing_approved'] = 'yes';
		$profile = self::sanitize_profile( $raw );
		foreach ( array( 'units_per_carton', 'carton_length', 'carton_width', 'carton_height', 'carton_cbm', 'carton_net_weight', 'carton_gross_weight' ) as $key ) {
			$product->update_meta_data( self::PREFIX . $key, $profile[ $key ] );
		}
		$product->update_meta_data( self::PREFIX . 'orientations', $profile['allowed_orientations'] );
		$product->update_meta_data( self::PREFIX . 'orientation_customized', 'yes' );
		$product->update_meta_data( self::PREFIX . 'packing_approved', $profile['approved'] );
		$product->update_meta_data( self::PREFIX . 'packing_complete', $profile['complete'] ? 'yes' : 'no' );
		$product->save_meta_data();
	}

	/**
	 * Sanitize a posted profile and calculate completeness.
	 *
	 * @param array $raw Raw values.
	 * @return array
	 */
	public static function sanitize_profile( $raw ) {
		$decimal_keys = array( 'carton_length', 'carton_width', 'carton_height', 'carton_cbm', 'carton_net_weight', 'carton_gross_weight' );
		$profile      = array(
			'units_per_carton'   => isset( $raw['units_per_carton'] ) ? absint( $raw['units_per_carton'] ) : 0,
			'max_stack'          => 0,
			'stackable'          => 'yes',
			'approved'           => 'yes',
			'allowed_orientations' => array(),
		);

		foreach ( $decimal_keys as $key ) {
			$precision = 'carton_cbm' === $key ? 6 : 3;
			$profile[ $key ] = isset( $raw[ $key ] ) && '' !== $raw[ $key ] ? wc_format_decimal( $raw[ $key ], $precision ) : '';
		}

		$orientation_value = $raw['orientations'] ?? ( $raw['allowed_orientations'] ?? array() );
		if ( is_string( $orientation_value ) ) {
			$orientation_value = array_filter( array_map( 'trim', explode( ',', $orientation_value ) ) );
		}
		$orientations = is_array( $orientation_value ) ? array_map( 'strtolower', array_map( 'wc_clean', $orientation_value ) ) : array();
		$profile['allowed_orientations'] = array_values( array_intersect( self::ORIENTATIONS, array_unique( $orientations ) ) );
		if ( empty( $raw['orientation_customized'] ) || empty( $profile['allowed_orientations'] ) ) {
			$profile['allowed_orientations'] = self::ORIENTATIONS;
		}
		// Keep both names in the normalized public API; `orientations` is the canonical persisted key.
		$profile['orientations'] = $profile['allowed_orientations'];
		$profile['orientation_customized'] = ! empty( $raw['orientation_customized'] );
		$profile['packing_approved'] = $profile['approved'];
		$profile['has_dimensions'] = (float) $profile['carton_length'] > 0 && (float) $profile['carton_width'] > 0 && (float) $profile['carton_height'] > 0;
		$dimension_cbm = $profile['has_dimensions'] ? (float) $profile['carton_length'] * (float) $profile['carton_width'] * (float) $profile['carton_height'] / 1000000 : 0.0;
		$profile['cbm_per_carton'] = $dimension_cbm > 0 ? $dimension_cbm : (float) $profile['carton_cbm'];
		$profile['has_volume'] = $profile['cbm_per_carton'] > 0;
		$profile['weight_known'] = '' !== (string) $profile['carton_gross_weight'] && (float) $profile['carton_gross_weight'] > 0;
		$profile['complete'] = self::is_profile_complete( $profile );

		return $profile;
	}

	/**
	 * Return normalized packing data for a product.
	 *
	 * @param WC_Product|int $product Product object or ID.
	 * @return array
	 */
	public static function get_profile( $product ) {
		$product = is_numeric( $product ) ? wc_get_product( $product ) : $product;
		if ( ! $product instanceof WC_Product ) {
			return array();
		}

		$raw = array(
			'units_per_carton'    => $product->get_meta( self::PREFIX . 'units_per_carton', true ),
			'carton_length'       => $product->get_meta( self::PREFIX . 'carton_length', true ),
			'carton_width'        => $product->get_meta( self::PREFIX . 'carton_width', true ),
			'carton_height'       => $product->get_meta( self::PREFIX . 'carton_height', true ),
			'carton_cbm'          => $product->get_meta( self::PREFIX . 'carton_cbm', true ),
			'carton_net_weight'   => $product->get_meta( self::PREFIX . 'carton_net_weight', true ),
			'carton_gross_weight' => $product->get_meta( self::PREFIX . 'carton_gross_weight', true ),
			'packing_approved'    => $product->get_meta( self::PREFIX . 'packing_approved', true ),
			'orientations'        => 'yes' === $product->get_meta( self::PREFIX . 'orientation_customized', true ) ? $product->get_meta( self::PREFIX . 'orientations', true ) : array(),
			'orientation_customized' => 'yes' === $product->get_meta( self::PREFIX . 'orientation_customized', true ),
		);

		return self::sanitize_profile( $raw );
	}

	/** Determine whether all required packing data is valid. Worker-entered data is accepted automatically. */
	public static function is_profile_complete( $profile ) {
		if ( ! isset( $profile['units_per_carton'] ) || (int) $profile['units_per_carton'] <= 0 ) {
			return false;
		}
		$has_dimensions = ! empty( $profile['has_dimensions'] ) || ( (float) ( $profile['carton_length'] ?? 0 ) > 0 && (float) ( $profile['carton_width'] ?? 0 ) > 0 && (float) ( $profile['carton_height'] ?? 0 ) > 0 );
		$has_volume = ! empty( $profile['has_volume'] ) || $has_dimensions || (float) ( $profile['carton_cbm'] ?? $profile['cbm_per_carton'] ?? 0 ) > 0;
		if ( ! $has_volume ) {
			return false;
		}
		$net_known = '' !== (string) ( $profile['carton_net_weight'] ?? '' );
		$gross_known = '' !== (string) ( $profile['carton_gross_weight'] ?? '' ) && (float) $profile['carton_gross_weight'] > 0;
		if ( $net_known && (float) $profile['carton_net_weight'] < 0 ) {
			return false;
		}
		if ( $net_known && $gross_known && (float) $profile['carton_gross_weight'] < (float) $profile['carton_net_weight'] ) {
			return false;
		}
		return true;
	}

	/** Human-readable orientation labels. */
	private static function orientation_labels() {
		return array(
			'lwh' => __( 'L × W × H (upright)', 'b2b-container-loading-planner' ),
			'lhw' => __( 'L × H × W', 'b2b-container-loading-planner' ),
			'wlh' => __( 'W × L × H', 'b2b-container-loading-planner' ),
			'whl' => __( 'W × H × L', 'b2b-container-loading-planner' ),
			'hlw' => __( 'H × L × W', 'b2b-container-loading-planner' ),
			'hwl' => __( 'H × W × L', 'b2b-container-loading-planner' ),
		);
	}
}
