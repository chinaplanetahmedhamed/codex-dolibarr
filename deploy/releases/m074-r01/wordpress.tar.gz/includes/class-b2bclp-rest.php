<?php
/**
 * Headless B2B REST API for the China Planet React website.
 *
 * @package B2B_Container_Loading_Planner
 */

defined( 'ABSPATH' ) || exit;

final class B2BCLP_REST {
	const NAMESPACE = 'chinaplanet-b2b/v1';
	// Reuse the established WooCommerce metadata contract so React-created
	// requests appear in the same admin/customer views as native plugin orders.
	const LINE_SNAPSHOT = '_b2bclp_packing_snapshot';
	const ORDER_SNAPSHOT = '_b2bclp_loading_plan';
	const MAX_LINES = 100;
	const MAX_CARTONS_PER_LINE = 2000;
	const MAX_TOTAL_CARTONS = 5000;

	public static function init() {
		add_action( 'rest_api_init', array( __CLASS__, 'register_routes' ) );
	}

	public static function register_routes() {
		register_rest_route(
			self::NAMESPACE,
			'/catalog',
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( __CLASS__, 'catalog' ),
				'permission_callback' => '__return_true',
				'args'                => array(
					'page'     => array( 'default' => 1, 'sanitize_callback' => 'absint' ),
					'per_page' => array( 'default' => 24, 'sanitize_callback' => 'absint' ),
					'search'   => array( 'default' => '', 'sanitize_callback' => 'sanitize_text_field' ),
					'category' => array(
						'default'           => '',
						'sanitize_callback' => function ( $value ) {
							return sanitize_title( (string) $value );
						},
					),
				),
			)
		);

		register_rest_route(
			self::NAMESPACE,
			'/plan',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( __CLASS__, 'plan' ),
				'permission_callback' => array( __CLASS__, 'authorize_request' ),
			)
		);

		// React submits the authoritative plan through its secure Node gateway to
		// Dolibarr. Deliberately do not expose a second REST write path that would
		// create a duplicate WooCommerce order.
	}

	public static function catalog( WP_REST_Request $request ) {
		$page = max( 1, (int) $request->get_param( 'page' ) );
		$per_page = min( 48, max( 1, (int) $request->get_param( 'per_page' ) ) );
		$args = array(
			'status'   => 'publish',
			'limit'    => $per_page,
			'page'     => $page,
			'paginate' => true,
			'orderby'  => 'title',
			'order'    => 'ASC',
			'return'   => 'objects',
		);
		$search = trim( (string) $request->get_param( 'search' ) );
		$category = trim( (string) $request->get_param( 'category' ) );
		if ( '' !== $search ) {
			$args['s'] = $search;
		}
		if ( '' !== $category ) {
			$args['category'] = array( $category );
		}

		try {
			$result = wc_get_products( $args );
		} catch ( Throwable $error ) {
			error_log( 'B2BCLP catalog product query failed: ' . $error->getMessage() ); // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log
			return new WP_Error( 'b2bclp_catalog_query_failed', __( 'The B2B catalog is temporarily unavailable.', 'b2b-container-loading-planner' ), array( 'status' => 503, 'stage' => 'products' ) );
		}
		$products = is_object( $result ) && isset( $result->products ) ? $result->products : (array) $result;
		$total = is_object( $result ) && isset( $result->total ) ? (int) $result->total : count( $products );
		$pages = is_object( $result ) && isset( $result->max_num_pages ) ? (int) $result->max_num_pages : 1;
		$mapped = array();
		foreach ( $products as $product ) {
			try {
				if ( $product instanceof WC_Product && $product->is_visible() ) {
					$mapped[] = self::map_product( $product );
				}
			} catch ( Throwable $error ) {
				error_log( 'B2BCLP catalog product mapping failed for product ' . ( $product instanceof WC_Product ? $product->get_id() : 0 ) . ': ' . $error->getMessage() ); // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log
			}
		}

		try {
			$categories = get_terms(
				array(
					'taxonomy'   => 'product_cat',
					'hide_empty' => true,
					'orderby'    => 'name',
					'order'      => 'ASC',
				)
			);
		} catch ( Throwable $error ) {
			error_log( 'B2BCLP catalog category query failed: ' . $error->getMessage() ); // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log
			return new WP_Error( 'b2bclp_catalog_category_failed', __( 'The B2B catalog is temporarily unavailable.', 'b2b-container-loading-planner' ), array( 'status' => 503, 'stage' => 'categories' ) );
		}
		if ( is_wp_error( $categories ) ) {
			$categories = array();
		}
		$categories = array_values(
			array_filter(
				is_array( $categories ) ? $categories : array(),
				function ( $term ) {
					return $term instanceof WP_Term;
				}
			)
		);

		return rest_ensure_response(
			array(
				'ok'         => true,
				'source'     => 'woocommerce',
				'products'   => $mapped,
				'categories' => array_values(
					array_map(
						function ( $term ) {
							return array(
								'id'     => (int) $term->term_id,
								'name'   => (string) $term->name,
								'slug'   => (string) $term->slug,
								'count'  => (int) $term->count,
								'parent' => (int) $term->parent,
							);
						},
						$categories
					)
				),
				'pagination' => array(
					'page'       => $page,
					'perPage'    => $per_page,
					'total'      => $total,
					'totalPages' => max( 1, $pages ),
				),
				'containers' => array_values( B2BCLP_Settings::containers() ),
			)
		);
	}

	private static function map_product( WC_Product $product ) {
		$profile = B2BCLP_Cart::profile( $product->get_id(), 0 );
		$category_ids = $product->get_category_ids();
		$categories = array();
		foreach ( $category_ids as $category_id ) {
			$term = get_term( $category_id, 'product_cat' );
			if ( $term && ! is_wp_error( $term ) ) {
				$categories[] = array( 'id' => (int) $term->term_id, 'name' => (string) $term->name, 'slug' => (string) $term->slug );
			}
		}
		$image_ids = array_filter( array_merge( array( $product->get_image_id() ), $product->get_gallery_image_ids() ) );
		$images = array_values(
			array_filter(
				array_map(
					function ( $image_id ) { return wp_get_attachment_image_url( $image_id, 'large' ); },
					array_slice( $image_ids, 0, 6 )
				)
			)
		);
		$variations = array();
		if ( $product->is_type( 'variable' ) ) {
			foreach ( array_slice( $product->get_children(), 0, 100 ) as $variation_id ) {
				$variation = wc_get_product( $variation_id );
				// Quote-only variations may intentionally have no WooCommerce price. Keep every enabled,
				// published variation in the public B2B catalogue and let priceMode report "request".
				if ( $variation instanceof WC_Product_Variation && $variation->exists() && 'publish' === $variation->get_status() ) {
					$variations[] = self::map_variation( $product, $variation );
				}
			}
		}
		$price = self::public_price( $product );

		return array(
			'id'          => (int) $product->get_id(),
			'sku'         => (string) $product->get_sku(),
			'name'        => (string) $product->get_name(),
		'description' => wp_trim_words( wp_strip_all_tags( $product->get_short_description() ?: $product->get_description() ), 55, '…' ),
			'permalink'   => (string) $product->get_permalink(),
			'images'      => $images,
			'categories'  => $categories,
			'price'       => $price['unitPrice'],
			'unitPrice'   => $price['unitPrice'],
			'cartonPrice' => null,
			'currency'    => get_woocommerce_currency(),
			'priceMode'   => 'public' === $price['visibility'] ? 'public' : 'request',
			'pricePolicy' => $price,
			'packing'     => self::public_profile( $profile ),
			'variations'  => $variations,
		);
	}

	private static function map_variation( WC_Product $parent, WC_Product_Variation $variation ) {
		$profile = B2BCLP_Cart::profile( $parent->get_id(), $variation->get_id() );
		$attributes = array();
		foreach ( $variation->get_attributes() as $key => $value ) {
			$taxonomy = str_replace( 'attribute_', '', $key );
			$label = wc_attribute_label( $taxonomy, $parent );
			$term = taxonomy_exists( $taxonomy ) ? get_term_by( 'slug', $value, $taxonomy ) : null;
			$attributes[] = array( 'name' => (string) $label, 'value' => (string) ( $term ? $term->name : $value ) );
		}
		$price = self::public_price( $variation );
		$image = wp_get_attachment_image_url( $variation->get_image_id(), 'large' );
		return array(
			'id'         => (int) $variation->get_id(),
			'sku'        => (string) $variation->get_sku(),
			'name'       => (string) $variation->get_name(),
			'attributes' => $attributes,
			'image'      => $image ? (string) $image : '',
			'price'      => $price['unitPrice'],
			'unitPrice'  => $price['unitPrice'],
			'cartonPrice' => null,
			'priceMode'  => 'public' === $price['visibility'] ? 'public' : 'request',
			'pricePolicy' => $price,
			'packing'    => self::public_profile( $profile ),
		);
	}

	private static function public_profile( $profile ) {
		$units = self::positive_int_or_null( $profile['units_per_carton'] ?? null );
		$length = self::positive_float_or_null( $profile['carton_length'] ?? null );
		$width = self::positive_float_or_null( $profile['carton_width'] ?? null );
		$height = self::positive_float_or_null( $profile['carton_height'] ?? null );
		$cbm = self::positive_float_or_null( $profile['cbm_per_carton'] ?? $profile['carton_cbm'] ?? null );
		$net = self::positive_float_or_null( $profile['carton_net_weight'] ?? null );
		$gross = self::positive_float_or_null( $profile['carton_gross_weight'] ?? null );
		$declared_complete = ! empty( $profile['complete'] );
		$missing = array();
		if ( null === $units ) { $missing[] = 'unitsPerCarton'; }
		if ( null === $cbm ) { $missing[] = 'cbmPerCarton'; }
		if ( null === $gross ) { $missing[] = 'grossWeightKg'; }
		if ( ! $declared_complete ) { $missing[] = 'packingComplete'; }
		$ready = empty( $missing );
		return array(
			'unitsPerCarton'   => $units,
			'lengthCm'         => $length,
			'widthCm'          => $width,
			'heightCm'         => $height,
			'cbmPerCarton'     => $cbm,
			'netWeightKg'      => $net,
			'grossWeightKg'    => $gross,
			'weightKnown'      => null !== $gross,
			'hasDimensions'    => ! empty( $profile['has_dimensions'] ),
			'packingComplete'  => $declared_complete,
			'calculationReady' => $ready,
			'missingFields'    => $missing,
			'orientations'     => array_values( (array) ( $profile['orientations'] ?? $profile['allowed_orientations'] ?? array() ) ),
		);
	}

	/** Public price projection. Never expose or derive a price hidden by B2BKing/WooCommerce. */
	private static function public_price( WC_Product $product ) {
		// The signed Node request carries no WordPress login. A public amount is
		// eligible only when the anonymous Woo/B2BKing-rendered output contains
		// WooCommerce's actual amount marker. Text such as "Login to view prices"
		// is deliberately not treated as a public-price entitlement.
		$html = (string) $product->get_price_html();
		$visible = 0 === (int) get_current_user_id() && 1 === preg_match( '/woocommerce-Price-amount\b/', $html );
		$display = $visible ? wc_get_price_to_display( $product ) : null;
		$amount = $visible && is_numeric( $display ) && (float) $display > 0 ? (float) $display : null;
		return array(
			'visibility' => null === $amount ? 'request_quote' : 'public',
			'mode' => null === $amount ? 'request' : 'fixed',
			'unit' => 'piece',
			'currency' => null === $amount ? null : get_woocommerce_currency(),
			'unitPrice' => $amount,
			'minUnitPrice' => null,
			'maxUnitPrice' => null,
		);
	}

	private static function positive_int_or_null( $value ) {
		if ( ! is_numeric( $value ) ) {
			return null;
		}
		$number = (float) $value;
		return $number > 0 && $number <= 1000000 && floor( $number ) === $number ? (int) $number : null;
	}

	private static function positive_float_or_null( $value ) {
		return is_numeric( $value ) && (float) $value > 0 ? (float) $value : null;
	}

	public static function plan( WP_REST_Request $request ) {
		$payload = $request->get_json_params();
		if ( ! is_array( $payload ) || 2 !== absint( $payload['schema_version'] ?? 0 ) || 'catalog_order' !== ( $payload['request_type'] ?? '' ) ) {
			return new WP_Error( 'b2bclp_invalid_contract', __( 'The catalog request contract is invalid.', 'b2b-container-loading-planner' ), array( 'status' => 422 ) );
		}
		$normalized = self::normalize_lines( is_array( $payload ) ? ( $payload['lines'] ?? array() ) : array() );
		if ( is_wp_error( $normalized ) ) {
			return $normalized;
		}
		$selected = sanitize_key( is_array( $payload ) ? ( $payload['container'] ?? 'auto' ) : 'auto' );
		$plan = self::calculate_plan( $normalized, $selected );
		if ( is_wp_error( $plan ) ) {
			return $plan;
		}
		return rest_ensure_response( array( 'ok' => true, 'request_type' => 'catalog_order', 'schema_version' => 2, 'contract' => 'cpo.catalog-order.v2', 'currency' => get_woocommerce_currency(), 'plan' => $plan, 'lines' => self::response_lines( $normalized ) ) );
	}

	private static function normalize_lines( $raw_lines ) {
		if ( ! is_array( $raw_lines ) || empty( $raw_lines ) ) {
			return new WP_Error( 'b2bclp_empty_lines', __( 'Add at least one product to the request.', 'b2b-container-loading-planner' ), array( 'status' => 422 ) );
		}
		if ( count( $raw_lines ) > self::MAX_LINES ) {
			return new WP_Error( 'b2bclp_too_many_lines', __( 'Too many products in one request.', 'b2b-container-loading-planner' ), array( 'status' => 422 ) );
		}

		$normalized = array();
		$line_ids = array();
		$total_cartons = 0;
		foreach ( $raw_lines as $index => $raw ) {
			$line_id = sanitize_text_field( $raw['lineId'] ?? '' );
			$product_id = absint( $raw['productId'] ?? 0 );
			$variation_id = absint( $raw['variationId'] ?? 0 );
			$cartons = absint( $raw['cartons'] ?? 0 );
			if ( ! preg_match( '/^[A-Za-z0-9][A-Za-z0-9._:-]{7,99}$/', $line_id ) || isset( $line_ids[ $line_id ] ) || $product_id < 1 || $cartons < 1 || $cartons > self::MAX_CARTONS_PER_LINE ) {
				return new WP_Error( 'b2bclp_invalid_line', sprintf( __( 'Request line %d is invalid.', 'b2b-container-loading-planner' ), $index + 1 ), array( 'status' => 422 ) );
			}
			$line_ids[ $line_id ] = true;
			$total_cartons += $cartons;
			if ( $total_cartons > self::MAX_TOTAL_CARTONS ) {
				return new WP_Error( 'b2bclp_too_many_cartons', __( 'The request exceeds the maximum carton quantity.', 'b2b-container-loading-planner' ), array( 'status' => 422 ) );
			}
			$parent = wc_get_product( $product_id );
			$product = wc_get_product( $variation_id ?: $product_id );
			if ( ! ( $parent instanceof WC_Product ) || ! $parent->exists() || ! $parent->is_visible() || 'publish' !== get_post_status( $product_id ) || ! ( $product instanceof WC_Product ) || ! $product->exists() ) {
				return new WP_Error( 'b2bclp_product_unavailable', __( 'A selected product is unavailable.', 'b2b-container-loading-planner' ), array( 'status' => 422 ) );
			}
			if ( $variation_id && ( ! ( $product instanceof WC_Product_Variation ) || 'publish' !== $product->get_status() || (int) $product->get_parent_id() !== $product_id ) ) {
				return new WP_Error( 'b2bclp_invalid_variation', __( 'A selected product option is invalid.', 'b2b-container-loading-planner' ), array( 'status' => 422 ) );
			}
			$cart_data = B2BCLP_Cart::add_snapshot( array(), $product_id, $variation_id, $cartons );
			$snapshot = $cart_data[ B2BCLP_Cart::LINE_SNAPSHOT ];
			$snapshot['external_line_id'] = $line_id;
			$profile = self::public_profile( B2BCLP_Cart::profile( $product_id, $variation_id ) );
			$normalized[] = array(
				'line_id'      => $line_id,
				'product'      => $product,
				'product_id'   => $product_id,
				'variation_id' => $variation_id,
				'cartons'      => $cartons,
				'snapshot'     => $snapshot,
				'profile'      => $profile,
				'price'        => self::public_price( $product ),
			);
		}
		return $normalized;
	}

	private static function calculate_plan( $lines, $selected ) {
		$containers = B2BCLP_Settings::containers();
		if ( 'auto' !== $selected && ! isset( $containers[ $selected ] ) ) {
			return new WP_Error( 'b2bclp_invalid_container', __( 'The selected container is unavailable.', 'b2b-container-loading-planner' ), array( 'status' => 422 ) );
		}
		$items = array();
		$excluded = array();
		$total_cartons = 0;
		$total_units = 0;
		$units_complete = true;
		foreach ( $lines as $line ) {
			$s = $line['snapshot'];
			$profile = $line['profile'];
			$total_cartons += $line['cartons'];
			if ( null !== $profile['unitsPerCarton'] ) { $total_units += $line['cartons'] * $profile['unitsPerCarton']; } else { $units_complete = false; }
			if ( empty( $profile['calculationReady'] ) ) {
				$excluded[] = array(
					'lineId' => $line['line_id'],
					'productId' => $line['product_id'], 'variationId' => $line['variation_id'], 'sku' => $s['sku'],
					'name' => $s['product_name'], 'quantity' => $line['cartons'], 'reason' => 'packing_data_missing', 'missingFields' => $profile['missingFields'],
				);
				continue;
			}
			$items[] = array(
				'id' => $line['line_id'], 'line_key' => $line['line_id'], 'name' => $s['product_name'],
				'product_id' => $line['product_id'], 'variation_id' => $line['variation_id'], 'sku' => $s['sku'],
				'quantity' => $line['cartons'], 'units_per_carton' => $profile['unitsPerCarton'],
				'length' => (float) $s['length'], 'width' => (float) $s['width'], 'height' => (float) $s['height'],
				'cbm_per_carton' => $profile['cbmPerCarton'], 'volume_only' => empty( $s['has_dimensions'] ),
				'net_weight' => $profile['netWeightKg'] ?? 0, 'gross_weight' => $profile['grossWeightKg'],
				'weight_known' => true, 'orientations' => (array) $s['orientations'],
				'stackable' => true, 'max_stack' => 0,
			);
		}
		if ( empty( $items ) ) {
			$plan = array( 'ok' => false, 'success' => false, 'reason' => 'no_calculation_ready_lines', 'placements' => array(), 'unpacked' => array(), 'container' => null, 'totals' => array( 'cartons' => 0, 'cbm' => 0, 'gross_weight' => 0, 'remaining_cbm' => 0, 'remaining_payload' => 0 ) );
		} else {
			$plan = B2BCLP_Packer::recommend_flexible( $items, $containers, $selected );
		}
		$plan['selectionMode'] = $selected;
		$plan['containers'] = array_values( $containers );
		$plan['excludedItems'] = $excluded;
		$plan['excluded_items'] = $excluded;
		$plan['warnings'] = isset( $plan['warnings'] ) ? (array) $plan['warnings'] : array();
		if ( $excluded ) {
			$plan['warnings'][] = __( 'Some products are included in the request but excluded from the loading estimate because packing data is incomplete.', 'b2b-container-loading-planner' );
		}
		if ( isset( $plan['totals'] ) ) {
			$plan['totals']['calculated_cartons'] = (int) ( $plan['totals']['cartons'] ?? 0 );
			$plan['totals']['cartons'] = $total_cartons;
			$plan['totals']['units'] = $total_units;
			$plan['totals']['units_complete'] = $units_complete;
		}
		$plan['schema_version'] = 2;
		$plan['contract'] = 'cpo.catalog-order.v2';
		$plan['calculationReadyLines'] = count( $items );
		$plan['generated_at'] = gmdate( 'c' );
		return $plan;
	}

	private static function response_lines( $lines ) {
		return array_values(
			array_map(
				function ( $line ) {
					$s = $line['snapshot'];
					$p = $line['profile'];
					$price = $line['price'];
					$pieces = null !== $p['unitsPerCarton'] ? $p['unitsPerCarton'] * $line['cartons'] : null;
					return array(
						'lineId' => $line['line_id'],
						'source' => 'woocommerce',
						'productId' => $line['product_id'], 'variationId' => $line['variation_id'], 'cartons' => $line['cartons'],
						'sku' => $s['sku'], 'name' => $s['product_name'], 'requestedPieces' => $pieces, 'unitsPerCarton' => $p['unitsPerCarton'],
						'packingComplete' => $p['packingComplete'], 'calculationReady' => $p['calculationReady'], 'missingFields' => $p['missingFields'],
						'packingSource' => $line['variation_id'] > 0 ? 'woocommerce_variation' : 'woocommerce_product',
						'cbmPerCarton' => $p['cbmPerCarton'], 'grossWeightKg' => $p['grossWeightKg'],
						'price' => $price,
						'sourceSnapshot' => array( 'provider' => 'woocommerce', 'productId' => $line['product_id'], 'variationId' => $line['variation_id'], 'sku' => $s['sku'], 'name' => $s['product_name'] ),
					);
				},
				$lines
			)
		);
	}

	public static function authorize_request( WP_REST_Request $request ) {
		$secret = defined( 'CHINAPLANET_B2B_API_SECRET' ) ? (string) CHINAPLANET_B2B_API_SECRET : '';
		if ( strlen( $secret ) < 32 ) {
			return new WP_Error( 'b2bclp_api_not_configured', __( 'The B2B request service is not configured.', 'b2b-container-loading-planner' ), array( 'status' => 503 ) );
		}
		$timestamp = (string) $request->get_header( 'x-chinaplanet-timestamp' );
		$signature = (string) $request->get_header( 'x-chinaplanet-signature' );
		if ( ! self::verify_signature_value( $request->get_body(), $timestamp, $signature, $secret, time() ) ) {
			return new WP_Error( 'b2bclp_invalid_signature', __( 'The B2B request signature is invalid.', 'b2b-container-loading-planner' ), array( 'status' => 401 ) );
		}
		return true;
	}

	public static function verify_signature_value( $body, $timestamp, $signature, $secret, $now ) {
		if ( ! ctype_digit( (string) $timestamp ) || abs( (int) $now - (int) $timestamp ) > 300 ) {
			return false;
		}
		$provided = 0 === strpos( (string) $signature, 'sha256=' ) ? substr( (string) $signature, 7 ) : (string) $signature;
		$expected = hash_hmac( 'sha256', (string) $timestamp . '.' . (string) $body, (string) $secret );
		return strlen( $provided ) === strlen( $expected ) && hash_equals( $expected, $provided );
	}

}
