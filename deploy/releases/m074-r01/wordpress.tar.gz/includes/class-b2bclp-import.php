<?php
/**
 * Internal spreadsheet loading planner and draft-product importer.
 *
 * @package B2B_Container_Loading_Planner
 */

defined( 'ABSPATH' ) || exit;

final class B2BCLP_Import {
	const PAGE_SLUG      = 'b2bclp-import';
	const TRANSIENT_TTL  = HOUR_IN_SECONDS;
	const MAX_FILE_BYTES = 268435456;

	private static $messages = array();
	private static $errors   = array();

	/** Register internal admin hooks. */
	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'menu' ), 61 );
		add_action( 'admin_init', array( __CLASS__, 'handle_upload_request' ) );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'assets' ) );
		add_action( 'wp_ajax_b2bclp_import_plan', array( __CLASS__, 'ajax_plan' ) );
		add_action( 'admin_post_b2bclp_create_import_drafts', array( __CLASS__, 'create_drafts' ) );
	}

	/** Add the company-only WooCommerce menu page. */
	public static function menu() {
		add_submenu_page(
			'woocommerce',
			__( 'Excel Container Planner', 'b2b-container-loading-planner' ),
			__( 'Excel Container Planner', 'b2b-container-loading-planner' ),
			'manage_woocommerce',
			self::PAGE_SLUG,
			array( __CLASS__, 'render' )
		);
	}

	/** Parse an uploaded spreadsheet before the admin page and its assets render. */
	public static function handle_upload_request() {
		if ( ! is_admin() || ! current_user_can( 'manage_woocommerce' ) ) {
			return;
		}
		if ( ! empty( $_POST['b2bclp_sheet_submit'] ) ) {
			check_admin_referer( 'b2bclp_import_sheets', 'b2bclp_sheets_nonce' );
			$stored   = self::current_import();
			$selected = isset( $_POST['b2bclp_sheets'] ) ? array_map( 'sanitize_text_field', (array) wp_unslash( $_POST['b2bclp_sheets'] ) ) : array();
			if ( empty( $stored['sheet_imports'] ) || empty( $selected ) ) {
				self::$errors[] = __( 'Select at least one detected cargo sheet.', 'b2b-container-loading-planner' );
				return;
			}
			$combined = self::combine_sheet_imports( $stored['sheet_imports'], $selected, $stored['filename'] ?? '' );
			set_transient( self::transient_key(), $combined, self::TRANSIENT_TTL );
			self::$messages[] = __( 'Selected sheets recalculated.', 'b2b-container-loading-planner' );
			return;
		}
		if ( empty( $_POST['b2bclp_import_submit'] ) ) {
			return;
		}
		check_admin_referer( 'b2bclp_import_upload', 'b2bclp_import_nonce' );

		$file = isset( $_FILES['b2bclp_import_file'] ) ? $_FILES['b2bclp_import_file'] : array(); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Temporary upload is validated before parsing.
		if ( in_array( (int) ( $file['error'] ?? UPLOAD_ERR_NO_FILE ), array( UPLOAD_ERR_INI_SIZE, UPLOAD_ERR_FORM_SIZE ), true ) ) {
			self::$errors[] = __( 'The server rejected this file before import because its PHP upload limit is too low.', 'b2b-container-loading-planner' );
			return;
		}
		if ( empty( $file['tmp_name'] ) || UPLOAD_ERR_OK !== (int) ( $file['error'] ?? UPLOAD_ERR_NO_FILE ) ) {
			self::$errors[] = __( 'Choose a valid Excel or CSV file.', 'b2b-container-loading-planner' );
			return;
		}
		if ( (int) ( $file['size'] ?? 0 ) < 1 || (int) $file['size'] > self::MAX_FILE_BYTES ) {
			self::$errors[] = __( 'The import file must be smaller than 256 MB.', 'b2b-container-loading-planner' );
			return;
		}

		$name      = sanitize_file_name( wp_unslash( $file['name'] ) );
		$extension = strtolower( pathinfo( $name, PATHINFO_EXTENSION ) );
		if ( ! in_array( $extension, array( 'xlsx', 'csv' ), true ) ) {
			self::$errors[] = __( 'Only .xlsx and .csv files are supported.', 'b2b-container-loading-planner' );
			return;
		}

		try {
			$workbook = B2BCLP_Spreadsheet_Reader::read_workbook( $file['tmp_name'], $extension );
			$sheet_imports = array();
			foreach ( $workbook as $sheet_name => $rows ) {
				$sheet_import = self::normalize_rows( $rows, $name . ' — ' . $sheet_name );
				$sheet_import['sheet_name'] = $sheet_name;
				foreach ( $sheet_import['items'] as &$item ) {
					$item['sheet_name'] = $sheet_name;
				}
				unset( $item );
				if ( ! empty( $sheet_import['items'] ) ) {
					$sheet_imports[ $sheet_name ] = $sheet_import;
				}
			}
			$import = self::combine_sheet_imports( $sheet_imports, array_keys( $sheet_imports ), $name );
			if ( empty( $import['items'] ) ) {
				self::$errors[] = __( 'No valid cargo rows were found. Correct the file and upload it again.', 'b2b-container-loading-planner' );
				self::$errors   = array_merge( self::$errors, $import['errors'] );
				return;
			}
			set_transient( self::transient_key(), $import, self::TRANSIENT_TTL );
			self::$messages[] = sprintf(
				/* translators: 1: valid rows, 2: rejected rows. */
				__( 'Import ready: %1$d valid rows and %2$d rejected rows.', 'b2b-container-loading-planner' ),
				count( $import['items'] ),
				count( $import['errors'] )
			);
		} catch ( Exception $exception ) {
			self::$errors[] = $exception->getMessage();
		}
	}

	/** Convert spreadsheet rows to validated packing lines. */
	public static function normalize_rows( array $rows, $filename = '' ) {
		if ( count( $rows ) < 2 ) {
			return array( 'items' => array(), 'unknown' => array(), 'errors' => array( __( 'The spreadsheet must contain a header row and at least one cargo row.', 'b2b-container-loading-planner' ) ), 'filename' => $filename );
		}

		$header_index = self::detect_header_row( $rows );
		$header       = self::map_headers( $rows[ $header_index ] );
		$rows         = array_slice( $rows, $header_index + 1 );
		$items = array();
		$unknown = array();
		$errors = array();
		$summary_totals = array();
		$last_name = '';
		foreach ( $rows as $offset => $row ) {
			$row_number = $offset + $header_index + 2;
			$values     = array();
			foreach ( $header as $index => $key ) {
				if ( '' !== $key && ! isset( $values[ $key ] ) ) {
					$values[ $key ] = trim( (string) ( $row[ $index ] ?? '' ) );
				}
			}
			if ( ! array_filter( $values, 'strlen' ) ) {
				continue;
			}
			if ( self::is_summary_row( $values ) ) {
				$summary_totals = array(
					'cartons'      => self::positive_integer( self::field( $values, array( 'cartons', 'carton_quantity' ) ) ),
					'cbm'          => self::numeric_value( self::field( $values, array( 'total_cbm', 'cbm_total' ) ) ),
					'gross_weight' => self::numeric_value( self::field( $values, array( 'total_gross_weight_kg', 'total_gross_weight', 'gross_weight_total' ) ) ),
				);
				continue;
			}

			$sku     = self::field( $values, array( 'sku', 'product_sku', 'item_code', 'supplier_item_code' ) );
			$name    = self::field( $values, array( 'product_name', 'name', 'item_name', 'description' ) );
			if ( '' !== $name ) {
				$last_name = $name;
			} elseif ( '' !== $last_name ) {
				$name = $last_name;
			}
			$cartons = self::positive_integer( self::field( $values, array( 'cartons', 'carton_quantity', 'quantity' ) ) );
			if ( ! $cartons ) {
				$errors[] = sprintf( __( 'Row %d: Cartons must be a positive whole number.', 'b2b-container-loading-planner' ), $row_number );
				continue;
			}

			$product_id = '' !== $sku ? wc_get_product_id_by_sku( $sku ) : 0;
			$product    = $product_id ? wc_get_product( $product_id ) : false;
			$source          = 'temporary';
			$volume_only     = false;
			$cbm_per_carton  = 0.0;
			if ( $product ) {
				$profile = B2BCLP_Product_Fields::get_profile( $product );
				if ( empty( $profile['complete'] ) ) {
					$errors[] = sprintf( __( 'Row %1$d: SKU %2$s exists, but its WooCommerce packing profile is incomplete.', 'b2b-container-loading-planner' ), $row_number, $sku );
					continue;
				}
				$name   = $product->get_name();
				$source = 'catalog';
				$cbm_per_carton = (float) ( $profile['cbm_per_carton'] ?? 0 );
				$volume_only = empty( $profile['has_dimensions'] );
			} else {
				$orientations = self::field( $values, array( 'allowed_orientations', 'orientations' ) );
				$dimensions = self::dimension_values( self::field( $values, array( 'carton_dimensions_mm', 'carton_dimensions_cm', 'box_size', 'carton_size' ) ), isset( $values['carton_dimensions_mm'] ) );
				$units_per_carton = self::positive_integer( self::field( $values, array( 'units_per_carton', 'units_carton', 'units' ) ) );
				$total_net = self::numeric_value( self::field( $values, array( 'total_net_weight_kg', 'total_net_weight' ) ) );
				$net_per_carton = self::numeric_value( self::field( $values, array( 'carton_net_weight_kg', 'carton_net_weight', 'net_weight_kg', 'net_weight' ) ) );
				if ( $net_per_carton <= 0 && $total_net > 0 ) {
					$net_per_carton = $total_net / $cartons;
				}
				if ( $net_per_carton <= 0 ) {
					$unit_net = self::numeric_value( self::field( $values, array( 'unit_net_weight_kg' ) ) );
					$net_per_carton = $unit_net > 0 && $units_per_carton ? $unit_net * $units_per_carton : 0;
				}
				$profile = B2BCLP_Product_Fields::sanitize_profile(
					array(
						'units_per_carton'    => $units_per_carton,
						'carton_length'       => self::field( $values, array( 'carton_length_cm', 'carton_length', 'length_cm', 'length' ) ) ?: ( $dimensions[0] ?? '' ),
						'carton_width'        => self::field( $values, array( 'carton_width_cm', 'carton_width', 'width_cm', 'width' ) ) ?: ( $dimensions[1] ?? '' ),
						'carton_height'       => self::field( $values, array( 'carton_height_cm', 'carton_height', 'height_cm', 'height' ) ) ?: ( $dimensions[2] ?? '' ),
						'carton_cbm'          => self::field( $values, array( 'carton_cbm', 'cbm_per_carton', 'cbm' ) ),
						'carton_net_weight'   => $net_per_carton,
						'carton_gross_weight' => self::field( $values, array( 'carton_gross_weight_kg', 'carton_gross_weight', 'gross_weight_kg', 'gross_weight' ) ),
						'orientations'        => '' === $orientations ? B2BCLP_Product_Fields::ORIENTATIONS : $orientations,
						'packing_approved'    => 'yes',
					)
				);
				if ( ! empty( $profile['complete'] ) ) {
					$cbm_per_carton = (float) ( $profile['cbm_per_carton'] ?? 0 );
					$volume_only = empty( $profile['has_dimensions'] );
				} else {
					$total_units      = self::numeric_value( self::field( $values, array( 'total_units', 'qty' ) ) );
					if ( ! $units_per_carton && $total_units > 0 ) {
						$units_per_carton = max( 1, (int) round( $total_units / $cartons ) );
					}
					$cbm_per_carton = self::numeric_value( self::field( $values, array( 'carton_cbm', 'cbm_per_carton', 'cbm' ) ) );
					$total_cbm      = self::numeric_value( self::field( $values, array( 'total_cbm', 'cbm_total' ) ) );
					if ( $cbm_per_carton <= 0 && $total_cbm > 0 ) {
						$cbm_per_carton = $total_cbm / $cartons;
					}
					$gross_per_carton = self::numeric_value( self::field( $values, array( 'carton_gross_weight_kg', 'carton_gross_weight', 'gross_weight_kg', 'gross_weight' ) ) );
					$total_gross       = self::numeric_value( self::field( $values, array( 'total_gross_weight_kg', 'total_gross_weight', 'gross_weight_total' ) ) );
					if ( $gross_per_carton <= 0 && $total_gross > 0 ) {
						$gross_per_carton = $total_gross / $cartons;
					}
					if ( '' === $name || ! $units_per_carton || $cbm_per_carton <= 0 ) {
						$errors[] = sprintf( __( 'Row %d: This row needs a product name, carton count, units/carton, and carton CBM. Weight is optional.', 'b2b-container-loading-planner' ), $row_number );
						continue;
					}
					$profile = array(
						'units_per_carton'    => $units_per_carton,
						'carton_length'       => 0,
						'carton_width'        => 0,
						'carton_height'       => 0,
						'carton_cbm'          => $cbm_per_carton,
						'carton_net_weight'   => 0,
						'carton_gross_weight' => $gross_per_carton,
						'allowed_orientations'=> B2BCLP_Product_Fields::ORIENTATIONS,
					);
					$source      = 'summary';
					$volume_only = true;
				}
			}

			$line_key = 'import-' . $row_number . '-' . substr( md5( $filename . '|' . $sku . '|' . $name ), 0, 8 );
			$item = array(
				'id'                 => $line_key,
				'line_key'           => $line_key,
				'row_number'         => $row_number,
				'source'             => $source,
				'volume_only'        => $volume_only,
				'cbm_per_carton'     => $cbm_per_carton,
				'product_id'         => (int) $product_id,
				'sku'                => $sku,
				'name'               => $name,
				'product_name'       => $name,
				'quantity'           => $cartons,
				'units_per_carton'   => (int) $profile['units_per_carton'],
				'length'             => (float) $profile['carton_length'],
				'width'              => (float) $profile['carton_width'],
				'height'             => (float) $profile['carton_height'],
				'net_weight'         => (float) $profile['carton_net_weight'],
				'gross_weight'       => (float) $profile['carton_gross_weight'],
				'weight_known'       => (float) $profile['carton_gross_weight'] > 0,
				'orientations'       => array_values( $profile['allowed_orientations'] ),
				'stackable'          => true,
				'max_stack'          => 0,
			);
			$items[] = $item;
			if ( 'temporary' === $source ) {
				$unknown[ $line_key ] = $item;
			}
		}

		if ( $items && ! empty( $summary_totals['cartons'] ) && $summary_totals['cbm'] > 0 ) {
			$items[0]['import_summary'] = $summary_totals;
			$errors = array_values( array_filter( $errors, function ( $error ) {
				return false === strpos( $error, 'Cartons must be a positive whole number' );
			} ) );
		}
		return array(
			'schema_version' => 1,
			'import_id'      => wp_generate_uuid4(),
			'filename'       => sanitize_file_name( $filename ),
			'imported_at'    => gmdate( 'c' ),
			'items'          => $items,
			'unknown'        => $unknown,
			'errors'         => $errors,
			'summary_totals' => $summary_totals,
			'header_row'     => $header_index + 1,
			'detected_columns'=> array_values( array_unique( array_filter( $header ) ) ),
			'confidence'     => self::mapping_confidence( $header ),
		);
	}

	private static function combine_sheet_imports( array $sheet_imports, array $selected, $filename ) {
		$combined = array( 'schema_version' => 2, 'import_id' => wp_generate_uuid4(), 'filename' => sanitize_file_name( $filename ), 'imported_at' => gmdate( 'c' ), 'items' => array(), 'unknown' => array(), 'errors' => array(), 'summary_totals' => array(), 'sheet_imports' => $sheet_imports, 'selected_sheets' => array() );
		foreach ( $selected as $sheet_name ) {
			if ( empty( $sheet_imports[ $sheet_name ] ) ) {
				continue;
			}
			$sheet = $sheet_imports[ $sheet_name ];
			$combined['selected_sheets'][] = $sheet_name;
			$combined['items'] = array_merge( $combined['items'], $sheet['items'] );
			$combined['unknown'] += $sheet['unknown'];
			foreach ( $sheet['errors'] as $error ) {
				$combined['errors'][] = '[' . $sheet_name . '] ' . $error;
			}
		}
		return $combined;
	}

	/** Build a server-authoritative plan from imported packing lines. */
	public static function calculate_plan( array $items, $selected = 'auto' ) {
		foreach ( $items as $item ) {
			if ( ! empty( $item['volume_only'] ) ) {
				return self::calculate_summary_plan( $items, $selected );
			}
		}
		$containers = B2BCLP_Settings::containers();
		$selected   = isset( $containers[ $selected ] ) ? $selected : 'auto';
		$plan       = B2BCLP_Packer::recommend( $items, $containers, $selected );
		$plan['selection_mode']       = $selected;
		$plan['valid']                = ! empty( $plan['ok'] );
		$plan['containers']           = array_values( $containers );
		$plan['recommendedContainerId'] = $plan['recommended_container'] ?? '';
		$plan['warnings']             = empty( $plan['ok'] ) ? array( self::reason_message( $plan['reason'] ?? '' ) ) : array();
		if ( ! empty( $plan['totals'] ) ) {
			$plan['totals']['volume'] = (float) ( $plan['totals']['cbm'] ?? 0 );
		}
		$worker_items = array();
		foreach ( $items as $item ) {
			$item['allowedOrientations'] = $item['orientations'];
			$item['grossWeight']         = $item['gross_weight'];
			$item['netWeight']           = $item['net_weight'];
			$item['maxStack']            = 0;
			$worker_items[]              = $item;
		}
		$worker_container = $plan['container'] ?? array();
		if ( $worker_container ) {
			$worker_container['maxPayload']   = $worker_container['max_payload'];
			$worker_container['volumeMargin'] = $worker_container['volume_margin_percent'];
			$worker_container['weightMargin'] = $worker_container['weight_margin_percent'];
		}
		$plan['packingInput'] = array( 'items' => $worker_items, 'container' => $worker_container );
		$plan['estimate_notice'] = __( 'This 3D loading plan is an estimate and requires operational confirmation before loading.', 'b2b-container-loading-planner' );
		return $plan;
	}

	/** Serve container switches for the current user's last import. */
	public static function ajax_plan() {
		check_ajax_referer( 'b2bclp_import_plan', 'nonce' );
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_send_json_error( array( 'message' => __( 'You do not have permission to use the internal planner.', 'b2b-container-loading-planner' ) ), 403 );
		}
		$import = self::current_import();
		if ( empty( $import['items'] ) ) {
			wp_send_json_error( array( 'message' => __( 'Upload a spreadsheet before changing the container.', 'b2b-container-loading-planner' ) ), 400 );
		}
		$selected = isset( $_POST['container'] ) ? sanitize_key( wp_unslash( $_POST['container'] ) ) : 'auto';
		if ( 'auto' !== $selected && ! isset( B2BCLP_Settings::containers()[ $selected ] ) ) {
			wp_send_json_error( array( 'message' => __( 'Invalid container selection.', 'b2b-container-loading-planner' ) ), 400 );
		}
		wp_send_json_success( array( 'plan' => self::calculate_plan( $import['items'], $selected ) ) );
	}

	/** Promote selected temporary cargo lines to unpublished WooCommerce products. */
	public static function create_drafts() {
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_die( esc_html__( 'You do not have permission to create products.', 'b2b-container-loading-planner' ) );
		}
		check_admin_referer( 'b2bclp_create_import_drafts', 'b2bclp_create_nonce' );
		$import   = self::current_import();
		$selected = isset( $_POST['b2bclp_unknown'] ) ? array_map( 'sanitize_text_field', (array) wp_unslash( $_POST['b2bclp_unknown'] ) ) : array();
		$created  = 0;
		foreach ( $selected as $line_key ) {
			if ( empty( $import['unknown'][ $line_key ] ) ) {
				continue;
			}
			$item = $import['unknown'][ $line_key ];
			if ( '' !== $item['sku'] && wc_get_product_id_by_sku( $item['sku'] ) ) {
				continue;
			}
			$product = new WC_Product_Simple();
			$product->set_name( $item['name'] );
			$product->set_status( 'draft' );
			$product->set_catalog_visibility( 'hidden' );
			if ( '' !== $item['sku'] ) {
				$product->set_sku( $item['sku'] );
			}
			$product->set_length( $item['length'] );
			$product->set_width( $item['width'] );
			$product->set_height( $item['height'] );
			$product->update_meta_data( '_b2bclp_units_per_carton', $item['units_per_carton'] );
			$product->update_meta_data( '_b2bclp_carton_length', $item['length'] );
			$product->update_meta_data( '_b2bclp_carton_width', $item['width'] );
			$product->update_meta_data( '_b2bclp_carton_height', $item['height'] );
			$product->update_meta_data( '_b2bclp_carton_cbm', $item['cbm_per_carton'] ?? '' );
			$product->update_meta_data( '_b2bclp_carton_net_weight', $item['net_weight'] );
			$product->update_meta_data( '_b2bclp_carton_gross_weight', $item['gross_weight'] );
			$product->update_meta_data( '_b2bclp_orientations', $item['orientations'] );
			$product->update_meta_data( '_b2bclp_orientation_customized', 'yes' );
			$product->update_meta_data( '_b2bclp_packing_approved', 'yes' );
			$has_volume = ( (float) $item['length'] > 0 && (float) $item['width'] > 0 && (float) $item['height'] > 0 ) || (float) ( $item['cbm_per_carton'] ?? 0 ) > 0;
			$product->update_meta_data( '_b2bclp_packing_complete', ( (int) $item['units_per_carton'] > 0 && $has_volume ) ? 'yes' : 'no' );
			$product->update_meta_data( '_b2bclp_import_id', $import['import_id'] );
			$product->update_meta_data( '_b2bclp_import_line_id', $line_key );
			$product->save();
			$created++;
		}
		wp_safe_redirect( add_query_arg( array( 'page' => self::PAGE_SLUG, 'b2bclp_created' => $created ), admin_url( 'admin.php' ) ) );
		exit;
	}

	/** Load the shared interactive planner only on the internal import page. */
	public static function assets( $hook ) {
		if ( 'woocommerce_page_' . self::PAGE_SLUG !== $hook ) {
			return;
		}
		wp_enqueue_style( 'b2bclp', B2BCLP_URL . 'assets/css/frontend.css', array(), B2BCLP_VERSION );
		wp_enqueue_style( 'b2bclp-import', B2BCLP_URL . 'assets/css/admin-import.css', array( 'b2bclp' ), B2BCLP_VERSION );
		wp_enqueue_script( 'b2bclp', B2BCLP_URL . 'assets/js/frontend.js', array(), B2BCLP_VERSION, true );
		wp_localize_script(
			'b2bclp',
			'B2BCLP',
			array(
				'ajaxUrl'   => admin_url( 'admin-ajax.php' ),
				'action'    => 'b2bclp_import_plan',
				'nonce'     => wp_create_nonce( 'b2bclp_import_plan' ),
				'workerUrl' => B2BCLP_URL . 'assets/js/packer-worker.js',
				'containers'=> array_values( B2BCLP_Settings::containers() ),
				'i18n'      => array(
					'title'            => __( 'Imported cargo loading estimate', 'b2b-container-loading-planner' ),
					'container'        => __( 'Container', 'b2b-container-loading-planner' ),
					'automatic'        => __( 'Automatic — smallest suitable', 'b2b-container-loading-planner' ),
					'cargoCbm'         => __( 'Cargo CBM (all cartons)', 'b2b-container-loading-planner' ),
					'loadedCbm'        => __( 'Loaded CBM', 'b2b-container-loading-planner' ),
					'unallocatedCbm'   => __( 'Unallocated CBM', 'b2b-container-loading-planner' ),
					'aggregateVisual'  => __( 'Aggregate cargo volume — not carton placement', 'b2b-container-loading-planner' ),
					'estimateDisclaimer'=> __( 'Planning estimate only — operational confirmation is required before loading.', 'b2b-container-loading-planner' ),
				),
			)
		);
	}

	/** Render upload, validation, loading plan, and optional draft creation. */
	public static function render() {
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			return;
		}
		$import = self::current_import();
		$plan   = ! empty( $import['items'] ) ? self::calculate_plan( $import['items'], 'auto' ) : array();
		if ( isset( $_GET['b2bclp_created'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Informational redirect value only.
			self::$messages[] = sprintf( __( '%d WooCommerce draft products were created. Packing approval is still required before ordering.', 'b2b-container-loading-planner' ), absint( $_GET['b2bclp_created'] ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		}
		?>
		<div class="wrap b2bclp-import-admin">
			<h1><?php esc_html_e( 'Internal Excel Container Planner', 'b2b-container-loading-planner' ); ?></h1>
			<p><?php esc_html_e( 'Upload company cargo data to calculate a loading estimate. Existing SKUs use calculation-ready WooCommerce packing data; unknown products are calculated temporarily.', 'b2b-container-loading-planner' ); ?></p>
			<?php foreach ( self::$messages as $message ) : ?><div class="notice notice-success is-dismissible"><p><?php echo esc_html( $message ); ?></p></div><?php endforeach; ?>
			<?php foreach ( self::$errors as $error ) : ?><div class="notice notice-error"><p><?php echo esc_html( $error ); ?></p></div><?php endforeach; ?>
			<div class="b2bclp-import-upload">
				<div>
					<h2><?php esc_html_e( '1. Upload cargo spreadsheet', 'b2b-container-loading-planner' ); ?></h2>
					<p><?php esc_html_e( 'Accepted formats: XLSX or CSV, maximum 256 MB. Embedded product images are ignored. Every worksheet is scanned; choose which detected cargo sheets belong to this load.', 'b2b-container-loading-planner' ); ?></p>
					<form method="post" enctype="multipart/form-data">
						<?php wp_nonce_field( 'b2bclp_import_upload', 'b2bclp_import_nonce' ); ?>
						<input type="file" name="b2bclp_import_file" accept=".xlsx,.csv" required>
						<?php submit_button( __( 'Upload and calculate', 'b2b-container-loading-planner' ), 'primary', 'b2bclp_import_submit', false ); ?>
					</form>
				</div>
				<p><a class="button" href="<?php echo esc_url( B2BCLP_URL . 'assets/templates/b2bclp-import-template.xlsx' ); ?>" download><?php esc_html_e( 'Download Excel template', 'b2b-container-loading-planner' ); ?></a></p>
			</div>

			<?php if ( ! empty( $import['items'] ) ) : ?>
				<h2><?php esc_html_e( '2. Review imported cargo', 'b2b-container-loading-planner' ); ?></h2>
				<?php if ( ! empty( $import['sheet_imports'] ) ) : ?>
				<form method="post" class="b2bclp-sheet-review">
					<h3><?php esc_html_e( 'Detected worksheet interpretation', 'b2b-container-loading-planner' ); ?></h3>
					<?php wp_nonce_field( 'b2bclp_import_sheets', 'b2bclp_sheets_nonce' ); ?>
					<?php foreach ( $import['sheet_imports'] as $sheet_name => $sheet ) : ?>
						<label><input type="checkbox" name="b2bclp_sheets[]" value="<?php echo esc_attr( $sheet_name ); ?>" <?php checked( in_array( $sheet_name, $import['selected_sheets'] ?? array(), true ) ); ?>> <strong><?php echo esc_html( $sheet_name ); ?></strong> — <?php echo esc_html( sprintf( __( 'header row %1$d, %2$d cargo rows, %3$d%% confidence', 'b2b-container-loading-planner' ), (int) ( $sheet['header_row'] ?? 1 ), count( $sheet['items'] ), (int) ( $sheet['confidence'] ?? 0 ) ) ); ?> <small><?php echo esc_html( implode( ', ', $sheet['detected_columns'] ?? array() ) ); ?></small></label>
					<?php endforeach; ?>
					<?php submit_button( __( 'Recalculate selected sheets', 'b2b-container-loading-planner' ), 'secondary', 'b2bclp_sheet_submit', false ); ?>
				</form>
				<?php endif; ?>
				<p><strong><?php esc_html_e( 'File:', 'b2b-container-loading-planner' ); ?></strong> <?php echo esc_html( $import['filename'] ); ?> &nbsp; <strong><?php esc_html_e( 'Valid rows:', 'b2b-container-loading-planner' ); ?></strong> <?php echo esc_html( count( $import['items'] ) ); ?> &nbsp; <strong><?php esc_html_e( 'Rejected rows:', 'b2b-container-loading-planner' ); ?></strong> <?php echo esc_html( count( $import['errors'] ) ); ?></p>
				<?php if ( $import['errors'] ) : ?><div class="notice notice-warning inline"><p><strong><?php esc_html_e( 'Rejected rows', 'b2b-container-loading-planner' ); ?></strong></p><ul><?php foreach ( $import['errors'] as $error ) : ?><li><?php echo esc_html( $error ); ?></li><?php endforeach; ?></ul></div><?php endif; ?>
				<div class="b2bclp-import-table-wrap"><table class="widefat striped"><thead><tr><th><?php esc_html_e( 'Row', 'b2b-container-loading-planner' ); ?></th><th><?php esc_html_e( 'SKU', 'b2b-container-loading-planner' ); ?></th><th><?php esc_html_e( 'Product', 'b2b-container-loading-planner' ); ?></th><th><?php esc_html_e( 'Source', 'b2b-container-loading-planner' ); ?></th><th><?php esc_html_e( 'Cartons', 'b2b-container-loading-planner' ); ?></th><th><?php esc_html_e( 'Units', 'b2b-container-loading-planner' ); ?></th><th><?php esc_html_e( 'CBM', 'b2b-container-loading-planner' ); ?></th><th><?php esc_html_e( 'Gross kg', 'b2b-container-loading-planner' ); ?></th></tr></thead><tbody>
				<?php foreach ( $import['items'] as $item ) : $cbm = $item['quantity'] * (float) ( $item['cbm_per_carton'] ?? ( $item['length'] * $item['width'] * $item['height'] / 1000000 ) ); ?>
					<tr><td><?php echo esc_html( $item['row_number'] ); ?></td><td><?php echo esc_html( $item['sku'] ?: '—' ); ?></td><td><?php echo esc_html( $item['name'] ); ?></td><td><span class="b2bclp-source b2bclp-source-<?php echo esc_attr( $item['source'] ); ?>"><?php echo esc_html( self::source_label( $item['source'] ) ); ?></span></td><td><?php echo esc_html( number_format_i18n( $item['quantity'] ) ); ?></td><td><?php echo esc_html( number_format_i18n( $item['quantity'] * $item['units_per_carton'] ) ); ?></td><td><?php echo esc_html( number_format_i18n( $cbm, 3 ) ); ?></td><td><?php echo ! empty( $item['weight_known'] ) ? esc_html( number_format_i18n( $item['quantity'] * $item['gross_weight'], 1 ) ) : '—'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Static dash. ?></td></tr>
				<?php endforeach; ?></tbody></table></div>

				<h2><?php esc_html_e( '3. Loading estimate', 'b2b-container-loading-planner' ); ?></h2>
				<div data-b2bclp-planner data-plan="<?php echo esc_attr( wp_json_encode( $plan, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ) ); ?>"></div>

				<?php if ( ! empty( $import['unknown'] ) ) : ?>
					<div class="b2bclp-import-drafts"><h2><?php esc_html_e( '4. Optional: create unknown products as drafts', 'b2b-container-loading-planner' ); ?></h2>
					<p><?php esc_html_e( 'Drafts are hidden from customers and cannot be ordered until a manager completes commercial data and approves the packing profile.', 'b2b-container-loading-planner' ); ?></p>
					<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
						<input type="hidden" name="action" value="b2bclp_create_import_drafts"><?php wp_nonce_field( 'b2bclp_create_import_drafts', 'b2bclp_create_nonce' ); ?>
						<?php foreach ( $import['unknown'] as $key => $item ) : ?><label><input type="checkbox" name="b2bclp_unknown[]" value="<?php echo esc_attr( $key ); ?>"> <strong><?php echo esc_html( $item['name'] ); ?></strong> — <?php echo esc_html( $item['sku'] ?: __( 'No SKU', 'b2b-container-loading-planner' ) ); ?></label><?php endforeach; ?>
						<?php submit_button( __( 'Create selected products as drafts', 'b2b-container-loading-planner' ), 'secondary' ); ?>
					</form></div>
				<?php endif; ?>
			<?php endif; ?>
		</div>
		<?php
	}

	private static function current_import() {
		$value = get_transient( self::transient_key() );
		return is_array( $value ) ? $value : array();
	}

	/** Calculate a capacity-only plan when carton L/W/H are unavailable. */
	private static function calculate_summary_plan( array $items, $selected ) {
		$containers = B2BCLP_Settings::containers();
		if ( empty( $containers ) ) {
			return array( 'ok' => false, 'valid' => false, 'reason' => 'no_enabled_container', 'placements' => array(), 'unpacked' => array(), 'warnings' => array( __( 'No container types are enabled.', 'b2b-container-loading-planner' ) ) );
		}
		$totals = array( 'cartons' => 0, 'units' => 0, 'cbm' => 0.0, 'net_weight' => 0.0, 'gross_weight' => 0.0 );
		$missing_weight_cartons = 0;
		$group_totals = array();
		foreach ( $items as $item ) {
			$group = (string) ( $item['sheet_name'] ?? 'default' );
			if ( ! isset( $group_totals[ $group ] ) ) {
				$group_totals[ $group ] = array( 'cartons' => 0, 'cbm' => 0.0, 'gross_weight' => 0.0, 'override' => array() );
			}
			if ( ! empty( $item['import_summary'] ) && is_array( $item['import_summary'] ) ) {
				$group_totals[ $group ]['override'] = $item['import_summary'];
			}
			$quantity = (int) $item['quantity'];
			$cbm      = (float) ( $item['cbm_per_carton'] ?? ( $item['length'] * $item['width'] * $item['height'] / 1000000 ) );
			$totals['units']       += $quantity * (int) $item['units_per_carton'];
			$totals['net_weight']  += $quantity * (float) $item['net_weight'];
			if ( empty( $item['weight_known'] ) ) {
				$missing_weight_cartons += $quantity;
			}
			$group_totals[ $group ]['cartons'] += $quantity;
			$group_totals[ $group ]['cbm'] += $quantity * $cbm;
			$group_totals[ $group ]['gross_weight'] += $quantity * (float) $item['gross_weight'];
		}
		$summary_override = false;
		foreach ( $group_totals as $group ) {
			$override = $group['override'];
			$valid_override = ! empty( $override['cartons'] ) && (float) ( $override['cbm'] ?? 0 ) > 0;
			$summary_override = $summary_override || $valid_override;
			$totals['cartons'] += $valid_override ? (int) $override['cartons'] : $group['cartons'];
			$totals['cbm'] += $valid_override ? (float) $override['cbm'] : $group['cbm'];
			$totals['gross_weight'] += $valid_override && (float) ( $override['gross_weight'] ?? 0 ) > 0 ? (float) $override['gross_weight'] : $group['gross_weight'];
		}

		$candidates = array_values( $containers );
		usort( $candidates, function ( $a, $b ) { return (float) $a['capacity_cbm'] <=> (float) $b['capacity_cbm']; } );
		$automatic = 'auto' === $selected || ! isset( $containers[ $selected ] );
		if ( ! $automatic ) {
			$candidates = array( $containers[ $selected ] );
		}
		$chosen = end( $candidates );
		foreach ( $candidates as $candidate ) {
			$volume_capacity = (float) $candidate['capacity_cbm'] * ( 1 - ( (float) $candidate['volume_margin'] / 100 ) );
			$payload_capacity= (float) $candidate['payload'] * ( 1 - ( (float) $candidate['weight_margin'] / 100 ) );
			$chosen = $candidate;
			if ( $totals['cbm'] <= $volume_capacity && $totals['gross_weight'] <= $payload_capacity ) {
				break;
			}
		}
		$volume_capacity = (float) $chosen['capacity_cbm'] * ( 1 - ( (float) $chosen['volume_margin'] / 100 ) );
		$payload_capacity= (float) $chosen['payload'] * ( 1 - ( (float) $chosen['weight_margin'] / 100 ) );
		$volume_ok       = $totals['cbm'] <= $volume_capacity;
		$payload_ok      = $totals['gross_weight'] <= $payload_capacity;
		$ok              = $volume_ok && $payload_ok;
		$reason          = $ok ? '' : ( ! $volume_ok && ! $payload_ok ? 'multiple_limits' : ( $volume_ok ? 'payload_limit' : 'volume_limit' ) );
		$container       = array(
			'id' => $chosen['id'], 'label' => $chosen['label'], 'length' => $chosen['length'], 'width' => $chosen['width'], 'height' => $chosen['height'],
			'capacity_cbm' => $chosen['capacity_cbm'], 'max_payload' => $chosen['payload'], 'volume_margin_percent' => $chosen['volume_margin'], 'weight_margin_percent' => $chosen['weight_margin'],
		);
		$warnings = array( __( 'Volume estimate: some carton dimensions are missing, so exact 3D placement cannot be validated.', 'b2b-container-loading-planner' ) );
		if ( $missing_weight_cartons ) {
			$warnings[] = __( 'Some carton weights are unknown. Payload used and remaining payload are based on known weights only.', 'b2b-container-loading-planner' );
		}
		if ( $summary_override ) {
			$warnings[] = __( 'Cartons and CBM use the workbook total row because some detail rows are incomplete. Gross weight uses the total row only when supplied.', 'b2b-container-loading-planner' );
		}
		if ( ! $ok ) {
			$warnings[] = self::reason_message( $reason );
		}
		$totals['volume']             = round( $totals['cbm'], 6 );
		$totals['cbm']                = round( $totals['cbm'], 6 );
		$totals['net_weight']         = round( $totals['net_weight'], 3 );
		$totals['gross_weight']       = round( $totals['gross_weight'], 3 );
		$totals['remaining_cbm']      = round( max( 0, $volume_capacity - $totals['cbm'] ), 6 );
		$totals['remaining_payload']  = round( max( 0, $payload_capacity - $totals['gross_weight'] ), 3 );
		$totals['weight_complete']    = 0 === $missing_weight_cartons;
		$totals['missing_weight_cartons'] = $missing_weight_cartons;
		$fill_ratio = $volume_capacity > 0 ? min( 1, max( 0, $totals['cbm'] / $volume_capacity ) ) : 0;
		$placements = array();
		if ( $fill_ratio > 0 ) {
			$placements[] = array(
				'x' => (float) $chosen['length'] * 0.02,
				'y' => (float) $chosen['width'] * 0.02,
				'z' => (float) $chosen['height'] * 0.02,
				'length' => (float) $chosen['length'] * 0.96 * $fill_ratio,
				'width' => (float) $chosen['width'] * 0.96,
				'height' => (float) $chosen['height'] * 0.96,
				'line_key' => 'aggregate-cargo-volume',
				'name' => __( 'Aggregate cargo volume', 'b2b-container-loading-planner' ),
				'carton_index' => 1,
				'color' => '#f59e0b',
				'visual_only' => true,
			);
		}
		return array(
			'ok' => $ok, 'success' => $ok, 'valid' => $ok, 'reason' => $reason, 'automatic' => $automatic, 'selection_mode' => $automatic ? 'auto' : $selected,
			'container' => $container, 'containers' => array_values( $containers ), 'recommended_container' => $chosen['id'], 'recommendedContainerId' => $chosen['id'],
			'capacity' => array( 'volume' => $volume_capacity, 'volume_cbm' => $volume_capacity, 'payload' => $payload_capacity ),
			'used' => array( 'volume' => $totals['cbm'], 'volume_cbm' => $totals['cbm'], 'gross_weight' => $totals['gross_weight'] ),
			'remaining' => array( 'volume' => $totals['remaining_cbm'], 'volume_cbm' => $totals['remaining_cbm'], 'payload' => $totals['remaining_payload'] ),
			'totals' => $totals, 'placements' => $placements, 'unpacked' => array(), 'warnings' => $warnings, 'packingInput' => null, 'dimension_validation' => false, 'visual_mode' => 'aggregate_volume',
			'estimate_notice' => __( 'This is an operational estimate. Add carton dimensions for 3D validation and weights for complete payload validation.', 'b2b-container-loading-planner' ),
		);
	}

	/** Locate a likely header row in operational spreadsheets with title rows. */
	private static function detect_header_row( array $rows ) {
		$best_index = 0;
		$best_score = -1;
		foreach ( array_slice( $rows, 0, 30, true ) as $index => $row ) {
			$mapped = self::map_headers( $row );
			$score  = count( array_intersect( array_unique( $mapped ), array( 'sku', 'product_name', 'cartons', 'units_per_carton', 'total_units', 'carton_length_cm', 'carton_cbm', 'total_cbm', 'carton_gross_weight_kg', 'total_gross_weight_kg' ) ) );
			if ( $score > $best_score ) {
				$best_score = $score;
				$best_index = (int) $index;
			}
		}
		return $best_index;
	}

	/** Normalize English/Chinese headers and infer merged CBM/KG total columns. */
	private static function map_headers( array $row ) {
		$mapped = array_fill( 0, count( $row ), '' );
		foreach ( $row as $index => $raw ) {
			$key = self::canonical_header( $raw );
			if ( false !== strpos( $key, '品名' ) || in_array( $key, array( 'product_name', 'item_name', 'description' ), true ) ) {
				$key = 'product_name';
			} elseif ( in_array( $key, array( 'code', 'item_code', 'product_code', 'sku' ), true ) ) {
				$key = 'sku';
			} elseif ( false !== strpos( $key, '件数' ) ) {
				$key = 'cartons';
			} elseif ( in_array( $key, array( 'boxes', 'box', 'cartons', 'outer_packing_no_carton', 'outer_packing_carton' ), true ) ) {
				$key = 'cartons';
			} elseif ( false !== strpos( $key, '单间数量' ) || in_array( $key, array( 'pcs', 'pcs_box', 'pcs_per_box', 'inner_packing' ), true ) ) {
				$key = 'units_per_carton';
			} elseif ( in_array( $key, array( 'qty', 'qty_pcs', 'total_quantity_pcs', 'total_qty' ), true ) ) {
				$key = 'total_units';
			} elseif ( in_array( $key, array( 'box_size_mm', 'wooden_case_size_mm', 'carton_size_mm' ), true ) ) {
				$key = 'carton_dimensions_mm';
			} elseif ( in_array( $key, array( 'box_size_cm', 'carton_size_cm' ), true ) ) {
				$key = 'carton_dimensions_cm';
			} elseif ( in_array( $key, array( 'cbm_box', 'cbm_per_box', 'cbm_carton' ), true ) ) {
				$key = 'carton_cbm';
			} elseif ( in_array( $key, array( 'total_cbm', 'cbm_total', 'cbm' ), true ) ) {
				$key = 'total_cbm';
			} elseif ( in_array( $key, array( 'g_w_kg_box', 'gross_weight_kg_box', 'gw_kg_box' ), true ) ) {
				$key = 'carton_gross_weight_kg';
			} elseif ( in_array( $key, array( 'total_g_w_kgs', 'total_gw_kgs', 'g_w_kgs', 'gross_weight_kgs' ), true ) ) {
				$key = 'total_gross_weight_kg';
			} elseif ( in_array( $key, array( 'total_n_w_kgs', 'total_nw_kgs', 'n_w_kgs' ), true ) ) {
				$key = 'total_net_weight_kg';
			} elseif ( in_array( $key, array( 'n_w_kg_pc', 'nw_kg_pc' ), true ) ) {
				$key = 'unit_net_weight_kg';
			} elseif ( 'cm' === $key || 'cbm' === $key ) {
				$key = 'carton_cbm';
				if ( isset( $row[ $index + 1 ] ) && '' === trim( (string) $row[ $index + 1 ] ) ) {
					$mapped[ $index + 1 ] = 'total_cbm';
				}
			} elseif ( 'kg' === $key ) {
				$key = 'carton_gross_weight_kg';
				if ( isset( $row[ $index + 1 ] ) && '' === trim( (string) $row[ $index + 1 ] ) ) {
					$mapped[ $index + 1 ] = 'total_gross_weight_kg';
				}
			} elseif ( false !== strpos( $key, '箱号' ) ) {
				$key = 'carton_numbers';
			}
			if ( '' !== $key ) {
				$mapped[ $index ] = $key;
			}
		}
		return $mapped;
	}

	private static function is_summary_row( array $values ) {
		$text = implode( ' ', array_values( $values ) );
		if ( 1 === preg_match( '/合计|总计|定金|grand[ _-]*total|deposit|total[ _-]*(qty|weight|cartons|cbm)/i', $text ) ) {
			return true;
		}
		$has_totals = self::numeric_value( self::field( $values, array( 'cartons' ) ) ) > 0
			&& self::numeric_value( self::field( $values, array( 'total_cbm' ) ) ) > 0
			&& self::numeric_value( self::field( $values, array( 'total_gross_weight_kg' ) ) ) > 0;
		return $has_totals && '' === self::field( $values, array( 'product_name', 'sku' ) ) && '' === self::field( $values, array( 'units_per_carton', 'carton_cbm' ) );
	}

	private static function transient_key() {
		return 'b2bclp_import_' . get_current_user_id();
	}

	private static function canonical_header( $header ) {
		$header = strtolower( trim( preg_replace( '/^\xEF\xBB\xBF/', '', (string) $header ) ) );
		return trim( preg_replace( '/[^\p{L}\p{N}]+/u', '_', $header ), '_' );
	}

	private static function field( array $values, array $keys ) {
		foreach ( $keys as $key ) {
			if ( isset( $values[ $key ] ) && '' !== $values[ $key ] ) {
				return sanitize_text_field( $values[ $key ] );
			}
		}
		return '';
	}

	private static function positive_integer( $value ) {
		$value = self::numeric_value( $value );
		return $value >= 1 && floor( $value ) === $value ? (int) $value : 0;
	}

	private static function numeric_value( $value ) {
		$value = str_replace( array( ',', ' ' ), '', (string) $value );
		if ( preg_match( '/[-+]?\d*\.?\d+/', $value, $match ) ) {
			return (float) $match[0];
		}
		return 0.0;
	}

	private static function dimension_values( $value, $millimetres = false ) {
		preg_match_all( '/\d+(?:\.\d+)?/', (string) $value, $matches );
		if ( count( $matches[0] ) < 3 ) {
			return array();
		}
		$values = array_map( 'floatval', array_slice( $matches[0], -3 ) );
		if ( $millimetres ) {
			$values = array_map( function ( $number ) { return $number / 10; }, $values );
		}
		return $values;
	}

	private static function mapping_confidence( array $header ) {
		$keys = array_unique( array_filter( $header ) );
		$score = count( array_intersect( $keys, array( 'product_name', 'sku' ) ) ) ? 25 : 0;
		$score += in_array( 'cartons', $keys, true ) ? 25 : 0;
		$score += count( array_intersect( $keys, array( 'units_per_carton', 'total_units' ) ) ) ? 15 : 0;
		$score += count( array_intersect( $keys, array( 'carton_dimensions_mm', 'carton_dimensions_cm', 'carton_cbm', 'total_cbm' ) ) ) ? 20 : 0;
		$score += count( array_intersect( $keys, array( 'carton_gross_weight_kg', 'total_gross_weight_kg' ) ) ) ? 15 : 0;
		return min( 100, $score );
	}

	private static function source_label( $source ) {
		if ( 'catalog' === $source ) {
			return __( 'WooCommerce', 'b2b-container-loading-planner' );
		}
		if ( 'summary' === $source ) {
			return __( 'Volume/weight only', 'b2b-container-loading-planner' );
		}
		return __( 'Temporary cargo', 'b2b-container-loading-planner' );
	}

	private static function reason_message( $reason ) {
		$messages = array(
			'payload'         => __( 'Gross payload exceeds the configured safe limit.', 'b2b-container-loading-planner' ),
			'payload_limit'   => __( 'Gross payload exceeds the configured safe limit.', 'b2b-container-loading-planner' ),
			'volume'          => __( 'Carton volume exceeds the configured safe capacity.', 'b2b-container-loading-planner' ),
			'volume_limit'    => __( 'Carton volume exceeds the configured safe capacity.', 'b2b-container-loading-planner' ),
			'dimensions'      => __( 'One or more cartons are dimensionally unpackable in this container.', 'b2b-container-loading-planner' ),
			'cannot_place'    => __( 'One or more cartons are dimensionally unpackable in this container.', 'b2b-container-loading-planner' ),
			'multiple_limits' => __( 'The load exceeds multiple container constraints.', 'b2b-container-loading-planner' ),
		);
		return $messages[ $reason ] ?? __( 'All cartons could not be placed in the container.', 'b2b-container-loading-planner' );
	}
}
