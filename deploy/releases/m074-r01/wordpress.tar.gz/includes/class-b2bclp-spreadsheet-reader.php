<?php
/**
 * Small, dependency-free reader for the first worksheet of CSV/XLSX imports.
 *
 * @package B2B_Container_Loading_Planner
 */

defined( 'ABSPATH' ) || define( 'B2BCLP_READER_STANDALONE', true );

final class B2BCLP_Spreadsheet_Reader {
	const MAX_XML_BYTES = 26214400;

	/** Read a supported spreadsheet into a rectangular array of scalar values. */
	public static function read( $path, $extension ) {
		$workbook = self::read_workbook( $path, $extension );
		return $workbook ? reset( $workbook ) : array();
	}

	/** Read every worksheet, preserving sheet names for staff review. */
	public static function read_workbook( $path, $extension ) {
		$extension = strtolower( (string) $extension );
		if ( 'csv' === $extension ) {
			return array( 'CSV' => self::read_csv( $path ) );
		}
		if ( 'xlsx' === $extension ) {
			return self::read_xlsx_workbook( $path );
		}
		throw new InvalidArgumentException( 'Only CSV and XLSX files are supported.' );
	}

	/** Read a CSV file, detecting comma, semicolon, or tab delimiters. */
	private static function read_csv( $path ) {
		$handle = fopen( $path, 'rb' );
		if ( false === $handle ) {
			throw new RuntimeException( 'The CSV file could not be opened.' );
		}
		$sample = fgets( $handle );
		rewind( $handle );
		$counts = array(
			','  => substr_count( (string) $sample, ',' ),
			';'  => substr_count( (string) $sample, ';' ),
			"\t" => substr_count( (string) $sample, "\t" ),
		);
		arsort( $counts );
		$delimiter = (string) key( $counts );
		$rows      = array();
		while ( false !== ( $row = fgetcsv( $handle, 0, $delimiter ) ) ) {
			if ( empty( $rows ) && isset( $row[0] ) ) {
				$row[0] = preg_replace( '/^\xEF\xBB\xBF/', '', (string) $row[0] );
			}
			$rows[] = array_map( array( __CLASS__, 'scalar' ), $row );
		}
		fclose( $handle );
		return $rows;
	}

	/** Read the first XLSX worksheet using PHP's ZIP and XML extensions. */
	private static function read_xlsx_workbook( $path ) {
		if ( ! class_exists( 'ZipArchive' ) || ! function_exists( 'simplexml_load_string' ) ) {
			throw new RuntimeException( 'This server requires the PHP ZIP and SimpleXML extensions to read XLSX files.' );
		}
		$zip = new ZipArchive();
		if ( true !== $zip->open( $path ) ) {
			throw new RuntimeException( 'The XLSX file is invalid or cannot be opened.' );
		}

		$shared = self::shared_strings( $zip );
		$sheets = self::sheet_paths( $zip );
		$result = array();
		foreach ( $sheets as $name => $sheet ) {
			$xml = self::zip_text( $zip, $sheet );
			if ( '' !== $xml ) {
				$result[ $name ] = self::parse_worksheet( $xml, $shared );
			}
		}
		$zip->close();
		if ( ! $result ) {
			throw new RuntimeException( 'No readable XLSX worksheet could be found.' );
		}
		return $result;
	}

	/** Parse one worksheet XML document. */
	private static function parse_worksheet( $xml, array $shared ) {
		libxml_use_internal_errors( true );
		$worksheet = simplexml_load_string( $xml, 'SimpleXMLElement', LIBXML_NONET | LIBXML_NOCDATA );
		if ( false === $worksheet ) {
			throw new RuntimeException( 'The XLSX worksheet XML is invalid.' );
		}
		$worksheet->registerXPathNamespace( 'm', 'http://schemas.openxmlformats.org/spreadsheetml/2006/main' );
		$rows = array();
		foreach ( $worksheet->xpath( '//m:sheetData/m:row' ) as $row_node ) {
			$row_node->registerXPathNamespace( 'm', 'http://schemas.openxmlformats.org/spreadsheetml/2006/main' );
			$row = array();
			$cells = $row_node->xpath( './m:c' );
			foreach ( is_array( $cells ) ? $cells : array() as $cell ) {
				$cell->registerXPathNamespace( 'm', 'http://schemas.openxmlformats.org/spreadsheetml/2006/main' );
				$reference = (string) $cell['r'];
				$index     = self::column_index( $reference );
				$type      = (string) $cell['t'];
				$value     = '';
				if ( 'inlineStr' === $type ) {
					$texts = $cell->xpath( './m:is//m:t' );
					foreach ( $texts as $text ) {
						$value .= (string) $text;
					}
				} else {
					$nodes = $cell->xpath( './m:v' );
					$value = isset( $nodes[0] ) ? (string) $nodes[0] : '';
					if ( 's' === $type && isset( $shared[ (int) $value ] ) ) {
						$value = $shared[ (int) $value ];
					}
				}
				$row[ $index ] = self::scalar( $value );
			}
			if ( $row ) {
				$max = max( array_keys( $row ) );
				$rows[] = array_replace( array_fill( 0, $max + 1, '' ), $row );
			}
		}
		libxml_clear_errors();
		return $rows;
	}

	/** Resolve the first worksheet through workbook relationships. */
	private static function sheet_paths( ZipArchive $zip ) {
		$workbook_xml = self::zip_text( $zip, 'xl/workbook.xml', true );
		$rels_xml     = self::zip_text( $zip, 'xl/_rels/workbook.xml.rels', true );
		if ( '' === $workbook_xml || '' === $rels_xml ) {
			return array( 'Sheet1' => 'xl/worksheets/sheet1.xml' );
		}
		$workbook = simplexml_load_string( $workbook_xml, 'SimpleXMLElement', LIBXML_NONET | LIBXML_NOCDATA );
		$rels     = simplexml_load_string( $rels_xml, 'SimpleXMLElement', LIBXML_NONET | LIBXML_NOCDATA );
		if ( false === $workbook || false === $rels ) {
			return array( 'Sheet1' => 'xl/worksheets/sheet1.xml' );
		}
		$workbook->registerXPathNamespace( 'm', 'http://schemas.openxmlformats.org/spreadsheetml/2006/main' );
		$workbook->registerXPathNamespace( 'r', 'http://schemas.openxmlformats.org/officeDocument/2006/relationships' );
		$sheets = $workbook->xpath( '//m:sheets/m:sheet' );
		if ( empty( $sheets ) ) {
			return array( 'Sheet1' => 'xl/worksheets/sheet1.xml' );
		}
		$relationships = array();
		foreach ( $rels->Relationship as $relationship ) {
			$relationships[ (string) $relationship['Id'] ] = (string) $relationship['Target'];
		}
		$result = array();
		foreach ( $sheets as $index => $sheet ) {
			$attributes = $sheet->attributes( 'http://schemas.openxmlformats.org/officeDocument/2006/relationships' );
			$id         = (string) $attributes['id'];
			if ( isset( $relationships[ $id ] ) ) {
				$target = ltrim( $relationships[ $id ], '/' );
				$name   = trim( (string) $sheet['name'] );
				$result[ '' !== $name ? $name : 'Sheet' . ( $index + 1 ) ] = 0 === strpos( $target, 'xl/' ) ? $target : 'xl/' . $target;
			}
		}
		return $result ?: array( 'Sheet1' => 'xl/worksheets/sheet1.xml' );
	}

	/** Return the XLSX shared string table. */
	private static function shared_strings( ZipArchive $zip ) {
		$xml = self::zip_text( $zip, 'xl/sharedStrings.xml', true );
		if ( '' === $xml ) {
			return array();
		}
		$document = simplexml_load_string( $xml, 'SimpleXMLElement', LIBXML_NONET | LIBXML_NOCDATA );
		if ( false === $document ) {
			return array();
		}
		$document->registerXPathNamespace( 'm', 'http://schemas.openxmlformats.org/spreadsheetml/2006/main' );
		$out = array();
		foreach ( $document->xpath( '//m:si' ) as $item ) {
			$item->registerXPathNamespace( 'm', 'http://schemas.openxmlformats.org/spreadsheetml/2006/main' );
			$value = '';
			$texts = $item->xpath( './/m:t' );
			foreach ( is_array( $texts ) ? $texts : array() as $text ) {
				$value .= (string) $text;
			}
			$out[] = $value;
		}
		return $out;
	}

	/** Safely read a bounded XML member from the XLSX ZIP archive. */
	private static function zip_text( ZipArchive $zip, $name, $optional = false ) {
		$stat = $zip->statName( $name );
		if ( false === $stat ) {
			if ( $optional ) {
				return '';
			}
			throw new RuntimeException( 'A required XLSX component is missing.' );
		}
		if ( (int) ( $stat['size'] ?? 0 ) > self::MAX_XML_BYTES ) {
			throw new RuntimeException( 'An XLSX worksheet is too large to import safely.' );
		}
		$value = $zip->getFromName( $name );
		return false === $value ? '' : $value;
	}

	/** Convert an A1 reference to a zero-based column index. */
	private static function column_index( $reference ) {
		preg_match( '/^[A-Z]+/i', (string) $reference, $match );
		$letters = strtoupper( $match[0] ?? 'A' );
		$index   = 0;
		for ( $i = 0, $length = strlen( $letters ); $i < $length; $i++ ) {
			$index = ( $index * 26 ) + ord( $letters[ $i ] ) - 64;
		}
		return max( 0, $index - 1 );
	}

	/** Ensure XML/CSV values are simple trimmed strings. */
	private static function scalar( $value ) {
		return trim( is_scalar( $value ) ? (string) $value : '' );
	}
}
