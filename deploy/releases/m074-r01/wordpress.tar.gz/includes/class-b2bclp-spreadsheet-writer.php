<?php
/** Minimal dependency-free XLSX writer for company product-data exports. */

defined( 'ABSPATH' ) || exit;

final class B2BCLP_Spreadsheet_Writer {
	/** Create a styled workbook from named sheets containing rectangular row arrays. */
	public static function create( $path, array $sheets ) {
		if ( ! class_exists( 'ZipArchive' ) ) {
			throw new RuntimeException( __( 'The PHP ZIP extension is required to export XLSX files.', 'b2b-container-loading-planner' ) );
		}
		$zip = new ZipArchive();
		if ( true !== $zip->open( $path, ZipArchive::CREATE | ZipArchive::OVERWRITE ) ) {
			throw new RuntimeException( __( 'The export workbook could not be created.', 'b2b-container-loading-planner' ) );
		}

		$sheet_names = array_keys( $sheets );
		$zip->addFromString( '[Content_Types].xml', self::content_types( count( $sheets ) ) );
		$zip->addFromString( '_rels/.rels', '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/><Relationship Id="rId2" Type="http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties" Target="docProps/core.xml"/><Relationship Id="rId3" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/extended-properties" Target="docProps/app.xml"/></Relationships>' );
		$zip->addFromString( 'docProps/core.xml', '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:dcterms="http://purl.org/dc/terms/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"><dc:title>B2B Product and Packing Data</dc:title><dc:creator>WooCommerce</dc:creator><dcterms:created xsi:type="dcterms:W3CDTF">' . esc_xml( gmdate( 'c' ) ) . '</dcterms:created></cp:coreProperties>' );
		$zip->addFromString( 'docProps/app.xml', '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Properties xmlns="http://schemas.openxmlformats.org/officeDocument/2006/extended-properties"><Application>B2B Container Loading Planner</Application></Properties>' );
		$zip->addFromString( 'xl/workbook.xml', self::workbook( $sheet_names ) );
		$zip->addFromString( 'xl/_rels/workbook.xml.rels', self::workbook_rels( count( $sheets ) ) );
		$zip->addFromString( 'xl/styles.xml', self::styles() );
		$index = 1;
		foreach ( $sheets as $name => $rows ) {
			$zip->addFromString( 'xl/worksheets/sheet' . $index . '.xml', self::worksheet( $rows, 1 === $index ) );
			$index++;
		}
		$zip->close();
	}

	private static function worksheet( array $rows, $product_sheet ) {
		$max_columns = 1;
		foreach ( $rows as $row ) {
			$max_columns = max( $max_columns, count( $row ) );
		}
		$xml = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetViews><sheetView workbookViewId="0" showGridLines="0">';
		if ( $product_sheet && count( $rows ) > 1 ) {
			$xml .= '<pane ySplit="1" topLeftCell="A2" activePane="bottomLeft" state="frozen"/>';
		}
		$xml .= '</sheetView></sheetViews><cols>';
		for ( $column = 1; $column <= $max_columns; $column++ ) {
			$width = in_array( $column, array( 5, 6, 7 ), true ) ? 28 : ( $column >= 12 ? 18 : 15 );
			$xml .= '<col min="' . $column . '" max="' . $column . '" width="' . $width . '" customWidth="1"/>';
		}
		$xml .= '</cols><sheetData>';
		foreach ( array_values( $rows ) as $row_index => $row ) {
			$row_number = $row_index + 1;
			$xml .= '<row r="' . $row_number . '"' . ( 1 === $row_number ? ' ht="28" customHeight="1"' : '' ) . '>';
			foreach ( array_values( $row ) as $column_index => $value ) {
				$reference = self::column_name( $column_index + 1 ) . $row_number;
				$style = 1 === $row_number ? ' s="1"' : '';
				if ( is_int( $value ) || is_float( $value ) ) {
					$xml .= '<c r="' . $reference . '"' . $style . '><v>' . $value . '</v></c>';
				} else {
					$xml .= '<c r="' . $reference . '" t="inlineStr"' . $style . '><is><t xml:space="preserve">' . esc_xml( (string) $value ) . '</t></is></c>';
				}
			}
			$xml .= '</row>';
		}
		$xml .= '</sheetData>';
		if ( $product_sheet && $rows ) {
			$xml .= '<autoFilter ref="A1:' . self::column_name( $max_columns ) . count( $rows ) . '"/>';
		}
		return $xml . '</worksheet>';
	}

	private static function styles() {
		return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><fonts count="2"><font><sz val="11"/><name val="Arial"/></font><font><b/><color rgb="FFFFFFFF"/><sz val="11"/><name val="Arial"/></font></fonts><fills count="3"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill><fill><patternFill patternType="solid"><fgColor rgb="FF0F766E"/><bgColor indexed="64"/></patternFill></fill></fills><borders count="1"><border><left/><right/><top/><bottom/><diagonal/></border></borders><cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs><cellXfs count="2"><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/><xf numFmtId="0" fontId="1" fillId="2" borderId="0" xfId="0" applyFont="1" applyFill="1" applyAlignment="1"><alignment wrapText="1" vertical="center"/></xf></cellXfs></styleSheet>';
	}

	private static function workbook( array $names ) {
		$xml = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets>';
		foreach ( $names as $index => $name ) {
			$xml .= '<sheet name="' . esc_xml( mb_substr( (string) $name, 0, 31 ) ) . '" sheetId="' . ( $index + 1 ) . '" r:id="rId' . ( $index + 1 ) . '"/>';
		}
		return $xml . '</sheets></workbook>';
	}

	private static function workbook_rels( $count ) {
		$xml = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">';
		for ( $index = 1; $index <= $count; $index++ ) {
			$xml .= '<Relationship Id="rId' . $index . '" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet' . $index . '.xml"/>';
		}
		return $xml . '<Relationship Id="rId' . ( $count + 1 ) . '" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>';
	}

	private static function content_types( $count ) {
		$xml = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/><Override PartName="/docProps/core.xml" ContentType="application/vnd.openxmlformats-package.core-properties+xml"/><Override PartName="/docProps/app.xml" ContentType="application/vnd.openxmlformats-officedocument.extended-properties+xml"/>';
		for ( $index = 1; $index <= $count; $index++ ) {
			$xml .= '<Override PartName="/xl/worksheets/sheet' . $index . '.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>';
		}
		return $xml . '</Types>';
	}

	private static function column_name( $number ) {
		$name = '';
		while ( $number > 0 ) {
			$number--;
			$name = chr( 65 + ( $number % 26 ) ) . $name;
			$number = intdiv( $number, 26 );
		}
		return $name;
	}
}
