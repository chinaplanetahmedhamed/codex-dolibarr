<?php
/**
 * B2B request order status and loading-plan display.
 *
 * @package B2B_Container_Loading_Planner
 */

defined( 'ABSPATH' ) || exit;

/** Registers the request status and renders immutable order snapshots. */
final class B2BCLP_Order_Display {
	/** Customer contexts already rendered in this request (prevents thank-you duplication). */
	private static $customer_rendered = array();

	/** Custom WooCommerce order status slug (without wc- prefix). */
	const STATUS = 'b2b-await-review';

	/** Default order loading-plan snapshot meta key. */
	const SNAPSHOT_META_KEY = '_b2bclp_loading_plan';

	/** Register hooks. */
	public static function init() {
		add_action( 'init', array( __CLASS__, 'register_order_status' ) );
		add_filter( 'wc_order_statuses', array( __CLASS__, 'add_order_status' ) );
		add_action( 'woocommerce_thankyou', array( __CLASS__, 'render_customer_summary' ), 20 );
		add_action( 'woocommerce_order_details_after_order_table', array( __CLASS__, 'render_customer_summary' ), 20 );
		add_action( 'woocommerce_admin_order_data_after_order_details', array( __CLASS__, 'render_admin_summary' ), 20 );
		add_action( 'woocommerce_email_after_order_table', array( __CLASS__, 'render_email_summary' ), 20, 4 );
	}

	/** Register the custom post status used by both legacy storage and HPOS. */
	public static function register_order_status() {
		register_post_status(
			'wc-' . self::STATUS,
			array(
				'label'                     => _x( 'B2B Request – Awaiting Review', 'Order status', 'b2b-container-loading-planner' ),
				'public'                    => true,
				'exclude_from_search'       => false,
				'show_in_admin_all_list'    => true,
				'show_in_admin_status_list' => true,
				/* translators: %s: number of orders. */
				'label_count'               => _n_noop( 'B2B Request – Awaiting Review <span class="count">(%s)</span>', 'B2B Requests – Awaiting Review <span class="count">(%s)</span>', 'b2b-container-loading-planner' ),
			)
		);
	}

	/**
	 * Insert the status after On hold.
	 *
	 * @param array $statuses Status labels keyed by wc-* slug.
	 * @return array
	 */
	public static function add_order_status( $statuses ) {
		$result = array();
		foreach ( $statuses as $key => $label ) {
			$result[ $key ] = $label;
			if ( 'wc-on-hold' === $key ) {
				$result[ 'wc-' . self::STATUS ] = _x( 'B2B Request – Awaiting Review', 'Order status', 'b2b-container-loading-planner' );
			}
		}
		if ( ! isset( $result[ 'wc-' . self::STATUS ] ) ) {
			$result[ 'wc-' . self::STATUS ] = _x( 'B2B Request – Awaiting Review', 'Order status', 'b2b-container-loading-planner' );
		}

		return $result;
	}

	/** Render on thank-you and customer account order details. */
	public static function render_customer_summary( $order_or_id ) {
		$order = $order_or_id instanceof WC_Order ? $order_or_id : wc_get_order( $order_or_id );
		if ( ! $order || ! self::can_current_user_view( $order ) ) {
			return;
		}
		if ( isset( self::$customer_rendered[ $order->get_id() ] ) ) {
			return;
		}
		$snapshot = self::get_snapshot( $order );
		if ( $snapshot ) {
			self::$customer_rendered[ $order->get_id() ] = true;
			echo wp_kses_post( self::get_html( $snapshot, false ) );
		}
	}

	/** Render in the admin order screen. */
	public static function render_admin_summary( $order ) {
		if ( ! $order instanceof WC_Order || ! self::can_manage_order( $order ) ) {
			return;
		}
		$snapshot = self::get_snapshot( $order );
		if ( $snapshot ) {
			echo wp_kses_post( self::get_html( $snapshot, true ) );
		}
	}

	/** Render print-safe HTML or plain text in order emails. */
	public static function render_email_summary( $order, $sent_to_admin, $plain_text, $email ) {
		unset( $sent_to_admin, $email );
		if ( ! $order instanceof WC_Order ) {
			return;
		}
		$snapshot = self::get_snapshot( $order );
		if ( ! $snapshot ) {
			return;
		}

		if ( $plain_text ) {
			echo esc_html( self::get_plain_text( $snapshot ) );
		} else {
			echo wp_kses_post( self::get_html( $snapshot, false ) );
		}
	}

	/**
	 * Read and normalize the immutable loading-plan snapshot.
	 *
	 * @param WC_Order $order Order.
	 * @return array
	 */
	public static function get_snapshot( $order ) {
		$key      = (string) apply_filters( 'b2bclp_order_snapshot_meta_key', self::SNAPSHOT_META_KEY, $order );
		$snapshot = $order->get_meta( $key, true );
		if ( is_string( $snapshot ) ) {
			$decoded = json_decode( $snapshot, true );
			$snapshot = is_array( $decoded ) ? $decoded : array();
		}

		return is_array( $snapshot ) ? $snapshot : array();
	}

	/** Build accessible print-compatible summary HTML. */
	public static function get_html( $snapshot, $admin = false ) {
		$container = isset( $snapshot['container'] ) && is_array( $snapshot['container'] ) ? $snapshot['container'] : array();
		$totals    = isset( $snapshot['totals'] ) && is_array( $snapshot['totals'] ) ? $snapshot['totals'] : $snapshot;
		$name      = __( 'Container', 'b2b-container-loading-planner' );
		foreach ( array( 'name', 'label', 'type', 'id' ) as $name_key ) {
			if ( ! empty( $container[ $name_key ] ) ) {
				$name = $container[ $name_key ];
				break;
			}
		}
		$weight_complete = ! array_key_exists( 'weight_complete', $totals ) || ! empty( $totals['weight_complete'] );
		$rows      = array(
			__( 'Selected container', 'b2b-container-loading-planner' ) => $name,
			__( 'Cartons', 'b2b-container-loading-planner' )           => self::number( self::first_value( $totals, array( 'cartons', 'total_cartons' ), 0 ), 0 ),
			__( 'Units', 'b2b-container-loading-planner' )             => self::number( self::first_value( $totals, array( 'units', 'total_units' ), 0 ), 0 ),
			__( 'Volume', 'b2b-container-loading-planner' )            => self::number( self::first_value( $totals, array( 'cbm', 'volume_cbm', 'used_volume' ), 0 ), 3 ) . ' ' . __( 'm³', 'b2b-container-loading-planner' ),
			$weight_complete ? __( 'Net weight', 'b2b-container-loading-planner' ) : __( 'Known net weight', 'b2b-container-loading-planner' ) => self::number( self::first_value( $totals, array( 'net_weight', 'total_net_weight' ), 0 ), 2 ) . ' ' . __( 'kg', 'b2b-container-loading-planner' ),
			$weight_complete ? __( 'Gross weight', 'b2b-container-loading-planner' ) : __( 'Known gross weight', 'b2b-container-loading-planner' ) => self::number( self::first_value( $totals, array( 'gross_weight', 'total_gross_weight', 'used_weight' ), 0 ), 2 ) . ' ' . __( 'kg', 'b2b-container-loading-planner' ),
		);

		$remaining_volume = self::first_value( $totals, array( 'remaining_cbm', 'remaining_volume' ), null );
		$remaining_weight = self::first_value( $totals, array( 'remaining_weight', 'remaining_payload' ), null );
		$unpacked         = self::first_value( $snapshot, array( 'unpacked_count', 'unpacked_cartons', 'unpacked' ), self::first_value( $totals, array( 'unpacked_cartons' ), 0 ) );
		$excluded         = self::first_value( $snapshot, array( 'excluded_items', 'excludedItems' ), array() );
		if ( null !== $remaining_volume ) {
			$rows[ __( 'Remaining volume', 'b2b-container-loading-planner' ) ] = self::number( $remaining_volume, 3 ) . ' ' . __( 'm³', 'b2b-container-loading-planner' );
		}
		if ( null !== $remaining_weight ) {
			$rows[ $weight_complete ? __( 'Remaining payload', 'b2b-container-loading-planner' ) : __( 'Remaining payload from known weight', 'b2b-container-loading-planner' ) ] = self::number( $remaining_weight, 2 ) . ' ' . __( 'kg', 'b2b-container-loading-planner' );
		}
		$rows[ __( 'Unpacked cartons', 'b2b-container-loading-planner' ) ] = self::number( is_array( $unpacked ) ? count( $unpacked ) : $unpacked, 0 );
		if ( is_array( $excluded ) && $excluded ) {
			$excluded_quantity = 0;
			foreach ( $excluded as $excluded_item ) {
				$excluded_quantity += (int) ( $excluded_item['quantity'] ?? 0 );
			}
			$rows[ __( 'Requested items excluded from calculation', 'b2b-container-loading-planner' ) ] = self::number( $excluded_quantity, 0 );
		}

		ob_start();
		?>
		<section class="b2bclp-order-summary" style="margin:1.5em 0;break-inside:avoid">
			<h2><?php esc_html_e( 'Container loading summary', 'b2b-container-loading-planner' ); ?></h2>
			<table class="shop_table shop_table_responsive" cellspacing="0" style="width:100%;border-collapse:collapse">
				<tbody>
				<?php foreach ( $rows as $label => $value ) : ?>
					<tr><th scope="row" style="text-align:start;padding:6px;border:1px solid #ddd"><?php echo esc_html( $label ); ?></th><td style="padding:6px;border:1px solid #ddd"><?php echo esc_html( (string) $value ); ?></td></tr>
				<?php endforeach; ?>
				</tbody>
			</table>
			<?php self::render_warnings( $snapshot ); ?>
			<p><small><?php esc_html_e( 'This rectangular-carton 3D loading plan is an estimate only and requires operational confirmation before loading. It does not cover pallets, irregular or dangerous cargo, or axle-load guarantees.', 'b2b-container-loading-planner' ); ?></small></p>
			<?php if ( $admin && ! empty( $snapshot['generated_at'] ) ) : ?>
				<p><small><?php echo esc_html( sprintf( /* translators: %s: snapshot creation date/time. */ __( 'Immutable plan snapshot created: %s', 'b2b-container-loading-planner' ), (string) $snapshot['generated_at'] ) ); ?></small></p>
			<?php endif; ?>
		</section>
		<?php
		return (string) ob_get_clean();
	}

	/** Render warnings contained in a trusted-but-escaped snapshot. */
	private static function render_warnings( $snapshot ) {
		$warnings = isset( $snapshot['warnings'] ) ? $snapshot['warnings'] : array();
		if ( is_string( $warnings ) ) {
			$warnings = array( $warnings );
		}
		if ( ! is_array( $warnings ) || ! $warnings ) {
			return;
		}
		?>
		<div class="b2bclp-order-warnings"><strong><?php esc_html_e( 'Warnings', 'b2b-container-loading-planner' ); ?></strong><ul>
		<?php foreach ( $warnings as $warning ) : ?>
			<li><?php echo esc_html( is_scalar( $warning ) ? (string) $warning : wp_json_encode( $warning ) ); ?></li>
		<?php endforeach; ?>
		</ul></div>
		<?php
	}

	/** Build the plain-text email equivalent. */
	private static function get_plain_text( $snapshot ) {
		$html = self::get_html( $snapshot, false );
		$text = html_entity_decode( wp_strip_all_tags( preg_replace( '/<\/tr>/i', "\n", $html ) ), ENT_QUOTES, get_bloginfo( 'charset' ) );
		return "\n" . trim( preg_replace( '/[ \t]+/', ' ', $text ) ) . "\n\n";
	}

	/** Check whether a customer may see an order. */
	private static function can_current_user_view( $order ) {
		if ( self::can_manage_order( $order ) ) {
			return true;
		}
		if ( is_user_logged_in() && (int) $order->get_user_id() === get_current_user_id() ) {
			return true;
		}

		$order_key = isset( $_GET['key'] ) ? wc_clean( wp_unslash( $_GET['key'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- public WooCommerce order-key authorization.
		return function_exists( 'is_wc_endpoint_url' ) && is_wc_endpoint_url( 'order-received' ) && $order_key && hash_equals( (string) $order->get_order_key(), (string) $order_key );
	}

	/** Capability check that works with classic order posts and HPOS screens. */
	private static function can_manage_order( $order ) {
		return current_user_can( 'manage_woocommerce' ) || current_user_can( 'edit_shop_orders' ) || current_user_can( 'edit_shop_order', $order->get_id() );
	}

	/** Safely locate the first present value under several schema-compatible keys. */
	private static function first_value( $values, $keys, $default ) {
		foreach ( $keys as $key ) {
			if ( array_key_exists( $key, $values ) ) {
				return $values[ $key ];
			}
		}
		return $default;
	}

	/** Locale-aware numeric formatting. */
	private static function number( $value, $decimals ) {
		return number_format_i18n( is_numeric( $value ) ? (float) $value : 0, $decimals );
	}
}
