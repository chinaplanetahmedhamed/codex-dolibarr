<?php
defined( 'ABSPATH' ) || exit;

final class B2BCLP_Settings {
	const OPTION = 'b2bclp_settings';

	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'menu' ), 60 );
		add_action( 'admin_init', array( __CLASS__, 'register' ) );
	}

	public static function defaults() {
		return array(
			'volume_margin' => 0,
			'weight_margin' => 5,
			'containers'    => array(
				'20gp' => array( 'enabled' => 1, 'label' => '20GP', 'length' => 589.8, 'width' => 235.2, 'height' => 239.3, 'capacity_cbm' => 28, 'payload' => 28180 ),
				'40gp' => array( 'enabled' => 0, 'label' => '40GP', 'length' => 1203.2, 'width' => 235.2, 'height' => 239.3, 'capacity_cbm' => 58, 'payload' => 28800 ),
				'40hq' => array( 'enabled' => 1, 'label' => '40HQ', 'length' => 1203.2, 'width' => 235.2, 'height' => 269.8, 'capacity_cbm' => 68, 'payload' => 28600 ),
			),
		);
	}

	public static function get() {
		$saved = get_option( self::OPTION, array() );
		return array_replace_recursive( self::defaults(), is_array( $saved ) ? $saved : array() );
	}

	public static function containers() {
		$settings = self::get();
		$out = array();
		foreach ( $settings['containers'] as $key => $container ) {
			if ( ! empty( $container['enabled'] ) ) {
				$out[ $key ] = array(
					'id'       => $key,
					'label'    => sanitize_text_field( $container['label'] ),
					'length'   => (float) $container['length'],
					'width'    => (float) $container['width'],
					'height'   => (float) $container['height'],
					'capacity_cbm' => (float) $container['capacity_cbm'],
					'payload'  => (float) $container['payload'],
					'volume_margin' => (float) $settings['volume_margin'],
					'weight_margin' => (float) $settings['weight_margin'],
				);
			}
		}
		return $out;
	}

	public static function menu() {
		add_submenu_page( 'woocommerce', __( 'Container Loading', 'b2b-container-loading-planner' ), __( 'Container Loading', 'b2b-container-loading-planner' ), 'manage_woocommerce', 'b2bclp-settings', array( __CLASS__, 'render' ) );
	}

	public static function register() {
		register_setting( 'b2bclp', self::OPTION, array( 'sanitize_callback' => array( __CLASS__, 'sanitize' ), 'default' => self::defaults() ) );
	}

	public static function sanitize( $input ) {
		$defaults = self::defaults();
		$out = array(
			'volume_margin' => min( 50, max( 0, (float) ( $input['volume_margin'] ?? 0 ) ) ),
			'weight_margin' => min( 50, max( 0, (float) ( $input['weight_margin'] ?? 5 ) ) ),
			'containers' => array(),
		);
		foreach ( $defaults['containers'] as $key => $container ) {
			$row = isset( $input['containers'][ $key ] ) ? (array) $input['containers'][ $key ] : array();
			$out['containers'][ $key ] = array(
				'enabled' => empty( $row['enabled'] ) ? 0 : 1,
				'label'   => sanitize_text_field( $row['label'] ?? $container['label'] ),
				'length'  => max( 1, (float) ( $row['length'] ?? $container['length'] ) ),
				'width'   => max( 1, (float) ( $row['width'] ?? $container['width'] ) ),
				'height'  => max( 1, (float) ( $row['height'] ?? $container['height'] ) ),
				'capacity_cbm' => max( 0.001, (float) ( $row['capacity_cbm'] ?? $container['capacity_cbm'] ) ),
				'payload' => max( 1, (float) ( $row['payload'] ?? $container['payload'] ) ),
			);
		}
		return $out;
	}

	public static function render() {
		if ( ! current_user_can( 'manage_woocommerce' ) ) { return; }
		$s = self::get();
		?>
		<div class="wrap"><h1><?php esc_html_e( 'B2B Container Loading Settings', 'b2b-container-loading-planner' ); ?></h1>
		<p><?php esc_html_e( 'Internal dimensions are centimetres; operational capacity is CBM; payload is kilograms. Confirm values with the carrier and actual container plate.', 'b2b-container-loading-planner' ); ?></p>
		<form method="post" action="options.php"><?php settings_fields( 'b2bclp' ); ?>
		<table class="form-table"><tr><th><?php esc_html_e( 'Safety margins', 'b2b-container-loading-planner' ); ?></th><td>
		<label><?php esc_html_e( 'Volume %', 'b2b-container-loading-planner' ); ?> <input type="number" min="0" max="50" step="0.1" name="<?php echo esc_attr( self::OPTION ); ?>[volume_margin]" value="<?php echo esc_attr( $s['volume_margin'] ); ?>"></label>
		<label><?php esc_html_e( 'Weight %', 'b2b-container-loading-planner' ); ?> <input type="number" min="0" max="50" step="0.1" name="<?php echo esc_attr( self::OPTION ); ?>[weight_margin]" value="<?php echo esc_attr( $s['weight_margin'] ); ?>"></label>
		</td></tr></table>
		<table class="widefat striped"><thead><tr><th><?php esc_html_e( 'Enabled', 'b2b-container-loading-planner' ); ?></th><th><?php esc_html_e( 'Container', 'b2b-container-loading-planner' ); ?></th><th><?php esc_html_e( 'Length (cm)', 'b2b-container-loading-planner' ); ?></th><th><?php esc_html_e( 'Width (cm)', 'b2b-container-loading-planner' ); ?></th><th><?php esc_html_e( 'Height (cm)', 'b2b-container-loading-planner' ); ?></th><th><?php esc_html_e( 'Usable capacity (CBM)', 'b2b-container-loading-planner' ); ?></th><th><?php esc_html_e( 'Max payload (kg)', 'b2b-container-loading-planner' ); ?></th></tr></thead><tbody>
		<?php foreach ( $s['containers'] as $key => $c ) : $base = esc_attr( self::OPTION . '[containers][' . $key . ']' ); ?>
		<tr><td><input type="checkbox" name="<?php echo $base; ?>[enabled]" value="1" <?php checked( $c['enabled'] ); ?>></td><td><input name="<?php echo $base; ?>[label]" value="<?php echo esc_attr( $c['label'] ); ?>"></td><td><input type="number" min="1" step="0.1" name="<?php echo $base; ?>[length]" value="<?php echo esc_attr( $c['length'] ); ?>"></td><td><input type="number" min="1" step="0.1" name="<?php echo $base; ?>[width]" value="<?php echo esc_attr( $c['width'] ); ?>"></td><td><input type="number" min="1" step="0.1" name="<?php echo $base; ?>[height]" value="<?php echo esc_attr( $c['height'] ); ?>"></td><td><input type="number" min="0.001" step="0.001" name="<?php echo $base; ?>[capacity_cbm]" value="<?php echo esc_attr( $c['capacity_cbm'] ); ?>"></td><td><input type="number" min="1" step="1" name="<?php echo $base; ?>[payload]" value="<?php echo esc_attr( $c['payload'] ); ?>"></td></tr>
		<?php endforeach; ?></tbody></table><?php submit_button(); ?></form></div>
		<?php
	}
}
