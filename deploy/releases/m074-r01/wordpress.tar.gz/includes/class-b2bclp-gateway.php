<?php
defined( 'ABSPATH' ) || exit;

final class B2BCLP_Gateway_Loader {
	public static function init() {
		add_filter( 'woocommerce_payment_gateways', array( __CLASS__, 'register' ) );
		add_filter( 'woocommerce_available_payment_gateways', array( __CLASS__, 'only_request_gateway' ), 100 );
	}

	public static function register( $gateways ) {
		$gateways[] = 'B2BCLP_Request_Gateway';
		return $gateways;
	}

	public static function only_request_gateway( $gateways ) {
		if ( is_admin() && ! wp_doing_ajax() ) { return $gateways; }
		if ( ! WC()->cart || WC()->cart->is_empty() ) { return $gateways; }
		foreach ( array_keys( $gateways ) as $id ) {
			if ( 'b2bclp_request' !== $id ) { unset( $gateways[ $id ] ); }
		}
		return $gateways;
	}
}

if ( class_exists( 'WC_Payment_Gateway' ) ) {
	final class B2BCLP_Request_Gateway extends WC_Payment_Gateway {
		public function __construct() {
			$this->id                 = 'b2bclp_request';
			$this->method_title       = __( 'B2B order request', 'b2b-container-loading-planner' );
			$this->method_description = __( 'Submits the order for staff review. Bank payment is arranged later.', 'b2b-container-loading-planner' );
			$this->has_fields         = false;
			$this->supports           = array( 'products' );
			$this->init_form_fields();
			$this->init_settings();
			$this->title       = $this->get_option( 'title', __( 'Submit B2B request', 'b2b-container-loading-planner' ) );
			$this->description = $this->get_option( 'description', __( 'No online payment is taken. Staff will confirm loading and send bank payment instructions.', 'b2b-container-loading-planner' ) );
			add_action( 'woocommerce_update_options_payment_gateways_' . $this->id, array( $this, 'process_admin_options' ) );
		}

		public function init_form_fields() {
			$this->form_fields = array(
				'enabled' => array( 'title' => __( 'Enable', 'b2b-container-loading-planner' ), 'type' => 'checkbox', 'label' => __( 'Enable B2B request checkout', 'b2b-container-loading-planner' ), 'default' => 'yes' ),
				'title' => array( 'title' => __( 'Title', 'b2b-container-loading-planner' ), 'type' => 'text', 'default' => __( 'Submit B2B request', 'b2b-container-loading-planner' ) ),
				'description' => array( 'title' => __( 'Description', 'b2b-container-loading-planner' ), 'type' => 'textarea', 'default' => __( 'No online payment is taken. Staff will confirm loading and send bank payment instructions.', 'b2b-container-loading-planner' ) ),
			);
		}

		public function process_payment( $order_id ) {
			$order = wc_get_order( $order_id );
			if ( ! $order ) { return array( 'result' => 'failure' ); }
			$order->update_status( 'b2b-await-review', __( 'B2B request submitted for loading review.', 'b2b-container-loading-planner' ) );
			WC()->cart->empty_cart();
			return array( 'result' => 'success', 'redirect' => $this->get_return_url( $order ) );
		}
	}
}
