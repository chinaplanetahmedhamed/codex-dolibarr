<?php
defined( 'ABSPATH' ) || exit;

final class B2BCLP_Cart {
	const LINE_SNAPSHOT  = '_b2bclp_packing_snapshot';
	const ORDER_SNAPSHOT = '_b2bclp_loading_plan';
	private static $last_plan;

	public static function init() {
		add_filter( 'woocommerce_add_to_cart_validation', array( __CLASS__, 'validate_add' ), 20, 5 );
		add_filter( 'woocommerce_add_cart_item_data', array( __CLASS__, 'add_snapshot' ), 20, 4 );
		add_filter( 'woocommerce_get_item_data', array( __CLASS__, 'item_data' ), 20, 2 );
		add_action( 'woocommerce_before_calculate_totals', array( __CLASS__, 'apply_carton_prices' ), 100000 );
		add_action( 'woocommerce_check_cart_items', array( __CLASS__, 'validate_cart' ) );
		add_action( 'woocommerce_checkout_process', array( __CLASS__, 'validate_cart' ) );
		add_action( 'woocommerce_checkout_create_order_line_item', array( __CLASS__, 'save_line_snapshot' ), 20, 4 );
		add_action( 'woocommerce_checkout_create_order', array( __CLASS__, 'save_order_snapshot' ), 20, 2 );
		add_action( 'woocommerce_cart_totals_before_order_total', array( __CLASS__, 'render_request_totals_rows' ) );
		add_action( 'woocommerce_review_order_before_order_total', array( __CLASS__, 'render_request_totals_rows' ) );
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'assets' ) );
		add_action( 'woocommerce_before_cart', array( __CLASS__, 'cart_layout_open' ), 1 );
		add_action( 'woocommerce_after_cart', array( __CLASS__, 'cart_layout_close' ), 20 );
		add_action( 'woocommerce_checkout_before_order_review', array( __CLASS__, 'render' ) );
		add_action( 'woocommerce_before_add_to_cart_button', array( __CLASS__, 'product_carton_info' ) );
		add_filter( 'woocommerce_available_variation', array( __CLASS__, 'variation_data' ), 20, 3 );
		add_filter( 'woocommerce_quantity_input_args', array( __CLASS__, 'quantity_args' ), 20, 2 );
		add_action( 'wp_ajax_b2bclp_plan', array( __CLASS__, 'ajax_plan' ) );
		add_action( 'wp_ajax_nopriv_b2bclp_plan', array( __CLASS__, 'ajax_plan' ) );
		add_action( 'wp_ajax_b2bclp_product_pricing', array( __CLASS__, 'ajax_product_pricing' ) );
		add_action( 'wp_ajax_nopriv_b2bclp_product_pricing', array( __CLASS__, 'ajax_product_pricing' ) );
		add_shortcode( 'b2bclp_bulk_order', array( __CLASS__, 'bulk_order_shortcode' ) );
	}

	private static function product_id_for_profile( $product_id, $variation_id ) {
		return $variation_id ? $variation_id : $product_id;
	}

	public static function profile( $product_id, $variation_id = 0 ) {
		$id = self::product_id_for_profile( $product_id, $variation_id );
		if ( method_exists( 'B2BCLP_Product_Fields', 'get_profile' ) ) {
			return B2BCLP_Product_Fields::get_profile( $id );
		}
		$keys = array( 'units_per_carton', 'carton_length', 'carton_width', 'carton_height', 'carton_cbm', 'carton_net_weight', 'carton_gross_weight', 'orientations', 'orientation_customized', 'stackable', 'max_stack', 'packing_approved' );
		$p = array();
		foreach ( $keys as $key ) { $p[ $key ] = get_post_meta( $id, '_b2bclp_' . $key, true ); }
		$p['has_dimensions'] = (float) $p['carton_length'] > 0 && (float) $p['carton_width'] > 0 && (float) $p['carton_height'] > 0;
		$p['cbm_per_carton'] = $p['has_dimensions'] ? ( (float) $p['carton_length'] * (float) $p['carton_width'] * (float) $p['carton_height'] / 1000000 ) : (float) $p['carton_cbm'];
		$p['weight_known'] = (float) $p['carton_gross_weight'] > 0;
		$p['packing_approved'] = 'yes';
		$p['orientation_customized'] = 'yes' === ( $p['orientation_customized'] ?? '' );
		if ( ! $p['orientation_customized'] || empty( $p['orientations'] ) ) { $p['orientations'] = array( 'lwh', 'lhw', 'wlh', 'whl', 'hlw', 'hwl' ); }
		$p['complete'] = (int) $p['units_per_carton'] > 0 && (float) $p['cbm_per_carton'] > 0;
		return $p;
	}

	/** Support both new snapshots and schema-v1 cart snapshots created before the completeness flag existed. */
	private static function snapshot_is_complete( $snapshot ) {
		$has_dimensions = (float) ( $snapshot['length'] ?? 0 ) > 0 && (float) ( $snapshot['width'] ?? 0 ) > 0 && (float) ( $snapshot['height'] ?? 0 ) > 0;
		return (int) ( $snapshot['units_per_carton'] ?? 0 ) > 0
			&& ( $has_dimensions || (float) ( $snapshot['cbm_per_carton'] ?? $snapshot['carton_cbm'] ?? 0 ) > 0 );
	}

	public static function validate_add( $passed, $product_id, $quantity, $variation_id = 0, $variations = array() ) {
		if ( ! is_numeric( $quantity ) || (float) $quantity < 1 || floor( (float) $quantity ) !== (float) $quantity ) {
			wc_add_notice( __( 'This product must be ordered as a positive whole number of cartons.', 'b2b-container-loading-planner' ), 'error' );
			return false;
		}
		return $passed;
	}

	public static function add_snapshot( $data, $product_id, $variation_id, $quantity ) {
		$profile = self::profile( $product_id, $variation_id );
		$product = wc_get_product( $variation_id ? $variation_id : $product_id );
		$has_dimensions = ! empty( $profile['has_dimensions'] ) || ( (float) ( $profile['carton_length'] ?? 0 ) > 0 && (float) ( $profile['carton_width'] ?? 0 ) > 0 && (float) ( $profile['carton_height'] ?? 0 ) > 0 );
		$cbm_per_carton = (float) ( $profile['cbm_per_carton'] ?? $profile['carton_cbm'] ?? 0 );
		$weight_known = ! empty( $profile['weight_known'] ) || (float) ( $profile['carton_gross_weight'] ?? 0 ) > 0;
		$units_per_carton = (int) ( $profile['units_per_carton'] ?? 0 );
		$unit_price = $product && '' !== (string) $product->get_price() ? (float) $product->get_price() : 0.0;
		$carton_price = self::carton_price( $unit_price, $units_per_carton );
		$data['_b2bclp_unit_price'] = $unit_price;
		$data['_b2bclp_carton_price'] = $carton_price;
		$data[ self::LINE_SNAPSHOT ] = array(
			'schema_version'    => 1,
			'external_line_id'  => wp_generate_uuid4(),
			'product_id'        => (int) $product_id,
			'variation_id'      => (int) $variation_id,
			'sku'               => $product ? (string) $product->get_sku() : '',
			'product_name'      => $product ? (string) $product->get_name() : '',
			'packing_complete'  => ! empty( $profile['complete'] ),
			'units_per_carton'  => $units_per_carton,
			'unit_price'        => $unit_price,
			'carton_price'      => $carton_price,
			'length'            => (float) ( $profile['length'] ?? $profile['carton_length'] ?? 0 ),
			'width'             => (float) ( $profile['width'] ?? $profile['carton_width'] ?? 0 ),
			'height'            => (float) ( $profile['height'] ?? $profile['carton_height'] ?? 0 ),
			'cbm_per_carton'    => $cbm_per_carton,
			'has_dimensions'    => $has_dimensions,
			'weight_known'      => $weight_known,
			'net_weight'        => (float) ( $profile['net_weight'] ?? $profile['carton_net_weight'] ?? 0 ),
			'gross_weight'      => (float) ( $profile['gross_weight'] ?? $profile['carton_gross_weight'] ?? 0 ),
			'orientations'      => array_values( (array) ( $profile['orientations'] ?? array( 'lwh', 'lhw', 'wlh', 'whl', 'hlw', 'hwl' ) ) ),
			'orientation_customized' => ! empty( $profile['orientation_customized'] ),
			'stackable'         => true,
			'max_stack'         => 0,
			'approved'          => true,
			'captured_at_gmt'   => gmdate( 'c' ),
		);
		return $data;
	}

	/** Convert a per-piece product price into the WooCommerce price for one carton. */
	public static function carton_price( $unit_price, $units_per_carton ) {
		$unit_price = is_numeric( $unit_price ) ? max( 0, (float) $unit_price ) : 0.0;
		$units_per_carton = max( 0, (int) $units_per_carton );
		return $units_per_carton > 0 ? $unit_price * $units_per_carton : $unit_price;
	}

	/**
	 * Keep WooCommerce quantity as cartons while its line-price engine receives
	 * the price of one carton. Taxes, percentage coupons, totals and refunds then
	 * continue through the official WooCommerce calculation APIs.
	 */
	public static function apply_carton_prices( $cart ) {
		if ( ! $cart || ! method_exists( $cart, 'get_cart' ) ) {
			return;
		}
		if ( is_admin() && ! wp_doing_ajax() ) {
			return;
		}
		foreach ( $cart->get_cart() as $cart_item_key => $cart_item ) {
			if ( empty( $cart_item['data'] ) || ! is_object( $cart_item['data'] ) || empty( $cart_item[ self::LINE_SNAPSHOT ] ) ) {
				continue;
			}
			$snapshot = $cart_item[ self::LINE_SNAPSHOT ];
			$units = (int) ( $snapshot['units_per_carton'] ?? 0 );
			if ( $units < 1 ) {
				continue;
			}
			$unit_price = isset( $cart_item['_b2bclp_unit_price'] ) ? (float) $cart_item['_b2bclp_unit_price'] : (float) ( $snapshot['unit_price'] ?? $cart_item['data']->get_price() );
			$carton_price = self::carton_price( $unit_price, $units );
			$cart_item['data']->set_price( $carton_price );
			if ( isset( $cart->cart_contents[ $cart_item_key ] ) ) {
				$cart->cart_contents[ $cart_item_key ]['_b2bclp_unit_price'] = $unit_price;
				$cart->cart_contents[ $cart_item_key ]['_b2bclp_carton_price'] = $carton_price;
			}
		}
	}

	public static function item_data( $item_data, $cart_item ) {
		if ( empty( $cart_item[ self::LINE_SNAPSHOT ] ) ) { return $item_data; }
		$s = $cart_item[ self::LINE_SNAPSHOT ];
		$item_data[] = array( 'key' => __( 'Cartons', 'b2b-container-loading-planner' ), 'value' => (int) $cart_item['quantity'] );
		if ( ! empty( $s['units_per_carton'] ) ) {
			$item_data[] = array( 'key' => __( 'Total units', 'b2b-container-loading-planner' ), 'value' => (int) $cart_item['quantity'] * (int) $s['units_per_carton'] );
			if ( isset( $s['unit_price'] ) ) {
				$item_data[] = array( 'key' => __( 'Price per piece', 'b2b-container-loading-planner' ), 'value' => wp_kses_post( wc_price( (float) $s['unit_price'] ) ) );
				$item_data[] = array( 'key' => __( 'Price per carton', 'b2b-container-loading-planner' ), 'value' => wp_kses_post( wc_price( (float) ( $s['carton_price'] ?? self::carton_price( $s['unit_price'], $s['units_per_carton'] ) ) ) ) );
			}
		}
		if ( ! self::snapshot_is_complete( $s ) ) {
			$item_data[] = array( 'key' => __( 'Container calculation', 'b2b-container-loading-planner' ), 'value' => __( 'Packing data missing — this item is included in the request but excluded from the loading estimate.', 'b2b-container-loading-planner' ) );
			return $item_data;
		}
		$item_data[] = array( 'key' => __( 'Total CBM', 'b2b-container-loading-planner' ), 'value' => wc_format_localized_decimal( (float) $cart_item['quantity'] * (float) ( $s['cbm_per_carton'] ?? 0 ), 3 ) . ' m³' );
		if ( ! empty( $s['weight_known'] ) ) {
			$item_data[] = array( 'key' => __( 'Gross weight', 'b2b-container-loading-planner' ), 'value' => wc_format_localized_decimal( (float) $cart_item['quantity'] * (float) $s['gross_weight'] ) . ' kg' );
		} else {
			$item_data[] = array( 'key' => __( 'Weight', 'b2b-container-loading-planner' ), 'value' => __( 'Unknown — excluded from payload calculation', 'b2b-container-loading-planner' ) );
		}
		return $item_data;
	}

	public static function product_carton_info() {
		global $product;
		if ( ! $product ) { return; }
		$profile = self::profile( $product->get_id(), 0 );
		$units = (int) ( $profile['units_per_carton'] ?? 0 );
		$unit_price = (float) wc_get_price_to_display( $product );
		if ( $product->is_type( 'variable' ) ) { $units = 0; }
		if ( $product->is_type( 'variable' ) || $units > 0 ) {
			echo '<p class="b2bclp-product-units" data-b2bclp-units-per-carton="' . esc_attr( $units ) . '" data-b2bclp-unit-price="' . esc_attr( $unit_price ) . '">';
			echo esc_html__( 'Quantity is cartons. Total units:', 'b2b-container-loading-planner' ) . ' <strong data-b2bclp-total-units>—</strong>';
			echo ' <span class="b2bclp-product-total-separator" aria-hidden="true">·</span> ' . esc_html__( 'Total price:', 'b2b-container-loading-planner' ) . ' <strong data-b2bclp-total-price>—</strong></p>';
		}
		if ( ! $product->is_type( 'variable' ) && empty( $profile['complete'] ) ) {
			echo '<p class="b2bclp-packing-missing">' . esc_html__( 'Carton volume is missing. This product can be added to the B2B request but is excluded from the container calculation.', 'b2b-container-loading-planner' ) . '</p>';
			return;
		}
		if ( ! empty( $profile['complete'] ) && empty( $profile['weight_known'] ) ) {
			echo '<p class="b2bclp-packing-missing">' . esc_html__( 'Weight is not available; payload totals will use known product weights only.', 'b2b-container-loading-planner' ) . '</p>';
		}
	}

	public static function variation_data( $data, $product, $variation ) {
		$profile = self::profile( $product->get_id(), $variation->get_id() );
		$data['b2bclp_units_per_carton'] = (int) ( $profile['units_per_carton'] ?? 0 );
		$data['b2bclp_unit_price'] = (float) wc_get_price_to_display( $variation );
		if ( empty( $profile['complete'] ) && ! empty( $data['is_purchasable'] ) ) {
			$data['availability_html'] = '<p class="stock b2bclp-packing-missing">' . esc_html__( 'Packing data is missing. This product can be requested but will not be included in the container calculation.', 'b2b-container-loading-planner' ) . '</p>';
		}
		return $data;
	}

	public static function quantity_args( $args, $product ) {
		$args['min_value'] = max( 1, (int) ( $args['min_value'] ?? 1 ) );
		$args['step'] = 1;
		return $args;
	}

	public static function items_from_cart() {
		$items = array();
		if ( ! WC()->cart ) { return $items; }
		foreach ( WC()->cart->get_cart() as $key => $line ) {
			if ( empty( $line[ self::LINE_SNAPSHOT ] ) ) { continue; }
			$s = $line[ self::LINE_SNAPSHOT ];
			if ( ! self::snapshot_is_complete( $s ) ) { continue; }
			$items[] = array(
				'id' => $s['external_line_id'], 'line_key' => $s['external_line_id'], 'cart_item_key' => $key,
				'name' => $s['product_name'], 'product_name' => $s['product_name'], 'product_id' => (int) $s['product_id'],
				'variation_id' => (int) $s['variation_id'], 'sku' => (string) $s['sku'],
				'quantity' => (int) $line['quantity'], 'units_per_carton' => (int) $s['units_per_carton'],
				'length' => (float) $s['length'], 'width' => (float) $s['width'], 'height' => (float) $s['height'],
				'cbm_per_carton' => (float) ( $s['cbm_per_carton'] ?? 0 ), 'volume_only' => empty( $s['has_dimensions'] ),
				'net_weight' => (float) $s['net_weight'], 'gross_weight' => (float) $s['gross_weight'],
				'weight_known' => ! empty( $s['weight_known'] ),
				'orientations' => ! empty( $s['orientation_customized'] ) && ! empty( $s['orientations'] ) ? (array) $s['orientations'] : array( 'lwh', 'lhw', 'wlh', 'whl', 'hlw', 'hwl' ),
				'stackable' => true, 'max_stack' => 0,
			);
		}
		return $items;
	}

	/** Cart lines that remain orderable but cannot be included in the loading calculation. */
	public static function excluded_items_from_cart() {
		$items = array();
		if ( ! WC()->cart ) { return $items; }
		foreach ( WC()->cart->get_cart() as $key => $line ) {
			$s = $line[ self::LINE_SNAPSHOT ] ?? array();
			if ( ! $s || self::snapshot_is_complete( $s ) ) { continue; }
			$items[] = array(
				'cart_item_key' => $key,
				'product_id' => (int) ( $s['product_id'] ?? 0 ),
				'variation_id' => (int) ( $s['variation_id'] ?? 0 ),
				'sku' => (string) ( $s['sku'] ?? '' ),
				'name' => (string) ( $s['product_name'] ?? '' ),
				'quantity' => (int) ( $line['quantity'] ?? 0 ),
				'units_per_carton' => (int) ( $s['units_per_carton'] ?? 0 ),
				'total_units' => (int) ( $line['quantity'] ?? 0 ) * (int) ( $s['units_per_carton'] ?? 0 ),
				'reason' => 'packing_data_missing',
			);
		}
		return $items;
	}

	/** Aggregate commercial quantities from every cart line, whether loadable or excluded. */
	public static function request_totals_from_lines( $lines ) {
		$totals = array( 'cartons' => 0, 'units' => 0, 'units_complete' => true, 'missing_units_cartons' => 0 );
		foreach ( (array) $lines as $line ) {
			$quantity = max( 0, (int) ( $line['quantity'] ?? 0 ) );
			$snapshot = (array) ( $line[ self::LINE_SNAPSHOT ] ?? array() );
			$units_per_carton = max( 0, (int) ( $snapshot['units_per_carton'] ?? 0 ) );
			$totals['cartons'] += $quantity;
			if ( $units_per_carton > 0 ) {
				$totals['units'] += $quantity * $units_per_carton;
			} elseif ( $quantity > 0 ) {
				$totals['units_complete'] = false;
				$totals['missing_units_cartons'] += $quantity;
			}
		}
		return $totals;
	}

	public static function cart_request_totals() {
		return WC()->cart ? self::request_totals_from_lines( WC()->cart->get_cart() ) : self::request_totals_from_lines( array() );
	}

	/** Create a consistent visual carton shape when only its cubic volume is known. */
	public static function estimated_dimensions_from_cbm( $cbm ) {
		$cbm = max( 0, (float) $cbm );
		if ( $cbm <= 0 ) { return array( 'length' => 0.0, 'width' => 0.0, 'height' => 0.0 ); }
		$base = pow( ( $cbm * 1000000 ) / ( 1.6 * 1.2 ), 1 / 3 );
		return array(
			'length' => round( 1.6 * $base, 6 ),
			'width'  => round( 1.2 * $base, 6 ),
			'height' => round( $base, 6 ),
		);
	}

	/** Add commercial carton and piece totals to the classic cart and checkout tables. */
	public static function render_request_totals_rows() {
		$totals = self::cart_request_totals();
		?>
		<tr class="b2bclp-cart-total-cartons"><th><?php esc_html_e( 'Total cartons', 'b2b-container-loading-planner' ); ?></th><td data-title="<?php esc_attr_e( 'Total cartons', 'b2b-container-loading-planner' ); ?>"><?php echo esc_html( number_format_i18n( $totals['cartons'] ) ); ?></td></tr>
		<tr class="b2bclp-cart-total-pieces"><th><?php echo esc_html( $totals['units_complete'] ? __( 'Total pieces', 'b2b-container-loading-planner' ) : __( 'Known total pieces', 'b2b-container-loading-planner' ) ); ?></th><td data-title="<?php esc_attr_e( 'Total pieces', 'b2b-container-loading-planner' ); ?>"><?php echo esc_html( number_format_i18n( $totals['units'] ) ); ?></td></tr>
		<?php
	}

	public static function calculate_plan( $selected = 'auto' ) {
		$items = self::items_from_cart();
		$excluded_items = self::excluded_items_from_cart();
		$containers = B2BCLP_Settings::containers();
		if ( empty( $containers ) ) { return array( 'ok' => false, 'reason' => 'no_containers', 'placements' => array(), 'unpacked' => $items, 'warnings' => array( __( 'No container types are enabled.', 'b2b-container-loading-planner' ) ) ); }
		$selected = isset( $containers[ $selected ] ) ? $selected : 'auto';
		$plan = B2BCLP_Packer::recommend_flexible( $items, $containers, $selected );
		$plan['selection_mode'] = $selected;
		$plan['valid'] = ! empty( $plan['ok'] );
		$plan['containers'] = array_values( $containers );
		$plan['recommendedContainerId'] = $plan['recommended_container'] ?? '';
		$plan['warnings'] = array();
		if ( empty( $plan['ok'] ) ) {
			$plan['warnings'][] = self::reason_message( $plan['reason'] ?? 'cannot_place' );
		}
		if ( $excluded_items ) {
			$plan['warnings'][] = __( 'Some requested products have no carton volume and are excluded from the container calculation.', 'b2b-container-loading-planner' );
		}
		$missing_weight_cartons = 0;
		$missing_dimension_cartons = 0;
		foreach ( $items as $item ) {
			if ( empty( $item['weight_known'] ) ) { $missing_weight_cartons += (int) $item['quantity']; }
			if ( ! empty( $item['volume_only'] ) ) { $missing_dimension_cartons += (int) $item['quantity']; }
		}
		if ( $missing_weight_cartons ) {
			$plan['warnings'][] = __( 'Some carton weights are unknown. Payload used and remaining payload are based on known weights only and require confirmation.', 'b2b-container-loading-planner' );
		}
		if ( $missing_dimension_cartons ) {
			$plan['warnings'][] = __( 'Some cartons use direct CBM without dimensions. Their volume is included, but exact 3D placement cannot be validated.', 'b2b-container-loading-planner' );
		}
		$plan['excluded_items'] = $excluded_items;
		$plan['excludedItems'] = $excluded_items;
		if ( ! empty( $plan['totals'] ) && ! empty( $plan['capacity'] ) ) {
			$request_totals = self::cart_request_totals();
			$plan['totals']['calculated_cartons'] = (int) ( $plan['totals']['cartons'] ?? 0 );
			$plan['totals']['calculated_units'] = (int) ( $plan['totals']['units'] ?? 0 );
			$plan['totals']['cartons'] = (int) $request_totals['cartons'];
			$plan['totals']['units'] = (int) $request_totals['units'];
			$plan['totals']['units_complete'] = ! empty( $request_totals['units_complete'] );
			$plan['totals']['missing_units_cartons'] = (int) $request_totals['missing_units_cartons'];
			$plan['totals']['volume'] = (float) ( $plan['totals']['cbm'] ?? 0 );
			$plan['totals']['usedVolumePercent'] = (float) $plan['capacity']['volume'] > 0 ? 100 * (float) ( $plan['used']['volume'] ?? 0 ) / (float) $plan['capacity']['volume'] : 0;
			$plan['totals']['usedWeightPercent'] = (float) $plan['capacity']['payload'] > 0 ? 100 * (float) ( $plan['used']['gross_weight'] ?? 0 ) / (float) $plan['capacity']['payload'] : 0;
			$plan['totals']['remainingVolume'] = (float) ( $plan['remaining']['volume'] ?? 0 );
			$plan['totals']['remainingWeight'] = (float) ( $plan['remaining']['payload'] ?? 0 );
			$plan['totals']['weight_complete'] = 0 === $missing_weight_cartons;
			$plan['totals']['missing_weight_cartons'] = $missing_weight_cartons;
			$plan['totals']['missing_dimension_cartons'] = $missing_dimension_cartons;
		}
		$worker_items = array();
		$estimated_line_keys = array();
		foreach ( $items as $item ) {
			if ( ! empty( $item['volume_only'] ) ) {
				$estimated = self::estimated_dimensions_from_cbm( $item['cbm_per_carton'] ?? 0 );
				if ( $estimated['length'] <= 0 ) { continue; }
				$item['length'] = $estimated['length'];
				$item['width'] = $estimated['width'];
				$item['height'] = $estimated['height'];
				$item['volume_only'] = false;
				$item['estimated_dimensions'] = true;
				$estimated_line_keys[] = (string) ( $item['line_key'] ?? '' );
			}
			$item['allowedOrientations'] = $item['orientations'];
			$item['grossWeight'] = $item['gross_weight'];
			$item['netWeight'] = $item['net_weight'];
			$item['maxStack'] = $item['max_stack'];
			$item['name'] = $item['product_name'];
			$worker_items[] = $item;
		}
		$worker_container = $plan['container'] ?? array();
		if ( $worker_container ) {
			$worker_container['maxPayload'] = $worker_container['max_payload'];
			$worker_container['volumeMargin'] = $worker_container['volume_margin_percent'];
			$worker_container['weightMargin'] = $worker_container['weight_margin_percent'];
		}
		$plan['packingInput'] = $worker_items ? array( 'items' => $worker_items, 'container' => $worker_container ) : null;
		$plan['estimated_dimensions_visual'] = ! empty( $estimated_line_keys );
		$plan['estimated_line_keys'] = array_values( array_filter( array_unique( $estimated_line_keys ) ) );
		$plan['estimate_notice'] = __( 'This 3D loading plan is an estimate and requires operational confirmation before loading.', 'b2b-container-loading-planner' );
		self::$last_plan = $plan;
		if ( WC()->session ) {
			// A large plan can contain thousands of placements and must not be
			// serialized into the WooCommerce session on every AJAX request.
			WC()->session->__unset( 'b2bclp_plan' );
			WC()->session->set( 'b2bclp_container', $selected );
		}
		return $plan;
	}

	private static function reason_message( $reason ) {
		$messages = array(
			'payload' => __( 'Gross payload exceeds the configured safe limit.', 'b2b-container-loading-planner' ),
			'volume' => __( 'Carton volume exceeds the configured safe capacity.', 'b2b-container-loading-planner' ),
			'dimensions' => __( 'One or more cartons are dimensionally unpackable in this container.', 'b2b-container-loading-planner' ),
			'payload_limit' => __( 'Gross payload exceeds the configured safe limit.', 'b2b-container-loading-planner' ),
			'volume_limit' => __( 'Carton volume exceeds the configured safe capacity.', 'b2b-container-loading-planner' ),
			'cannot_place' => __( 'One or more cartons are dimensionally unpackable in this container.', 'b2b-container-loading-planner' ),
			'multiple_limits' => __( 'The load exceeds multiple container constraints.', 'b2b-container-loading-planner' ),
		);
		return $messages[ $reason ] ?? __( 'All cartons could not be placed in the container.', 'b2b-container-loading-planner' );
	}

	public static function validate_cart() {
		if ( ! WC()->cart || WC()->cart->is_empty() ) { return; }
		foreach ( WC()->cart->get_cart() as $line ) {
			if ( empty( $line[ self::LINE_SNAPSHOT ] ) || (float) $line['quantity'] < 1 || floor( (float) $line['quantity'] ) !== (float) $line['quantity'] ) {
				wc_add_notice( __( 'Every item requires a valid request snapshot and a positive whole-number quantity.', 'b2b-container-loading-planner' ), 'error' );
				return;
			}
		}
		$selected = WC()->session ? (string) WC()->session->get( 'b2bclp_container', 'auto' ) : 'auto';
		$plan = self::calculate_plan( $selected );
		if ( empty( $plan['ok'] ) ) {
			wc_add_notice( self::reason_message( $plan['reason'] ?? '' ), 'error' );
		}
	}

	public static function save_line_snapshot( $item, $cart_item_key, $values, $order ) {
		if ( ! empty( $values[ self::LINE_SNAPSHOT ] ) ) {
			$snapshot = $values[ self::LINE_SNAPSHOT ];
			$item->add_meta_data( self::LINE_SNAPSHOT, wp_json_encode( $snapshot, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ), true );
			if ( self::snapshot_is_complete( $snapshot ) ) {
				$item->add_meta_data( __( 'Carton quantity', 'b2b-container-loading-planner' ), (int) $values['quantity'], true );
				$item->add_meta_data( __( 'Total units', 'b2b-container-loading-planner' ), (int) $values['quantity'] * (int) $snapshot['units_per_carton'], true );
				$item->add_meta_data( __( 'Price per piece', 'b2b-container-loading-planner' ), wc_format_decimal( (float) ( $snapshot['unit_price'] ?? 0 ) ), true );
				$item->add_meta_data( __( 'Price per carton', 'b2b-container-loading-planner' ), wc_format_decimal( (float) ( $snapshot['carton_price'] ?? 0 ) ), true );
			} else {
				$item->add_meta_data( __( 'Container calculation', 'b2b-container-loading-planner' ), __( 'Excluded — packing data missing', 'b2b-container-loading-planner' ), true );
			}
		}
	}

	public static function save_order_snapshot( $order, $data ) {
		$selected = WC()->session ? (string) WC()->session->get( 'b2bclp_container', 'auto' ) : 'auto';
		$plan = self::$last_plan ?: self::calculate_plan( $selected );
		if ( empty( $plan['ok'] ) ) { throw new Exception( esc_html__( 'The loading plan is invalid. Please return to the cart and adjust the request.', 'b2b-container-loading-planner' ) ); }
		$plan['schema_version'] = 1;
		$plan['generated_at'] = gmdate( 'c' );
		$order->update_meta_data( self::ORDER_SNAPSHOT, wp_json_encode( $plan, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ) );
		$order->update_meta_data( '_b2bclp_schema_version', 1 );
		$order->update_meta_data( '_b2bclp_external_id', wp_generate_uuid4() );
	}

	public static function assets() {
		global $post;
		$bulk_order_page = $post instanceof WP_Post && has_shortcode( $post->post_content, 'b2bclp_bulk_order' );
		if ( ! function_exists( 'is_cart' ) || ( ! is_cart() && ! is_checkout() && ! is_product() && ! $bulk_order_page ) ) { return; }
		wp_enqueue_style( 'b2bclp', B2BCLP_URL . 'assets/css/frontend.css', array(), B2BCLP_VERSION );
		wp_enqueue_script( 'b2bclp', B2BCLP_URL . 'assets/js/frontend.js', array( 'jquery' ), B2BCLP_VERSION, true );
		wp_localize_script( 'b2bclp', 'B2BCLP', array(
			'ajaxUrl' => admin_url( 'admin-ajax.php' ), 'nonce' => wp_create_nonce( 'b2bclp_plan' ), 'action' => 'b2bclp_plan',
			'pricingAction' => 'b2bclp_product_pricing',
			'currency' => array(
				'symbol' => html_entity_decode( get_woocommerce_currency_symbol(), ENT_QUOTES, 'UTF-8' ), 'position' => get_option( 'woocommerce_currency_pos', 'left' ),
				'decimals' => wc_get_price_decimals(), 'decimalSeparator' => wc_get_price_decimal_separator(), 'thousandSeparator' => wc_get_price_thousand_separator(),
			),
			'workerUrl' => B2BCLP_URL . 'assets/js/packer-worker.js', 'containers' => array_values( B2BCLP_Settings::containers() ),
			'i18n' => array(
				'loading' => __( 'Calculating loading estimate…', 'b2b-container-loading-planner' ),
				'error' => __( 'Unable to calculate the loading estimate.', 'b2b-container-loading-planner' ),
				'selectedContainer' => __( 'Selected container', 'b2b-container-loading-planner' ),
				'usableContainerCbm' => __( 'Usable container CBM', 'b2b-container-loading-planner' ),
				'cargoCbm' => __( 'Calculated cargo CBM', 'b2b-container-loading-planner' ),
				'loadedCbm' => __( 'Loaded CBM', 'b2b-container-loading-planner' ),
				'volumeUsed' => __( 'Usable CBM occupied', 'b2b-container-loading-planner' ),
				'unallocatedCbm' => __( 'Unallocated CBM', 'b2b-container-loading-planner' ),
				'cannotPlace' => __( 'Does not fit in the selected container', 'b2b-container-loading-planner' ),
				'excludedProducts' => __( 'Products not calculated', 'b2b-container-loading-planner' ),
				'packingDataMissing' => __( 'Packing data missing — included in the request, not in space or weight totals', 'b2b-container-loading-planner' ),
				'knownNetWeight' => __( 'Known net weight', 'b2b-container-loading-planner' ),
				'knownGrossWeight' => __( 'Known gross weight', 'b2b-container-loading-planner' ),
				'knownPayloadUsed' => __( 'Known payload used', 'b2b-container-loading-planner' ),
				'remainingFromKnownWeight' => __( 'Remaining from known weight', 'b2b-container-loading-planner' ),
				'aggregateVisual' => __( 'Aggregate cargo volume — not carton placement', 'b2b-container-loading-planner' ),
				'hybridVisual' => __( 'Amber block is CBM-only cargo — not verified carton placement', 'b2b-container-loading-planner' ),
				'estimatedCartonsVisual' => __( 'Amber cartons use estimated dimensions derived from CBM — not verified carton measurements', 'b2b-container-loading-planner' ),
				'totalCartons' => __( 'Total cartons', 'b2b-container-loading-planner' ),
				'totalPieces' => __( 'Total pieces', 'b2b-container-loading-planner' ),
				'knownTotalPieces' => __( 'Known total pieces', 'b2b-container-loading-planner' ),
				'calculatedCartons' => __( 'Cartons included in loading calculation', 'b2b-container-loading-planner' ),
				'piecePrice' => __( 'Piece price', 'b2b-container-loading-planner' ),
				'cartons' => __( 'Cartons', 'b2b-container-loading-planner' ),
				'pieces' => __( 'Pieces', 'b2b-container-loading-planner' ),
				'totalPrice' => __( 'Total price', 'b2b-container-loading-planner' ),
			),
		) );
	}

	public static function render( $allow_empty = false ) {
		if ( ! WC()->cart || ( ! $allow_empty && WC()->cart->is_empty() ) ) { return; }
		$current = WC()->session ? (string) WC()->session->get( 'b2bclp_container', 'auto' ) : 'auto';
		?>
		<section id="b2bclp-planner" class="b2bclp-planner" aria-live="polite">
		<h2><?php esc_html_e( 'Container loading estimate', 'b2b-container-loading-planner' ); ?></h2>
		<label for="b2bclp-container-select"><?php esc_html_e( 'Container', 'b2b-container-loading-planner' ); ?></label>
		<select id="b2bclp-container-select"><option value="auto" <?php selected( $current, 'auto' ); ?>><?php esc_html_e( 'Automatic — smallest suitable', 'b2b-container-loading-planner' ); ?></option><?php foreach ( B2BCLP_Settings::containers() as $id => $c ) : ?><option value="<?php echo esc_attr( $id ); ?>" <?php selected( $current, $id ); ?>><?php echo esc_html( $c['label'] ); ?></option><?php endforeach; ?></select>
		<div class="b2bclp-layout"><div class="b2bclp-canvas" role="img" aria-label="<?php esc_attr_e( 'Interactive 3D carton loading estimate', 'b2b-container-loading-planner' ); ?>"></div><div class="b2bclp-summary"></div></div>
		<div class="b2bclp-warning"></div><p class="b2bclp-disclaimer"><?php esc_html_e( 'Estimate only. Operational confirmation is required; no axle-load guarantee is provided.', 'b2b-container-loading-planner' ); ?></p>
		</section>
		<?php
	}

	/** Wrap the classic cart and its collaterals in a desktop two-column layout. */
	public static function cart_layout_open() {
		echo '<div class="b2bclp-cart-shell"><div class="b2bclp-cart-main">';
	}

	public static function cart_layout_close() {
		echo '</div><aside class="b2bclp-cart-sidebar" aria-label="' . esc_attr__( 'Container loading calculator', 'b2b-container-loading-planner' ) . '">';
		self::render();
		echo '</aside></div>';
	}

	/** Render B2BKing's supported order form beside the live cart loading plan. */
	public static function bulk_order_shortcode() {
		if ( ! shortcode_exists( 'b2bking_bulkorder' ) ) {
			return '<div class="woocommerce-error" role="alert">' . esc_html__( 'B2BKing must be active to use the bulk order page.', 'b2b-container-loading-planner' ) . '</div>';
		}

		ob_start();
		?>
		<section class="b2bclp-bulk-order" data-b2bclp-bulk-order>
			<div class="b2bclp-bulk-main">
				<header class="b2bclp-bulk-intro">
					<h2><?php esc_html_e( 'Bulk carton order', 'b2b-container-loading-planner' ); ?></h2>
					<p><?php esc_html_e( 'Choose products and enter carton quantities. Add them to the cart to update the loading estimate, available CBM, and payload.', 'b2b-container-loading-planner' ); ?></p>
				</header>
				<?php echo do_shortcode( '[b2bking_bulkorder theme="cream" multiselect="yes" width="adaptive" sku="yes"]' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Trusted B2BKing shortcode output. ?>
			</div>
			<aside class="b2bclp-bulk-sidebar" aria-label="<?php esc_attr_e( 'Container loading calculator', 'b2b-container-loading-planner' ); ?>">
				<?php self::render( true ); ?>
				<p class="b2bclp-bulk-cart-link"><a class="button" href="<?php echo esc_url( wc_get_cart_url() ); ?>"><?php esc_html_e( 'Review cart and request', 'b2b-container-loading-planner' ); ?></a></p>
			</aside>
		</section>
		<?php
		return ob_get_clean();
	}

	public static function ajax_plan() {
		check_ajax_referer( 'b2bclp_plan', 'nonce' );
		if ( ! WC()->cart ) { wp_send_json_error( array( 'message' => __( 'Cart is unavailable.', 'b2b-container-loading-planner' ) ), 400 ); }
		$selected = isset( $_POST['container'] ) ? sanitize_key( wp_unslash( $_POST['container'] ) ) : 'auto';
		if ( 'auto' !== $selected && ! isset( B2BCLP_Settings::containers()[ $selected ] ) ) { wp_send_json_error( array( 'message' => __( 'Invalid container selection.', 'b2b-container-loading-planner' ) ), 400 ); }
		wp_send_json_success( array( 'plan' => self::calculate_plan( $selected ) ) );
	}

	/** Supply effective per-piece prices and carton units for dynamic B2BKing rows. */
	public static function ajax_product_pricing() {
		check_ajax_referer( 'b2bclp_plan', 'nonce' );
		$raw_ids = isset( $_POST['ids'] ) ? (array) wp_unslash( $_POST['ids'] ) : array();
		$ids = array_slice( array_values( array_unique( array_filter( array_map( 'absint', $raw_ids ) ) ) ), 0, 50 );
		$products = array();
		foreach ( $ids as $product_id ) {
			$product = wc_get_product( $product_id );
			if ( ! $product || ! $product->is_visible() ) { continue; }
			$profile = self::profile( $product_id, 0 );
			$units = max( 0, (int) ( $profile['units_per_carton'] ?? 0 ) );
			$unit_price = (float) wc_get_price_to_display( $product );
			$products[ $product_id ] = array(
				'productId' => $product_id,
				'unitsPerCarton' => $units,
				'unitPrice' => $unit_price,
				'cartonPrice' => self::carton_price( $unit_price, $units ),
			);
		}
		wp_send_json_success( array( 'products' => $products ) );
	}
}
