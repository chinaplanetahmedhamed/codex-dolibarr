/* global self */
(function () {
    'use strict';

    var EPSILON = 0.000001;

    function number(value, fallback) {
        var parsed = Number(value);
        return Number.isFinite(parsed) ? parsed : (fallback || 0);
    }

    function cleanId(value) {
        return String(value == null ? '' : value).replace(/[^A-Za-z0-9_.:-]/g, '-');
    }

    function orientationPermutations(item) {
        var dimensions = [number(item.length), number(item.width), number(item.height)];
        var codes = {
            lwh: [0, 1, 2], lhw: [0, 2, 1],
            wlh: [1, 0, 2], whl: [1, 2, 0],
            hlw: [2, 0, 1], hwl: [2, 1, 0]
        };
        var orientationSource = item.allowedOrientations != null ? item.allowedOrientations : item.orientations;
        var allowed = Array.isArray(orientationSource) ? orientationSource : (typeof orientationSource === 'string' ? orientationSource.split(/[\s,|]+/) : []);
        var requested = allowed.length ? allowed : Object.keys(codes);
        var seen = {};
        var result = [];

        requested.forEach(function (entry) {
            var indices;
            if (Array.isArray(entry) && entry.length === 3) {
                var direct = entry.map(function (value) { return number(value); });
                var directKey = direct.join('x');
                if (direct.every(function (value) { return value > 0; }) && !seen[directKey]) {
                    seen[directKey] = true;
                    result.push({ length: direct[0], width: direct[1], height: direct[2], code: directKey });
                }
                return;
            }
            indices = codes[String(entry).toLowerCase()];
            if (!indices) {
                return;
            }
            var values = indices.map(function (index) { return dimensions[index]; });
            var key = values.join('x');
            if (values.every(function (value) { return value > 0; }) && !seen[key]) {
                seen[key] = true;
                result.push({ length: values[0], width: values[1], height: values[2], code: String(entry).toLowerCase() });
            }
        });
        return result;
    }

    function overlaps(a, b) {
        return a.x < b.x + b.length - EPSILON && a.x + a.length > b.x + EPSILON &&
            a.y < b.y + b.width - EPSILON && a.y + a.width > b.y + EPSILON &&
            a.z < b.z + b.height - EPSILON && a.z + a.height > b.z + EPSILON;
    }

    function supported(candidate, placed) {
        if (candidate.z <= EPSILON) {
            return { ok: true, level: 1, supporter: null };
        }
        for (var i = 0; i < placed.length; i += 1) {
            var base = placed[i];
            var top = base.z + base.height;
            var footprintFits = candidate.x >= base.x - EPSILON &&
                candidate.y >= base.y - EPSILON &&
                candidate.x + candidate.length <= base.x + base.length + EPSILON &&
                candidate.y + candidate.width <= base.y + base.width + EPSILON;
            if (Math.abs(top - candidate.z) < EPSILON && footprintFits && base.stackable && base.stackLevel < base.maxStack) {
                return { ok: true, level: base.stackLevel + 1, supporter: base.placementId };
            }
        }
        return { ok: false, level: 0, supporter: null };
    }

    function candidateKey(point) {
        return [point.x, point.y, point.z].map(function (value) { return value.toFixed(6); }).join(':');
    }

    function pruneCandidates(points, container) {
        var unique = {};
        return points.filter(function (point) {
            var inside = point.x >= -EPSILON && point.y >= -EPSILON && point.z >= -EPSILON &&
                point.x < container.length - EPSILON && point.y < container.width - EPSILON && point.z < container.height - EPSILON;
            var key = candidateKey(point);
            if (!inside || unique[key]) {
                return false;
            }
            unique[key] = true;
            return true;
        }).sort(function (a, b) {
            return (a.z - b.z) || (a.y - b.y) || (a.x - b.x);
        });
    }

    function expandItems(items) {
        var cartons = [];
        (items || []).forEach(function (item, itemIndex) {
            var count = Math.max(0, Math.floor(number(item.cartons != null ? item.cartons : item.quantity)));
            var orientations = orientationPermutations(item);
            var baseVolume = number(item.length) * number(item.width) * number(item.height);
            for (var cartonIndex = 0; cartonIndex < count; cartonIndex += 1) {
                cartons.push({
                    itemKey: cleanId(item.key || item.id || itemIndex),
                    itemIndex: itemIndex,
                    cartonIndex: cartonIndex,
                    name: String(item.name || ''),
                    grossWeight: Math.max(0, number(item.grossWeight != null ? item.grossWeight : item.gross_weight)),
                    volume: Math.max(0, baseVolume),
                    orientations: orientations,
                    stackable: true,
                    maxStack: 999999,
                    color: item.color || null
                });
            }
        });
        cartons.sort(function (a, b) {
            var maxA = Math.max.apply(Math, a.orientations.map(function (o) { return Math.max(o.length, o.width, o.height); }));
            var maxB = Math.max.apply(Math, b.orientations.map(function (o) { return Math.max(o.length, o.width, o.height); }));
            return (b.volume - a.volume) || (b.grossWeight - a.grossWeight) || (maxB - maxA) ||
                a.itemKey.localeCompare(b.itemKey) || (a.cartonIndex - b.cartonIndex);
        });
        return cartons;
    }

    function pack(payload) {
        var inputContainer = payload.container || {};
        var container = {
            id: cleanId(inputContainer.id || inputContainer.key || 'container'),
            length: Math.max(0, number(inputContainer.length)),
            width: Math.max(0, number(inputContainer.width)),
            height: Math.max(0, number(inputContainer.height)),
            maxPayload: Math.max(0, number(inputContainer.maxPayload != null ? inputContainer.maxPayload : inputContainer.max_payload)),
            capacityCbm: Math.max(0, number(inputContainer.capacityCbm != null ? inputContainer.capacityCbm : inputContainer.capacity_cbm)),
            volumeMargin: Math.min(99.99, Math.max(0, number(inputContainer.volumeMargin != null ? inputContainer.volumeMargin : (inputContainer.volume_margin_percent != null ? inputContainer.volume_margin_percent : inputContainer.volume_margin)))),
            weightMargin: Math.min(99.99, Math.max(0, number(inputContainer.weightMargin != null ? inputContainer.weightMargin : (inputContainer.weight_margin_percent != null ? inputContainer.weight_margin_percent : inputContainer.weight_margin))))
        };
        var placements = [];
        var unpacked = [];
        var candidates = [{ x: 0, y: 0, z: 0 }];
        var cartons = expandItems(payload.items);

        cartons.forEach(function (carton, sortedIndex) {
            var selected = null;
            for (var p = 0; p < candidates.length && !selected; p += 1) {
                for (var o = 0; o < carton.orientations.length; o += 1) {
                    var orientation = carton.orientations[o];
                    var candidate = {
                        x: candidates[p].x, y: candidates[p].y, z: candidates[p].z,
                        length: orientation.length, width: orientation.width, height: orientation.height
                    };
                    var fitsBounds = candidate.x + candidate.length <= container.length + EPSILON &&
                        candidate.y + candidate.width <= container.width + EPSILON &&
                        candidate.z + candidate.height <= container.height + EPSILON;
                    if (!fitsBounds || placements.some(function (placed) { return overlaps(candidate, placed); })) {
                        continue;
                    }
                    var support = supported(candidate, placements);
                    if (!support.ok || support.level > carton.maxStack) {
                        continue;
                    }
                    selected = {
                        pointIndex: p,
                        orientation: orientation,
                        support: support,
                        candidate: candidate
                    };
                    break;
                }
            }

            if (!selected) {
                unpacked.push({ itemKey: carton.itemKey, cartonIndex: carton.cartonIndex, name: carton.name, reason: 'dimensions' });
                return;
            }

            var box = selected.candidate;
            var placement = {
                placementId: carton.itemKey + '-' + carton.cartonIndex + '-' + sortedIndex,
                itemKey: carton.itemKey,
                cartonIndex: carton.cartonIndex,
                name: carton.name,
                x: box.x, y: box.y, z: box.z,
                length: box.length, width: box.width, height: box.height,
                grossWeight: carton.grossWeight,
                volume: carton.volume,
                orientation: selected.orientation.code,
                stackable: carton.stackable,
                maxStack: carton.maxStack,
                stackLevel: selected.support.level,
                supporter: selected.support.supporter,
                color: carton.color
            };
            placements.push(placement);
            candidates.splice(selected.pointIndex, 1);
            candidates.push(
                { x: box.x + box.length, y: box.y, z: box.z },
                { x: box.x, y: box.y + box.width, z: box.z }
            );
            if (carton.stackable && placement.stackLevel < carton.maxStack) {
                candidates.push({ x: box.x, y: box.y, z: box.z + box.height });
            }
            candidates = pruneCandidates(candidates, container);
        });

        var totalVolume = cartons.reduce(function (sum, carton) { return sum + carton.volume; }, 0);
        var grossWeight = cartons.reduce(function (sum, carton) { return sum + carton.grossWeight; }, 0);
        var containerVolume = container.length * container.width * container.height;
        var operationalVolume = container.capacityCbm > 0 ? Math.min(containerVolume, container.capacityCbm * 1000000) : containerVolume;
        var usableVolume = operationalVolume * (1 - container.volumeMargin / 100);
        var usablePayload = container.maxPayload * (1 - container.weightMargin / 100);
        var payloadExceeded = container.maxPayload > 0 && grossWeight > usablePayload + EPSILON;
        var volumeExceeded = containerVolume <= 0 || totalVolume > usableVolume + EPSILON;

        return {
            algorithm: 'deterministic-extreme-point-v1',
            containerId: container.id,
            placements: placements,
            unpacked: unpacked,
            totals: {
                cartons: cartons.length,
                packedCartons: placements.length,
                unpackedCartons: unpacked.length,
                volume: totalVolume,
                grossWeight: grossWeight,
                containerVolume: containerVolume,
                usableVolume: usableVolume,
                usablePayload: usablePayload
            },
            valid: unpacked.length === 0 && !payloadExceeded && !volumeExceeded,
            payloadExceeded: payloadExceeded,
            volumeExceeded: volumeExceeded
        };
    }

    self.addEventListener('message', function (event) {
        var message = event.data || {};
        if (message.type !== 'pack') {
            return;
        }
        try {
            self.postMessage({ type: 'result', requestId: message.requestId, result: pack(message.payload || {}) });
        } catch (error) {
            self.postMessage({ type: 'error', requestId: message.requestId, error: error && error.message ? error.message : 'Packing failed' });
        }
    });
}());
