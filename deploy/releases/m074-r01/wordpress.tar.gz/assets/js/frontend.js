(function (window, document) {
    'use strict';

    var config = window.B2BCLP || window.b2bClpConfig || window.B2BCLP_CONFIG || {};
    var roots = [];
    var instances = [];
    var refreshTimer = 0;
    var activeRequest = null;
    var requestSequence = 0;

    function t(key, fallback) {
        return config.i18n && config.i18n[key] ? config.i18n[key] : fallback;
    }

    function num(value, fallback) {
        var parsed = Number(value);
        return Number.isFinite(parsed) ? parsed : (fallback || 0);
    }

    function escapeHtml(value) {
        return String(value == null ? '' : value).replace(/[&<>'"]/g, function (character) {
            return { '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#039;', '"': '&quot;' }[character];
        });
    }

    function parseJson(value) {
        if (!value) { return null; }
        if (typeof value === 'object') { return value; }
        try { return JSON.parse(value); } catch (error) { return null; }
    }

    function format(value, digits) {
        return num(value).toLocaleString(config.locale || document.documentElement.lang || undefined, {
            minimumFractionDigits: digits,
            maximumFractionDigits: digits
        });
    }

    function formatMoney(value) {
        var currency = config.currency || {};
        var decimals = num(currency.decimals, 2);
        var amount = format(value, decimals);
        var symbol = String(currency.symbol || '');
        var position = String(currency.position || 'left');
        if (position === 'right') { return amount + symbol; }
        if (position === 'right_space') { return amount + ' ' + symbol; }
        if (position === 'left_space') { return symbol + ' ' + amount; }
        return symbol + amount;
    }

    function normalizePlan(raw) {
        raw = raw || {};
        var totals = raw.totals || raw.summary || {};
        var container = raw.container || raw.selectedContainer || raw.selected_container || {};
        var capacity = raw.capacity || raw.limits || {};
        var used = raw.used || {};
        var remaining = raw.remaining || {};
        var capacityVolume = num(capacity.volume_cbm != null ? capacity.volume_cbm : (capacity.volume != null ? capacity.volume : capacity.usable_cbm));
        var capacityPayload = num(capacity.payload != null ? capacity.payload : capacity.usable_payload);
        var usedVolume = num(used.volume_cbm != null ? used.volume_cbm : used.volume);
        var usedWeight = num(used.gross_weight != null ? used.gross_weight : used.payload);
        var warnings = raw.warnings || raw.errors || [];
        if (!Array.isArray(warnings)) { warnings = [warnings]; }
        if (raw.ok === false && raw.reason && !warnings.length) { warnings = [String(raw.reason).replace(/_/g, ' ')]; }
        return {
            valid: raw.ok !== false && raw.success !== false && raw.valid !== false && raw.canSubmit !== false && raw.can_submit !== false,
            container: container,
            containers: raw.containers || raw.availableContainers || raw.available_containers || config.containers || [],
            recommendedId: raw.recommendedContainerId || raw.recommended_container_id || raw.recommended_container || raw.recommended || '',
            selectionMode: raw.selection_mode || raw.selectionMode || '',
            placements: raw.placements || (raw.loadingPlan && raw.loadingPlan.placements) || raw.loading_plan || [],
            unpacked: raw.unpacked || raw.unpackedItems || raw.unpacked_items || [],
			excluded: raw.excluded_items || raw.excludedItems || [],
            warnings: warnings,
            totals: {
                cartons: num(totals.cartons || totals.total_cartons),
                units: num(totals.units || totals.total_units),
				calculatedCartons: num(totals.calculated_cartons != null ? totals.calculated_cartons : (totals.cartons || totals.total_cartons)),
				calculatedUnits: num(totals.calculated_units != null ? totals.calculated_units : (totals.units || totals.total_units)),
				unitsComplete: totals.units_complete !== false,
				missingUnitsCartons: num(totals.missing_units_cartons),
                volume: num(totals.volume != null ? totals.volume : (totals.volume_cbm != null ? totals.volume_cbm : (totals.cbm || totals.total_cbm))),
                loadedVolume: usedVolume,
                grossWeight: num(totals.grossWeight != null ? totals.grossWeight : (totals.gross_weight || totals.total_gross_weight)),
                netWeight: num(totals.netWeight != null ? totals.netWeight : (totals.net_weight || totals.total_net_weight)),
                usedVolumePercent: num(used.volume_percent != null ? used.volume_percent : (totals.usedVolumePercent != null ? totals.usedVolumePercent : (totals.used_volume_percent != null ? totals.used_volume_percent : (capacityVolume ? usedVolume / capacityVolume * 100 : 0)))),
                usedWeightPercent: num(used.weight_percent != null ? used.weight_percent : (totals.usedWeightPercent != null ? totals.usedWeightPercent : (totals.used_weight_percent != null ? totals.used_weight_percent : (capacityPayload ? usedWeight / capacityPayload * 100 : 0)))),
                remainingVolume: num(remaining.volume_cbm != null ? remaining.volume_cbm : (remaining.volume != null ? remaining.volume : (totals.remaining_cbm != null ? totals.remaining_cbm : (totals.remainingVolume != null ? totals.remainingVolume : totals.remaining_volume)))),
                remainingWeight: num(remaining.payload != null ? remaining.payload : (totals.remaining_payload != null ? totals.remaining_payload : (totals.remainingWeight != null ? totals.remainingWeight : totals.remaining_weight))),
                capacityVolume: capacityVolume,
                capacityPayload: capacityPayload,
                weightComplete: totals.weight_complete !== false && num(totals.missing_weight_cartons) === 0,
                missingWeightCartons: num(totals.missing_weight_cartons),
                missingDimensionCartons: num(totals.missing_dimension_cartons)
            },
            packingInput: raw.packingInput || raw.packing_input || null,
            visualMode: raw.visual_mode || raw.visualMode || '',
			estimatedDimensionsVisual: !!(raw.estimated_dimensions_visual || raw.estimatedDimensionsVisual),
			estimatedLineKeys: raw.estimated_line_keys || raw.estimatedLineKeys || [],
            serverFingerprint: raw.fingerprint || raw.serverFingerprint || ''
        };
    }

    function colorFor(key, index) {
        var palette = config.colors || ['#2563eb', '#f97316', '#16a34a', '#9333ea', '#0891b2', '#dc2626', '#ca8a04'];
        var hash = index;
        String(key || '').split('').forEach(function (character) { hash = ((hash << 5) - hash) + character.charCodeAt(0); });
        return palette[Math.abs(hash) % palette.length];
    }

    function Planner(root) {
        this.root = root;
        this.plan = normalizePlan(parseJson(root.getAttribute('data-plan')) || config.initialPlan || {});
        this.canvas = null;
        this.ctx = null;
        this.angle = -0.65;
        this.elevation = 0.52;
        this.zoom = 0.9;
        this.dragging = false;
        this.dragX = 0;
        this.dragY = 0;
        this.worker = null;
        this.workerRequest = 0;
		this.drawFrame = 0;
        this.ensureMarkup();
        this.bind();
        this.render();
        this.calculateClientEstimate();
    }

    Planner.prototype.ensureMarkup = function () {
        this.root.classList.add('b2bclp-planner');
        this.root.setAttribute('aria-live', 'polite');
        var serverCanvas = this.root.querySelector('.b2bclp-canvas');
        var serverSummary = this.root.querySelector('.b2bclp-summary');
        var serverWarning = this.root.querySelector('.b2bclp-warning');
        var serverSelect = this.root.querySelector('#b2bclp-container-select');
        if (serverCanvas && !serverCanvas.matches('canvas')) {
			serverCanvas.innerHTML = '<canvas data-b2bclp-stage tabindex="0" role="img"></canvas>' + this.viewControls() + '<p class="b2bclp-canvas-help">' + escapeHtml(t('canvasHelp', 'Drag in any direction to rotate. Scroll or use +/− to zoom.')) + '</p>';
            serverCanvas.classList.add('b2bclp-visual');
        } else if (serverCanvas) {
            serverCanvas.setAttribute('data-b2bclp-stage', '');
            serverCanvas.setAttribute('tabindex', '0');
        }
        if (serverSummary) {
            serverSummary.classList.add('b2bclp-details');
            serverSummary.innerHTML = '<div class="b2bclp-metrics" data-b2bclp-metrics></div><div data-b2bclp-messages></div><div class="b2bclp-unpacked" data-b2bclp-unpacked></div><div class="b2bclp-status" data-b2bclp-status role="status"></div>';
        }
        if (serverWarning) {
            serverWarning.setAttribute('data-b2bclp-server-warning', '');
        }
        if (serverSelect) {
            serverSelect.setAttribute('data-b2bclp-container-select', '');
        }
        if (!this.root.querySelector('[data-b2bclp-stage]')) {
            this.root.innerHTML = '<section class="b2bclp-card">' +
                '<header class="b2bclp-header"><div><h2>' + escapeHtml(t('title', 'Container loading estimate')) + '</h2>' +
                '<p class="b2bclp-disclaimer">' + escapeHtml(t('estimateDisclaimer', 'Planning estimate only — operational confirmation is required before loading.')) + '</p></div>' +
                '<label class="b2bclp-container-field"><span>' + escapeHtml(t('container', 'Container')) + '</span><select data-b2bclp-container-select></select></label></header>' +
				'<div class="b2bclp-layout"><div class="b2bclp-visual"><canvas data-b2bclp-stage tabindex="0" role="img"></canvas>' + this.viewControls() + '<p class="b2bclp-canvas-help">' + escapeHtml(t('canvasHelp', 'Drag in any direction to rotate. Scroll or use +/− to zoom.')) + '</p></div>' +
                '<div class="b2bclp-details"><div class="b2bclp-metrics" data-b2bclp-metrics></div><div data-b2bclp-messages></div></div></div>' +
                '<div class="b2bclp-unpacked" data-b2bclp-unpacked></div><div class="b2bclp-status" data-b2bclp-status role="status"></div>' +
                '</section>';
        }
        this.canvas = this.root.querySelector('[data-b2bclp-stage]');
        this.ctx = this.canvas && this.canvas.getContext ? this.canvas.getContext('2d') : null;
    };

	Planner.prototype.viewControls = function () {
		return '<div class="b2bclp-view-controls" role="group" aria-label="' + escapeHtml(t('viewControls', '3D view controls')) + '">' +
			'<button type="button" data-b2bclp-view="left" aria-label="' + escapeHtml(t('rotateLeft', 'Rotate left')) + '">↶</button>' +
			'<button type="button" data-b2bclp-view="reset" aria-label="' + escapeHtml(t('resetView', 'Reset 3D view')) + '">⌂</button>' +
			'<button type="button" data-b2bclp-view="right" aria-label="' + escapeHtml(t('rotateRight', 'Rotate right')) + '">↷</button>' +
			'<button type="button" data-b2bclp-view="zoom-out" aria-label="' + escapeHtml(t('zoomOut', 'Zoom out')) + '">−</button>' +
			'<button type="button" data-b2bclp-view="zoom-in" aria-label="' + escapeHtml(t('zoomIn', 'Zoom in')) + '">+</button></div>';
	};

    Planner.prototype.bind = function () {
        var self = this;
        var select = this.root.querySelector('[data-b2bclp-container-select]');
        if (select) {
            select.addEventListener('change', function () { refreshAll(select.value, true); });
        }
        this.root.addEventListener('click', function (event) {
            var button = event.target.closest('[data-b2bclp-container-id]');
            if (button) { refreshAll(button.getAttribute('data-b2bclp-container-id'), true); }
			var viewButton = event.target.closest('[data-b2bclp-view]');
			if (viewButton) {
				var action = viewButton.getAttribute('data-b2bclp-view');
				if (action === 'left') { self.angle -= 0.22; }
				if (action === 'right') { self.angle += 0.22; }
				if (action === 'zoom-in') { self.zoom = Math.min(2.4, self.zoom * 1.12); }
				if (action === 'zoom-out') { self.zoom = Math.max(0.42, self.zoom * 0.88); }
				if (action === 'reset') { self.angle = -0.72; self.elevation = 0.58; self.zoom = 0.92; }
				self.scheduleDraw();
			}
        });
        if (!this.canvas) { return; }
        this.canvas.addEventListener('pointerdown', function (event) {
            self.dragging = true; self.dragX = event.clientX; self.dragY = event.clientY;
            self.canvas.setPointerCapture(event.pointerId);
        });
        this.canvas.addEventListener('pointermove', function (event) {
            if (!self.dragging) { return; }
            self.angle += (event.clientX - self.dragX) * 0.012;
            self.elevation = Math.max(0.12, Math.min(1.25, self.elevation + (event.clientY - self.dragY) * 0.008));
			self.dragX = event.clientX; self.dragY = event.clientY; self.scheduleDraw();
        });
        this.canvas.addEventListener('pointerup', function () { self.dragging = false; });
        this.canvas.addEventListener('pointercancel', function () { self.dragging = false; });
        this.canvas.addEventListener('wheel', function (event) {
			event.preventDefault(); self.zoom = Math.max(0.42, Math.min(2.4, self.zoom * (event.deltaY > 0 ? 0.9 : 1.1))); self.scheduleDraw();
        }, { passive: false });
        this.canvas.addEventListener('keydown', function (event) {
			if (event.key === '+' || event.key === '=') { self.zoom = Math.min(2.4, self.zoom * 1.1); self.scheduleDraw(); }
			if (event.key === '-') { self.zoom = Math.max(0.42, self.zoom * 0.9); self.scheduleDraw(); }
			if (event.key === 'ArrowLeft' || event.key === 'ArrowRight') { self.angle += event.key === 'ArrowLeft' ? -0.12 : 0.12; self.scheduleDraw(); }
			if (event.key === 'ArrowUp' || event.key === 'ArrowDown') { self.elevation = Math.max(0.12, Math.min(1.25, self.elevation + (event.key === 'ArrowUp' ? -0.08 : 0.08))); self.scheduleDraw(); }
        });
        if (window.ResizeObserver) {
            new window.ResizeObserver(function () { self.resizeCanvas(); }).observe(this.canvas);
        } else {
            window.addEventListener('resize', function () { self.resizeCanvas(); });
        }
    };

	Planner.prototype.scheduleDraw = function () {
		var self = this;
		if (this.drawFrame) { return; }
		this.drawFrame = window.requestAnimationFrame(function () { self.drawFrame = 0; self.draw(); });
	};

    Planner.prototype.setLoading = function (loading) {
        this.root.classList.toggle('is-loading', loading);
        this.root.setAttribute('aria-busy', loading ? 'true' : 'false');
        var status = this.root.querySelector('[data-b2bclp-status]');
        if (status) { status.textContent = loading ? t('updating', 'Updating loading plan…') : ''; }
    };

    Planner.prototype.setPlan = function (plan) {
        this.plan = normalizePlan(plan);
        this.render();
		updateBulkCartSummary(document.querySelector('[data-b2bclp-bulk-order]'), this.plan.totals);
        this.calculateClientEstimate();
    };

    Planner.prototype.render = function () {
        this.renderContainers(); this.renderMetrics(); this.renderMessages(); this.renderUnpacked(); this.resizeCanvas();
        this.root.classList.toggle('is-invalid', !this.plan.valid);
    };

    Planner.prototype.renderContainers = function () {
        var select = this.root.querySelector('[data-b2bclp-container-select]');
        if (!select) { return; }
		var current = this.plan.selectionMode === 'auto' ? 'auto' : String(this.plan.container.id || this.plan.container.key || '');
        var automatic = '<option value="auto"' + (current === 'auto' || this.plan.selectionMode === 'auto' ? ' selected' : '') + '>' + escapeHtml(t('automatic', 'Automatic — smallest suitable')) + '</option>';
        select.innerHTML = automatic + this.plan.containers.map(function (container) {
            var id = String(container.id || container.key || '');
            var label = String(container.label || container.name || id);
            return '<option value="' + escapeHtml(id) + '"' + (id === current && this.plan.selectionMode !== 'auto' ? ' selected' : '') + '>' + escapeHtml(label) + '</option>';
        }, this).join('');
        if (!this.plan.containers.length && current && current !== 'auto') {
            select.innerHTML = '<option value="' + escapeHtml(current) + '">' + escapeHtml(this.plan.container.label || this.plan.container.name || current) + '</option>';
        }
        select.disabled = !select.options.length;
    };

    Planner.prototype.renderMetrics = function () {
        var target = this.root.querySelector('[data-b2bclp-metrics]');
        if (!target) { return; }
        var totals = this.plan.totals;
        var container = this.plan.container || {};
        var dimensions = [
            num(container.length || container.internalLength || container.internal_length),
            num(container.width || container.internalWidth || container.internal_width),
            num(container.height || container.internalHeight || container.internal_height)
        ];
        var containerName = String(container.label || container.name || container.id || container.key || '');
        var capacityCbm = num(container.capacity_cbm || container.capacityCbm || totals.capacityVolume);
        var containerSpec = containerName ? '<div class="b2bclp-container-spec"><span>' + escapeHtml(t('selectedContainer', 'Selected container')) + '</span><strong>' + escapeHtml(containerName) + '</strong>' +
            (dimensions.every(function (value) { return value > 0; }) ? '<small>' + dimensions.map(function (value) { return format(value, 0); }).join(' × ') + ' cm</small>' : '') +
            (capacityCbm > 0 ? '<small>' + escapeHtml(t('usableContainerCbm', 'Usable container CBM')) + ': ' + format(capacityCbm, 3) + ' m³</small>' : '') + '</div>' : '';
        var metrics = [
            [t('totalCartons', 'Total cartons'), format(totals.cartons, 0)],
            [totals.unitsComplete ? t('totalPieces', 'Total pieces') : t('knownTotalPieces', 'Known total pieces'), format(totals.units, 0)],
            [t('cargoCbm', 'Calculated cargo CBM'), format(totals.volume, 3) + ' m³'],
            [t('loadedCbm', 'Loaded CBM'), format(totals.loadedVolume, 3) + ' m³'],
            [totals.weightComplete ? t('netWeight', 'Net weight') : t('knownNetWeight', 'Known net weight'), format(totals.netWeight, 1) + ' kg'],
            [totals.weightComplete ? t('grossWeight', 'Gross weight') : t('knownGrossWeight', 'Known gross weight'), format(totals.grossWeight, 1) + ' kg']
        ];
		if (totals.calculatedCartons !== totals.cartons) {
			metrics.splice(2, 0, [t('calculatedCartons', 'Cartons included in loading calculation'), format(totals.calculatedCartons, 0)]);
		}
        target.innerHTML = containerSpec + metrics.map(function (metric) {
            return '<div class="b2bclp-metric"><span>' + escapeHtml(metric[0]) + '</span><strong>' + escapeHtml(metric[1]) + '</strong></div>';
        }).join('') + this.progress(t('volumeUsed', 'Usable CBM occupied'), totals.usedVolumePercent, totals.remainingVolume, 'm³', t('unallocatedCbm', 'Unallocated CBM')) +
            this.progress(totals.weightComplete ? t('payloadUsed', 'Payload used') : t('knownPayloadUsed', 'Known payload used'), totals.usedWeightPercent, totals.remainingWeight, 'kg', totals.weightComplete ? null : t('remainingFromKnownWeight', 'Remaining from known weight'));
    };

    Planner.prototype.progress = function (label, percent, remaining, unit, remainingLabel) {
        var bounded = Math.max(0, Math.min(100, percent));
        return '<div class="b2bclp-progress-row"><div><span>' + escapeHtml(label) + '</span><strong>' + format(percent, 1) + '%</strong></div>' +
            '<progress max="100" value="' + bounded + '">' + bounded + '%</progress><small>' + escapeHtml(remainingLabel || t('remaining', 'Remaining')) + ': ' + format(remaining, unit === 'm³' ? 3 : 1) + ' ' + unit + '</small></div>';
    };

    Planner.prototype.renderMessages = function () {
        var target = this.root.querySelector('[data-b2bclp-messages]');
        if (!target) { return; }
        var messages = this.plan.warnings.slice();
        if (this.plan.recommendedId && String(this.plan.recommendedId) !== String(this.plan.container.id || this.plan.container.key || '')) {
            messages.unshift(t('recommendation', 'Recommended container') + ': ' + this.plan.recommendedId);
        }
        target.innerHTML = messages.map(function (message) {
            var text = typeof message === 'object' ? (message.message || message.text || '') : message;
            return '<div class="b2bclp-notice" role="alert">' + escapeHtml(text) + '</div>';
        }).join('');
        var serverWarning = this.root.querySelector('[data-b2bclp-server-warning]');
        if (serverWarning) {
            serverWarning.innerHTML = target.innerHTML;
            target.innerHTML = '';
        }
    };

    Planner.prototype.renderUnpacked = function () {
        var target = this.root.querySelector('[data-b2bclp-unpacked]');
        if (!target) { return; }
		if (!this.plan.unpacked.length && !this.plan.excluded.length) { target.innerHTML = ''; return; }
		var html = '';
        var groups = {};
        this.plan.unpacked.forEach(function (item) {
            var name = String(item.name || item.itemName || item.key || t('carton', 'Carton'));
            var reason = String(item.reason || 'cannot_place');
            var key = name + '|' + reason;
            if (!groups[key]) { groups[key] = { name:name, reason:reason, count:0 }; }
            groups[key].count += Math.max(1, num(item.count || item.quantity, 1));
        });
        var reasonLabels = {
            cannot_place: t('cannotPlace', 'Does not fit in the selected container'),
            payload_exceeded: t('payloadExceeded', 'Payload limit exceeded'),
            invalid_dimensions: t('invalidDimensions', 'Invalid carton dimensions')
        };
		if (this.plan.unpacked.length) {
			html += '<h3>' + escapeHtml(t('unpacked', 'Unpacked cartons')) + '</h3><ul>' + Object.keys(groups).map(function (key) {
            var item = groups[key];
            var reason = reasonLabels[item.reason] || item.reason.replace(/_/g, ' ');
            return '<li><strong>' + escapeHtml(format(item.count, 0) + ' × ' + item.name) + '</strong><small>' + escapeHtml(reason) + '</small></li>';
			}).join('') + '</ul>';
		}
		if (this.plan.excluded.length) {
			html += '<h3>' + escapeHtml(t('excludedProducts', 'Products not calculated')) + '</h3><ul>' + this.plan.excluded.map(function (item) {
				return '<li><strong>' + escapeHtml(format(item.quantity, 0) + ' × ' + (item.name || item.sku || t('product', 'Product'))) + '</strong><small>' + escapeHtml(t('packingDataMissing', 'Packing data missing — included in the request, not in space or weight totals')) + '</small></li>';
			}).join('') + '</ul>';
		}
		target.innerHTML = html;
    };

    Planner.prototype.resizeCanvas = function () {
        if (!this.canvas || !this.ctx) { return; }
        var ratio = Math.min(2, window.devicePixelRatio || 1);
        var rect = this.canvas.getBoundingClientRect();
        var width = Math.max(280, Math.round(rect.width || 600));
        var height = Math.max(250, Math.round(rect.height || 380));
        if (this.canvas.width !== width * ratio || this.canvas.height !== height * ratio) {
            this.canvas.width = width * ratio; this.canvas.height = height * ratio;
            this.ctx.setTransform(ratio, 0, 0, ratio, 0, 0);
        }
        this.draw();
    };

    Planner.prototype.draw = function () {
		if (!this.ctx || !this.canvas) { return; }
		var ctx = this.ctx, width = this.canvas.clientWidth || 600, height = this.canvas.clientHeight || 380;
		var container = this.plan.container || {};
		var d = { length:num(container.length || container.internalLength || container.internal_length,1), width:num(container.width || container.internalWidth || container.internal_width,1), height:num(container.height || container.internalHeight || container.internal_height,1) };
		this.canvas.setAttribute('data-b2bclp-rendered-container', String(container.id || container.key || '') + '|' + [d.length,d.width,d.height].join('x'));
		var maxDimension = Math.max(d.length,d.width,d.height,1), scale = Math.min(width * 0.73,height * 0.72) / maxDimension * this.zoom;
		var self=this, cameraDistance=maxDimension*3.2;
		function cameraDepth(x,y){var dx=x-d.length/2,dy=y-d.width/2;return dx*Math.sin(self.angle)+dy*Math.cos(self.angle);}
		function project(x,y,z){
			var dx=x-d.length/2,dy=y-d.width/2,dz=z-d.height/2;
			var rx=dx*Math.cos(self.angle)-dy*Math.sin(self.angle),depth=dx*Math.sin(self.angle)+dy*Math.cos(self.angle);
			var perspective=cameraDistance/(cameraDistance+depth), vertical=depth*Math.sin(self.elevation)-dz*Math.cos(self.elevation);
			return{x:width/2+rx*scale*perspective,y:height*0.54+vertical*scale*perspective,depth:depth};
		}
		function vertices(box){var x=num(box.x),y=num(box.y),z=num(box.z),l=num(box.length||box.l),w=num(box.width||box.w),h=num(box.height||box.h);return[project(x,y,z),project(x+l,y,z),project(x+l,y+w,z),project(x,y+w,z),project(x,y,z+h),project(x+l,y,z+h),project(x+l,y+w,z+h),project(x,y+w,z+h)];}
		function polygon(points,fill,stroke,alpha,lineWidth){ctx.beginPath();ctx.moveTo(points[0].x,points[0].y);points.slice(1).forEach(function(p){ctx.lineTo(p.x,p.y);});ctx.closePath();ctx.globalAlpha=alpha==null?1:alpha;ctx.fillStyle=fill;ctx.fill();ctx.strokeStyle=stroke;ctx.lineWidth=lineWidth||1;ctx.stroke();ctx.globalAlpha=1;}
		function shade(hex,amount){var value=String(hex).replace('#','');if(value.length!==6){return hex;}var n=parseInt(value,16),r=Math.max(0,Math.min(255,(n>>16)+amount)),g=Math.max(0,Math.min(255,((n>>8)&255)+amount)),b=Math.max(0,Math.min(255,(n&255)+amount));return'#'+[r,g,b].map(function(v){return v.toString(16).padStart(2,'0');}).join('');}
		function line(a,b,color,lineWidth,alpha){ctx.beginPath();ctx.moveTo(a.x,a.y);ctx.lineTo(b.x,b.y);ctx.strokeStyle=color;ctx.lineWidth=lineWidth||1;ctx.globalAlpha=alpha==null?1:alpha;ctx.stroke();ctx.globalAlpha=1;}
		ctx.clearRect(0,0,width,height);
		var bg=ctx.createLinearGradient(0,0,0,height);bg.addColorStop(0,'#eef6ff');bg.addColorStop(0.58,'#f8fbff');bg.addColorStop(1,'#dce7f0');ctx.fillStyle=bg;ctx.fillRect(0,0,width,height);
		var shadow=ctx.createRadialGradient(width/2,height*.76,10,width/2,height*.76,width*.42);shadow.addColorStop(0,'rgba(15,23,42,.22)');shadow.addColorStop(1,'rgba(15,23,42,0)');ctx.fillStyle=shadow;ctx.fillRect(0,height*.5,width,height*.5);
		var cv=vertices({x:0,y:0,z:0,length:d.length,width:d.width,height:d.height});
		polygon([cv[0],cv[1],cv[2],cv[3]],'rgba(71,85,105,.16)','rgba(51,65,85,.45)',1,1);
		for(var gx=1;gx<6;gx++){line(project(d.length*gx/6,0,0),project(d.length*gx/6,d.width,0),'#64748b',.7,.24);}
		for(var gy=1;gy<4;gy++){line(project(0,d.width*gy/4,0),project(d.length,d.width*gy/4,0),'#64748b',.7,.24);}
		polygon([cv[0],cv[3],cv[7],cv[4]],'rgba(148,163,184,.09)','rgba(71,85,105,.22)',1,.8);
		polygon([cv[3],cv[2],cv[6],cv[7]],'rgba(148,163,184,.07)','rgba(71,85,105,.2)',1,.8);
		var placements=this.plan.placements.slice().sort(function(a,b){return cameraDepth(num(b.x)+num(b.length)/2,num(b.y)+num(b.width)/2)-cameraDepth(num(a.x)+num(a.length)/2,num(a.y)+num(a.width)/2);});
		placements.forEach(function(box,index){
			var p=vertices(box),color=box.color||colorFor(box.line_key||box.itemKey||box.key,index),edge='rgba(15,23,42,.58)';
			polygon([p[0],p[1],p[5],p[4]],shade(color,-20),edge,.92,.75);
			polygon([p[1],p[2],p[6],p[5]],shade(color,-38),edge,.9,.75);
			polygon([p[4],p[5],p[6],p[7]],shade(color,25),edge,.96,.75);
			line(p[4],p[6],'rgba(255,255,255,.5)',.6,.45);
			if(placements.length<=80){var cx=(p[4].x+p[5].x+p[6].x+p[7].x)/4,cy=(p[4].y+p[5].y+p[6].y+p[7].y)/4,faceWidth=Math.hypot(p[5].x-p[4].x,p[5].y-p[4].y);if(faceWidth>26){ctx.fillStyle='rgba(15,23,42,.82)';ctx.font='600 9px system-ui,sans-serif';ctx.textAlign='center';ctx.fillText(String(box.carton_index||index+1),cx,cy+3);}}
		});
		[[0,1],[1,2],[2,3],[3,0],[4,5],[5,6],[6,7],[7,4],[0,4],[1,5],[2,6],[3,7]].forEach(function(e){line(cv[e[0]],cv[e[1]],'#334155',1.55,.82);});
		ctx.fillStyle='rgba(15,23,42,.8)';ctx.font='600 11px system-ui,sans-serif';ctx.textAlign='left';ctx.fillText((container.label||container.name||container.id||'')+'  '+d.length.toFixed(1)+' × '+d.width.toFixed(1)+' × '+d.height.toFixed(1)+' cm',12,height-14);
		if(this.plan.estimatedDimensionsVisual&&this.plan.visualMode==='estimated_cartons'){
			var estimatedLabel=t('estimatedCartonsVisual','Amber cartons use estimated dimensions derived from CBM — not verified carton measurements');
			ctx.fillStyle='rgba(120,53,15,.86)';ctx.fillRect(12,12,Math.min(width-24,430),28);ctx.fillStyle='#fff';ctx.font='700 11px system-ui,sans-serif';ctx.fillText(estimatedLabel,22,31);
			this.canvas.setAttribute('aria-label',estimatedLabel+'.');
		}else if(this.plan.visualMode==='aggregate_volume'||this.plan.visualMode==='hybrid_volume'){
			var aggregateLabel=this.plan.visualMode==='hybrid_volume'?t('hybridVisual','Amber block is CBM-only cargo — not verified carton placement'):t('aggregateVisual','Aggregate cargo volume — not carton placement');
			ctx.fillStyle='rgba(15,23,42,.78)';ctx.fillRect(12,12,Math.min(width-24,310),28);ctx.fillStyle='#fff';ctx.font='700 11px system-ui,sans-serif';ctx.fillText(aggregateLabel,22,31);
			this.canvas.setAttribute('aria-label',aggregateLabel+'.');
		}else{
			this.canvas.setAttribute('aria-label',t('canvasLabel','Interactive container loading estimate')+'. '+placements.length+' '+t('cartonsPacked','cartons packed')+'.');
		}
    };

    Planner.prototype.calculateClientEstimate = function () {
        var self = this;
        if (!this.plan.packingInput || !window.Worker || config.enableWorker === false) { return; }
        if (!this.worker) {
            try { this.worker = new window.Worker(config.workerUrl || config.packerWorkerUrl); } catch (error) { return; }
            this.worker.addEventListener('message', function (event) {
                var message = event.data || {};
                if (message.type !== 'result' || message.requestId !== self.workerRequest) { return; }
				if (message.result.placements && (self.plan.estimatedDimensionsVisual || !self.plan.placements.length)) {
					var estimatedKeys = self.plan.estimatedLineKeys.map(String);
					self.plan.placements = message.result.placements.map(function (placement) {
						var key = String(placement.line_key || placement.itemKey || placement.key || '');
						if (self.plan.estimatedDimensionsVisual && estimatedKeys.indexOf(key) !== -1) {
							placement.color = '#f59e0b';
							placement.estimated_dimensions = true;
						}
						return placement;
					});
					if (self.plan.estimatedDimensionsVisual) { self.plan.visualMode = 'estimated_cartons'; }
					self.draw();
                }
                var serverUnpacked = self.plan.unpacked.length;
				if (!self.plan.estimatedDimensionsVisual && serverUnpacked !== message.result.unpacked.length && config.showAgreementWarning !== false) {
                    self.plan.warnings.push(t('agreementWarning', 'The visual estimate differs from the server plan. Refresh before submitting.'));
                    self.renderMessages();
                }
            });
        }
        this.workerRequest += 1;
        this.worker.postMessage({ type: 'pack', requestId: this.workerRequest, payload: this.plan.packingInput });
    };

    function extractResponse(json) {
        if (!json) { return null; }
        if (json.success === false) { throw new Error((json.data && (json.data.message || json.data[0])) || t('updateFailed', 'Could not update the loading plan.')); }
        return json.data && (json.data.plan || json.data.loadingPlan) ? (json.data.plan || json.data.loadingPlan) : (json.data || json.plan || json);
    }

    function refreshAll(containerId, manual) {
        window.clearTimeout(refreshTimer);
        refreshTimer = window.setTimeout(function () {
            if (!config.ajaxUrl) { return; }
            if (activeRequest) { activeRequest.abort(); }
            activeRequest = window.AbortController ? new window.AbortController() : null;
            instances.forEach(function (instance) { instance.setLoading(true); });
            var body = new window.URLSearchParams();
            body.set('action', config.action || config.ajaxAction || 'b2bclp_plan');
            body.set('nonce', config.nonce || '');
            var currentSelect = document.querySelector('#b2bclp-container-select, [data-b2bclp-container-select]');
            body.set('container', containerId || (currentSelect ? currentSelect.value : 'auto'));
            var sequence = ++requestSequence;
            window.fetch(config.ajaxUrl, {
                method: 'POST', credentials: 'same-origin', headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
                body: body.toString(), signal: activeRequest ? activeRequest.signal : undefined
            }).then(function (response) {
                if (!response.ok) { throw new Error(t('updateFailed', 'Could not update the loading plan.')); }
                return response.json();
            }).then(function (json) {
                if (sequence !== requestSequence) { return; }
                var plan = extractResponse(json);
                instances.forEach(function (instance) { instance.setPlan(plan); });
                document.dispatchEvent(new window.CustomEvent('b2bclp:plan-updated', { detail: plan }));
            }).catch(function (error) {
                if (error.name === 'AbortError') { return; }
                instances.forEach(function (instance) {
                    instance.plan.warnings.push(error.message); instance.renderMessages();
                });
            }).finally(function () { instances.forEach(function (instance) { instance.setLoading(false); }); });
        }, num(config.refreshDelay, 180));
    }

    function init() {
        roots = Array.prototype.slice.call(document.querySelectorAll('[data-b2bclp-planner], #b2bclp-planner'));
        roots.forEach(function (root) {
            if (!root.b2bClpInstance) { root.b2bClpInstance = new Planner(root); instances.push(root.b2bClpInstance); }
        });
    }

    function bindProductUnits() {
        var blocks = Array.prototype.slice.call(document.querySelectorAll('[data-b2bclp-units-per-carton]'));
        blocks.forEach(function (block) {
            if (block.b2bClpUnitsBound) { return; }
            block.b2bClpUnitsBound = true;
            var form = block.closest('form.cart') || document.querySelector('form.cart');
            var quantity = form && form.querySelector('input.qty');
            var output = block.querySelector('[data-b2bclp-total-units]') || document.querySelector('[data-b2bclp-total-units]');
            var priceOutput = block.querySelector('[data-b2bclp-total-price]') || document.querySelector('[data-b2bclp-total-price]');
            var units = num(block.getAttribute('data-b2bclp-units-per-carton'));
            var unitPrice = num(block.getAttribute('data-b2bclp-unit-price'));
            function update() {
                var cartons = quantity ? num(quantity.value) : 1;
                output.textContent = units > 0 && cartons > 0 && Number.isInteger(cartons) ? format(cartons * units, 0) : '—';
                if (priceOutput) { priceOutput.textContent = units > 0 && cartons > 0 && Number.isInteger(cartons) ? formatMoney(cartons * units * unitPrice) : '—'; }
            }
            if (!output) { return; }
            if (quantity) { quantity.addEventListener('input', update); quantity.addEventListener('change', update); }
            if (window.jQuery && form) {
                window.jQuery(form).on('found_variation', function (event, variation) {
                    units = num(variation && variation.b2bclp_units_per_carton);
                    unitPrice = num(variation && variation.b2bclp_unit_price);
                    block.setAttribute('data-b2bclp-units-per-carton', units);
                    block.setAttribute('data-b2bclp-unit-price', unitPrice);
                    update();
				}).on('reset_data hide_variation', function () { units = 0; unitPrice = 0; update(); });
            }
            update();
        });
    }

    var bulkPricingCache = {};
    var bulkPricingRequest = null;

    function bulkProductId(row) {
        var marker = row.querySelector('[class*="b2bking_selected_product_id_"]');
        if (!marker) { return 0; }
        var match = String(marker.className).match(/b2bking_selected_product_id_(\d+)/);
        return match ? num(match[1]) : 0;
    }

    function bulkRowMarkup(data, cartons) {
        var pieces = cartons * data.unitsPerCarton;
        var total = pieces * data.unitPrice;
        return '<div class="b2bclp-bulk-price-breakdown">' +
            '<span>' + escapeHtml(t('piecePrice', 'Piece price')) + ': <strong>' + escapeHtml(formatMoney(data.unitPrice)) + '</strong></span>' +
            '<span>' + escapeHtml(t('cartons', 'Cartons')) + ': <strong>' + escapeHtml(format(cartons, 0)) + '</strong></span>' +
            '<span>' + escapeHtml(t('pieces', 'Pieces')) + ': <strong>' + escapeHtml(format(pieces, 0)) + '</strong></span>' +
            '<span class="b2bclp-bulk-line-total">' + escapeHtml(t('totalPrice', 'Total price')) + ': <strong>' + escapeHtml(formatMoney(total)) + '</strong></span>' +
            '</div>';
    }

    function applyBulkRowPricing(row, data) {
        var quantity = row.querySelector('.b2bking_bulkorder_form_container_content_line_qty_cream');
        var subtotal = row.querySelector('.b2bking_bulkorder_form_container_content_line_subtotal_cream');
        if (!quantity || !subtotal || !data || data.unitsPerCarton < 1) { return; }
        var cartons = Math.max(1, Math.floor(num(quantity.value, 1)));
        var pieces = cartons * data.unitsPerCarton;
        var total = pieces * data.unitPrice;
        row.setAttribute('data-b2bclp-product-id', data.productId);
        row.setAttribute('data-b2bclp-units-per-carton', data.unitsPerCarton);
        row.setAttribute('data-b2bclp-unit-price', data.unitPrice);
        quantity.setAttribute('aria-label', t('cartons', 'Cartons'));
        subtotal.setAttribute('data-value', total);
        var markup = bulkRowMarkup(data, cartons);
        if (subtotal.innerHTML !== markup) { subtotal.innerHTML = markup; }
    }

    function updateBulkSelectedSummary(root) {
        var totalCartons = 0;
        var totalPieces = 0;
        var totalPrice = 0;
        root.querySelectorAll('.b2bking_cream_select_checkbox:checked').forEach(function (checkbox) {
            var row = checkbox.closest('.b2bking_bulkorder_form_container_content_line_cream');
            if (!row) { return; }
            var quantity = row.querySelector('.b2bking_bulkorder_form_container_content_line_qty_cream');
            var cartons = quantity ? Math.max(0, Math.floor(num(quantity.value))) : 0;
            var units = num(row.getAttribute('data-b2bclp-units-per-carton'));
            var unitPrice = num(row.getAttribute('data-b2bclp-unit-price'));
            totalCartons += cartons;
            totalPieces += cartons * units;
            totalPrice += cartons * units * unitPrice;
        });
        var summary = root.querySelector('.b2bking_cream_add_selected_number');
        if (!summary) { return; }
        var text = totalCartons > 0 ? ' (' + format(totalCartons, 0) + ' ' + t('cartons', 'cartons') + ' · ' + format(totalPieces, 0) + ' ' + t('pieces', 'pieces') + ' · ' + formatMoney(totalPrice) + ')' : '';
        summary.classList.add('b2bclp-selected-summary');
        if (summary.textContent !== text) { summary.textContent = text; }
    }

    function requestBulkPricing(ids, root) {
        if (!ids.length || bulkPricingRequest) { return; }
        var body = new window.URLSearchParams();
        body.set('action', config.pricingAction || 'b2bclp_product_pricing');
        body.set('nonce', config.nonce || '');
        ids.slice(0, 50).forEach(function (id) { body.append('ids[]', id); });
        bulkPricingRequest = window.fetch(config.ajaxUrl, {
            method: 'POST', credentials: 'same-origin', headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' }, body: body.toString()
        }).then(function (response) {
            if (!response.ok) { throw new Error('Pricing request failed'); }
            return response.json();
        }).then(function (json) {
            var products = json && json.success && json.data ? json.data.products : {};
            Object.keys(products || {}).forEach(function (id) { bulkPricingCache[id] = products[id]; });
        }).catch(function () {
            ids.forEach(function (id) { bulkPricingCache[id] = false; });
        }).finally(function () {
            bulkPricingRequest = null;
            decorateBulkOrder(root);
        });
    }

	function updateBulkCartSummary(root, totals) {
		if (!root) { return; }
		var cartItems = root.querySelector('.b2bking_cream_cart_button_items');
		if (!cartItems) { return; }
		var existingQuantity = cartItems.querySelector('.b2bking_cream_cart_button_items_qty');
		if (totals) {
			cartItems.setAttribute('data-b2bclp-cartons', totals.cartons);
			cartItems.setAttribute('data-b2bclp-pieces', totals.units);
			cartItems.setAttribute('data-b2bclp-units-complete', totals.unitsComplete ? 'yes' : 'no');
		}
		var cartons = cartItems.hasAttribute('data-b2bclp-cartons') ? num(cartItems.getAttribute('data-b2bclp-cartons')) : num(existingQuantity ? existingQuantity.textContent : 0);
		var pieces = cartItems.hasAttribute('data-b2bclp-pieces') ? num(cartItems.getAttribute('data-b2bclp-pieces')) : null;
		var piecesLabel = cartItems.getAttribute('data-b2bclp-units-complete') === 'no' ? t('knownTotalPieces', 'Known total pieces') : t('pieces', 'Pieces');
		var cartMarkup = '<span class="b2bking_cream_cart_button_items_qty">' + escapeHtml(format(cartons, 0)) + '</span> ' + escapeHtml(t('cartons', 'Cartons'));
		if (pieces !== null) { cartMarkup += ' · <span class="b2bclp-cart-total-pieces">' + escapeHtml(format(pieces, 0)) + ' ' + escapeHtml(piecesLabel) + '</span>'; }
		if (cartItems.innerHTML !== cartMarkup) { cartItems.innerHTML = cartMarkup; }
	}

    function decorateBulkOrder(root) {
        if (!root) { return; }
        var missing = [];
        root.querySelectorAll('.b2bking_bulkorder_form_container_content_line_cream').forEach(function (row) {
            var id = bulkProductId(row);
            if (!id) { return; }
            if (bulkPricingCache[id]) { applyBulkRowPricing(row, bulkPricingCache[id]); }
            else if (bulkPricingCache[id] !== false && missing.indexOf(id) === -1) { missing.push(id); }
        });
        root.querySelectorAll('.b2bking_bulkorder_form_container_content_header_qty_cream, .b2bking_bulkorder_form_container_content_header_qty_indigo').forEach(function (header) { header.textContent = t('cartons', 'Cartons'); });
        root.querySelectorAll('.b2bking_bulkorder_form_container_content_header_subtotal_cream:not(.b2bking_bulkorder_form_container_content_header_cart_cream)').forEach(function (header) { header.textContent = t('totalPrice', 'Total price'); });
		updateBulkCartSummary(root, null);
        updateBulkSelectedSummary(root);
        requestBulkPricing(missing, root);
    }

    function bindBulkOrderPricing() {
        var root = document.querySelector('[data-b2bclp-bulk-order]');
        if (!root || root.b2bClpBulkBound) { return; }
        root.b2bClpBulkBound = true;
        var scheduled = false;
        function schedule() {
            if (scheduled) { return; }
            scheduled = true;
            window.setTimeout(function () { scheduled = false; decorateBulkOrder(root); }, 0);
        }
        root.addEventListener('input', schedule, true);
        root.addEventListener('change', schedule, true);
        root.addEventListener('click', schedule, true);
        if (window.MutationObserver) {
            new window.MutationObserver(schedule).observe(root.querySelector('.b2bclp-bulk-main') || root, { childList: true, characterData: true, subtree: true });
        }
        decorateBulkOrder(root);
    }

    function bindCommerceEvents() {
        ['updated_wc_div', 'updated_checkout', 'wc_fragment_refresh', 'wc_fragments_refreshed', 'added_to_cart', 'removed_from_cart', 'b2bking_added_item_cart', 'b2bking_multiadded_item_cart'].forEach(function (name) {
            document.body.addEventListener(name, function () { init(); refreshAll('', false); });
        });
        if (window.jQuery) {
            window.jQuery(document.body).on('updated_wc_div updated_checkout wc_fragment_refresh wc_fragments_refreshed added_to_cart removed_from_cart b2bking_added_item_cart b2bking_multiadded_item_cart', function () { init(); refreshAll('', false); });
        }
        document.addEventListener('b2bclp:refresh', function (event) { refreshAll(event.detail && event.detail.containerId, false); });
    }

    function boot() { init(); bindProductUnits(); bindBulkOrderPricing(); bindCommerceEvents(); if (instances.length) { refreshAll(document.querySelector('#b2bclp-container-select') ? document.querySelector('#b2bclp-container-select').value : 'auto', false); } }
    if (document.readyState === 'loading') { document.addEventListener('DOMContentLoaded', boot); }
    else { boot(); }
    config.refresh = refreshAll;
    config.normalizePlan = normalizePlan;
    window.B2BCLP = config;
}(window, document));
