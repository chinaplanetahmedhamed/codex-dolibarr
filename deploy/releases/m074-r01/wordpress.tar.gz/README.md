# B2B Container Loading Planner for WooCommerce

Private China Planet WordPress plugin for carton-based B2B requests, packing-data maintenance, deterministic container-loading estimates, and immutable WooCommerce order snapshots.

## Requirements

- WordPress 6.4+
- WooCommerce 8.5+
- PHP 7.4+

## Headless React integration

Version `2.0.0` exposes a public, paginated product catalogue and a signed server-to-server loading-plan endpoint using `cpo.catalog-order.v2`. Enabled variations remain selectable for quotation requests even when packing or public price data is incomplete. The plugin returns an authoritative customer-safe snapshot; React submits it through the secure Node gateway to Dolibarr and does not create a duplicate WooCommerce order.

Generate one secret and configure the same value outside Git:

```bash
openssl rand -hex 32
```

WordPress `wp-config.php`:

```php
define('CHINAPLANET_B2B_API_SECRET', 'store-the-generated-value-securely');
```

Moaz runtime environment:

```text
B2B_API_SECRET=the-same-generated-value
```

Never commit the real value. The signed plan endpoint fails closed when the secret is absent or shorter than 32 characters.

## Verification

```bash
for test_file in tests/test-*.php; do php "$test_file" || exit 1; done
node tests/worker-smoke.js
find . -name '*.php' -print0 | xargs -0 -n1 php -l
```

## Release

Merge an approved change to `main`, then push a matching version tag such as `v1.9.0`. GitHub Actions validates the tag against the plugin header and publishes an installable `b2b-container-loading-planner.zip` release asset.

Container plans remain operational estimates. They are not cargo-securing, axle-load, dangerous-goods, or engineering certificates.
China Planet WooCommerce carton ordering and container loading planner
