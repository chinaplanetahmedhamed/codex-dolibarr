# Moaz React agent instructions

This repository owns the public China Planet React/Vite website and its secure Node server integration layer. It does not own authenticated customer operations or ERP source-of-truth data.

## Startup

1. Read `README.md` and the root `../AGENTS.md`.
2. Run `git status --short --branch` before editing.
3. Inspect the existing component, server route, test, and content contract before creating a new implementation.
4. Preserve unrelated user changes and do not switch branches or rewrite history without explicit approval.

## Ownership and security

- React owns public marketing, service discovery, catalog browsing, public content, and lead or booking-request UI.
- WordPress/WooCommerce remains the headless content and initial product/carton-data source.
- Dolibarr/ChinaPlanetOS remains the operational source for customers, quotations, orders, payments, balances, shipments, and documents.
- Customer Center owns authenticated customer operations.
- Use `React -> secure Node API -> Dolibarr`; never call Dolibarr directly from browser code.
- Never place credentials, privileged URLs, internal IDs, supplier data, costs, margins, private notes, or private documents in browser payloads or `VITE_*` variables.
- A public booking submission is a review request, not a carrier-confirmed booking. A public quote or catalog submission is not a validated Dolibarr order.
- Keep Arabic, English, RTL/LTR, mobile layout, accessibility, loading, empty, error, and success states functional.

## Implementation

- Reuse existing components, server services, schemas, rate limits, idempotency logic, and tests before adding new abstractions.
- Keep API contracts explicit and backward-compatible unless the approved scope says otherwise.
- Make small vertical changes that can be tested end to end.
- Use one code-writing agent. Subagents may perform bounded read-only review or independent testing when explicitly requested.

## Verification

Run the relevant smallest tests during development, then before completion run:

```bash
npm run lint
npm test
npm run test:ui
npm run build
```

For public integrations, also verify route options or prerequisite data, the real search or submission, server-side validation, durable success reference, safe error handling, and customer-safe response fields. Do not treat HTTP 200 or `/api/health` alone as acceptance.

Do not deploy staging or production without Ahmed's exact approval for that environment and release.

## Verified release status — 2026-08-13

Treat this as a handoff snapshot and verify again before making a release.

- Production: `https://chinaplanet.org`, stack `chinaplanet-web-production`.
- Staging/backup: `https://new.chinaplanet.org`, stack `chinaplanet-web-staging`.
- Both `/api/health` endpoints returned `ok=true` and `deploySha=e8b253d5cc8e3ce766d2da43dc55d2cd67b0637d`.
- Canonical `origin/main` and the M047 baseline parent were both `e8b253d5cc8e3ce766d2da43dc55d2cd67b0637d`; the documentation-only baseline branch is `codex/m047-react-baseline`.
- M047 moved the two unrelated Arabic contract DOCX files, without changing their SHA-256 hashes, to `/Users/mac/Documents/dev/chinaplanet-OS/documents/contracts/`. They are not application source and must not be moved back into the repository.
- Relevant delivered commits: `ea5c5ad` reveals/scrolls to the booking form after a shipping-rate selection; `be1065f` delivers verified catalog product snapshots to ERP; `e8b253d` makes B2B catalog pricing per piece.

## What is working now

- Clicking/selecting a shipping price reveals and scrolls to the booking form so the visitor has a clear next action.
- Public booking and price-inquiry submissions go through the secure Node server layer to Dolibarr; the browser never calls Dolibarr directly.
- Catalog products continue to originate from WordPress/WooCommerce, while the integration snapshot sent to ERP includes the data needed for the quotation workflow.
- Product selling price is per piece. Packing data must keep pieces per carton, requested cartons, and derived/requested pieces explicit and separate.
- Public requests remain review requests or drafts, not confirmed bookings, validated ERP orders, or final quotations.

## React incident playbook

### Clicking a rate did nothing

- Symptom: the selected card changed visually, but the customer did not see what to do next.
- Cause: rate selection did not reveal/focus the booking form.
- Fix: reuse the selection state to reveal the form and perform an accessible smooth scroll/focus after selection. The delivered reference is commit `ea5c5ad`.
- Regression check: desktop/mobile, Arabic RTL/English LTR, keyboard activation, form visibility, selected-rate payload, and successful durable request reference.

### Price unit incorrectly treated as cartons

- Symptom: ERP quotation rows displayed a selling price per carton even though catalog prices are per piece.
- Cause: requested carton quantity and price unit were conflated across the CMS snapshot and ERP request contract.
- Fix: the price field is per piece; transport `piecesPerCarton`, requested cartons, and requested/derived pieces as separate values. The delivered React references are `be1065f` and `e8b253d`.
- Never multiply or divide prices silently. Server-side validation must reject missing or inconsistent packing data rather than guessing.

### GitHub deployment stayed queued

- Symptom: workflow showed `No Available Runners` and remained queued.
- Cause: the required self-hosted runner was offline, misconfigured, label-mismatched, busy, or unavailable.
- Fix: inspect runner connectivity, service state, labels, and capacity; restore the runner, then cancel the stale queued run and start a fresh run for the same pinned SHA.
- Do not create a new Portainer stack or perform an unrelated manual deployment to bypass a runner problem.

### GitHub SSH host verification failed

- Symptom: the workflow could reach the deployment step but failed before the approved remote action.
- Known cause in M046: `DEPLOY_KNOWN_HOSTS` did not contain the verified current ED25519 host key.
- Fix: verify the server key through the approved secure access path, update only the exact GitHub secret, and rerun the workflow. Never use `StrictHostKeyChecking=no`.

### Portainer was being requested for every release

- Canonical approach: GitHub Actions builds and deploys the exact immutable SHA; Portainer pulls/updates the existing approved stack.
- Manual Portainer use is an emergency exception only when the GitHub path is unavailable and Ahmed explicitly approves the exact production action. Do not create a new stack for an ordinary code release.

### Health was green but the customer journey was not

- `/api/health` confirms process/configuration state and deployed SHA only.
- Also verify eligible route options, the real rate search, the rate-card-to-form interaction, server validation, inquiry submission, durable reference, ERP arrival, and safe error handling.
- If route options are empty, inspect published eligible shipping-rate data and the secure API contract before changing the UI.

## Deployment source of truth

- Staging deploys from the approved GitHub workflow to the existing `chinaplanet-web-staging` stack.
- Production deploys the exact SHA already accepted on staging to `chinaplanet-web-production` after separate production approval.
- Compare the live `/api/health.deploySha` with the approved Git commit after deployment. Do not infer success from a green workflow alone.
