# M049 — React Catalog Lifecycle Extraction

Date: 2026-08-13

## Objective

Reduce the responsibility of `App.jsx` by moving the existing public catalog loading and revision-refresh lifecycle into one focused hook, while preserving the current WooCommerce ownership, secure Node API boundary, timing, fallback, and retry behavior.

## Approved scope

- Extract catalog products, categories, status, initial loading, stale retry, and revision refresh into `useCatalogData`.
- Add executable characterization tests for route-specific load timing, payload normalization, and revision decisions.
- Keep the existing API functions and public component props unchanged.
- Run the complete React verification suite and dependency audit.

## Hard boundaries

- React repository only.
- WordPress/WooCommerce remains the product and packing-data source.
- Browser code continues to use the secure Node API; no direct WooCommerce or Dolibarr calls.
- No visual, copy, pricing-unit, cart, inquiry, database, configuration, or credential changes.
- No staging or production deployment.

## Acceptance

- `App.jsx` no longer owns catalog fetch/revision effects or catalog revision state.
- The extracted hook preserves existing customer-visible states: `loading`, `ready`, `demo`, and `unavailable`.
- The 15-second lightweight version check and stale-response retry remain unchanged.
- All required React checks pass.
