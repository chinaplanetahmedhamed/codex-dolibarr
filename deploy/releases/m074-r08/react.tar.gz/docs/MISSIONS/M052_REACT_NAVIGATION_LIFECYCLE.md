# M052 — React Navigation Lifecycle Extraction

Date: 2026-08-13

## Objective

Remove URL, route-view, active-navigation, and browser-history synchronization responsibility from `App.jsx` while preserving every current public, admin, secure-access, and localized route.

## Approved scope

- Add one focused `useAppNavigation` hook that owns the current route snapshot and browser navigation subscription.
- Centralize `hashchange` and `popstate` subscription behavior in the existing navigation module.
- Derive the active navigation tab from the route instead of keeping a second mutable tab state.
- Keep Arabic paths unprefixed and English/French paths prefixed exactly as they are today.
- Add characterization tests for route-to-tab selection and browser subscription cleanup.

## Hard boundaries

- React repository only; M052 is stacked on the unmerged M051 branch.
- No API, authentication, CMS schema, visual design, WordPress, Dolibarr, database, configuration, credential, staging, or production changes.
- No merge or deployment is part of this Mission.

## Acceptance

- `App.jsx` owns no route-view state, initial-route refs, browser navigation listeners, or active-tab fallback state.
- Back, forward, hash, locale switching, detail slugs, admin routes, and secure-access routes retain the existing behavior.
- Browser navigation listeners are installed and removed through one tested helper.
- All required React checks pass.
