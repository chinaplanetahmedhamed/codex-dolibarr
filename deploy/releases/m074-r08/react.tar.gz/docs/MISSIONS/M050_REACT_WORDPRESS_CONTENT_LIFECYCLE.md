# M050 — React WordPress Content Lifecycle Extraction

Date: 2026-08-13

## Objective

Reduce the responsibility of `App.jsx` by moving the existing WordPress posts and China Guide loading, retry, and revision-refresh lifecycle into one focused hook without changing content ownership, API contracts, or customer-visible behavior.

## Approved scope

- Extract blog posts, categories, China Guide collections, statuses, manual Guide retry, stale retry, and revision refresh into `useWordPressContent`.
- Add pure characterization tests for route timing, retry limits, collection normalization, and revision decisions.
- Keep the current secure Node API functions and page/component props unchanged.
- Run the complete React verification suite and dependency audit.

## Hard boundaries

- React repository only.
- WordPress remains the source for published articles and `china_guide` content.
- Browser code continues through the existing secure Node API.
- No WordPress plugin, content, media, webhook, API, visual, SEO, database, configuration, or credential changes.
- No staging or production deployment.

## Acceptance

- `App.jsx` no longer owns WordPress posts or China Guide fetch/revision effects.
- Existing `loading`, `ready`, `demo`, and `error` behavior remains intact.
- Existing route-priority delays, four stale retries, manual Guide retry, and 30-second revision polling remain intact.
- All required React checks pass.
