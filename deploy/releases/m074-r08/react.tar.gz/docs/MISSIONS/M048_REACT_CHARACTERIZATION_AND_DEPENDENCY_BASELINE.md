# M048 — React Characterization and Dependency Baseline

Date: 2026-08-13

## Objective

Prepare the public React application for later refactoring by locking down the current routing behavior and removing the known transitive dependency advisory without changing customer-facing behavior or API contracts.

## Approved scope

- Add a small, pure route-description module for the behavior already implemented in `App.jsx`.
- Add characterization tests for public, localized, detail, admin, and authenticated-access routes.
- Update only the dependency lock needed to resolve the known `nanoid` advisory.
- Run lint, server tests, UI tests, production build, and dependency audit.
- Document the verified result and remaining refactoring priorities.

## Hard boundaries

- React repository only.
- No Dolibarr, WordPress, database, configuration, credential, or business-data changes.
- No public API contract changes.
- No visual redesign or content rewrite.
- No staging or production deployment.

## Acceptance

- Existing route behavior is represented by executable tests.
- `App.jsx` uses the tested route-description and tab-mapping functions.
- The known transitive dependency advisory is removed without a broad dependency upgrade.
- All required React checks pass from a clean working tree before review.
