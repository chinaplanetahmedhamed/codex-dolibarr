# M051 — React Site Content and Admin Lifecycle Extraction

Date: 2026-08-13

## Objective

Reduce the responsibility of `App.jsx` by moving the centralized site-content load/save lifecycle and authenticated admin-session lifecycle into one focused hook without changing the CMS payload, session security, or admin UI.

## Approved scope

- Extract the six public CMS collections, central content loading, migration rules, last-published timestamp, save status, admin-session check, login, and logout into `useSiteContentAdmin`.
- Add pure characterization tests for published service, office, team, hero, save-payload, and unauthorized-session behavior.
- Keep the existing secure API functions, HttpOnly Cookie session, dashboard props, and page behavior unchanged.
- Run the complete React verification suite and dependency audit.

## Hard boundaries

- React repository only.
- No password, session secret, Cookie content, or privileged data is persisted in browser storage or added to public payloads.
- No server API, authentication policy, content schema, visual design, database, configuration, credential, media, WordPress, Dolibarr, staging, or production changes.

## Acceptance

- `App.jsx` no longer owns central site-content fetch/save or admin-session effects and actions.
- Existing content migration rules remain executable and tested.
- Admin save still transmits exactly six public CMS collections.
- Only a 401 save response clears the local admin user.
- All required React checks pass.
