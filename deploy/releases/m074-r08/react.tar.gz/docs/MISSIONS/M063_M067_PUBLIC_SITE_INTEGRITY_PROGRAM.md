# M063–M067 — Public Site Integrity and Importer Conversion Program

Date: 2026-08-29

## Program order and release boundary

Execute sequentially: M063 → M064 → M065 → M066 → M067. Agent 007 is the sole code-writing owner for each Mission; no concurrent writer may edit the same program. Local implementation and acceptance are approved. Search Console, staging, and production are separate later approval gates.

The public shipping journey must remain published-rate search → selected rate → review request. It must never represent a confirmed carrier booking. React owns public discovery and request UI, WordPress/WooCommerce remains the catalog and packing-data source, and authenticated customer operations remain in Customer Center/Dolibarr through the secure server boundary.

## M063 — B2B packing integrity and fail-safe planning

**Business outcome:** Importers see calculations only when authoritative carton and volume data is complete; incomplete products enter quotation review without guessed packing or pricing.

**In scope:** explicit packing-readiness rules; block incomplete product/variation choices; purge stale incomplete planner lines; safe empty/error explanations; route incomplete selections into the public quotation-review form; validate authoritative server lines before calculation or Dolibarr submission; preserve per-piece pricing; regression coverage for WP-E1003-like data.

**Out of scope:** inventing `PCS/CTN` or CBM from names/attributes; editing WooCommerce records; changing prices; confirmed orders/bookings; direct browser-to-Dolibarr calls.

**Dependencies and likely areas:** first Mission; `src/pages/B2BPage.jsx`, packing helpers/tests, `server/b2b.js` and its tests, existing catalog/API contracts.

**Security and ownership:** Woo is packing source; server revalidates browser requests; browser payloads exclude costs, margins, internal IDs, private notes, and credentials; Dolibarr remains operational source.

**AR/EN/FR, direction, mobile acceptance:** explanations, unavailable values, quotation route, labels, and consent are localized; Arabic RTL and EN/FR LTR; no horizontal overflow or inaccessible generic controls on mobile.

**Automated tests:** readiness, stale-line filtering, declared-attribute handling, calculation rejection, submit rejection, and live-like WP-E1003 regression; full lint/unit/UI/build suite.

**Live/runtime acceptance:** an incomplete variation displays no zero/fictional calculation and opens a prefilled review request; a complete product still calculates; request remains a draft/review with durable reference only after secure submission.

**Rollback/stopping gate:** stop if the server can accept incomplete packing, if price units change, or if any private/internal field reaches the browser. Roll back this Mission before M064. **Risk: High.**

## M064 — Localized catalog discovery and display hygiene

**Business outcome:** Arabic and French buyers can discover English-source products using curated synonyms without altering WooCommerce source records.

**In scope:** normalized Arabic/French synonym expansion; multiword discovery; localized display-only category labels; hide `Uncategorized` from category navigation while retaining its products under all products; correct known display-only spelling artifacts; accessible search status.

**Out of scope:** mass-editing 1,214 WooCommerce products; machine-translating product records; rewriting source slugs/SKUs/categories; changing canonical source ownership.

**Dependencies and likely areas:** after M063; `src/pages/ProductsCatalogPage.jsx`, catalog-search helper/tests, translations and catalog CSS.

**Security and ownership:** search aliases are public presentation metadata; Woo remains immutable headless source; no supplier/private fields or unpublished prices are added.

**AR/EN/FR, direction, mobile acceptance:** Arabic `مضخة` and French `pompe` expand to `pump`; localized category display respects RTL/LTR; search labels and result explanations are understandable on mobile.

**Automated tests:** Arabic normalization, French aliases, multiword synonyms, category localization, spelling cleanup, and uncategorized-navigation filtering; full project suite.

**Live/runtime acceptance:** production-like catalog data returns pump matches for Arabic/French synonyms, English search remains unchanged, and Woo identifiers/data are not mutated.

**Rollback/stopping gate:** stop if aliases create broad false positives, source data is rewritten, or catalog performance materially regresses. Remove the presentation helper without changing Woo. **Risk: Medium.**

## M065 — Trust, legal identity, and content proof

**Business outcome:** Visitors receive verifiable, privacy-safe evidence and accurate legal/content statements instead of unsupported conversion claims.

**In scope:** real existing office/warehouse/inspection imagery; redaction guidance for sample evidence; China Planet versus contracting-entity explanation; correct Egypt office manager role; remove unsupported `750 clients`/`1.1M followers` claims; public privacy and terms pages; legal routes/SEO/sitemap; Markdown-free blog excerpts.

**Out of scope:** fabricating testimonials, metrics, certificates, case outcomes, or legal guarantees; publishing client/supplier identities, costs, reports, or documents; providing jurisdiction-specific legal advice.

**Dependencies and likely areas:** after M064; About/team/evidence components, footer, legal pages, routing, SEO/sitemap, WordPress excerpt sanitizer/tests, translations/CSS.

**Security and ownership:** only existing public-safe assets are used; complete evidence remains authenticated or shared in an approved engagement; a written proposal/contract/invoice controls the actual contracting identity.

**AR/EN/FR, direction, mobile acceptance:** all new legal/trust copy is available in three languages with RTL/LTR and responsive evidence/legal layouts.

**Automated tests:** legal route recognition, sitemap/static metadata coverage, Markdown stripping, unsupported-claim source checks, full suite.

**Live/runtime acceptance:** privacy/terms resolve in AR/EN/FR; footer and request consent link to privacy; evidence has no private data; team role is accurate; no unsupported numeric claims or Markdown markers appear.

**Rollback/stopping gate:** stop publication if legal entity wording is not approved, an asset exposes private data, or a claim lacks evidence. Remove the affected content block while preserving routes. **Risk: Medium–High.**

## M066 — Returning-customer navigation and guided importer intake

**Business outcome:** Returning customers can clearly reach Customer Center while new importers provide enough public-safe information for review.

**In scope:** verified Customer Center link in desktop/mobile/footer navigation; React link-only boundary; three-step contact/product/service intake; prefill from an incomplete B2B item; privacy consent and explicit sensitive-data warning; accessible dialog and field labels.

**Out of scope:** recreating login, order, payment, document, quotation, or shipment tracking functions in React; transmitting passwords, card details, private ERP documents, or supplier data.

**Dependencies and likely areas:** after M065 privacy route; `src/App.jsx`, Navbar/Footer, `QuoteModal.jsx`, environment example, navigation and styles.

**Security and ownership:** Customer Center/Dolibarr owns authentication and operations; React sends a review request through the secure Node layer only; public fields remain minimal and server-validated.

**AR/EN/FR, direction, mobile acceptance:** localized customer link, modal, steps, labels, warning, errors, consent, and success states; keyboard-readable dialog; RTL/LTR; mobile without overflow.

**Automated tests:** route/source contract, accessible labels, privacy link and warning, prefill behavior where practical, full suite.

**Live/runtime acceptance:** desktop and mobile reach the verified Customer Center URL; incomplete B2B selection prefills review intake; no ERP functionality or private data appears in React.

**Rollback/stopping gate:** stop if the destination is unverified, authentication is embedded in React, or sensitive data is requested/exposed. Restore the prior link while keeping ERP ownership unchanged. **Risk: Medium.**

## M067 — Shipping transparency, navigation, and accessibility polish

**Business outcome:** Importers understand what a published freight rate does and does not cover, while the proven request flow stays clear and accessible.

**In scope:** published inclusions/exclusions; origin/destination-charge explanation; public validity, service type, transit, and free-time values when supplied; explicit “not published—confirm in review” instead of guesses; historical chart only with at least three distinct public dates; less crowded desktop/mobile navigation; localized accessible labels and consent.

**Out of scope:** exposing carrier costs, margins, internal IDs, unpublished contracts, or private rate history; estimating missing transit/free time; confirming space or carrier booking; changing authenticated shipping operations.

**Dependencies and likely areas:** after M063–M066; `ShippingRatesPage.jsx` and tests, Navbar, translations and responsive CSS.

**Security and ownership:** only customer-safe server fields may render; review requests stay behind existing validation/rate limiting/idempotency; operational shipping remains Dolibarr/Customer Center.

**AR/EN/FR, direction, mobile acceptance:** all transparency text, controls, chart states, consent, and errors are localized; Arabic RTL and EN/FR LTR; keyboard selection and 390px mobile layout work without overflow.

**Automated tests:** inclusions/exclusions, missing-field copy, validity, minimum-history threshold, review-request wording, navigation/accessibility source checks, full suite.

**Live/runtime acceptance:** preserve Egypt + Shenzhen → SOKHNA + 40HQ published search and selected-rate → review form; response shows only safe fields; no confirmation language; chart stays hidden for insufficient history.

**Rollback/stopping gate:** stop if a private field is exposed, rate selection no longer reveals the request form, or wording implies confirmed booking. Revert presentation changes while preserving the proven flow. **Risk: Medium–High.**

## Program completion gate

Local completion requires all automated commands, browser acceptance across AR/EN/FR and desktop/mobile, and a clean diff check. After Ahmed accepts the local result, request a separate staging approval. Production requires a second approval after staging runtime and business acceptance. Search Console sitemap submission, URL Inspection, and 2–4 week monitoring happen only after the accepted production release; they are not a duplicate programming Mission.
