# React refactoring baseline — 2026-08-13

## Status

- **Evidence:** Verified locally and against the deployed health endpoints on 2026-08-13.
- **Source commit:** `e8b253d5cc8e3ce766d2da43dc55d2cd67b0637d`.
- **Production:** `https://chinaplanet.org` reported the exact source commit through `/api/health`.
- **Staging:** `https://new.chinaplanet.org` reported the same source commit through `/api/health`.
- **Runtime change in this baseline mission:** None.

## Verification baseline

- `npm run lint`: PASS.
- `npm test`: PASS, 45 server tests.
- `npm run test:ui`: PASS, 7 UI-contract tests.
- `npm run build`: PASS.
- Production bundle entry: `424.61 kB`, `126.02 kB` gzip at this snapshot.
- Dependency audit: one transitive high-severity advisory in `nanoid@3.3.16` through `sanitize-html -> postcss`; a fix is available, but no automatic dependency rewrite is authorized by this baseline mission.

## Refactoring hotspots

| File | Snapshot size | Primary concern |
|---|---:|---|
| `src/index.css` | 2,073 lines | Global tokens, utilities, public pages, shipping, catalog and admin styles are coupled. |
| `src/dashboard/SiteEditorTab.jsx` | 933 lines | Multiple editors, local forms and save behavior live in one component. |
| `src/App.jsx` | 736 lines | Route state, CMS state, catalog state, session state, cart state and page orchestration are combined. |
| `src/pages/ProductsCatalogPage.jsx` | 602 lines | Catalog query, presentation and interaction concerns need characterization tests before separation. |
| `server/http.js` | 451 lines | Many API route families share one dispatcher. |

## Approved next refactoring boundaries

1. Add characterization tests before moving behavior.
2. Extract route and page orchestration from `App.jsx` without changing URLs or public API contracts.
3. Split `SiteEditorTab` by existing subtab while preserving one published content contract.
4. Split CSS by tokens, shared layout and feature ownership without visual redesign.
5. Split `server/http.js` into domain route handlers while preserving validation, rate limits, idempotency and response DTOs.
6. Resolve the dependency advisory through an intentional lockfile update and full regression suite.

## Guardrails

- Keep `React -> secure Node API -> Dolibarr`.
- WordPress/WooCommerce remains the content, product and packing source.
- Do not move authenticated customer operations into React.
- Do not combine refactoring with UI redesign, API migration, CMS retirement or production deployment.
- Each vertical refactoring change must keep lint, server tests, UI tests and build green.
