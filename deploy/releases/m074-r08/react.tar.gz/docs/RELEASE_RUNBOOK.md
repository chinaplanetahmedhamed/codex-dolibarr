# China Planet website release runbook

## Environments

| GitHub environment | Public URL | Portainer stack | Trigger |
|---|---|---|---|
| `staging` | `https://new.chinaplanet.org` | `chinaplanet-web-staging` | Automatic after `main` passes lint, tests, and build |
| `production` | `https://chinaplanet.org` | `chinaplanet-web-production` | Manual confirmation; promotes the exact SHA currently active on staging |

GitHub Actions builds the verified commit and publishes a private image to GitHub Container Registry. Portainer only pulls that image and updates the assigned website stack. The GitHub deployment secret is a Portainer API key belonging to a deployment-only user. Do not use an administrator API key.

The Portainer endpoint must have a `ghcr.io` registry entry that can read `ghcr.io/chinaplanetahmedhamed/moaz-web`. Use a GitHub personal access token (classic) limited to `read:packages`, store it in Portainer, and do not add it to the repository or workflow.

## GitHub environment configuration

Create both `staging` and `production`. Configure these values separately in each environment:

### Variables

- `PORTAINER_URL=https://portainer.visiontrading.biz`
- `PORTAINER_ENDPOINT_ID=3`
- `PORTAINER_STACK_ID=6` for the current staging stack
- Production receives its own stack ID only after the production stack is created.

### Secret

- `PORTAINER_API_KEY`: API key for a Portainer user restricted to the website deployment resources.
- `DOLIBARR_API_KEY`: API key for the dedicated staging website user. It must have only
  `website_rate_search` and `website_intake_create`; never reuse an administrator key.

### M043 staging variables

- `DOLIBARR_API_BASE_URL=https://backup-erp.visiontrading.biz/api/index.php/`
- `DOLIBARR_ALLOWED_HOST=backup-erp.visiontrading.biz`
- `TRUSTED_PROXY_HOPS=2` for the current Cloudflare then Nginx Proxy Manager chain.
  Reconfirm this value whenever the proxy chain changes.

Keep all Dolibarr credentials server-side. Do not expose them through any `VITE_*`
variable or browser-delivered asset.

### Public analytics and ownership identifiers

- The staging image build compiles the public GA4 measurement ID `G-PEKLM9QLB5`.
  Tracking remains restricted in browser code to `chinaplanet.org` and excludes
  admin, login, and Customer Center paths.
- The production stack publishes the public Search Console HTML-tag token through
  `GOOGLE_SITE_VERIFICATION`. Staging deliberately omits it and remains `noindex`.
- These identifiers are public configuration, not credentials. Never place Google
  passwords, recovery codes, DNS API keys, or service-account keys in the repository.

The production environment should require Ahmed Hamed as an approver when the GitHub plan supports required reviewers.

## Normal staging release

1. Test changes locally.
2. Open and review a pull request.
3. Merge to `main`.
4. `Quality checks` runs lint, unit tests, and the production build.
5. Only after those checks pass, `Deploy new.chinaplanet.org` publishes the same commit as a private GHCR image and updates stack `chinaplanet-web-staging`.
6. Verify the deployment URL and `/api/health`.

## Production release

Do not create or run the production stack until WordPress works at `cms.chinaplanet.org` and the cutover checklist in `HEADLESS_DEPLOYMENT.md` passes.

1. Accept the current release on `https://new.chinaplanet.org` after the automatic `main` deployment succeeds.
2. Open GitHub Actions and run `Deploy chinaplanet.org` from `main`.
3. Enter the exact phrase `DEPLOY chinaplanet.org`; no commit SHA input is required.
4. The workflow reads `deploySha` from staging, requires it to equal the latest `main` commit, verifies that the immutable GHCR image exists, and rechecks staging before deployment.
5. Approve the protected `production` environment.
6. After deployment, verify health, homepage, products, blog, China Guide, lead delivery, admin login, and mobile layout.
7. If any release check fails, restore the previous stack version/image and return the DNS/proxy route to the previous origin.

## CMS stage before live cutover

1. Back up the current WordPress database and files and prove the backup can be restored.
2. Add `cms.chinaplanet.org` to the current WordPress origin and issue a valid certificate.
3. Change WordPress URLs with a serialized-data-safe migration tool.
4. Verify `/wp-admin`, WooCommerce REST/Store APIs, media, posts, `china_guide`, webhooks, and lead receiver on the CMS hostname.
5. Change staging to use `WORDPRESS_BASE_URL=https://cms.chinaplanet.org` and test again.
6. Create the separate production stack and volume.
7. Only then change the main domain proxy/DNS to React.

Never point `chinaplanet.org` at React while WordPress still depends on that hostname as its only working origin.
