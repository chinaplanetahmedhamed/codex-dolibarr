# نشر China Planet بنظام WordPress Headless

## الشكل النهائي

| النطاق | المسؤولية |
|---|---|
| `https://chinaplanet.org` | موقع React العام: الصفحة الرئيسية، المنتجات، المدونة، ودليل الصين |
| `https://cms.chinaplanet.org` | WordPress/WooCommerce ولوحة نشر المقالات ودليل الصين |
| Dolibarr Customer Center | حسابات العملاء والطلبات والشحنات والمستندات |

WordPress يبقى مصدر المنتجات والمقالات ودليل الصين. React لا ينشئ نسخة تحرير ثانية من هذه البيانات.

## المرحلة الآمنة قبل تغيير النطاق الرئيسي

1. أنشئ `new.chinaplanet.org` كتطبيق Node.js في Hostinger.
2. اربطه بهذا المستودع وشغّل:

   ```text
   Build command: npm ci && npm run build
   Start command: npm start
   Node version: 22
   ```

3. أضف متغيرات البيئة من `.env.example`. استخدم في بيئة الاختبار:

   ```text
   PUBLIC_SITE_ORIGIN=https://new.chinaplanet.org
   WORDPRESS_BASE_URL=https://chinaplanet.org
   VITE_WORDPRESS_ADMIN_URL=https://chinaplanet.org/wp-admin/
   ```

4. لا تنقل WordPress ولا تغيّر DNS الخاص بـ`chinaplanet.org` في هذه المرحلة.
5. اختبر المسارات النظيفة مباشرة، وليس بالـhash فقط:

   ```text
   /products
   /blog
   /blog/{slug}
   /china-guide
   /api/health
   /api/posts
   /api/china-guide
   ```

## تفعيل جسر WordPress

1. ارفع ملف `chinaplanet-headless-bridge-upload.zip` من لوحة WordPress: إضافات ← أضف إضافة ← رفع إضافة.
2. فعّل الإضافة.
3. أنشئ سرًا مستقلًا:

   ```bash
   openssl rand -hex 32
   ```

4. أضف إلى `wp-config.php` قبل سطر إيقاف التحرير:

   ```php
   define('CHINAPLANET_HEADLESS_WEBHOOK_URL', 'https://new.chinaplanet.org/api/webhooks/wordpress/content');
   define('CHINAPLANET_HEADLESS_WEBHOOK_SECRET', 'ضع-السر-العشوائي-هنا');
   ```

5. ضع القيمة نفسها في متغير الخادم `WP_CONTENT_WEBHOOK_SECRET`.
6. حدّث مقالًا تجريبيًا ومكانًا في دليل الصين، ثم تأكد أن `revision` يتغير في `/api/wordpress-content-version` وأن React يعرض التحديث خلال نحو 30 ثانية.

الإضافة لا تكشف كل `post_meta`. هي تسمح فقط بحقول عامة محددة. إذا كانت إضافة دليل الصين الحالية تستخدم أسماء حقول مختلفة، تُضاف عبر فلتر `chinaplanet_headless_public_meta_fields` بعد مراجعة أسمائها، وليس بفتح جميع الحقول للعموم.

## نقل WordPress إلى `cms.chinaplanet.org`

هذه المرحلة تُنفذ فقط بعد نجاح الاختبار وأخذ نسخة احتياطية كاملة للملفات وقاعدة البيانات.

1. أنشئ نسخة Staging من WordPress على `cms.chinaplanet.org`.
2. اختبر تسجيل الدخول، WooCommerce، REST API، الصور، المقالات، و`china_guide` على النطاق الجديد.
3. نفّذ استبدالًا آمنًا للروابط القديمة داخل WordPress بأداة تدعم serialized data؛ لا تستخدم استبدال SQL نصي عادي.
4. غيّر على تطبيق React:

   ```text
   WORDPRESS_BASE_URL=https://cms.chinaplanet.org
   VITE_WORDPRESS_ADMIN_URL=https://cms.chinaplanet.org/wp-admin/
   PUBLIC_SITE_ORIGIN=https://chinaplanet.org
   ```

5. غيّر Webhook في `wp-config.php` إلى النطاق النهائي:

   ```php
   define('CHINAPLANET_HEADLESS_WEBHOOK_URL', 'https://chinaplanet.org/api/webhooks/wordpress/content');
   ```

6. انشر React على `chinaplanet.org`، ثم اختبر كل الرحلة قبل إغلاق نسخة الموقع القديمة.

## شروط التحويل النهائي

- نسخة احتياطية قابلة للاستعادة تم اختبارها.
- المدونة ودليل الصين والمنتجات والصور تعمل من React.
- Webhooks الخاصة بالمنتجات والمحتوى تعيد HTTP 200 بتوقيع صحيح.
- نماذج العملاء تصل إلى البوابة المعتمدة.
- روابط Google المهمة لديها redirects دائمة إلى المسارات الجديدة.
- لوحة WordPress وReact وCustomer Center لا تكشف أي مفاتيح في JavaScript أو `localStorage`.
- يوجد rollback واضح: إعادة DNS إلى WordPress السابق إذا فشل فحص ما بعد النشر.

## ما يحتاج وصول Ahmed أو مسؤول Hostinger

- إنشاء `new.chinaplanet.org` و`cms.chinaplanet.org`.
- إضافة أسرار البيئة من لوحة Hostinger.
- رفع وتفعيل إضافة WordPress.
- النسخة الاحتياطية وتغيير DNS في موعد التحويل المعتمد.

لا ينبغي تنفيذ تغيير DNS أو نقل قاعدة WordPress تلقائيًا من بيئة التطوير المحلية.
