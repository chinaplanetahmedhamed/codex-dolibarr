<?php
/**
 * Plugin Name: ChinaPlanet Headless Bridge
 * Description: Connects WordPress/WooCommerce content and signed website leads to the China Planet React website.
 * Version: 1.1.0
 * Author: China Planet
 */

if (!defined('ABSPATH')) {
    exit;
}

const CHINAPLANET_HEADLESS_OPTION = 'chinaplanet_headless_settings';

function chinaplanet_headless_settings() {
    $stored = get_option(CHINAPLANET_HEADLESS_OPTION, array());
    return is_array($stored) ? $stored : array();
}

function chinaplanet_headless_setting($key, $constant_name = '', $default = '') {
    if ($constant_name && defined($constant_name)) {
        $constant_value = constant($constant_name);
        if (is_scalar($constant_value) && (string) $constant_value !== '') {
            return (string) $constant_value;
        }
    }

    $settings = chinaplanet_headless_settings();
    return isset($settings[$key]) && is_scalar($settings[$key])
        ? (string) $settings[$key]
        : (string) $default;
}

function chinaplanet_headless_secret_configured($key, $constant_name = '') {
    return chinaplanet_headless_setting($key, $constant_name) !== '';
}

add_action('admin_menu', static function () {
    add_options_page(
        'ChinaPlanet Headless',
        'ChinaPlanet Headless',
        'manage_options',
        'chinaplanet-headless',
        'chinaplanet_headless_render_settings_page'
    );
});

function chinaplanet_headless_render_settings_page() {
    if (!current_user_can('manage_options')) {
        return;
    }

    $saved = false;
    if (isset($_POST['chinaplanet_headless_save'])) {
        check_admin_referer('chinaplanet_headless_save_settings');
        $current = chinaplanet_headless_settings();
        $current['webhook_url'] = isset($_POST['webhook_url'])
            ? esc_url_raw(wp_unslash($_POST['webhook_url']))
            : '';
        $current['lead_recipient'] = isset($_POST['lead_recipient'])
            ? sanitize_email(wp_unslash($_POST['lead_recipient']))
            : '';

        foreach (array('content_webhook_secret', 'lead_webhook_token', 'lead_webhook_secret') as $secret_key) {
            $submitted = isset($_POST[$secret_key]) ? trim((string) wp_unslash($_POST[$secret_key])) : '';
            if ($submitted !== '') {
                $current[$secret_key] = sanitize_text_field($submitted);
            }
        }

        update_option(CHINAPLANET_HEADLESS_OPTION, $current, false);
        $saved = true;
    }

    $settings = chinaplanet_headless_settings();
    $webhook_url = isset($settings['webhook_url']) ? (string) $settings['webhook_url'] : '';
    $recipient = isset($settings['lead_recipient']) && $settings['lead_recipient']
        ? (string) $settings['lead_recipient']
        : (string) get_option('admin_email');
    ?>
    <div class="wrap">
        <h1>ChinaPlanet Headless Bridge</h1>
        <?php if ($saved) : ?>
            <div class="notice notice-success is-dismissible"><p>تم حفظ إعدادات الربط.</p></div>
        <?php endif; ?>
        <p>اربط نشر المحتوى بموقع React، واستقبل طلبات التسعير الموقعة عبر البريد بدون تخزين بيانات العميل داخل WordPress.</p>
        <form method="post">
            <?php wp_nonce_field('chinaplanet_headless_save_settings'); ?>
            <table class="form-table" role="presentation">
                <tr>
                    <th scope="row"><label for="cp-webhook-url">رابط تحديث محتوى React</label></th>
                    <td><input id="cp-webhook-url" name="webhook_url" type="url" class="regular-text code" value="<?php echo esc_attr($webhook_url); ?>" placeholder="https://new.chinaplanet.org/api/webhooks/wordpress/content"></td>
                </tr>
                <tr>
                    <th scope="row"><label for="cp-content-secret">سر تحديث المحتوى</label></th>
                    <td><input id="cp-content-secret" name="content_webhook_secret" type="password" class="regular-text" value="" autocomplete="new-password" placeholder="اتركه فارغاً للاحتفاظ بالقيمة الحالية"><p class="description">الحالة: <?php echo chinaplanet_headless_secret_configured('content_webhook_secret', 'CHINAPLANET_HEADLESS_WEBHOOK_SECRET') ? 'مُهيأ' : 'غير مُهيأ'; ?></p></td>
                </tr>
                <tr>
                    <th scope="row"><label for="cp-lead-token">رمز استلام الطلبات</label></th>
                    <td><input id="cp-lead-token" name="lead_webhook_token" type="password" class="regular-text" value="" autocomplete="new-password" placeholder="اتركه فارغاً للاحتفاظ بالقيمة الحالية"><p class="description">الحالة: <?php echo chinaplanet_headless_secret_configured('lead_webhook_token') ? 'مُهيأ' : 'غير مُهيأ'; ?></p></td>
                </tr>
                <tr>
                    <th scope="row"><label for="cp-lead-secret">سر توقيع الطلبات</label></th>
                    <td><input id="cp-lead-secret" name="lead_webhook_secret" type="password" class="regular-text" value="" autocomplete="new-password" placeholder="اتركه فارغاً للاحتفاظ بالقيمة الحالية"><p class="description">الحالة: <?php echo chinaplanet_headless_secret_configured('lead_webhook_secret') ? 'مُهيأ' : 'غير مُهيأ'; ?></p></td>
                </tr>
                <tr>
                    <th scope="row"><label for="cp-lead-recipient">بريد استلام الطلبات</label></th>
                    <td><input id="cp-lead-recipient" name="lead_recipient" type="email" class="regular-text" value="<?php echo esc_attr($recipient); ?>"></td>
                </tr>
            </table>
            <p><strong>رابط استلام الطلبات:</strong> <code><?php echo esc_html(rest_url('chinaplanet-headless/v1/leads')); ?></code></p>
            <?php submit_button('حفظ إعدادات الربط', 'primary', 'chinaplanet_headless_save'); ?>
        </form>
    </div>
    <?php
}

function chinaplanet_headless_public_meta($post_id) {
    $field_map = array(
        'address' => array('address', 'place_address', 'china_guide_address'),
        'address_ar' => array('address_ar', 'place_address_ar', 'china_guide_address_ar'),
        'phone' => array('phone', 'place_phone', 'china_guide_phone'),
        'website' => array('website', 'place_website', 'china_guide_website'),
        'google_maps_url' => array('google_maps_url', 'map_url', 'place_map_url'),
    );
    $field_map = apply_filters('chinaplanet_headless_public_meta_fields', $field_map, $post_id);
    $result = array();

    foreach ($field_map as $public_name => $candidate_keys) {
        foreach ((array) $candidate_keys as $meta_key) {
            $value = get_post_meta($post_id, $meta_key, true);
            if ($value !== '' && $value !== null) {
                $result[$public_name] = is_scalar($value) ? (string) $value : '';
                break;
            }
        }
    }

    return array_filter($result, static function ($value) {
        return $value !== '';
    });
}

function chinaplanet_headless_rest_value($object) {
    $post_id = isset($object['id']) ? (int) $object['id'] : 0;
    $post = get_post($post_id);
    if (!$post || $post->post_status !== 'publish') {
        return null;
    }

    $image = get_the_post_thumbnail_url($post_id, 'large');
    return array(
        'content' => apply_filters('the_content', $post->post_content),
        'excerpt' => has_excerpt($post_id) ? get_the_excerpt($post_id) : wp_trim_words(wp_strip_all_tags($post->post_content), 55),
        'featuredImage' => $image ? esc_url_raw($image) : '',
        'publicMeta' => $post->post_type === 'china_guide' ? chinaplanet_headless_public_meta($post_id) : array(),
    );
}

add_action('rest_api_init', static function () {
    foreach (array('post', 'china_guide') as $post_type) {
        register_rest_field($post_type, 'chinaplanet_headless', array(
            'get_callback' => 'chinaplanet_headless_rest_value',
            'schema' => array(
                'description' => 'Public fields approved for the China Planet React frontend.',
                'type' => array('object', 'null'),
                'context' => array('view'),
                'readonly' => true,
            ),
        ));
    }
});

function chinaplanet_headless_notify($post_id, $event = 'updated') {
    $webhook_url = chinaplanet_headless_setting('webhook_url', 'CHINAPLANET_HEADLESS_WEBHOOK_URL');
    $webhook_secret = chinaplanet_headless_setting('content_webhook_secret', 'CHINAPLANET_HEADLESS_WEBHOOK_SECRET');
    if (!$webhook_url || !$webhook_secret) {
        return;
    }

    $post = get_post($post_id);
    if (!$post || !in_array($post->post_type, array('post', 'china_guide'), true)) {
        return;
    }

    $body = wp_json_encode(array(
        'post_id' => (int) $post_id,
        'post_type' => $post->post_type,
        'event' => sanitize_key($event),
        'updated_at' => gmdate('c'),
    ));
    $signature = base64_encode(hash_hmac('sha256', $body, $webhook_secret, true));

    wp_remote_post($webhook_url, array(
        'timeout' => 5,
        'blocking' => false,
        'headers' => array(
            'Content-Type' => 'application/json',
            'X-ChinaPlanet-Signature' => $signature,
        ),
        'body' => $body,
    ));
}

add_action('save_post', static function ($post_id, $post, $update) {
    if (wp_is_post_revision($post_id) || wp_is_post_autosave($post_id)) {
        return;
    }
    if (!$post || !in_array($post->post_type, array('post', 'china_guide'), true)) {
        return;
    }
    chinaplanet_headless_notify($post_id, $update ? 'updated' : 'created');
}, 20, 3);

add_action('set_object_terms', static function ($object_id, $terms, $tt_ids, $taxonomy) {
    if (in_array($taxonomy, array('category', 'china_city', 'place_type', 'place_tag'), true)) {
        chinaplanet_headless_notify($object_id, 'terms_updated');
    }
}, 20, 4);

add_action('before_delete_post', static function ($post_id) {
    chinaplanet_headless_notify($post_id, 'deleted');
});

function chinaplanet_headless_lead_text($value, $max_length = 1000) {
    if (!is_scalar($value)) {
        return '';
    }
    return mb_substr(trim(wp_strip_all_tags((string) $value)), 0, $max_length);
}

function chinaplanet_headless_lead_row($label, $value) {
    if ($value === '' || $value === null) {
        return '';
    }
    return '<tr><th style="text-align:right;padding:8px;border:1px solid #ddd;background:#f7f7f7">'
        . esc_html($label)
        . '</th><td style="padding:8px;border:1px solid #ddd">'
        . nl2br(esc_html((string) $value))
        . '</td></tr>';
}

function chinaplanet_headless_receive_lead(WP_REST_Request $request) {
    $token = chinaplanet_headless_setting('lead_webhook_token');
    $secret = chinaplanet_headless_setting('lead_webhook_secret');
    if (!$token || !$secret) {
        return new WP_Error('chinaplanet_leads_not_configured', 'Lead receiver is not configured.', array('status' => 503));
    }

    $raw_body = (string) $request->get_body();
    $authorization = trim((string) $request->get_header('authorization'));
    $signature = trim((string) $request->get_header('x-chinaplanet-signature'));
    $expected_authorization = 'Bearer ' . $token;
    $expected_signature = 'sha256=' . hash_hmac('sha256', $raw_body, $secret);
    if (!hash_equals($expected_authorization, $authorization) || !hash_equals($expected_signature, $signature)) {
        return new WP_Error('chinaplanet_invalid_lead_signature', 'Invalid lead signature.', array('status' => 401));
    }

    $payload = json_decode($raw_body, true);
    $lead = is_array($payload) && isset($payload['lead']) && is_array($payload['lead']) ? $payload['lead'] : array();
    $reference = chinaplanet_headless_lead_text(isset($payload['reference']) ? $payload['reference'] : '', 80);
    $client_name = chinaplanet_headless_lead_text(isset($lead['clientName']) ? $lead['clientName'] : '', 120);
    $phone = chinaplanet_headless_lead_text(isset($lead['phone']) ? $lead['phone'] : '', 40);
    if (!$reference || !$client_name || !$phone) {
        return new WP_Error('chinaplanet_invalid_lead', 'Invalid lead payload.', array('status' => 422));
    }

    $idempotency_key = chinaplanet_headless_lead_text($request->get_header('idempotency-key'), 120);
    $dedupe_key = 'cp_headless_lead_' . substr(hash('sha256', $idempotency_key ?: $reference), 0, 32);
    if (get_transient($dedupe_key)) {
        return new WP_REST_Response(array('ok' => true, 'reference' => $reference, 'duplicate' => true), 200);
    }

    $type = isset($lead['type']) && $lead['type'] === 'catalog_order' ? 'طلب كتالوج' : 'طلب تسعير';
    $rows = '';
    $rows .= chinaplanet_headless_lead_row('المرجع', $reference);
    $rows .= chinaplanet_headless_lead_row('نوع الطلب', $type);
    $rows .= chinaplanet_headless_lead_row('الاسم', $client_name);
    $rows .= chinaplanet_headless_lead_row('واتساب / الهاتف', $phone);
    $rows .= chinaplanet_headless_lead_row('البريد', chinaplanet_headless_lead_text(isset($lead['email']) ? $lead['email'] : '', 180));
    $rows .= chinaplanet_headless_lead_row('الشركة', chinaplanet_headless_lead_text(isset($lead['company']) ? $lead['company'] : '', 180));
    $rows .= chinaplanet_headless_lead_row('الدولة', chinaplanet_headless_lead_text(isset($lead['country']) ? $lead['country'] : '', 100));
    $rows .= chinaplanet_headless_lead_row('المنتج / الخدمة', chinaplanet_headless_lead_text(isset($lead['productName']) ? $lead['productName'] : '', 240));
    $rows .= chinaplanet_headless_lead_row('الكمية', chinaplanet_headless_lead_text(isset($lead['quantity']) ? $lead['quantity'] : '', 120));
    $rows .= chinaplanet_headless_lead_row('السعر المستهدف', chinaplanet_headless_lead_text(isset($lead['targetPrice']) ? $lead['targetPrice'] : '', 120));
    $rows .= chinaplanet_headless_lead_row('الخدمة المطلوبة', chinaplanet_headless_lead_text(isset($lead['serviceRequired']) ? $lead['serviceRequired'] : '', 240));
    $rows .= chinaplanet_headless_lead_row('ملاحظات', chinaplanet_headless_lead_text(isset($lead['notes']) ? $lead['notes'] : '', 4000));

    $items = isset($lead['items']) && is_array($lead['items']) ? array_slice($lead['items'], 0, 100) : array();
    if ($items) {
        $item_lines = array();
        foreach ($items as $index => $item) {
            if (!is_array($item)) {
                continue;
            }
            $title = chinaplanet_headless_lead_text(isset($item['title']) ? $item['title'] : '', 240);
            $sku = chinaplanet_headless_lead_text(isset($item['sku']) ? $item['sku'] : '', 100);
            $option = chinaplanet_headless_lead_text(isset($item['selectedOptionLabel']) ? $item['selectedOptionLabel'] : '', 240);
            $quantity = chinaplanet_headless_lead_text(isset($item['quantity']) ? $item['quantity'] : '', 80);
            $item_lines[] = ($index + 1) . '. ' . $title
                . ($sku ? ' | SKU: ' . $sku : '')
                . ($option ? ' | ' . $option : '')
                . ($quantity ? ' | ' . $quantity : '');
        }
        $rows .= chinaplanet_headless_lead_row('المنتجات', implode("\n", $item_lines));
    }

    $recipient = chinaplanet_headless_setting('lead_recipient', '', get_option('admin_email'));
    if (!is_email($recipient)) {
        return new WP_Error('chinaplanet_invalid_lead_recipient', 'Lead recipient is not configured.', array('status' => 503));
    }

    $subject = sprintf('[China Planet] %s - %s', $type, $reference);
    $message = '<div dir="rtl" style="font-family:Arial,sans-serif"><h2>طلب جديد من موقع كوكب الصين</h2><table style="border-collapse:collapse;width:100%;max-width:760px">' . $rows . '</table></div>';
    $sent = wp_mail($recipient, $subject, $message, array('Content-Type: text/html; charset=UTF-8'));
    if (!$sent) {
        return new WP_Error('chinaplanet_lead_delivery_failed', 'Lead email delivery failed.', array('status' => 502));
    }

    set_transient($dedupe_key, 1, 7 * DAY_IN_SECONDS);
    do_action('chinaplanet_headless_lead_received', $payload, $reference);
    return new WP_REST_Response(array('ok' => true, 'reference' => $reference), 202);
}

add_action('rest_api_init', static function () {
    register_rest_route('chinaplanet-headless/v1', '/leads', array(
        'methods' => WP_REST_Server::CREATABLE,
        'callback' => 'chinaplanet_headless_receive_lead',
        'permission_callback' => '__return_true',
    ));
});
