# ChinaPlanet Headless Bridge

الإضافة تربط نشر WordPress بموقع React، وتعرض فقط الحقول العامة الموافق عليها للمقالات و`china_guide`.

لإنشاء حزمة الرفع من جذر المشروع:

```bash
cd wordpress-plugin
zip -r ../chinaplanet-headless-bridge.zip chinaplanet-headless-bridge
```

تعليمات الإعداد الكامل موجودة في `docs/HEADLESS_DEPLOYMENT.md`.
