import { createPasswordHash } from "./auth.js";

const password = process.argv[2];
if (!password) {
  console.error("Usage: npm run admin:hash -- 'a-long-random-password'");
  process.exitCode = 1;
} else {
  console.log(await createPasswordHash(password));
}
