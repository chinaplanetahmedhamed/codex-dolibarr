import { getRuntimeConfig } from "./config.js";
import { readSiteContent } from "./content.js";
import { fetchChinaGuide, fetchWordPressPosts } from "./wordpress-content.js";

const STATIC_PATHS = [
  "/",
  "/about",
  "/services",
  "/products",
  "/b2b",
  "/shipping-rates",
  "/how-we-work",
  "/china-guide",
  "/blog",
  "/faq",
  "/contact",
  "/privacy",
  "/terms",
];
const PUBLIC_LOCALES = ["ar", "en", "fr"];

function basePath(value) {
  const normalized = value?.startsWith("/") ? value : `/${value || ""}`;
  return normalized.replace(/^\/(?:en|fr)(?=\/|$)/, "") || "/";
}

function localizedPath(path, locale) {
  const base = basePath(path);
  if (locale === "ar") return base;
  return base === "/" ? `/${locale}` : `/${locale}${base}`;
}

function escapeXml(value) {
  return String(value || "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&apos;");
}

function safeOrigin(value) {
  try {
    const url = new URL(value || "https://chinaplanet.org");
    return `${url.protocol}//${url.host}`;
  } catch {
    return "https://chinaplanet.org";
  }
}

function safeSlug(value) {
  return encodeURIComponent(String(value || "").trim());
}

function safeLastModified(value) {
  const date = new Date(value || "");
  return Number.isNaN(date.getTime()) ? "" : date.toISOString();
}

export function renderRobots({ origin, allowIndexing }) {
  const normalizedOrigin = safeOrigin(origin);
  return [
    "User-agent: *",
    allowIndexing ? "Allow: /" : "Disallow: /",
    "Disallow: /admin",
    "Disallow: /api/",
    `Sitemap: ${normalizedOrigin}/sitemap.xml`,
    "",
  ].join("\n");
}

export function renderSitemap({ origin, entries }) {
  const normalizedOrigin = safeOrigin(origin);
  const baseEntries = new Map();
  entries.forEach((entry) => {
    const path = basePath(entry?.path);
    if (!baseEntries.has(path)) baseEntries.set(path, { ...entry, path });
  });

  const urls = [...baseEntries.values()].flatMap((entry) => PUBLIC_LOCALES.map((locale) => {
    const location = `${normalizedOrigin}${localizedPath(entry.path, locale)}`;
    const lastModified = safeLastModified(entry.lastModified);
    const alternates = PUBLIC_LOCALES.map((alternateLocale) =>
      `    <xhtml:link rel="alternate" hreflang="${alternateLocale}" href="${escapeXml(`${normalizedOrigin}${localizedPath(entry.path, alternateLocale)}`)}" />`
    );
    alternates.push(`    <xhtml:link rel="alternate" hreflang="x-default" href="${escapeXml(`${normalizedOrigin}${localizedPath(entry.path, "ar")}`)}" />`);
    return [
      "  <url>",
      `    <loc>${escapeXml(location)}</loc>`,
      ...alternates,
      lastModified ? `    <lastmod>${lastModified}</lastmod>` : "",
      "  </url>",
    ].filter(Boolean).join("\n");
  })).join("\n");

  return [
    "<?xml version=\"1.0\" encoding=\"UTF-8\"?>",
    "<urlset xmlns=\"http://www.sitemaps.org/schemas/sitemap/0.9\" xmlns:xhtml=\"http://www.w3.org/1999/xhtml\">",
    urls,
    "</urlset>",
    "",
  ].join("\n");
}

export async function buildSitemap({ env = process.env, fetchImpl = fetch } = {}) {
  const config = getRuntimeConfig(env);
  const origin = safeOrigin(config.publicSiteOrigin || "https://chinaplanet.org");
  const entries = STATIC_PATHS.map((path) => ({ path }));
  const [contentResult, postsResult, guideResult] = await Promise.allSettled([
    readSiteContent(env),
    fetchWordPressPosts({ env, fetchImpl }),
    fetchChinaGuide({ env, fetchImpl }),
  ]);

  if (contentResult.status === "fulfilled") {
    const updatedAt = contentResult.value?.updatedAt;
    (contentResult.value?.content?.servicesData || []).forEach((service) => {
      if (service?.id) entries.push({ path: `/service/${safeSlug(service.id)}`, lastModified: updatedAt });
    });
  }
  if (postsResult.status === "fulfilled") {
    (postsResult.value?.posts || []).forEach((post) => {
      if (post?.slug) entries.push({ path: `/blog/${safeSlug(post.slug)}`, lastModified: post.modifiedAt || post.publishedAt });
    });
  }
  if (guideResult.status === "fulfilled") {
    (guideResult.value?.places || []).forEach((place) => {
      if (place?.slug) entries.push({ path: `/china-guide/${safeSlug(place.slug)}`, lastModified: place.modifiedAt });
    });
  }

  return renderSitemap({ origin, entries });
}

export function legacyRedirect(pathname) {
  const normalized = String(pathname || "/").replace(/\/+$/, "") || "/";
  const exact = new Map([
    ["/index.html", "/"],
    ["/about-us", "/about"],
    ["/contact-us", "/contact"],
    ["/shop", "/products"],
    ["/store", "/products"],
  ]);
  if (exact.has(normalized)) return exact.get(normalized);
  if (/^\/(?:product-category|product)\//i.test(normalized)) return "/products";
  if (/^\/(?:category|tag|author)\//i.test(normalized)) return "/blog";

  const datedPost = normalized.match(/^\/\d{4}\/\d{2}(?:\/\d{2})?\/([^/]+)$/);
  return datedPost ? `/blog/${safeSlug(decodeURIComponent(datedPost[1]))}` : "";
}

export function canonicalHostRedirect({ host, pathname = "/", search = "", origin }) {
  let canonical;
  try {
    canonical = new URL(origin || "https://chinaplanet.org");
  } catch {
    return "";
  }

  const incomingHost = String(host || "").split(",", 1)[0].trim().toLowerCase();
  const canonicalHost = canonical.host.toLowerCase();
  if (!incomingHost || incomingHost !== `www.${canonicalHost}`) return "";
  const safePath = String(pathname || "/").startsWith("/") ? String(pathname || "/") : "/";
  return `${canonical.origin}${safePath}${String(search || "")}`;
}
