import { createHmac, timingSafeEqual } from "node:crypto";
import sanitizeHtml from "sanitize-html";
import { getRuntimeConfig } from "./config.js";

const DEFAULT_IMAGE = "/images/hero.webp";
const CITY_CONTENT = {
  foshan: { nameAr: "فوشان", description: "مدينة الأثاث والسيراميك ومواد البناء والأسواق الصناعية.", fallbackImage: "/images/warehouse.webp" },
  guangzhou: { nameAr: "جوانزو", description: "مركز التجارة والمعارض وأسواق الجملة الرئيسي في جنوب الصين.", fallbackImage: "/images/hero.webp" },
  shanghai: { nameAr: "شنغهاي", description: "العاصمة التجارية الحديثة ومركز المعارض والأعمال الدولية.", fallbackImage: "/images/china_planet_hero_banner_1785418012119.jpg" },
  shenzhen: { nameAr: "شينزن", description: "مدينة الإلكترونيات والتقنية والأسواق الحديثة قرب هونغ كونغ.", fallbackImage: "/images/inspection.webp" },
  zhongshan: { nameAr: "تشونغشان", description: "وجهة صناعية مهمة تشتهر بمدينة الإضاءة في غوزن.", fallbackImage: "/images/quality_inspection_1785418041351.jpg" },
  zhuhai: { nameAr: "تشوهاي", description: "مدينة ساحلية للأعمال والسياحة بجوار ماكاو.", fallbackImage: "/images/guangzhou_warehouse_1785418026628.jpg" },
};

function contentError(message, code = "wordpress_content_error", status = 502) {
  const error = new Error(message);
  error.code = code;
  error.status = status;
  return error;
}

function safeText(value) {
  return sanitizeHtml(String(value || ""), { allowedTags: [], allowedAttributes: {} })
    .replace(/\s+/g, " ")
    .trim();
}

export function stripMarkdownArtifacts(value) {
  return String(value || '')
    .replace(/^\s{0,3}#{1,6}\s+/gm, '')
    .replace(/!\[([^\]]*)\]\([^)]*\)/g, '$1')
    .replace(/\[([^\]]+)\]\([^)]*\)/g, '$1')
    .replace(/\*\*([^*]+)\*\*/g, '$1')
    .replace(/__([^_]+)__/g, '$1')
    .replace(/(?<!\*)\*([^*]+)\*(?!\*)/g, '$1')
    .replace(/`{1,3}([^`]+)`{1,3}/g, '$1')
    .replace(/\s+/g, ' ')
    .trim();
}

function plainTextHtml(value) {
  const text = safeText(value);
  return text ? `<p>${text}</p>` : "";
}

export function sanitizeWordPressHtml(value) {
  const withoutDocumentChrome = String(value || "")
    .replace(/<head[\s\S]*?<\/head>/gi, "")
    .replace(/<!doctype[\s\S]*?>/gi, "");

  return sanitizeHtml(withoutDocumentChrome, {
    allowedTags: [
      "p", "br", "h2", "h3", "h4", "h5", "strong", "b", "em", "i", "u",
      "ul", "ol", "li", "blockquote", "a", "img", "figure", "figcaption", "table",
      "thead", "tbody", "tr", "th", "td", "hr", "code", "pre", "span", "div",
    ],
    allowedAttributes: {
      a: ["href", "title", "target", "rel"],
      img: ["src", "alt", "title", "width", "height", "loading"],
      th: ["colspan", "rowspan"],
      td: ["colspan", "rowspan"],
    },
    allowedSchemes: ["http", "https", "mailto", "tel"],
    allowedSchemesByTag: { img: ["https"] },
    transformTags: {
      a: (_tagName, attribs) => ({
        tagName: "a",
        attribs: {
          ...attribs,
          rel: "noopener noreferrer",
          ...(attribs.target === "_blank" ? { target: "_blank" } : {}),
        },
      }),
      img: (_tagName, attribs) => ({
        tagName: "img",
        attribs: { ...attribs, loading: "lazy" },
      }),
    },
  }).trim();
}

async function getJson(url, fetchImpl) {
  const response = await fetchImpl(url, {
    headers: { Accept: "application/json" },
    signal: AbortSignal.timeout(12_000),
  });
  if (!response.ok) {
    throw contentError(`WordPress REST request failed (${response.status})`, "wordpress_request_failed", response.status >= 500 ? 502 : response.status);
  }
  return response.json();
}

async function getHtml(url, fetchImpl) {
  const response = await fetchImpl(url, {
    headers: { Accept: "text/html,application/xhtml+xml" },
    signal: AbortSignal.timeout(12_000),
  });
  if (!response.ok) throw contentError(`WordPress page request failed (${response.status})`, "wordpress_page_failed", 502);
  return response.text();
}

async function fetchPages(baseUrl, restPath, maxPages, fetchImpl, params = {}) {
  const rows = [];
  for (let page = 1; page <= maxPages; page += 1) {
    const endpoint = new URL(`/wp-json/wp/v2/${restPath}`, baseUrl);
    Object.entries(params).forEach(([key, value]) => {
      if (value !== "" && value !== null && value !== undefined) endpoint.searchParams.set(key, String(value));
    });
    endpoint.searchParams.set("per_page", "100");
    endpoint.searchParams.set("page", String(page));
    const pageRows = await getJson(endpoint, fetchImpl);
    if (!Array.isArray(pageRows)) throw contentError("WordPress returned an invalid collection");
    rows.push(...pageRows);
    if (pageRows.length < 100) break;
  }
  return rows;
}

function embeddedImage(item, fallback = DEFAULT_IMAGE) {
  const media = item?._embedded?.["wp:featuredmedia"]?.[0];
  const source = item?.chinaplanet_headless?.featuredImage || media?.source_url;
  return typeof source === "string" && /^https:\/\//i.test(source) ? source : fallback;
}

function publicImageUrl(value) {
  return typeof value === "string" && /^https:\/\//i.test(value) ? value : "";
}

function guidePrimaryImage(item) {
  return publicImageUrl(item?.meta?._main_image_url) || embeddedImage(item, "");
}

function chunkRows(rows, size) {
  const chunks = [];
  for (let index = 0; index < rows.length; index += size) chunks.push(rows.slice(index, index + size));
  return chunks;
}

async function fetchGuideMedia(rawPlaces, config, fetchImpl) {
  const mediaByPostId = new Map();
  const groups = chunkRows(rawPlaces.map((item) => Number(item?.id)).filter(Number.isFinite), 40);
  const results = await Promise.allSettled(groups.map(async (ids) => {
    const endpoint = new URL("/wp-json/wp/v2/media", config.wordpressBaseUrl);
    endpoint.searchParams.set("parent", ids.join(","));
    endpoint.searchParams.set("per_page", "100");
    endpoint.searchParams.set("_fields", "id,post,source_url,alt_text,media_details");
    return getJson(endpoint, fetchImpl);
  }));
  results.forEach((result) => {
    if (result.status !== "fulfilled" || !Array.isArray(result.value)) return;
    result.value.forEach((media) => {
      const postId = Number(media?.post);
      const source = media?.source_url;
      if (Number.isFinite(postId) && !mediaByPostId.has(postId) && typeof source === "string" && /^https:\/\//i.test(source)) {
        mediaByPostId.set(postId, source);
      }
    });
  });
  return mediaByPostId;
}

async function fetchMediaByIds(ids, config, fetchImpl) {
  const mediaById = new Map();
  const uniqueIds = [...new Set(ids.map(Number).filter((id) => Number.isInteger(id) && id > 0))];
  const results = await Promise.allSettled(chunkRows(uniqueIds, 40).map(async (group) => {
    const endpoint = new URL("/wp-json/wp/v2/media", config.wordpressBaseUrl);
    endpoint.searchParams.set("include", group.join(","));
    endpoint.searchParams.set("per_page", String(group.length));
    endpoint.searchParams.set("_fields", "id,source_url");
    return getJson(endpoint, fetchImpl);
  }));

  results.forEach((result) => {
    if (result.status !== "fulfilled" || !Array.isArray(result.value)) return;
    result.value.forEach((media) => {
      const id = Number(media?.id);
      const source = publicImageUrl(media?.source_url);
      if (Number.isInteger(id) && id > 0 && source) mediaById.set(id, source);
    });
  });

  return mediaById;
}

function extractMetaContent(html, key) {
  const escaped = key.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  const tag = String(html || "").match(new RegExp(`<meta[^>]+(?:property|name)=["']${escaped}["'][^>]*>`, "i"))?.[0] || "";
  return safeText(tag.match(/content=["']([^"']*)["']/i)?.[1] || "");
}

function extractGuidePageContent(html) {
  const raw = String(html || "").match(/<div[^>]+class=["'][^"']*entry-content[^"']*["'][^>]*>([\s\S]*?)<\/div>/i)?.[1] || "";
  const withHeadings = raw
    .replace(/<p>\s*##\s*([^<]+)<br\s*\/?>/gi, "<h2>$1</h2><p>")
    .replace(/\*\*([^*]+)\*\*/g, "<strong>$1</strong>");
  return sanitizeWordPressHtml(withHeadings);
}

function formatArabicDate(value) {
  const date = new Date(value);
  return Number.isNaN(date.getTime())
    ? ""
    : new Intl.DateTimeFormat("ar-EG", { year: "numeric", month: "long", day: "numeric" }).format(date);
}

function estimateReadTime(html) {
  const words = safeText(html).split(/\s+/).filter(Boolean).length;
  return `${Math.max(1, Math.ceil(words / 180))} دقائق`;
}

function mapPost(item, categoriesById) {
  const contentHtml = sanitizeWordPressHtml(item?.content?.rendered || item?.chinaplanet_headless?.content || "");
  const excerpt = stripMarkdownArtifacts(safeText(item?.excerpt?.rendered || item?.chinaplanet_headless?.excerpt || contentHtml)).slice(0, 320);
  const category = (Array.isArray(item?.categories) ? item.categories : [])
    .map((id) => categoriesById.get(Number(id)))
    .find(Boolean);
  const slug = decodeURIComponent(String(item?.slug || item?.id || ""));

  return {
    id: `wp-${item.id}`,
    wordpressId: item.id,
    slug,
    title: safeText(item?.title?.rendered).slice(0, 240),
    category: category?.name || "مقالات الاستيراد من الصين",
    categorySlug: category?.slug || "",
    author: safeText(item?._embedded?.author?.[0]?.name || "فريق كوكب الصين").slice(0, 120),
    date: formatArabicDate(item?.date),
    publishedAt: item?.date || "",
    modifiedAt: item?.modified || "",
    readTime: estimateReadTime(contentHtml),
    image: embeddedImage(item),
    excerpt,
    metaDescription: excerpt,
    contentHtml,
    source: "wordpress",
  };
}

function mapTaxonomy(rows) {
  return (Array.isArray(rows) ? rows : []).map((term) => ({
    id: Number(term?.id),
    slug: String(term?.slug || ""),
    name: safeText(term?.name).slice(0, 160),
    count: Math.max(Number(term?.count || 0), 0),
    imageId: Math.max(Number(term?.meta?.kcg_city_image_id || term?.kcg_city_image?.id || 0), 0),
    image: publicImageUrl(term?.kcg_city_image?.source_url || term?.kcg_city_image?.url),
  })).filter((term) => Number.isFinite(term.id) && term.name);
}

export async function fetchWordPressPosts({ env = process.env, fetchImpl = fetch } = {}) {
  const config = getRuntimeConfig(env);
  if (!config.wordpressBaseUrl) throw contentError("WordPress is not configured", "wordpress_not_configured", 503);

  const categoriesUrl = new URL("/wp-json/wp/v2/categories", config.wordpressBaseUrl);
  categoriesUrl.searchParams.set("per_page", "100");
  categoriesUrl.searchParams.set("_fields", "id,slug,name,count");
  const allCategories = mapTaxonomy(await getJson(categoriesUrl, fetchImpl));
  const allowed = new Set(config.wordpressPostCategoryAllowlist.map((value) => value.toLowerCase()));
  const categories = allCategories.filter((category) => allowed.has(category.slug.toLowerCase()) || allowed.has(String(category.id)));
  if (!categories.length) throw contentError("No approved WordPress post categories were found", "wordpress_categories_not_configured", 503);

  const rawPosts = await fetchPages(config.wordpressBaseUrl, "posts", config.wordpressContentMaxPages, fetchImpl, {
    status: "publish",
    categories: categories.map((category) => category.id).join(","),
    _embed: "1",
  });
  const categoriesById = new Map(categories.map((category) => [category.id, category]));
  const posts = rawPosts.map((item) => mapPost(item, categoriesById)).filter((post) => post.title && post.excerpt);
  return { posts, categories: categories.map((category) => category.name), source: "wordpress" };
}

export async function fetchChinaGuide({ env = process.env, fetchImpl = fetch } = {}) {
  const config = getRuntimeConfig(env);
  if (!config.wordpressBaseUrl) throw contentError("WordPress is not configured", "wordpress_not_configured", 503);

  const [rawPlaces, rawCities, rawTypes, rawTags] = await Promise.all([
    fetchPages(config.wordpressBaseUrl, "china_guide", config.wordpressContentMaxPages, fetchImpl, {
      status: "publish",
      _fields: [
        "id", "slug", "title", "modified", "link", "china_city", "place_type", "place_tag", "meta",
        "chinaplanet_headless.excerpt", "chinaplanet_headless.featuredImage", "chinaplanet_headless.publicMeta",
      ].join(","),
    }),
    fetchPages(config.wordpressBaseUrl, "china_city", 2, fetchImpl, { hide_empty: "false" }),
    fetchPages(config.wordpressBaseUrl, "place_type", 2, fetchImpl, { hide_empty: "false" }),
    fetchPages(config.wordpressBaseUrl, "place_tag", 3, fetchImpl, { hide_empty: "false" }),
  ]);

  const cities = mapTaxonomy(rawCities);
  const types = mapTaxonomy(rawTypes);
  const tags = mapTaxonomy(rawTags);
  const cityMap = new Map(cities.map((term) => [term.id, term]));
  const typeMap = new Map(types.map((term) => [term.id, term]));
  const tagMap = new Map(tags.map((term) => [term.id, term]));
  const [mediaByPostId, cityMediaById] = await Promise.all([
    fetchGuideMedia(rawPlaces, config, fetchImpl),
    fetchMediaByIds(cities.map((city) => city.imageId), config, fetchImpl),
  ]);
  let places = rawPlaces.map((item) => {
    const bridge = item?.chinaplanet_headless || {};
    const publicMeta = bridge.publicMeta && typeof bridge.publicMeta === "object" ? bridge.publicMeta : {};
    const guideMeta = item?.meta && typeof item.meta === "object" ? item.meta : {};
    const placeDescription = safeText(guideMeta._place_desc || "").slice(0, 1_200);
    const contentHtml = sanitizeWordPressHtml(placeDescription
      ? plainTextHtml(placeDescription)
      : (bridge.content || item?.content?.rendered || ""));
    const addressEn = safeText(guideMeta._address_en || "").slice(0, 300);
    const addressZh = safeText(guideMeta._address_zh || "").slice(0, 300);
    const mapUrlCandidate = publicMeta.map_url || publicMeta.google_maps_url || guideMeta._map_url;
    const city = cityMap.get(Number(item?.china_city?.[0]));
    const type = typeMap.get(Number(item?.place_type?.[0]));
    return {
      id: `guide-${item.id}`,
      wordpressId: item.id,
      slug: decodeURIComponent(String(item?.slug || item?.id || "")),
      title: safeText(item?.title?.rendered).slice(0, 240),
      cityId: city?.id || null,
      city: city?.name || "",
      typeId: type?.id || null,
      type: type?.name || "",
      tags: (Array.isArray(item?.place_tag) ? item.place_tag : []).map((id) => tagMap.get(Number(id))?.name).filter(Boolean),
      excerpt: safeText(placeDescription || bridge.excerpt || contentHtml).slice(0, 320),
      contentHtml,
      image: guidePrimaryImage(item) || mediaByPostId.get(Number(item?.id)) || "",
      address: safeText(publicMeta.address_ar || publicMeta.address || addressEn || addressZh).slice(0, 300),
      addressEn,
      addressZh,
      phone: safeText(publicMeta.phone || guideMeta._phone_number || "").slice(0, 80),
      website: typeof publicMeta.website === "string" && /^https:\/\//i.test(publicMeta.website) ? publicMeta.website : "",
      mapUrl: typeof mapUrlCandidate === "string" && /^https:\/\//i.test(mapUrlCandidate) ? mapUrlCandidate : "",
      sourceUrl: typeof item?.link === "string" && /^https:\/\//i.test(item.link) ? item.link : "",
      modifiedAt: item?.modified || "",
      source: "wordpress",
    };
  }).filter((place) => place.title);

  const cityImages = new Map();
  places.forEach((place) => {
    if (place.cityId && place.image && !cityImages.has(place.cityId)) cityImages.set(place.cityId, place.image);
  });
  const citiesWithImages = cities.map((city) => ({
    ...city,
    nameAr: CITY_CONTENT[city.slug]?.nameAr || city.name,
    description: CITY_CONTENT[city.slug]?.description || "دليل الأسواق والخدمات المهمة في المدينة.",
    image: city.image || cityMediaById.get(city.imageId) || cityImages.get(city.id) || CITY_CONTENT[city.slug]?.fallbackImage || DEFAULT_IMAGE,
  }));
  const cityImageById = new Map(citiesWithImages.map((city) => [city.id, city.image]));
  places = places.map((place) => ({ ...place, image: place.image || cityImageById.get(place.cityId) || DEFAULT_IMAGE }));

  return { places, cities: citiesWithImages, types, source: "wordpress", detailsAvailable: true };
}

export async function fetchChinaGuidePlaceDetail(place, { env = process.env, fetchImpl = fetch } = {}) {
  const config = getRuntimeConfig(env);
  if (!place?.sourceUrl) throw contentError("Guide place was not found", "guide_place_not_found", 404);
  const sourceUrl = new URL(place.sourceUrl);
  if (!config.wordpressBaseUrl || sourceUrl.origin !== new URL(config.wordpressBaseUrl).origin) {
    throw contentError("Guide source is not trusted", "guide_source_not_allowed", 400);
  }
  const html = await getHtml(sourceUrl, fetchImpl);
  const renderedContentHtml = extractGuidePageContent(html);
  const contentHtml = place.contentHtml || renderedContentHtml || "";
  const metaDescription = extractMetaContent(html, "description") || extractMetaContent(html, "og:description");
  const ogImage = extractMetaContent(html, "og:image");
  const publishedImage = publicImageUrl(place.image);
  const address = safeText(place.address || contentHtml.match(/:\s*<\/strong>\s*([^<]+)/i)?.[1] || "").slice(0, 300);
  const mapUrl = place.mapUrl || contentHtml.match(/https:\/\/(?:www\.)?google\.com\/maps[^\s<"]+/i)?.[0] || "";
  return {
    ...place,
    // The headless guide payload is the current CMS source of truth. The
    // rendered WordPress page can retain an older social image in its cache.
    image: publishedImage || publicImageUrl(ogImage) || place.image,
    excerpt: place.excerpt || metaDescription,
    metaDescription: place.excerpt || metaDescription,
    contentHtml,
    address,
    mapUrl,
    detailsAvailable: Boolean(contentHtml),
  };
}

export function verifyWordPressContentWebhook(body, signature, secret) {
  if (!body || !signature || !secret) return false;
  const expected = createHmac("sha256", secret).update(body).digest("base64");
  const expectedBuffer = Buffer.from(expected);
  const actualBuffer = Buffer.from(String(signature).trim());
  return expectedBuffer.length === actualBuffer.length && timingSafeEqual(expectedBuffer, actualBuffer);
}
