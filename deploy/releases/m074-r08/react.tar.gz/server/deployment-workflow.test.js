import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import test from "node:test";

const workflowUrl = new URL("../.github/workflows/deploy-production.yml", import.meta.url);
const stagingWorkflowUrl = new URL("../.github/workflows/deploy-staging.yml", import.meta.url);
const productionStackUrl = new URL("../compose.production.yaml", import.meta.url);
const stagingStackUrl = new URL("../compose.vps.yaml", import.meta.url);

test("production promotion resolves the exact current staging SHA without manual copying", async () => {
  const workflow = await readFile(workflowUrl, "utf8");

  assert.doesNotMatch(workflow, /^\s+commit_sha:/m);
  assert.match(workflow, /confirmation:/);
  assert.match(workflow, /https:\/\/new\.chinaplanet\.org\/api\/health/);
  assert.match(workflow, /approved_sha: \$\{\{ steps\.release\.outputs\.approved_sha \}\}/);
  assert.match(workflow, /git ls-remote origin refs\/heads\/main/);
  assert.match(workflow, /if \[\[ "\$APPROVED_SHA" != "\$main_sha" \]\]/);
  assert.match(workflow, /Verify the approved commit is active on staging/);
  assert.match(workflow, /IMAGE_TAG: \$\{\{ needs\.authorize-production\.outputs\.approved_sha \}\}/);
});

test("the immutable website image receives the approved public GA4 measurement ID", async () => {
  const workflow = await readFile(stagingWorkflowUrl, "utf8");
  assert.match(workflow, /VITE_GA_MEASUREMENT_ID=G-PEKLM9QLB5/);
});

test("Search Console verification is published only by the canonical production stack", async () => {
  const [productionStack, stagingStack] = await Promise.all([
    readFile(productionStackUrl, "utf8"),
    readFile(stagingStackUrl, "utf8"),
  ]);
  assert.match(productionStack, /GOOGLE_SITE_VERIFICATION: tyxjkIpuD2N-wgjM3MlWrDE47VH7Xgumcrno_mLfLhU/);
  assert.doesNotMatch(stagingStack, /GOOGLE_SITE_VERIFICATION/);
});
