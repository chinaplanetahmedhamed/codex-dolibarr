import { mkdir, readFile, rename, writeFile } from "node:fs/promises";
import path from "node:path";
import { randomBytes } from "node:crypto";
import { getRuntimeConfig } from "./config.js";

const ALLOWED_KEYS = new Set([
  "siteInfo",
  "teamMembers",
  "customSections",
  "heroInfo",
  "sectorsInfo",
  "servicesData",
  "blogPosts",
  "blogCategories",
]);
const BLOCKED_KEYS = new Set(["__proto__", "prototype", "constructor"]);

function sanitizeValue(value, depth = 0) {
  if (depth > 8) return null;
  if (typeof value === "string") {
    return Array.from(value, (character) => {
      const code = character.charCodeAt(0);
      return code < 32 && ![9, 10, 13].includes(code) ? " " : character;
    }).join("").slice(0, 20_000);
  }
  if (typeof value === "number") return Number.isFinite(value) ? value : null;
  if (typeof value === "boolean" || value === null) return value;
  if (Array.isArray(value)) return value.slice(0, 250).map((entry) => sanitizeValue(entry, depth + 1));
  if (value && typeof value === "object") {
    return Object.fromEntries(Object.entries(value)
      .filter(([key]) => !BLOCKED_KEYS.has(key))
      .slice(0, 100)
      .map(([key, entry]) => [key.slice(0, 120), sanitizeValue(entry, depth + 1)]));
  }
  return null;
}

export function sanitizeSiteContent(input) {
  if (!input || typeof input !== "object" || Array.isArray(input)) {
    throw Object.assign(new Error("Site content must be an object"), { status: 422, code: "invalid_content" });
  }
  const content = Object.fromEntries(Object.entries(input)
    .filter(([key]) => ALLOWED_KEYS.has(key))
    .map(([key, value]) => [key, sanitizeValue(value)]));
  const serialized = JSON.stringify(content);
  if (serialized.length > 450_000) {
    throw Object.assign(new Error("Site content is too large"), { status: 413, code: "content_too_large" });
  }
  return content;
}

function contentPath(env) {
  const configured = getRuntimeConfig(env).contentStorePath;
  return path.resolve(configured || path.join(process.cwd(), "data/site-content.json"));
}

export async function readSiteContent(env = process.env) {
  try {
    const stored = JSON.parse(await readFile(contentPath(env), "utf8"));
    return {
      content: sanitizeSiteContent(stored.content || {}),
      updatedAt: stored.updatedAt || null,
      revision: Number.isInteger(stored.revision) ? stored.revision : 0,
    };
  } catch (error) {
    if (error.code === "ENOENT") return { content: null, updatedAt: null, revision: 0 };
    throw Object.assign(new Error("Unable to read site content"), { status: 500, code: "content_read_failed" });
  }
}

export async function writeSiteContent(input, user, env = process.env) {
  const content = sanitizeSiteContent(input);
  const previous = await readSiteContent(env);
  const record = {
    revision: previous.revision + 1,
    updatedAt: new Date().toISOString(),
    updatedBy: user.email,
    content,
  };
  const target = contentPath(env);
  await mkdir(path.dirname(target), { recursive: true });
  const temporary = `${target}.${randomBytes(6).toString("hex")}.tmp`;
  await writeFile(temporary, `${JSON.stringify(record, null, 2)}\n`, { encoding: "utf8", mode: 0o600 });
  await rename(temporary, target);
  return { content, updatedAt: record.updatedAt, revision: record.revision };
}
