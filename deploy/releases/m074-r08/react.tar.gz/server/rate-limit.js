import { mkdirSync, readFileSync, renameSync, writeFileSync } from "node:fs";
import { dirname } from "node:path";

const stores = new Map();

function loadStore(storePath) {
  const key = storePath || "__memory__";
  if (stores.has(key)) return stores.get(key);
  let value = { version: 1, buckets: {} };
  if (storePath) {
    try {
      const parsed = JSON.parse(readFileSync(storePath, "utf8"));
      if (parsed?.version === 1 && parsed.buckets && typeof parsed.buckets === "object") value = parsed;
    } catch (error) {
      if (error?.code !== "ENOENT") throw error;
    }
  }
  stores.set(key, value);
  return value;
}

function persistStore(storePath, store) {
  if (!storePath) return;
  mkdirSync(dirname(storePath), { recursive: true });
  const temporaryPath = `${storePath}.${process.pid}.tmp`;
  writeFileSync(temporaryPath, JSON.stringify(store), { encoding: "utf8", mode: 0o600 });
  renameSync(temporaryPath, storePath);
}

export function consumeRateLimit({ storePath = "", bucket, clientKey, limit, now = Date.now(), windowMs = 15 * 60_000 }) {
  try {
    const store = loadStore(storePath);
    const entries = store.buckets[bucket] || (store.buckets[bucket] = {});
    const current = entries[clientKey];
    if (!current || current.resetAt <= now) entries[clientKey] = { count: 1, resetAt: now + windowMs };
    else current.count += 1;

    const keys = Object.keys(entries);
    if (keys.length >= 5_000) {
      for (const key of keys) {
        if (entries[key].resetAt <= now || Object.keys(entries).length >= 4_500) delete entries[key];
      }
    }
    persistStore(storePath, store);
    const active = entries[clientKey];
    return active.count > limit ? Math.max(1, Math.ceil((active.resetAt - now) / 1_000)) : 0;
  } catch {
    return Math.max(1, Math.ceil(windowMs / 1_000));
  }
}

export function resetRateLimitStoresForTests() {
  stores.clear();
}
