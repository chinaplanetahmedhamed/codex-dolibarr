import test from "node:test";
import assert from "node:assert/strict";
import { deliverLead, validateLeadPayload } from "./leads.js";

const validQuote = {
  type: "quote_request",
  clientName: "Ahmed Customer",
  phone: "+201001234567",
  email: "customer@example.com",
  country: "مصر",
  productName: "آلة تعبئة",
  consent: true,
};

test("validateLeadPayload rejects honeypot and incomplete requests", () => {
  assert.throws(() => validateLeadPayload({ ...validQuote, website: "spam.example" }), /rejected/);
  assert.throws(() => validateLeadPayload({ ...validQuote, phone: "12" }), /phone/);
  assert.throws(() => validateLeadPayload({ ...validQuote, productName: "" }), /Product/);
  assert.throws(() => validateLeadPayload({ ...validQuote, consent: false }), /Consent/);
});

test("validateLeadPayload keeps WooCommerce variation and carton details", () => {
  const lead = validateLeadPayload({
    type: "catalog_order",
    clientName: "Ahmed Customer",
    phone: "+201001234567",
    email: "customer@example.com",
    consent: true,
    items: [{
      id: "wc-108151:108154",
      wooProductId: 108151,
      wooVariationId: 108154,
      sku: "WP-E1003",
      title: "FEMALE THREADED COUPLING",
      selectedOptionLabel: "20*3/4",
      quantity: "2 كرتونة",
      cartons: 2,
      pcsPerCarton: 560,
    }],
  });

  assert.equal(lead.items[0].wooVariationId, 108154);
  assert.equal(lead.items[0].selectedOptionLabel, "20*3/4");
  assert.equal(lead.items[0].cartons, 2);
  assert.equal(lead.items[0].piecesPerCarton, 560);
});

test("deliverLead reports success only after Dolibarr accepts the intake record", async () => {
  let deliveredPayload;
  const fetchImpl = async (_url, options) => {
    deliveredPayload = JSON.parse(options.body);
    return { ok: true, status: 201, headers: new Headers(), text: async () => JSON.stringify({ request_ref: "WEB-20260805-ABC123", status: "new", duplicate: false }) };
  };

  const result = await deliverLead(validQuote, {
    env: {
      DOLIBARR_API_BASE_URL: "https://erp.example.com/api/index.php/",
      DOLIBARR_ALLOWED_HOST: "erp.example.com",
      DOLIBARR_API_KEY: "dedicated-api-key-at-least-twenty-characters",
    },
    fetchImpl,
    idempotencyKey: "test-idempotency-key",
  });

  assert.equal(result.reference, "WEB-20260805-ABC123");
  assert.equal(deliveredPayload.idempotency_key, "test-idempotency-key");
  assert.equal(deliveredPayload.details.product_summary, "آلة تعبئة");
  assert.equal(deliveredPayload.request_type, "quote_request");
});

test("deliverLead fails closed when delivery is not configured", async () => {
  await assert.rejects(() => deliverLead(validQuote, { env: {} }), (error) => {
    assert.equal(error.code, "dolibarr_not_configured");
    assert.equal(error.status, 503);
    return true;
  });

  await assert.rejects(() => deliverLead(validQuote, {
    env: { DOLIBARR_API_BASE_URL: "https://erp.example.com/api/index.php/" },
  }), (error) => {
    assert.equal(error.code, "dolibarr_not_configured");
    return true;
  });
});
