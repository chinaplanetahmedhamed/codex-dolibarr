import test from "node:test";
import assert from "node:assert/strict";
import { createHmac } from "node:crypto";
import { readFile } from "node:fs/promises";
import { calculateB2bPlan, createB2bRequest, fetchB2bCatalog, __test } from "./b2b.js";

const env = { WORDPRESS_BASE_URL: "https://wordpress.example.com", B2B_API_SECRET: "12345678901234567890123456789012", DOLIBARR_API_BASE_URL: "https://erp.example.com/api/index.php/", DOLIBARR_ALLOWED_HOST: "erp.example.com", DOLIBARR_API_KEY: "dedicated-api-key-at-least-twenty-characters" };
const response = (payload, status = 200) => ({ ok: status >= 200 && status < 300, status, json: async () => payload });
const completeLine = (overrides = {}) => ({
  lineId: "line-complete-001", source: "woocommerce", productId: 10, variationId: 0, cartons: 2, sku: "CP-10", name: "Pump", optionLabel: "Large", image: "https://wordpress.example.com/pump.jpg",
  unitsPerCarton: 12, cbmPerCarton: 0.08, grossWeightKg: 10, packingComplete: true, packingSource: "woocommerce_product", calculationReady: true, missingFields: [],
  price: { visibility: "public", mode: "fixed", unit: "piece", currency: "USD", unitPrice: 99, minUnitPrice: null, maxUnitPrice: null }, ...overrides,
});
const incompleteLine = (overrides = {}) => ({
  lineId: "line-incomplete-001", source: "woocommerce", productId: 11, variationId: 0, cartons: 1, sku: "CP-11", name: "Valve", optionLabel: "", image: "", unitsPerCarton: null, cbmPerCarton: null,
  grossWeightKg: null, packingComplete: false, packingSource: "woocommerce_product", calculationReady: false, missingFields: ["unitsPerCarton", "cbmPerCarton", "grossWeightKg", "packingComplete"],
  price: { visibility: "request_quote", mode: "request", unit: "piece", currency: null, unitPrice: null, minUnitPrice: null, maxUnitPrice: null }, ...overrides,
});

test("B2B catalog proxy sends bounded public filters", async () => {
  let requestedUrl = "";
  const result = await fetchB2bCatalog({ query: { page: "2", perPage: "500", search: "pump", category: "tools" }, env, fetchImpl: async (url) => { requestedUrl = String(url); return response({ ok: true, products: [] }); } });
  const url = new URL(requestedUrl);
  assert.equal(url.pathname, "/wp-json/chinaplanet-b2b/v1/catalog");
  assert.equal(url.searchParams.get("per_page"), "48");
  assert.equal(result.ok, true);
});

test("plan preserves request-unique lineId and strips browser packing and price claims", async () => {
  let captured;
  const result = await calculateB2bPlan({ container: "40hq", lines: [{ lineId: "line-complete-001", productId: 10, variationId: 0, cartons: 2, price: 0.01, cbm: 999 }] }, { env, fetchImpl: async (_url, options) => { captured = options; return response({ ok: true, plan: { totals: { cartons: 2 }, calculationReadyLines: 1 }, lines: [completeLine()] }); } });
  const body = JSON.parse(captured.body);
  assert.deepEqual(body, { request_type: "catalog_order", schema_version: 2, container: "40hq", lines: [{ lineId: "line-complete-001", productId: 10, variationId: 0, cartons: 2 }] });
  const timestamp = captured.headers["X-ChinaPlanet-Timestamp"];
  assert.equal(captured.headers["X-ChinaPlanet-Signature"], `sha256=${createHmac("sha256", env.B2B_API_SECRET).update(`${timestamp}.${captured.body}`).digest("hex")}`);
  assert.equal(result.lines[0].lineId, "line-complete-001");
});

test("duplicate product rows remain separate while duplicate lineIds fail", async () => {
  const fetchImpl = async () => response({ ok: true, plan: {}, lines: [completeLine(), completeLine({ lineId: "line-complete-002" })] });
  const result = await calculateB2bPlan({ lines: [{ lineId: "line-complete-001", productId: 10, cartons: 2 }, { lineId: "line-complete-002", productId: 10, cartons: 2 }] }, { env, fetchImpl });
  assert.deepEqual(result.lines.map((line) => line.lineId), ["line-complete-001", "line-complete-002"]);
  await assert.rejects(calculateB2bPlan({ lines: [{ lineId: "same-line-001", productId: 10, cartons: 1 }, { lineId: "same-line-001", productId: 10, cartons: 1 }] }, { env, fetchImpl }), (error) => error.code === "invalid_b2b_line");
});

test("mixed plan keeps incomplete rows and never turns unknown packing into zero", async () => {
  const result = await calculateB2bPlan({ lines: [{ lineId: "line-complete-001", productId: 10, cartons: 2 }, { lineId: "line-incomplete-001", productId: 11, cartons: 1 }] }, { env, fetchImpl: async () => response({ ok: true, plan: { calculationReadyLines: 1 }, lines: [completeLine(), incompleteLine()] }) });
  assert.equal(result.lines.length, 2);
  assert.equal(result.lines[1].calculationReady, false);
  assert.equal(result.lines[1].unitsPerCarton, null);
  assert.equal(result.lines[1].totalCbm, null);
});

test("request requires ISO country, consent, and a stable acceptance timestamp", async () => {
  await assert.rejects(createB2bRequest({ lines: [{ lineId: "line-complete-001", productId: 10, cartons: 1 }], customer: { name: "Ahmed", phone: "123456", email: "a@example.com", country: "Egypt", consent: true, consentAcceptedAt: new Date().toISOString() } }, { env, fetchImpl: async () => response({}) }), (error) => error.code === "invalid_b2b_country");
  await assert.rejects(createB2bRequest({ lines: [{ lineId: "line-complete-001", productId: 10, cartons: 1 }], customer: { name: "Ahmed", phone: "123456", email: "a@example.com", country: "ZZ", consent: true, consentAcceptedAt: new Date().toISOString() } }, { env, fetchImpl: async () => response({}) }), (error) => error.code === "invalid_b2b_country");
  await assert.rejects(createB2bRequest({ lines: [{ lineId: "line-complete-001", productId: 10, cartons: 1 }], customer: { name: "Ahmed", phone: "123456", email: "a@example.com", country: "EG", consent: false } }, { env, fetchImpl: async () => response({}) }), (error) => error.code === "invalid_b2b_customer");
});

test("line identifiers and packing integers reject partial or fractional numbers", () => {
  assert.throws(() => __test.normalizeLines([{ lineId: "line-bad-number-001", productId: "2x", cartons: 1 }]), (error) => error.code === "invalid_b2b_line");
  assert.throws(() => __test.normalizeLines([{ lineId: "line-bad-number-002", productId: 2, cartons: 1.5 }]), (error) => error.code === "invalid_b2b_line");
  const fractional = completeLine({ unitsPerCarton: 12.5 });
  assert.throws(() => __test.normalizeAuthoritativeLines({ lines: [fractional] }, [{ lineId: fractional.lineId, productId: fractional.productId, variationId: 0, cartons: fractional.cartons }]), (error) => error.code === "invalid_b2b_snapshot");
});

test("WordPress calls deny redirects and reject a changed final origin", async () => {
  let options;
  await assert.rejects(fetchB2bCatalog({ env, fetchImpl: async (_url, requestOptions) => {
    options = requestOptions;
    return { ...response({ ok: true, products: [] }), url: "https://attacker.example/catalog" };
  } }), (error) => error.code === "b2b_upstream_origin");
  assert.equal(options.redirect, "error");
});

test("request sends one frozen cpo.catalog-order.v2 contract to Dolibarr and never calls WordPress request", async () => {
  const calls = []; const acceptedAt = "2026-09-01T00:00:00.000Z";
  const result = await createB2bRequest({ lines: [{ lineId: "line-complete-001", productId: 10, cartons: 2 }, { lineId: "line-incomplete-001", productId: 11, cartons: 1 }], container: "40hq", locale: "ar", customer: { name: "Ahmed", phone: "+201001234567", email: "a@example.com", country: "EG", consent: true, consentAcceptedAt: acceptedAt } }, {
    env, idempotencyKey: "b2b-request-key-123456", fetchImpl: async (url, options) => {
      const body = options?.body ? JSON.parse(options.body) : null; calls.push({ url: String(url), body });
      if (String(url).includes("/catalog")) return response({ products: [{ id: 10, sku: "CP-10", name: "Pump", images: ["https://wordpress.example.com/pump-live.jpg"], variations: [] }, { id: 11, sku: "CP-11", name: "Valve", images: [], variations: [] }] });
      if (String(url).includes("wordpress.example.com")) return response({ ok: true, currency: "USD", plan: { placements: [{ line_key: "line-complete-001", carton_index: 1, x: 1, y: 2, z: 3, length: 50, width: 40, height: 30 }] }, lines: [completeLine(), incompleteLine()] });
      return { ok: true, status: 201, headers: new Headers(), text: async () => JSON.stringify({ request_ref: "WEB-B2B-1", status: "new", duplicate: false }) };
    },
  });
  assert.equal(calls.some((call) => call.url.includes("wordpress.example.com") && call.url.includes("/request")), false);
  const delivery = calls.at(-1).body;
  assert.equal(delivery.schema_version, 2);
  assert.equal(delivery.request_type, "catalog_order");
  assert.equal(delivery.consent.accepted_at, acceptedAt);
  assert.deepEqual(delivery.details.lines.map((line) => line.lineId), ["line-complete-001", "line-incomplete-001"]);
  assert.equal(delivery.details.lines[1].unitsPerCarton, null);
  assert.equal(delivery.details.lines[1].price.unitPrice, null);
  assert.equal(delivery.details.packing_plan.requestCartons, 3);
  assert.equal(delivery.details.packing_plan.calculatedCartons, 2);
  assert.deepEqual(delivery.details.packing_plan.excludedItems[0].missingFields, incompleteLine().missingFields);
  assert.equal("snapshot" in delivery, false);
  assert.equal(result.request_ref, "WEB-B2B-1");
});

test("mismatched authoritative lineId fails closed", async () => {
  await assert.rejects(calculateB2bPlan({ lines: [{ lineId: "line-complete-001", productId: 10, cartons: 1 }] }, { env, fetchImpl: async () => response({ lines: [completeLine({ lineId: "other-line-001", cartons: 1 })] }) }), (error) => error.code === "invalid_b2b_snapshot" && error.status === 502);
});

test("shared cpo.catalog-order.v2 fixture preserves duplicate products and nullable packing", async () => {
  const fixture = JSON.parse(await readFile(new URL("./cpo_catalog_order_v2.fixture.json", import.meta.url), "utf8"));
  assert.equal(fixture.request_type, "catalog_order");
  assert.equal(fixture.schema_version, 2);
  assert.equal(new Set(fixture.details.lines.map((line) => line.lineId)).size, 2);
  assert.equal(new Set(fixture.details.lines.map((line) => line.productId)).size, 1);
  const requested = fixture.details.lines.map(({ lineId, productId, variationId, cartons }) => ({ lineId, productId, variationId, cartons }));
  const normalized = __test.normalizeAuthoritativeLines({ lines: fixture.details.lines }, requested);
  assert.equal(normalized[0].calculationReady, true);
  assert.equal(normalized[1].calculationReady, false);
  assert.equal(normalized[1].unitsPerCarton, null);
  assert.deepEqual(fixture.details.packing_plan.excludedItems[0].missingFields, normalized[1].missingFields);
});

test("shared invalid fixture freezes cross-system fail-closed cases", async () => {
  const fixture = JSON.parse(await readFile(new URL("./cpo_catalog_order_v2.invalid.fixture.json", import.meta.url), "utf8"));
  assert.equal(fixture.contract, "cpo.catalog-order.v2");
  assert.deepEqual(fixture.cases.map((item) => item.name), ["fractional_units_per_carton", "incomplete_line_placement", "unknown_iso_country"]);
  assert.equal(fixture.cases.every((item) => item.expected === "reject"), true);
});

test("authoritative calculationReady mismatch fails closed", () => {
  const line = completeLine({ calculationReady: false });
  assert.throws(() => __test.normalizeAuthoritativeLines({ lines: [line] }, [{ lineId: line.lineId, productId: line.productId, variationId: 0, cartons: line.cartons }]), (error) => error.code === "invalid_b2b_snapshot");
});

test("public plan projection strips internal and malformed placement fields", () => {
  const line = __test.normalizeAuthoritativeLines({ lines: [completeLine()] }, [{ lineId: "line-complete-001", productId: 10, variationId: 0, cartons: 2 }])[0];
  const incomplete = __test.normalizeAuthoritativeLines({ lines: [incompleteLine()] }, [{ lineId: "line-incomplete-001", productId: 11, variationId: 0, cartons: 1 }])[0];
  const projected = __test.publicPlanProjection({
    ok: true, internal_id: 99, supplier_cost: 1,
    container: { id: "40hq", label: "40HQ", length: 1200, width: 235, height: 269, internal_secret: "no" },
    placements: [
      { line_key: line.lineId, x: 0, y: 1, z: 2, length: 50, width: 40, height: 30, supplier_id: 3 },
      { line_key: incomplete.lineId, x: 0, y: 0, z: 0, length: 1, width: 1, height: 1 },
      { line_key: "foreign-line", x: 0, y: 0, z: 0, length: 1, width: 1, height: 1 },
    ],
    totals: { cartons: 2, cbm: 0.16, gross_weight: 20, private_margin: 50 },
    calculationReadyLines: 1,
  }, [line, incomplete]);
  assert.equal(projected.placements.length, 1);
  assert.equal("supplier_id" in projected.placements[0], false);
  assert.equal("internal_secret" in projected.container, false);
  assert.equal("private_margin" in projected.totals, false);
  assert.equal("internal_id" in projected, false);
  assert.deepEqual(projected.excludedItems.map((item) => item.lineId), [incomplete.lineId]);
});

test("hidden price values and ERP delivery failures fail closed", async () => {
  const leaked = incompleteLine({ price: { visibility: "login_required", mode: "request", unit: "piece", currency: "USD", unitPrice: 1, minUnitPrice: null, maxUnitPrice: null } });
  await assert.rejects(calculateB2bPlan({ lines: [{ lineId: leaked.lineId, productId: leaked.productId, cartons: 1 }] }, { env, fetchImpl: async () => response({ lines: [leaked] }) }), (error) => error.code === "invalid_b2b_snapshot");

  const calls = [];
  await assert.rejects(createB2bRequest({ lines: [{ lineId: "line-complete-001", productId: 10, cartons: 2 }], customer: { name: "Ahmed", phone: "+201001234567", email: "a@example.com", country: "EG", consent: true, consentAcceptedAt: new Date().toISOString() } }, {
    env, idempotencyKey: "b2b-erp-failure-123456", fetchImpl: async (url) => {
      calls.push(String(url));
      if (String(url).includes("/catalog")) return response({ products: [] });
      if (String(url).includes("wordpress.example.com")) return response({ ok: true, plan: {}, lines: [completeLine()] });
      return { ok: false, status: 503, headers: new Headers(), text: async () => JSON.stringify({ message: "unavailable" }) };
    },
  }), (error) => error.status === 502 || error.status === 503);
  assert.equal(calls.some((url) => url.includes("wordpress.example.com") && url.includes("/request")), false);
});
