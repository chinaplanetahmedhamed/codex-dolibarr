import { mkdir, writeFile } from "node:fs/promises";
import path from "node:path";
import { randomBytes } from "node:crypto";
import { getRuntimeConfig } from "./config.js";

const MIME_EXTENSIONS = new Map([
  ["image/jpeg", "jpg"],
  ["image/png", "png"],
  ["image/webp", "webp"],
]);

function dataDirectory(env) {
  const configured = getRuntimeConfig(env).contentStorePath;
  return path.dirname(path.resolve(configured || path.join(process.cwd(), "data/site-content.json")));
}

function hasValidSignature(buffer, mimeType) {
  if (mimeType === "image/jpeg") return buffer[0] === 0xFF && buffer[1] === 0xD8 && buffer[2] === 0xFF;
  if (mimeType === "image/png") return buffer.subarray(0, 8).equals(Buffer.from([0x89, 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A]));
  if (mimeType === "image/webp") return buffer.subarray(0, 4).toString("ascii") === "RIFF" && buffer.subarray(8, 12).toString("ascii") === "WEBP";
  return false;
}

export async function writeWebsiteImage(input, env = process.env) {
  const mimeType = String(input?.mimeType || "").toLowerCase();
  const extension = MIME_EXTENSIONS.get(mimeType);
  if (!extension || typeof input?.data !== "string") {
    throw Object.assign(new Error("Unsupported image"), { status: 422, code: "unsupported_image" });
  }
  const buffer = Buffer.from(input.data, "base64");
  if (buffer.length < 16 || buffer.length > 5_000_000 || !hasValidSignature(buffer, mimeType)) {
    throw Object.assign(new Error("Invalid image"), { status: 422, code: "invalid_image" });
  }

  const filename = `${randomBytes(16).toString("hex")}.${extension}`;
  const directory = path.join(dataDirectory(env), "media");
  await mkdir(directory, { recursive: true });
  await writeFile(path.join(directory, filename), buffer, { mode: 0o600 });
  return { url: `/media/${filename}` };
}

export function resolveMediaPath(urlPath, env = process.env) {
  const match = String(urlPath).match(/^\/media\/([a-f0-9]{32}\.(?:jpg|png|webp))$/);
  return match ? path.join(dataDirectory(env), "media", match[1]) : null;
}
