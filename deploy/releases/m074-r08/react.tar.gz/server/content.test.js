import test from "node:test";
import assert from "node:assert/strict";
import { mkdtemp, rm } from "node:fs/promises";
import path from "node:path";
import os from "node:os";
import { readSiteContent, sanitizeSiteContent, writeSiteContent } from "./content.js";

test("site content keeps only CMS fields and persists atomically", async () => {
  const directory = await mkdtemp(path.join(os.tmpdir(), "cp-content-test-"));
  const env = { CONTENT_STORE_PATH: path.join(directory, "site-content.json") };
  try {
    const sanitized = sanitizeSiteContent({
      siteInfo: { siteNameAr: "كوكب الصين", constructor: "blocked" },
      servicesData: [{ id: "inspection", title: "فحص الجودة" }],
      internalOrders: [{ supplierCost: 100 }],
    });
    assert.equal(sanitized.internalOrders, undefined);
    assert.equal(Object.hasOwn(sanitized.siteInfo, "constructor"), false);

    const saved = await writeSiteContent(sanitized, { email: "admin@example.com" }, env);
    assert.equal(saved.revision, 1);
    const loaded = await readSiteContent(env);
    assert.equal(loaded.content.siteInfo.siteNameAr, "كوكب الصين");
    assert.equal(loaded.revision, 1);
  } finally {
    await rm(directory, { recursive: true, force: true });
  }
});
