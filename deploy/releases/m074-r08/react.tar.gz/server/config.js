import { CHINAPLANETOS_RELEASE } from '../release/chinaplanetos-release.js';

const RELEASE_ID_PATTERN = /^M\d{3}-R\d{2}$/;
const DEPLOY_SHA_PATTERN = /^[0-9a-f]{40}$/;

function normalizeUrl(value) {
  if (!value) return "";

  try {
    const url = new URL(value);
    if (url.protocol !== "https:" && url.hostname !== "127.0.0.1" && url.hostname !== "localhost") {
      return "";
    }
    return url.toString().replace(/\/$/, "");
  } catch {
    return "";
  }
}

function csvValues(value, fallback = "") {
  return String(value || fallback)
    .split(",")
    .map((entry) => entry.trim())
    .filter(Boolean);
}

function adminPasswordHash(env) {
  const encoded = String(env.ADMIN_PASSWORD_HASH_B64 || "").trim();
  if (encoded) {
    const decoded = Buffer.from(encoded, "base64").toString("utf8");
    if (decoded.startsWith("scrypt$")) return decoded;
  }
  return env.ADMIN_PASSWORD_HASH || "";
}

export function getRuntimeConfig(env = process.env) {
  const configuredReleaseId = String(env.RELEASE_ID || '').trim();
  const embeddedReleaseId = String(CHINAPLANETOS_RELEASE.releaseId || '').trim();
  const releaseId = RELEASE_ID_PATTERN.test(embeddedReleaseId) ? embeddedReleaseId : '';
  const configuredDeploySha = String(env.DEPLOY_SHA || '').trim();
  const deploySha = DEPLOY_SHA_PATTERN.test(configuredDeploySha) ? configuredDeploySha : '';
  const releaseMetadataValid = Boolean(releaseId)
    && Boolean(deploySha)
    && (!configuredReleaseId || configuredReleaseId === releaseId);
  return {
    nodeEnv: env.NODE_ENV || "development",
    releaseId,
    releaseMetadataValid,
    deploySha,
    port: Number.parseInt(env.PORT || "8080", 10),
    publicSiteOrigin: normalizeUrl(env.PUBLIC_SITE_ORIGIN),
    seoAllowIndexing: String(env.SEO_ALLOW_INDEXING || "").toLowerCase() === "true",
    googleSiteVerification: /^[A-Za-z0-9_-]{10,200}$/.test(String(env.GOOGLE_SITE_VERIFICATION || "").trim())
      ? String(env.GOOGLE_SITE_VERIFICATION).trim()
      : "",
    wordpressBaseUrl: normalizeUrl(env.WORDPRESS_BASE_URL),
    b2bApiSecret: env.B2B_API_SECRET || "",
    wooConsumerKey: env.WC_CONSUMER_KEY || "",
    wooConsumerSecret: env.WC_CONSUMER_SECRET || "",
    wooWebhookSecret: env.WC_WEBHOOK_SECRET || "",
    catalogMaxPages: Math.min(Math.max(Number.parseInt(env.CATALOG_MAX_PAGES || "20", 10), 1), 50),
    catalogCacheSeconds: Math.min(Math.max(Number.parseInt(env.CATALOG_CACHE_SECONDS || "300", 10), 30), 3600),
    wordpressContentMaxPages: Math.min(Math.max(Number.parseInt(env.WP_CONTENT_MAX_PAGES || "5", 10), 1), 20),
    wordpressContentCacheSeconds: Math.min(Math.max(Number.parseInt(env.WP_CONTENT_CACHE_SECONDS || "300", 10), 30), 3600),
    wordpressPostCategoryAllowlist: csvValues(
      env.WP_POST_CATEGORY_ALLOWLIST,
      "import-from-china-blog,before-importing-from-china,importing-from-china,shipping-and-customs,guangzhou-guide",
    ),
    wordpressContentWebhookSecret: env.WP_CONTENT_WEBHOOK_SECRET || "",
    dolibarrApiBaseUrl: normalizeUrl(env.DOLIBARR_API_BASE_URL),
    dolibarrApiKey: String(env.DOLIBARR_API_KEY || "").trim(),
    dolibarrAllowedHost: String(env.DOLIBARR_ALLOWED_HOST || "").trim().toLowerCase(),
    trustedProxyHops: Math.min(Math.max(Number.parseInt(env.TRUSTED_PROXY_HOPS || "0", 10), 0), 5),
    rateLimitStorePath: String(env.RATE_LIMIT_STORE_PATH || "").trim(),
    adminEmail: String(env.ADMIN_EMAIL || "").trim().toLowerCase(),
    adminPasswordHash: adminPasswordHash(env),
    adminSessionSecret: env.ADMIN_SESSION_SECRET || "",
    contentStorePath: env.CONTENT_STORE_PATH || "",
  };
}
