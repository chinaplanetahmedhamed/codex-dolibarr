import { createHmac, timingSafeEqual } from "node:crypto";

export function verifyWooWebhookSignature(rawBody, providedSignature, secret) {
  if (typeof rawBody !== "string" || !providedSignature || !secret) return false;

  const expected = createHmac("sha256", secret).update(rawBody, "utf8").digest("base64");
  const expectedBuffer = Buffer.from(expected, "utf8");
  const providedBuffer = Buffer.from(String(providedSignature).trim(), "utf8");
  return expectedBuffer.length === providedBuffer.length
    && timingSafeEqual(expectedBuffer, providedBuffer);
}

export function isWooWebhookPing(rawBody, headers = {}) {
  const header = (name) => {
    const key = Object.keys(headers).find((entry) => entry.toLowerCase() === name);
    return key ? String(headers[key]) : "";
  };
  const userAgent = header("user-agent");
  const signature = header("x-wc-webhook-signature");
  const topic = header("x-wc-webhook-topic");
  return !signature
    && !topic
    && /^WooCommerce\/[\w.-]+ Hookshot \(WordPress\/[\w.-]+\)$/.test(userAgent.trim())
    && /^webhook_id=\d+$/.test(String(rawBody || "").trim());
}

export function isWooProductTopic(topic, resource, event) {
  const normalizedTopic = String(topic || "").trim().toLowerCase();
  if (normalizedTopic.startsWith("product.")) return true;
  return String(resource || "").trim().toLowerCase() === "product"
    && Boolean(String(event || "").trim());
}
