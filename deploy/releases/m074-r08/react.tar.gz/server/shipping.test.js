import test from "node:test";
import assert from "node:assert/strict";
import { createShippingBooking, normalizeRateSearch, normalizeRouteOptions } from "./shipping.js";

test("rate search requires exact FCL route filters", () => {
  assert.deepEqual(normalizeRateSearch({ pol: "NANSHA", pod: "ALEXANDRIA", container_type: "40hq" }), { pol: "NANSHA", pod: "ALEXANDRIA", container_type: "40HQ", country_code: "", service_type: "", incoterm: "FOB" });
  assert.throws(() => normalizeRateSearch({ pol: "%", pod: "ALEXANDRIA", container_type: "40HQ" }), (error) => error.code === "invalid_rate_search");
  assert.throws(() => normalizeRateSearch({ pol: "NANSHA", pod: "ALEXANDRIA", container_type: "LCL" }), (error) => error.code === "invalid_rate_search");
});

test("route options accept only a blank or exact ISO-2 country", () => {
  assert.equal(normalizeRouteOptions({ country_code: "eg" }), "EG");
  assert.equal(normalizeRouteOptions({}), "");
  assert.throws(() => normalizeRouteOptions({ country_code: "E%" }), (error) => error.code === "invalid_route_options");
});

test("booking submission remains a Dolibarr intake request", async () => {
  let delivered;
  const env = { DOLIBARR_API_BASE_URL: "https://erp.example.com/api/index.php/", DOLIBARR_ALLOWED_HOST: "erp.example.com", DOLIBARR_API_KEY: "dedicated-api-key-at-least-twenty-characters" };
  const result = await createShippingBooking({ rate_token: "A".repeat(64), container_quantity: 2, cargo_summary: "Furniture", dangerous_goods: "no", terms_accepted: true, contact: { name: "Ahmed", phone: "+201001234567", email: "a@example.com" } }, { env, idempotencyKey: "shipping-request-key-12345", fetchImpl: async (_url, options) => { delivered = JSON.parse(options.body); const body = JSON.stringify({ request_ref: "WEB-SHIP-1", status: "new" }); return { ok: true, status: 201, headers: new Headers(), text: async () => body }; } });
  assert.equal(delivered.request_type, "shipping_booking");
  assert.equal(delivered.details.container_quantity, 2);
  assert.equal(delivered.details.restricted_cargo, false);
  assert.equal(result.request_ref, "WEB-SHIP-1");
});
