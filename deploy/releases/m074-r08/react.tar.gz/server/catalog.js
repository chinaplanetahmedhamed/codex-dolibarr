import { getRuntimeConfig } from "./config.js";

const CARTON_META_KEYS = {
  unitsPerCarton: "_b2bclp_units_per_carton",
  cartonLength: "_b2bclp_carton_length",
  cartonWidth: "_b2bclp_carton_width",
  cartonHeight: "_b2bclp_carton_height",
  cartonCbm: "_b2bclp_carton_cbm",
  cartonNetWeight: "_b2bclp_carton_net_weight",
  cartonGrossWeight: "_b2bclp_carton_gross_weight",
  orientations: "_b2bclp_orientations",
  packingComplete: "_b2bclp_packing_complete",
};

function stripHtml(value) {
  return String(value || "")
    .replace(/<script[\s\S]*?<\/script>/gi, " ")
    .replace(/<style[\s\S]*?<\/style>/gi, " ")
    .replace(/<[^>]+>/g, " ")
    .replace(/&nbsp;/g, " ")
    .replace(/&amp;/g, "&")
    .replace(/&quot;/g, '"')
    .replace(/&#039;/g, "'")
    .replace(/&#(\d+);/g, (_match, code) => String.fromCodePoint(Number(code)))
    .replace(/&#x([0-9a-f]+);/gi, (_match, code) => String.fromCodePoint(Number.parseInt(code, 16)))
    .replace(/\s+/g, " ")
    .trim();
}

function asPositiveNumber(value) {
  const number = Number.parseFloat(value);
  return Number.isFinite(number) && number > 0 ? number : null;
}

function normalizeAttributeName(value) {
  return stripHtml(value).toLowerCase().replace(/[^a-z0-9\u0600-\u06ff]/g, "");
}

function isPiecesPerCartonAttribute(name) {
  const normalized = normalizeAttributeName(name);
  return normalized.includes("pcsctn")
    || normalized.includes("qtyctn")
    || normalized.includes("piecespercarton")
    || normalized.includes("unitspercarton")
    || normalized.includes("قطعةكرتونة")
    || normalized.includes("قطعكرتونة");
}

function mapStoreVariation(variation) {
  const attributes = (Array.isArray(variation?.attributes) ? variation.attributes : [])
    .map((attribute) => ({
      name: stripHtml(attribute?.name).slice(0, 120),
      value: stripHtml(attribute?.value).slice(0, 240),
    }))
    .filter((attribute) => attribute.name && attribute.value);
  const cartonAttribute = attributes.find((attribute) => isPiecesPerCartonAttribute(attribute.name));
  const optionAttributes = attributes.filter((attribute) => !isPiecesPerCartonAttribute(attribute.name));
  const label = optionAttributes.map((attribute) => attribute.value).join(" / ")
    || attributes.map((attribute) => attribute.value).join(" / ")
    || `خيار ${variation?.id || ""}`.trim();

  return {
    id: `wc-variation-${variation.id}`,
    wooVariationId: variation.id,
    label,
    attributes,
    pcsPerCarton: asPositiveNumber(cartonAttribute?.value),
  };
}

function priceFromStoreApi(prices) {
  if (!prices || prices.price === null || prices.price === undefined || prices.price === "") return "";
  const minorUnit = Math.min(Math.max(Number.parseInt(prices.currency_minor_unit || "0", 10), 0), 6);
  const amount = Number.parseInt(String(prices.price), 10);
  if (!Number.isFinite(amount)) return "";
  return (amount / (10 ** minorUnit)).toFixed(minorUnit);
}

function getMetaMap(product) {
  return new Map(
    (Array.isArray(product.meta_data) ? product.meta_data : [])
      .filter((entry) => entry && typeof entry.key === "string")
      .map((entry) => [entry.key, entry.value]),
  );
}

export function mapWooProduct(product) {
  const meta = getMetaMap(product);
  const categories = Array.isArray(product.categories) ? product.categories : [];
  const images = (Array.isArray(product.images) ? product.images : [])
    .map((image) => image?.src)
    .filter((src) => typeof src === "string" && /^https:\/\//i.test(src));

  const cartonLength = asPositiveNumber(meta.get(CARTON_META_KEYS.cartonLength));
  const cartonWidth = asPositiveNumber(meta.get(CARTON_META_KEYS.cartonWidth));
  const cartonHeight = asPositiveNumber(meta.get(CARTON_META_KEYS.cartonHeight));
  const directCbm = asPositiveNumber(meta.get(CARTON_META_KEYS.cartonCbm));
  const calculatedCbm = cartonLength && cartonWidth && cartonHeight
    ? (cartonLength * cartonWidth * cartonHeight) / 1_000_000
    : null;

  return {
    id: `wc-${product.id}`,
    wooProductId: product.id,
    wooVariationId: product.parent_id || null,
    sku: String(product.sku || ""),
    title: stripHtml(product.name).slice(0, 240),
    description: stripHtml(product.short_description || product.description).slice(0, 3000),
    image: images[0] || "",
    images,
    categoryName: stripHtml(categories[0]?.name || "منتجات من الصين").slice(0, 120),
    subCategoryName: stripHtml(categories[1]?.name || "").slice(0, 120),
    category: categories[0]?.id ? String(categories[0].id) : "uncategorized",
    categoryIds: categories.map((category) => String(category?.id || "")).filter(Boolean),
    price: product.price ? String(product.price) : "",
    currency: "",
    stockStatus: product.stock_status === "instock" ? "available" : "on_request",
    pcsPerCarton: asPositiveNumber(meta.get(CARTON_META_KEYS.unitsPerCarton)),
    cbmPerCarton: directCbm || calculatedCbm,
    cartonLengthCm: cartonLength,
    cartonWidthCm: cartonWidth,
    cartonHeightCm: cartonHeight,
    cartonNetWeightKg: asPositiveNumber(meta.get(CARTON_META_KEYS.cartonNetWeight)),
    cartonGrossWeightKg: asPositiveNumber(meta.get(CARTON_META_KEYS.cartonGrossWeight)),
    orientations: meta.get(CARTON_META_KEYS.orientations) || null,
    packingComplete: ["1", "true", "yes"].includes(String(meta.get(CARTON_META_KEYS.packingComplete)).toLowerCase()),
    source: "woocommerce",
  };
}

export function mapWooStoreProduct(product) {
  const categories = Array.isArray(product.categories) ? product.categories : [];
  const images = (Array.isArray(product.images) ? product.images : [])
    .map((image) => image?.src)
    .filter((src) => typeof src === "string" && /^https:\/\//i.test(src));
  const variants = (Array.isArray(product.variations) ? product.variations : [])
    .filter((variation) => variation && Number.isFinite(Number(variation.id)))
    .map(mapStoreVariation);
  const cartonValues = [...new Set(variants.map((variation) => variation.pcsPerCarton).filter(Boolean))];
  const productCartonAttribute = (Array.isArray(product.attributes) ? product.attributes : [])
    .find((attribute) => isPiecesPerCartonAttribute(attribute?.name));
  const productCartonTerms = Array.isArray(productCartonAttribute?.terms) ? productCartonAttribute.terms : [];
  const singleProductCartonValue = productCartonTerms.length === 1
    ? asPositiveNumber(productCartonTerms[0]?.name)
    : null;

  return {
    id: `wc-${product.id}`,
    wooProductId: product.id,
    wooVariationId: null,
    sku: String(product.sku || ""),
    title: stripHtml(product.name).slice(0, 240),
    description: stripHtml(product.short_description || product.description).slice(0, 3000),
    image: images[0] || "",
    images,
    categoryName: stripHtml(categories[0]?.name || "منتجات من الصين").slice(0, 120),
    subCategoryName: stripHtml(categories[1]?.name || "").slice(0, 120),
    category: categories[0]?.id ? String(categories[0].id) : "uncategorized",
    categoryIds: categories.map((category) => String(category?.id || "")).filter(Boolean),
    price: priceFromStoreApi(product.prices),
    currency: String(product.prices?.currency_code || ""),
    stockStatus: product.is_in_stock ? "available" : "on_request",
    pcsPerCarton: cartonValues.length === 1 ? cartonValues[0] : singleProductCartonValue,
    cbmPerCarton: null,
    cartonLengthCm: null,
    cartonWidthCm: null,
    cartonHeightCm: null,
    cartonNetWeightKg: null,
    cartonGrossWeightKg: null,
    orientations: null,
    packingComplete: false,
    variants,
    hasOptions: Boolean(product.has_options || variants.length),
    permalink: typeof product.permalink === "string" && /^https:\/\//i.test(product.permalink)
      ? product.permalink
      : "",
    source: "woocommerce",
  };
}

export function mapWooCategory(category) {
  const image = category?.image?.src;
  return {
    id: String(category?.id || ""),
    parentId: category?.parent ? String(category.parent) : null,
    name: stripHtml(category?.name || "قسم بدون اسم").slice(0, 160),
    slug: String(category?.slug || "").slice(0, 180),
    count: Math.max(Number.parseInt(category?.count || "0", 10), 0),
    image: typeof image === "string" && /^https:\/\//i.test(image) ? image : "",
  };
}

export async function fetchWooCatalog({ env = process.env, fetchImpl = fetch } = {}) {
  const config = getRuntimeConfig(env);
  if (!config.wordpressBaseUrl) {
    const error = new Error("WooCommerce catalog connection is not configured");
    error.code = "catalog_not_configured";
    error.status = 503;
    throw error;
  }

  const authenticated = Boolean(config.wooConsumerKey && config.wooConsumerSecret);
  const authorization = authenticated
    ? Buffer.from(`${config.wooConsumerKey}:${config.wooConsumerSecret}`).toString("base64")
    : "";
  const products = [];
  const categories = [];
  const headers = { Accept: "application/json" };
  if (authenticated) headers.Authorization = `Basic ${authorization}`;

  for (let page = 1; page <= config.catalogMaxPages; page += 1) {
    const endpoint = new URL(authenticated ? "/wp-json/wc/v3/products" : "/wp-json/wc/store/v1/products", config.wordpressBaseUrl);
    if (authenticated) endpoint.searchParams.set("status", "publish");
    endpoint.searchParams.set("per_page", "100");
    endpoint.searchParams.set("page", String(page));

    const response = await fetchImpl(endpoint, {
      headers,
      signal: AbortSignal.timeout(12_000),
    });

    if (!response.ok) {
      if (response.status === 400 && page > 1) break;
      const error = new Error(`WooCommerce returned HTTP ${response.status}`);
      error.code = "catalog_upstream_error";
      error.status = 502;
      throw error;
    }

    const pageProducts = await response.json();
    if (!Array.isArray(pageProducts) || pageProducts.length === 0) break;
    products.push(...pageProducts.map(authenticated ? mapWooProduct : mapWooStoreProduct));
    if (pageProducts.length < 100) break;
  }

  try {
    for (let page = 1; page <= config.catalogMaxPages; page += 1) {
      const endpoint = new URL(
        authenticated ? "/wp-json/wc/v3/products/categories" : "/wp-json/wc/store/v1/products/categories",
        config.wordpressBaseUrl,
      );
      endpoint.searchParams.set("per_page", "100");
      endpoint.searchParams.set("page", String(page));

      const response = await fetchImpl(endpoint, {
        headers,
        signal: AbortSignal.timeout(12_000),
      });
      if (!response.ok) {
        if (response.status === 400 && page > 1) break;
        categories.length = 0;
        break;
      }

      const pageCategories = await response.json();
      if (!Array.isArray(pageCategories) || pageCategories.length === 0) break;
      categories.push(...pageCategories.map(mapWooCategory).filter((category) => category.id));
      if (pageCategories.length < 100) break;
    }
  } catch {
    // Product browsing remains available if the optional taxonomy request fails.
    categories.length = 0;
  }

  return {
    products,
    categories,
    source: "woocommerce",
    mode: authenticated ? "authenticated_rest" : "store_api",
    syncedAt: new Date().toISOString(),
  };
}
