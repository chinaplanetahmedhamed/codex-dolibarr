import test from "node:test";
import assert from "node:assert/strict";
import { fetchWebsiteRateTrend, fetchWebsiteRouteOptions, searchWebsiteRates, submitWebsiteRequest } from "./dolibarr.js";

const env = {
  DOLIBARR_API_BASE_URL: "https://erp.example.com/api/index.php/",
  DOLIBARR_ALLOWED_HOST: "erp.example.com",
  DOLIBARR_API_KEY: "dedicated-api-key-at-least-twenty-characters",
};

function response(payload, status = 200) {
  const body = JSON.stringify(payload);
  return { ok: status >= 200 && status < 300, status, headers: new Headers({ "content-length": String(body.length) }), text: async () => body };
}

test("Dolibarr website request uses the server-only API key and fixed host", async () => {
  let captured;
  const result = await submitWebsiteRequest({ request_type: "quote_request" }, { env, fetchImpl: async (url, options) => { captured = { url: String(url), options }; return response({ request_ref: "WEB-1" }, 201); } });
  assert.equal(new URL(captured.url).hostname, "erp.example.com");
  assert.equal(new URL(captured.url).pathname, "/api/index.php/chinaplanetoperations/website-requests");
  assert.equal(captured.options.headers.DOLAPIKEY, env.DOLIBARR_API_KEY);
  assert.equal(result.request_ref, "WEB-1");
});

test("public rate search sends only exact public filters", async () => {
  let capturedUrl;
  await searchWebsiteRates({ pol: "NANSHA", pod: "ALEXANDRIA", container_type: "40HQ" }, { env, fetchImpl: async (url) => { capturedUrl = new URL(url); return response({ results: [] }); } });
  assert.equal(capturedUrl.searchParams.get("pol"), "NANSHA");
  assert.equal(capturedUrl.searchParams.get("container_type"), "40HQ");
  assert.equal(capturedUrl.searchParams.has("cost_price"), false);
});

test("public route options use the protected Dolibarr directory endpoint", async () => {
  let capturedUrl;
  await fetchWebsiteRouteOptions("EG", { env, fetchImpl: async (url) => { capturedUrl = new URL(url); return response({ country_code: "EG", routes: [] }); } });
  assert.equal(capturedUrl.pathname, "/api/index.php/chinaplanetshippingprices/website-route-options");
  assert.equal(capturedUrl.searchParams.get("country_code"), "EG");
});

test("public price trend uses the protected exact-route endpoint", async () => {
  let capturedUrl;
  await fetchWebsiteRateTrend({ country_code: "EG", pol: "NANSHA", pod: "ALEXANDRIA", container_type: "40HQ" }, { env, fetchImpl: async (url) => { capturedUrl = new URL(url); return response({ points: [] }); } });
  assert.equal(capturedUrl.pathname, "/api/index.php/chinaplanetshippingprices/website-rate-trend");
  assert.equal(capturedUrl.searchParams.get("pod"), "ALEXANDRIA");
  assert.equal(capturedUrl.searchParams.has("cost_price"), false);
});

test("Dolibarr gateway rejects non-HTTPS non-loopback endpoints", async () => {
  await assert.rejects(() => searchWebsiteRates({}, { env: { ...env, DOLIBARR_API_BASE_URL: "http://erp.example.com/api/index.php/" }, fetchImpl: async () => response({}) }), (error) => error.code === "dolibarr_not_configured" && error.status === 503);
});
