import sanitizeHtml from "sanitize-html";

import { readSiteContent } from "./content.js";
import { fetchChinaGuide, fetchWordPressPosts } from "./wordpress-content.js";

const DEFAULT_ORIGIN = "https://chinaplanet.org";
const CACHE_TTL_MS = 5 * 60_000;
const dataCache = new Map();

const HOME_META = {
  ar: {
    title: "كوكب الصين | شريكك للاستيراد وفحص الجودة من الصين",
    description: "إدارة التوريد من الصين: بحث الموردين، التفاوض، فحص الجودة، تجميع الطلبات والشحن للأسواق العربية من مكتب جوانزو.",
  },
  en: {
    title: "China Planet | Sourcing, Quality Control and Shipping from China",
    description: "China sourcing support from Guangzhou: supplier research, negotiation, quality inspection, consolidation and shipping to Arab markets.",
  },
  fr: {
    title: "China Planet | Sourcing, contrôle qualité et expédition depuis la Chine",
    description: "Accompagnement depuis Guangzhou : recherche de fournisseurs, négociation, inspection, groupage et expédition vers les marchés arabes.",
  },
};

const STATIC_META = {
  "/": HOME_META,
  "/about": {
    ar: { title: "من نحن | كوكب الصين وVision Trading", description: "تعرف على فريق كوكب الصين وخبرتنا العملية في إدارة التوريد والتجارة بين الصين والأسواق العربية منذ 2007." },
    en: { title: "About China Planet and Vision Trading", description: "Meet the Guangzhou team supporting sourcing and trade between China and Arab markets since 2007." },
    fr: { title: "À propos de China Planet et Vision Trading", description: "Découvrez notre équipe à Guangzhou et notre expérience du commerce entre la Chine et les marchés arabes depuis 2007." },
  },
  "/services": {
    ar: { title: "خدمات الاستيراد والتوريد من الصين | كوكب الصين", description: "بحث الموردين، تدقيق المصانع، فحص الجودة، تجميع الطلبات، الشحن والتخليص من الصين ضمن نطاق عمل واضح." },
    en: { title: "China Sourcing and Import Services | China Planet", description: "Supplier research, factory audits, quality control, consolidation, shipping and customs support from China." },
    fr: { title: "Services de sourcing et d'importation de Chine | China Planet", description: "Recherche fournisseurs, audits, contrôle qualité, groupage, transport et assistance douanière depuis la Chine." },
  },
  "/products": {
    ar: { title: "كتالوج منتجات الصين وطلب الأسعار | كوكب الصين", description: "تصفح منتجات مختارة من الصين وأرسل طلب مراجعة سعر ومواصفات إلى فريق كوكب الصين في جوانزو." },
    en: { title: "China Product Catalogue and Quote Requests | China Planet", description: "Browse selected products from China and send a specification and quotation review request to our Guangzhou team." },
    fr: { title: "Catalogue produits Chine et demandes de devis | China Planet", description: "Parcourez des produits sélectionnés et envoyez une demande de vérification et de devis à notre équipe de Guangzhou." },
  },
  "/b2b": {
    ar: { title: "مخطط طلبات الجملة والحاويات من الصين | كوكب الصين", description: "خطط كميات الكراتين والحاويات وأرسل طلب جملة للمراجعة التشغيلية قبل تأكيد السعر أو الحجز." },
    en: { title: "B2B Carton and Container Planner | China Planet", description: "Plan carton and container quantities, then send a wholesale request for operational review before price or booking confirmation." },
    fr: { title: "Planificateur B2B cartons et conteneurs | China Planet", description: "Planifiez cartons et conteneurs puis envoyez une demande grossiste à vérifier avant confirmation du prix ou de la réservation." },
  },
  "/shipping-rates": {
    ar: { title: "أسعار الشحن البحري من الصين وطلب الحجز | كوكب الصين", description: "ابحث عن سعر FCL منشور من الصين وأرسل طلب حجز للمراجعة؛ السعر لا يؤكد المساحة أو الحجز من الخط الملاحي." },
    en: { title: "Ocean Freight Rates from China | China Planet", description: "Search published FCL rates from China and submit a booking review request; displayed rates do not confirm carrier space." },
    fr: { title: "Tarifs de fret maritime depuis la Chine | China Planet", description: "Recherchez un tarif FCL publié et envoyez une demande à vérifier, sans confirmation automatique d'espace transporteur." },
  },
  "/how-we-work": {
    ar: { title: "كيف ندير طلب الاستيراد من الصين | كوكب الصين", description: "خطوات عملية من تحديد المواصفات والبحث عن المورد حتى الفحص والتجميع وترتيب الشحن من الصين." },
    en: { title: "How We Manage China Sourcing Projects | China Planet", description: "A practical workflow from requirements and supplier research to inspection, consolidation and shipping from China." },
    fr: { title: "Notre méthode de sourcing en Chine | China Planet", description: "Un processus clair des spécifications et fournisseurs jusqu'au contrôle, groupage et transport depuis la Chine." },
  },
  "/china-guide": {
    ar: { title: "دليل الصين التجاري والأسواق | كوكب الصين", description: "دليل عملي لمدن الصين والأسواق ومراكز الجملة والخدمات التي تهم المستورد العربي." },
    en: { title: "China Business, City and Wholesale Market Guide | China Planet", description: "A practical guide to Chinese cities, wholesale markets and services for international buyers." },
    fr: { title: "Guide des villes et marchés de gros en Chine | China Planet", description: "Guide pratique des villes, marchés de gros et services utiles aux acheteurs internationaux." },
  },
  "/blog": {
    ar: { title: "مدونة الاستيراد والشحن من الصين | كوكب الصين", description: "مقالات عملية عن الموردين وفحص الجودة والأسواق والشحن والجمارك للاستيراد من الصين." },
    en: { title: "China Sourcing and Shipping Blog | China Planet", description: "Practical articles about suppliers, quality inspection, wholesale markets, shipping and customs from China." },
    fr: { title: "Blog sourcing et transport depuis la Chine | China Planet", description: "Conseils pratiques sur les fournisseurs, le contrôle qualité, les marchés, le transport et la douane en Chine." },
  },
  "/faq": {
    ar: { title: "الأسئلة الشائعة عن الاستيراد من الصين | كوكب الصين", description: "إجابات واضحة عن البحث عن المورد، الفحص، الدفع، التجميع والشحن من الصين." },
    en: { title: "China Import Frequently Asked Questions | China Planet", description: "Clear answers about suppliers, inspection, payment, consolidation and shipping from China." },
    fr: { title: "Questions fréquentes sur l'importation de Chine | China Planet", description: "Réponses sur les fournisseurs, contrôles, paiements, groupage et transport depuis la Chine." },
  },
  "/contact": {
    ar: { title: "تواصل مع مكتب كوكب الصين في جوانزو", description: "أرسل متطلبات المنتج أو الشحن إلى فريق كوكب الصين وVision Trading في جوانزو للمراجعة والرد." },
    en: { title: "Contact China Planet in Guangzhou", description: "Send your product or shipping requirements to the China Planet and Vision Trading team in Guangzhou for review." },
    fr: { title: "Contacter China Planet à Guangzhou", description: "Envoyez vos besoins produit ou transport à notre équipe de Guangzhou pour étude." },
  },
  "/privacy": {
    ar: { title: "سياسة الخصوصية | كوكب الصين", description: "كيفية استخدام وحماية بيانات التواصل وطلبات التوريد والشحن العامة في موقع كوكب الصين." },
    en: { title: "Privacy Policy | China Planet", description: "How China Planet uses and protects contact data submitted through public sourcing and shipping requests." },
    fr: { title: "Politique de confidentialité | China Planet", description: "Utilisation et protection des coordonnées envoyées dans les demandes publiques d'achat et de transport." },
  },
  "/terms": {
    ar: { title: "شروط الاستخدام والطلبات العامة | كوكب الصين", description: "شروط استخدام الأسعار والكتالوج وطلبات المراجعة العامة في موقع كوكب الصين." },
    en: { title: "Website Terms and Public Requests | China Planet", description: "Terms for public rates, catalogue information and review requests on the China Planet website." },
    fr: { title: "Conditions du site et demandes publiques | China Planet", description: "Conditions applicables aux tarifs, au catalogue et aux demandes publiques sur China Planet." },
  },
};

function safeOrigin(value) {
  try {
    const url = new URL(value || DEFAULT_ORIGIN);
    return `${url.protocol}//${url.host}`;
  } catch {
    return DEFAULT_ORIGIN;
  }
}

function normalizeRoute(pathname) {
  const normalized = String(pathname || "/").split("?", 1)[0].replace(/\/+$/, "") || "/";
  const segments = normalized.split("/").filter(Boolean);
  const first = segments[0]?.toLowerCase();
  const locale = first === "en" || first === "fr" ? first : "ar";
  const routeSegments = first === "en" || first === "fr" || first === "ar" ? segments.slice(1) : segments;
  return { locale, route: routeSegments.length ? `/${routeSegments.join("/")}` : "/" };
}

function localizedPath(route, locale) {
  if (locale === "ar") return route;
  return route === "/" ? `/${locale}` : `/${locale}${route}`;
}

function localizedField(record, field, locale, fallback = "") {
  if (!record || typeof record !== "object") return fallback;
  if (locale === "ar") return record[field] || fallback;
  return record[`${field}${locale === "en" ? "En" : "Fr"}`] || fallback || record[field] || "";
}

function textOnly(value, maxLength = 320) {
  return sanitizeHtml(String(value || ""), { allowedTags: [], allowedAttributes: {} })
    .replace(/\s+/g, " ")
    .trim()
    .slice(0, maxLength);
}

function absoluteImage(value, origin) {
  try {
    return new URL(String(value || "/images/hero.webp"), `${origin}/`).toString();
  } catch {
    return `${origin}/images/hero.webp`;
  }
}

function decodeSlug(route, prefix) {
  try {
    return decodeURIComponent(route.slice(prefix.length));
  } catch {
    return route.slice(prefix.length);
  }
}

export function buildSeoPage({ pathname = "/", origin = DEFAULT_ORIGIN, posts = [], places = [], siteContent = null } = {}) {
  const canonicalOrigin = safeOrigin(origin);
  const { locale, route } = normalizeRoute(pathname);
  const staticMeta = STATIC_META[route]?.[locale] || HOME_META[locale];
  let title = staticMeta.title;
  let description = staticMeta.description;
  let image = "/images/hero.webp";
  let type = "website";
  let contentHtml = "";
  let found = Boolean(STATIC_META[route]);

  if (route.startsWith("/blog/")) {
    const slug = decodeSlug(route, "/blog/");
    const post = posts.find((entry) => String(entry?.slug || entry?.id) === slug);
    if (post) {
      const postTitle = localizedField(post, "title", locale, post.title);
      title = `${textOnly(postTitle, 180)} | China Planet`;
      description = textOnly(localizedField(post, "metaDescription", locale, post.metaDescription || post.excerpt), 320) || staticMeta.description;
      image = post.image || image;
      type = "article";
      contentHtml = localizedField(post, "contentHtml", locale, post.contentHtml || post.content);
      found = true;
    }
  } else if (route.startsWith("/china-guide/")) {
    const slug = decodeSlug(route, "/china-guide/");
    const place = places.find((entry) => String(entry?.slug || entry?.id) === slug);
    if (place) {
      title = `${textOnly(localizedField(place, "title", locale, place.title), 180)} | China Planet`;
      description = textOnly(localizedField(place, "metaDescription", locale, place.metaDescription || place.excerpt), 320) || STATIC_META["/china-guide"][locale].description;
      image = place.image || image;
      contentHtml = localizedField(place, "contentHtml", locale, place.contentHtml);
      found = true;
    }
  } else if (route.startsWith("/service/")) {
    const id = decodeSlug(route, "/service/");
    const service = siteContent?.servicesData?.find((entry) => String(entry?.id) === id);
    if (service) {
      title = `${textOnly(localizedField(service, "title", locale, service.title), 180)} | China Planet`;
      description = textOnly(localizedField(service, "description", locale, service.description), 320) || STATIC_META["/services"][locale].description;
      image = service.image || image;
      found = true;
    }
  }

  const canonicalPath = localizedPath(route, locale);
  return {
    locale,
    direction: locale === "ar" ? "rtl" : "ltr",
    route,
    title,
    description,
    image: absoluteImage(image, canonicalOrigin),
    canonicalUrl: `${canonicalOrigin}${canonicalPath === "/" ? "" : canonicalPath}`,
    alternates: Object.fromEntries(["ar", "en", "fr"].map((targetLocale) => [
      targetLocale,
      `${canonicalOrigin}${localizedPath(route, targetLocale) === "/" ? "" : localizedPath(route, targetLocale)}`,
    ])),
    type,
    contentHtml,
    noIndex: !found || /^\/(?:admin|login|customer-center)(?:\/|$)/.test(route),
  };
}

async function cached(key, loader) {
  const now = Date.now();
  const existing = dataCache.get(key);
  if (existing?.expiresAt > now) return existing.value;
  const value = await loader();
  dataCache.set(key, { value, expiresAt: now + CACHE_TTL_MS });
  return value;
}

export async function resolveSeoPage({ pathname, origin, env = process.env, fetchImpl = fetch } = {}) {
  const { route } = normalizeRoute(pathname);
  let posts = [];
  let places = [];
  let siteContent = null;

  if (route.startsWith("/blog/")) {
    posts = (await cached("posts", () => fetchWordPressPosts({ env, fetchImpl })).catch(() => ({ posts: [] }))).posts || [];
  } else if (route.startsWith("/china-guide/")) {
    places = (await cached("places", () => fetchChinaGuide({ env, fetchImpl })).catch(() => ({ places: [] }))).places || [];
  } else if (route.startsWith("/service/")) {
    siteContent = (await cached("site-content", () => readSiteContent(env)).catch(() => ({ content: null }))).content;
  }

  return buildSeoPage({ pathname, origin, posts, places, siteContent });
}

function escapeHtml(value) {
  return String(value || "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

function safeArticleHtml(value) {
  return sanitizeHtml(String(value || ""), {
    allowedTags: ["p", "h2", "h3", "h4", "ul", "ol", "li", "strong", "em", "blockquote", "a"],
    allowedAttributes: { a: ["href"] },
    allowedSchemes: ["https"],
  });
}

export function renderSeoDocument(template, page, { googleSiteVerification = "" } = {}) {
  const escapedTitle = escapeHtml(page.title);
  const escapedDescription = escapeHtml(page.description);
  const escapedCanonical = escapeHtml(page.canonicalUrl);
  const escapedImage = escapeHtml(page.image);
  const graph = {
    "@context": "https://schema.org",
    "@graph": [
      {
        "@type": "Organization",
        "@id": `${new URL(page.canonicalUrl).origin}/#organization`,
        name: "كوكب الصين China Planet",
        url: new URL(page.canonicalUrl).origin,
        logo: `${new URL(page.canonicalUrl).origin}/brand/china-planet-primary.webp`,
      },
      {
        "@type": page.type === "article" ? "BlogPosting" : "WebPage",
        headline: page.title,
        name: page.title,
        description: page.description,
        image: page.image,
        url: page.canonicalUrl,
        inLanguage: page.locale,
        publisher: { "@id": `${new URL(page.canonicalUrl).origin}/#organization` },
      },
    ],
  };
  const schema = JSON.stringify(graph).replace(/</g, "\\u003c");
  const verification = /^[A-Za-z0-9_-]{10,200}$/.test(googleSiteVerification)
    ? `<meta name="google-site-verification" content="${escapeHtml(googleSiteVerification)}">`
    : "";
  const head = [
    `<meta name="robots" content="${page.noIndex ? "noindex,nofollow,noarchive" : "index,follow,max-image-preview:large"}">`,
    `<link rel="canonical" href="${escapedCanonical}">`,
    ...Object.entries(page.alternates).map(([locale, href]) => `<link rel="alternate" hreflang="${locale}" href="${escapeHtml(href)}">`),
    `<link rel="alternate" hreflang="x-default" href="${escapeHtml(page.alternates.ar)}">`,
    `<meta property="og:title" content="${escapedTitle}">`,
    `<meta property="og:description" content="${escapedDescription}">`,
    `<meta property="og:image" content="${escapedImage}">`,
    `<meta property="og:url" content="${escapedCanonical}">`,
    `<meta property="og:type" content="${page.type}">`,
    `<meta property="og:site_name" content="كوكب الصين China Planet">`,
    `<meta property="og:locale" content="${page.locale === "ar" ? "ar_AR" : page.locale === "fr" ? "fr_FR" : "en_US"}">`,
    `<meta name="twitter:card" content="summary_large_image">`,
    `<meta name="twitter:title" content="${escapedTitle}">`,
    `<meta name="twitter:description" content="${escapedDescription}">`,
    `<meta name="twitter:image" content="${escapedImage}">`,
    verification,
    `<script type="application/ld+json" id="server-json-ld">${schema}</script>`,
  ].filter(Boolean).join("\n    ");
  const article = safeArticleHtml(page.contentHtml);
  const snapshot = `<div id="root"><main class="seo-snapshot" data-server-seo-snapshot><h1>${escapedTitle}</h1><p>${escapedDescription}</p>${article}</main></div>`;

  return String(template)
    .replace(/<html\b[^>]*>/i, `<html lang="${page.locale}" dir="${page.direction}">`)
    .replace(/<title>[\s\S]*?<\/title>/i, `<title>${escapedTitle}</title>`)
    .replace(/<meta\s+name=["']description["'][^>]*>/i, `<meta name="description" content="${escapedDescription}">`)
    .replace(/\s*<\/head>/i, `\n    ${head}\n  </head>`)
    .replace(/<div\s+id=["']root["']\s*><\/div>/i, snapshot);
}
