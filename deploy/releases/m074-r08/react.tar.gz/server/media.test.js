import test from "node:test";
import assert from "node:assert/strict";
import { mkdtemp, readFile, rm } from "node:fs/promises";
import path from "node:path";
import os from "node:os";
import { resolveMediaPath, writeWebsiteImage } from "./media.js";

test("website media accepts validated images and stores random filenames", async () => {
  const directory = await mkdtemp(path.join(os.tmpdir(), "cp-media-test-"));
  const env = { CONTENT_STORE_PATH: path.join(directory, "site-content.json") };
  const png = "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNk+A8AAQUBAScY42YAAAAASUVORK5CYII=";
  try {
    const result = await writeWebsiteImage({ mimeType: "image/png", data: png }, env);
    assert.match(result.url, /^\/media\/[a-f0-9]{32}\.png$/);
    const stored = await readFile(resolveMediaPath(result.url, env));
    assert.equal(stored.subarray(1, 4).toString("ascii"), "PNG");
    await assert.rejects(() => writeWebsiteImage({ mimeType: "image/svg+xml", data: png }, env), (error) => error.code === "unsupported_image");
  } finally {
    await rm(directory, { recursive: true, force: true });
  }
});
