import test from "node:test";
import assert from "node:assert/strict";

import { buildSeoPage, renderSeoDocument } from "./seo-html.js";

const template = `<!doctype html><html lang="ar" dir="rtl"><head><title>Old home title</title><meta name="description" content="Old description"></head><body><div id="root"></div></body></html>`;

test("localized static routes receive distinct canonical metadata", () => {
  const page = buildSeoPage({ pathname: "/en/blog", origin: "https://chinaplanet.org" });
  assert.match(page.title, /China Sourcing and Shipping Blog/);
  assert.equal(page.locale, "en");
  assert.equal(page.direction, "ltr");
  assert.equal(page.canonicalUrl, "https://chinaplanet.org/en/blog");
  assert.equal(page.alternates.ar, "https://chinaplanet.org/blog");
  assert.equal(page.alternates.fr, "https://chinaplanet.org/fr/blog");
  assert.equal(page.noIndex, false);
});

test("privacy and terms routes are indexable in all public locales", () => {
  for (const pathname of ["/privacy", "/en/privacy", "/fr/terms"]) {
    const page = buildSeoPage({ pathname, origin: "https://chinaplanet.org" });
    assert.equal(page.noIndex, false, pathname);
    assert.match(page.canonicalUrl, new RegExp(`${pathname.replaceAll("/", "\\/")}$`));
    assert.ok(page.title.length > 10, pathname);
    assert.ok(page.description.length > 30, pathname);
  }
});

test("dynamic blog pages expose article metadata and crawlable sanitized content", () => {
  const page = buildSeoPage({
    pathname: "/blog/factory-audit",
    origin: "https://chinaplanet.org",
    posts: [{
      id: 42,
      slug: "factory-audit",
      title: "تدقيق المصنع قبل الشراء",
      excerpt: "خطوات عملية لتقليل مخاطر التوريد.",
      image: "/images/inspection.webp",
      contentHtml: '<h2>ابدأ بالمستندات</h2><p>ثم نفذ الفحص.</p><script>alert("x")</script>',
    }],
  });
  const html = renderSeoDocument(template, page, { googleSiteVerification: "valid_token_12345" });

  assert.equal(page.type, "article");
  assert.match(html, /<title>تدقيق المصنع قبل الشراء \| China Planet<\/title>/);
  assert.match(html, /property="og:type" content="article"/);
  assert.match(html, /rel="canonical" href="https:\/\/chinaplanet\.org\/blog\/factory-audit"/);
  assert.match(html, /data-server-seo-snapshot/);
  assert.match(html, /<h2>ابدأ بالمستندات<\/h2>/);
  assert.doesNotMatch(html, /alert\(/);
  assert.match(html, /google-site-verification/);
});

test("unknown and private routes are noindex and invalid verification tokens are omitted", () => {
  const unknown = buildSeoPage({ pathname: "/unknown-page" });
  const privatePage = buildSeoPage({ pathname: "/admin" });
  assert.equal(unknown.noIndex, true);
  assert.equal(privatePage.noIndex, true);
  assert.doesNotMatch(renderSeoDocument(template, unknown, { googleSiteVerification: 'bad"token' }), /google-site-verification/);
});
