import { createServer } from "node:http";
import { readFile, stat } from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { getRuntimeConfig } from "./config.js";
import { processApiRequest, warmWordPressContent } from "./http.js";
import { resolveMediaPath } from "./media.js";
import { buildSitemap, canonicalHostRedirect, legacyRedirect, renderRobots } from "./seo.js";
import { renderSeoDocument, resolveSeoPage } from "./seo-html.js";

const currentDir = path.dirname(fileURLToPath(import.meta.url));
const distDir = path.resolve(currentDir, "../dist");
const config = getRuntimeConfig();

const mimeTypes = {
  ".css": "text/css; charset=utf-8",
  ".html": "text/html; charset=utf-8",
  ".ico": "image/x-icon",
  ".jpg": "image/jpeg",
  ".jpeg": "image/jpeg",
  ".js": "text/javascript; charset=utf-8",
  ".json": "application/json; charset=utf-8",
  ".png": "image/png",
  ".svg": "image/svg+xml",
  ".woff2": "font/woff2",
  ".webp": "image/webp",
};

let sitemapCache = null;

function setSecurityHeaders(response) {
  response.setHeader("X-Content-Type-Options", "nosniff");
  response.setHeader("Referrer-Policy", "strict-origin-when-cross-origin");
  response.setHeader("X-Frame-Options", "SAMEORIGIN");
  response.setHeader("Permissions-Policy", "camera=(), microphone=(), geolocation=()");
  response.setHeader("Cross-Origin-Opener-Policy", "same-origin");
  response.setHeader("Content-Security-Policy", "default-src 'self'; base-uri 'self'; connect-src 'self' https://www.facebook.com https://connect.facebook.net https://www.google-analytics.com https://region1.google-analytics.com; font-src 'self' data:; form-action 'self'; frame-ancestors 'self'; frame-src https://www.youtube.com https://www.youtube-nocookie.com; img-src 'self' data: blob: https:; media-src 'self' https:; object-src 'none'; script-src 'self' https://connect.facebook.net https://www.googletagmanager.com; style-src 'self' 'unsafe-inline'; upgrade-insecure-requests");
  if (!config.seoAllowIndexing) {
    response.setHeader("X-Robots-Tag", "noindex, nofollow, noarchive");
  }
  if (config.nodeEnv === "production") {
    response.setHeader("Strict-Transport-Security", "max-age=31536000; includeSubDomains");
  }
}

async function readRequestBody(request, maxBytes) {
  const chunks = [];
  let size = 0;
  for await (const chunk of request) {
    size += chunk.length;
    if (size > maxBytes) throw Object.assign(new Error("Payload too large"), { status: 413 });
    chunks.push(chunk);
  }
  return Buffer.concat(chunks).toString("utf8");
}

async function serveStatic(urlPath, requestMethod, response) {
  const requested = urlPath === "/" ? "/index.html" : decodeURIComponent(urlPath);
  let filePath = path.resolve(distDir, `.${requested}`);
  if (!filePath.startsWith(`${distDir}${path.sep}`)) return false;

  try {
    const fileStat = await stat(filePath);
    if (!fileStat.isFile()) return false;
  } catch {
    filePath = path.join(distDir, "index.html");
  }

  let content = await readFile(filePath);
  const extension = path.extname(filePath).toLowerCase();
  if (extension === ".html") {
    const page = await resolveSeoPage({ pathname: urlPath, origin: config.publicSiteOrigin });
    content = Buffer.from(renderSeoDocument(content.toString("utf8"), page, {
      googleSiteVerification: config.googleSiteVerification,
    }));
  }
  response.statusCode = 200;
  response.setHeader("Content-Type", mimeTypes[extension] || "application/octet-stream");
  response.setHeader("Cache-Control", extension === ".html" ? "no-cache" : "public, max-age=31536000, immutable");
  response.end(requestMethod === "HEAD" ? "" : content);
  return true;
}

async function serveMedia(urlPath, response) {
  const filePath = resolveMediaPath(urlPath);
  if (!filePath) return false;
  try {
    const content = await readFile(filePath);
    response.statusCode = 200;
    response.setHeader("Content-Type", mimeTypes[path.extname(filePath).toLowerCase()] || "application/octet-stream");
    response.setHeader("Cache-Control", "public, max-age=31536000, immutable");
    response.end(content);
    return true;
  } catch {
    return false;
  }
}

async function serveSeo(urlPath, requestMethod, response) {
  if (urlPath === "/robots.txt") {
    const content = renderRobots({ origin: config.publicSiteOrigin, allowIndexing: config.seoAllowIndexing });
    response.statusCode = 200;
    response.setHeader("Content-Type", "text/plain; charset=utf-8");
    response.setHeader("Cache-Control", "public, max-age=300");
    response.end(requestMethod === "HEAD" ? "" : content);
    return true;
  }
  if (urlPath === "/sitemap.xml") {
    const now = Date.now();
    if (!sitemapCache || sitemapCache.expiresAt <= now) {
      const content = await buildSitemap().catch(() => buildSitemap({ env: { ...process.env, WORDPRESS_BASE_URL: "" } }));
      sitemapCache = { content, expiresAt: now + 10 * 60_000 };
    }
    response.statusCode = 200;
    response.setHeader("Content-Type", "application/xml; charset=utf-8");
    response.setHeader("Cache-Control", "public, max-age=300, stale-while-revalidate=600");
    response.end(requestMethod === "HEAD" ? "" : sitemapCache.content);
    return true;
  }
  return false;
}

const server = createServer(async (request, response) => {
  setSecurityHeaders(response);
  const url = new URL(request.url || "/", `http://${request.headers.host || "localhost"}`);

  try {
    const canonicalTarget = canonicalHostRedirect({
      host: request.headers.host,
      pathname: url.pathname,
      search: url.search,
      origin: config.publicSiteOrigin,
    });
    if (canonicalTarget) {
      response.statusCode = 301;
      response.setHeader("Location", canonicalTarget);
      response.setHeader("Cache-Control", "public, max-age=86400");
      response.end();
      return;
    }

    const redirectTarget = legacyRedirect(url.pathname);
    if (redirectTarget) {
      response.statusCode = 301;
      response.setHeader("Location", redirectTarget);
      response.setHeader("Cache-Control", "public, max-age=86400");
      response.end();
      return;
    }

    if (await serveSeo(url.pathname, request.method || "GET", response)) return;

    if (url.pathname.startsWith("/api/")) {
      const hasBody = ["POST", "PUT", "PATCH"].includes(request.method || "");
      const maxBytes = url.pathname === "/api/admin/media"
        ? 7_000_000
        : url.pathname === "/api/admin/content"
          ? 500_000
          : url.pathname === "/api/webhooks/woocommerce/catalog"
            ? 2_000_000
            : url.pathname.startsWith("/api/b2b/")
              ? 100_000
              : 20_000;
      const body = hasBody ? await readRequestBody(request, maxBytes) : null;
      const result = await processApiRequest({
        path: url.pathname,
        query: Object.fromEntries(url.searchParams),
        method: request.method || "GET",
        headers: request.headers,
        remoteAddress: request.socket?.remoteAddress || "",
        body,
      });
      response.writeHead(result.status, result.headers);
      response.end(JSON.stringify(result.body));
      return;
    }

    if (url.pathname.startsWith("/media/")) {
      if (await serveMedia(url.pathname, response)) return;
      response.statusCode = 404;
      response.end("Not found");
      return;
    }
    await serveStatic(url.pathname, request.method || "GET", response);
  } catch (error) {
    response.statusCode = error.status || 500;
    response.setHeader("Content-Type", "application/json; charset=utf-8");
    response.end(JSON.stringify({ ok: false, code: error.status === 413 ? "payload_too_large" : "server_error" }));
  }
});

server.listen(config.port, "0.0.0.0", () => {
  console.log(`China Planet website listening on port ${config.port}`);
  void warmWordPressContent().catch(() => null);
});
