import test from "node:test";
import assert from "node:assert/strict";
import { createHmac } from "node:crypto";
import { processApiRequest, __test } from "./http.js";
import { createPasswordHash } from "./auth.js";

test("client identity ignores spoofed proxy headers unless proxy trust is configured", () => {
  const headers = { "x-real-ip": "198.51.100.9", "x-forwarded-for": "203.0.113.7, 192.0.2.4" };
  assert.equal(__test.clientAddress(headers, 0, "10.0.0.8"), "10.0.0.8");
  assert.equal(__test.clientAddress(headers, 2, "10.0.0.8"), "203.0.113.7");
});

test("health reveals configuration state without revealing secrets", async () => {
  const response = await processApiRequest({
    path: "/api/health",
    method: "GET",
    headers: {},
    env: {
      DEPLOY_SHA: "0123456789abcdef0123456789abcdef01234567",
      WORDPRESS_BASE_URL: "https://wordpress.example.com",
      WC_CONSUMER_KEY: "ck_secret",
      WC_CONSUMER_SECRET: "cs_secret",
      WC_WEBHOOK_SECRET: "catalog-webhook-secret",
      B2B_API_SECRET: "12345678901234567890123456789012",
      DOLIBARR_API_BASE_URL: "https://erp.example.com/api/index.php/",
      DOLIBARR_ALLOWED_HOST: "erp.example.com",
      DOLIBARR_API_KEY: "dedicated-api-key-at-least-twenty-characters",
      RATE_LIMIT_STORE_PATH: "/app/data/rate-limits.json",
      ADMIN_EMAIL: "admin@example.com",
      ADMIN_PASSWORD_HASH: "scrypt$test-salt$test-hash",
      ADMIN_SESSION_SECRET: "a-long-test-session-secret-value-123456",
    },
  });

  assert.equal(response.status, 200);
  assert.equal(response.body.releaseId, "M072-R01");
  assert.equal(response.body.releaseMetadataValid, true);
  assert.equal(response.body.deploySha, "0123456789abcdef0123456789abcdef01234567");
  assert.equal(response.body.catalogConfigured, true);
  assert.equal(response.body.catalogAuthenticated, true);
  assert.equal(response.body.catalogWebhookConfigured, true);
  assert.equal(response.body.b2bIntegrationConfigured, true);
  assert.equal(response.body.dolibarrGatewayConfigured, true);
  assert.equal(response.body.durableRateLimitConfigured, true);
  assert.equal(response.body.adminConfigured, true);
  assert.equal(response.body.adminEmailConfigured, true);
  assert.equal(response.body.adminPasswordHashConfigured, true);
  assert.equal(response.body.adminSessionSecretConfigured, true);
  assert.equal(JSON.stringify(response.body).includes("ck_secret"), false);
});

test("health rejects a valid-looking release override that differs from immutable metadata", async () => {
  const response = await processApiRequest({
    path: "/api/health",
    method: "GET",
    headers: {},
    env: { RELEASE_ID: "M999-R99", DEPLOY_SHA: "manual" },
  });

  assert.equal(response.status, 503);
  assert.equal(response.body.ok, false);
  assert.equal(response.body.releaseId, "M072-R01");
  assert.equal(response.body.releaseMetadataValid, false);
  assert.equal(response.body.deploySha, "");
});

test("health fails closed when deploy SHA is missing or malformed", async () => {
  for (const env of [{}, { DEPLOY_SHA: "manual" }, { DEPLOY_SHA: "a".repeat(39) }]) {
    const response = await processApiRequest({
      path: "/api/health",
      method: "GET",
      headers: {},
      env,
    });

    assert.equal(response.status, 503);
    assert.equal(response.body.ok, false);
    assert.equal(response.body.releaseId, "M072-R01");
    assert.equal(response.body.releaseMetadataValid, false);
    assert.equal(response.body.deploySha, "");
  }
});

test("a signed WooCommerce product webhook invalidates the catalog cache", async () => {
  const env = {
    WORDPRESS_BASE_URL: "https://wordpress.example.com",
    WC_WEBHOOK_SECRET: "test-webhook-secret",
    CATALOG_MAX_PAGES: "1",
    CATALOG_CACHE_SECONDS: "300",
  };
  let productTitle = "Before update";
  let productFetchCalls = 0;
  const fetchImpl = async (url) => {
    const isCategoryRequest = String(url).includes("/products/categories");
    if (!isCategoryRequest) productFetchCalls += 1;
    return {
      ok: true,
      status: 200,
      json: async () => isCategoryRequest ? [] : [{
        id: 99,
        sku: "CP-99",
        name: productTitle,
        prices: { price: "0", currency_code: "USD", currency_minor_unit: 2 },
        is_in_stock: true,
        categories: [],
        images: [],
        variations: [],
      }],
    };
  };
  const rawBody = JSON.stringify({ id: 99, name: "Product changed" });
  const signature = createHmac("sha256", env.WC_WEBHOOK_SECRET).update(rawBody).digest("base64");
  const webhookHeaders = {
    "x-wc-webhook-signature": signature,
    "x-wc-webhook-topic": "product.updated",
    "x-wc-webhook-resource": "product",
    "x-wc-webhook-event": "updated",
  };

  const initialWebhook = await processApiRequest({
    path: "/api/webhooks/woocommerce/catalog",
    method: "POST",
    headers: webhookHeaders,
    body: rawBody,
    env,
  });
  assert.equal(initialWebhook.status, 200);
  assert.equal(initialWebhook.body.invalidated, true);

  const firstCatalog = await processApiRequest({ path: "/api/catalog", method: "GET", headers: {}, env, fetchImpl });
  const cachedCatalog = await processApiRequest({ path: "/api/catalog", method: "GET", headers: {}, env, fetchImpl });
  assert.equal(firstCatalog.body.products[0].title, "Before update");
  assert.equal(cachedCatalog.body.products[0].title, "Before update");
  assert.equal(productFetchCalls, 1);

  productTitle = "After update";
  const updatedWebhook = await processApiRequest({
    path: "/api/webhooks/woocommerce/catalog",
    method: "POST",
    headers: webhookHeaders,
    body: rawBody,
    env,
  });
  const version = await processApiRequest({ path: "/api/catalog-version", method: "GET", headers: {}, env });
  const staleCatalog = await processApiRequest({ path: "/api/catalog", method: "GET", headers: {}, env, fetchImpl });
  assert.equal(staleCatalog.body.products[0].title, "Before update");
  assert.equal(staleCatalog.body.stale, true);
  await new Promise((resolve) => setImmediate(resolve));
  const refreshedCatalog = await processApiRequest({ path: "/api/catalog", method: "GET", headers: {}, env, fetchImpl });

  assert.equal(updatedWebhook.status, 200);
  assert.equal(version.body.revision, updatedWebhook.body.revision);
  assert.equal(refreshedCatalog.body.products[0].title, "After update");
  assert.equal(refreshedCatalog.body.revision, updatedWebhook.body.revision);
  assert.equal(productFetchCalls, 2);
});

test("an expired direct Guide detail request refreshes its parent CMS record", async () => {
  const { processApiRequest: processFreshApiRequest } = await import(`./http.js?guide-refresh-${Math.random()}`);
  const originalNow = Date.now;
  let now = 1_000;
  let image = "https://wordpress.example.com/wp-content/uploads/old.jpg";
  Date.now = () => now;

  const fetchImpl = async (url) => {
    const endpoint = new URL(url);
    if (endpoint.pathname.endsWith("/china_guide")) {
      return {
        ok: true,
        status: 200,
        json: async () => [{
          id: 102388,
          slug: "taikoo-hui",
          title: { rendered: "Taikoo Hui" },
          status: "publish",
          link: "https://wordpress.example.com/china_guide/taikoo-hui/",
          china_city: [133],
          place_type: [132],
          place_tag: [],
          meta: { _main_image_url: image },
          chinaplanet_headless: { excerpt: "Guide", content: "<p>Guide</p>", publicMeta: {} },
        }],
      };
    }
    if (endpoint.pathname.endsWith("/china_city")) return { ok: true, status: 200, json: async () => [{ id: 133, slug: "guangzhou", name: "Guangzhou", count: 1 }] };
    if (endpoint.pathname.endsWith("/place_type")) return { ok: true, status: 200, json: async () => [{ id: 132, slug: "shopping", name: "Shopping", count: 1 }] };
    if (endpoint.pathname.endsWith("/place_tag") || endpoint.pathname.endsWith("/media")) return { ok: true, status: 200, json: async () => [] };
    if (endpoint.pathname === "/china_guide/taikoo-hui/") {
      return {
        ok: true,
        status: 200,
        text: async () => '<html><head><meta property="og:image" content="https://legacy.example/stale.jpg"></head><body><div class="entry-content"><p>Guide</p></div></body></html>',
      };
    }
    throw new Error(`Unexpected endpoint ${endpoint.pathname}`);
  };
  const request = {
    path: "/api/china-guide/taikoo-hui",
    method: "GET",
    headers: {},
    env: {
      WORDPRESS_BASE_URL: "https://wordpress.example.com",
      WP_CONTENT_MAX_PAGES: "1",
      WP_CONTENT_CACHE_SECONDS: "30",
    },
    fetchImpl,
  };

  try {
    const first = await processFreshApiRequest(request);
    assert.equal(first.body.image, "https://wordpress.example.com/wp-content/uploads/old.jpg");

    image = "https://wordpress.example.com/wp-content/uploads/new.jpg";
    now = 32_000;
    const refreshed = await processFreshApiRequest(request);
    assert.equal(refreshed.body.image, "https://wordpress.example.com/wp-content/uploads/new.jpg");
  } finally {
    Date.now = originalNow;
  }
});

test("WooCommerce webhook rejects an invalid signature without invalidating the catalog", async () => {
  const before = await processApiRequest({ path: "/api/catalog-version", method: "GET", headers: {}, env: {} });
  const response = await processApiRequest({
    path: "/api/webhooks/woocommerce/catalog",
    method: "POST",
    headers: {
      "x-wc-webhook-signature": "not-a-valid-signature",
      "x-wc-webhook-topic": "product.updated",
    },
    body: "{\"id\":99}",
    env: { WC_WEBHOOK_SECRET: "test-webhook-secret" },
  });
  const after = await processApiRequest({ path: "/api/catalog-version", method: "GET", headers: {}, env: {} });

  assert.equal(response.status, 401);
  assert.equal(response.body.code, "invalid_webhook_signature");
  assert.equal(after.body.revision, before.body.revision);
});

test("WooCommerce setup ping is accepted without invalidating the catalog", async () => {
  const before = await processApiRequest({ path: "/api/catalog-version", method: "GET", headers: {}, env: {} });
  const response = await processApiRequest({
    path: "/api/webhooks/woocommerce/catalog",
    method: "POST",
    headers: {
      "user-agent": "WooCommerce/10.4.3 Hookshot (WordPress/6.8.2)",
      "content-type": "application/x-www-form-urlencoded",
    },
    body: "webhook_id=123",
    env: { WC_WEBHOOK_SECRET: "test-webhook-secret" },
  });
  const after = await processApiRequest({ path: "/api/catalog-version", method: "GET", headers: {}, env: {} });

  assert.equal(response.status, 200);
  assert.equal(response.body.ping, true);
  assert.equal(response.body.invalidated, false);
  assert.equal(after.body.revision, before.body.revision);
});

test("unsigned webhook-like requests cannot use the setup ping exception", async () => {
  const response = await processApiRequest({
    path: "/api/webhooks/woocommerce/catalog",
    method: "POST",
    headers: { "user-agent": "Mozilla/5.0" },
    body: "webhook_id=123",
    env: { WC_WEBHOOK_SECRET: "test-webhook-secret" },
  });

  assert.equal(response.status, 401);
  assert.equal(response.body.code, "invalid_webhook_signature");
});

test("lead endpoint rejects a foreign origin", async () => {
  const response = await processApiRequest({
    path: "/api/leads",
    method: "POST",
    headers: { origin: "https://attacker.example" },
    body: "{}",
    env: { PUBLIC_SITE_ORIGIN: "https://www.chinaplanet.example" },
  });

  assert.equal(response.status, 403);
  assert.equal(response.body.code, "origin_not_allowed");
});

test("B2B planning endpoint rejects a foreign origin before contacting WordPress", async () => {
  let fetchCalls = 0;
  const response = await processApiRequest({
    path: "/api/b2b/plan",
    method: "POST",
    headers: { origin: "https://attacker.example" },
    body: JSON.stringify({ lines: [{ productId: 10, variationId: 0, cartons: 2 }], container: "auto" }),
    env: {
      PUBLIC_SITE_ORIGIN: "https://www.chinaplanet.example",
      WORDPRESS_BASE_URL: "https://wordpress.example.com",
      B2B_API_SECRET: "12345678901234567890123456789012",
    },
    fetchImpl: async () => { fetchCalls += 1; throw new Error("must not be called"); },
  });

  assert.equal(response.status, 403);
  assert.equal(response.body.code, "origin_not_allowed");
  assert.equal(fetchCalls, 0);
});

test("B2B quotation endpoint rejects a foreign origin before creating a request", async () => {
  let fetchCalls = 0;
  const response = await processApiRequest({
    path: "/api/b2b/request",
    method: "POST",
    headers: { origin: "https://attacker.example", "idempotency-key": "foreign-request-key-123456" },
    body: JSON.stringify({ lines: [{ lineId: "foreign-line-001", productId: 10, variationId: 0, cartons: 2 }], container: "auto" }),
    env: { PUBLIC_SITE_ORIGIN: "https://www.chinaplanet.example", WORDPRESS_BASE_URL: "https://wordpress.example.com", B2B_API_SECRET: "12345678901234567890123456789012" },
    fetchImpl: async () => { fetchCalls += 1; throw new Error("must not be called"); },
  });
  assert.equal(response.status, 403);
  assert.equal(response.body.code, "origin_not_allowed");
  assert.equal(fetchCalls, 0);
});

test("admin login creates a server-signed session cookie", async () => {
  const adminEnv = {
    ADMIN_EMAIL: "admin@example.com",
    ADMIN_PASSWORD_HASH: await createPasswordHash("a-long-test-password-2026", "http-test-salt"),
    ADMIN_SESSION_SECRET: "12345678901234567890123456789012",
    PUBLIC_SITE_ORIGIN: "https://www.chinaplanet.example",
  };
  const login = await processApiRequest({
    path: "/api/admin/login",
    method: "POST",
    headers: { origin: "https://www.chinaplanet.example" },
    body: JSON.stringify({ email: "admin@example.com", password: "a-long-test-password-2026" }),
    env: adminEnv,
  });
  assert.equal(login.status, 200);
  assert.match(login.headers["Set-Cookie"], /HttpOnly/);

  const session = await processApiRequest({
    path: "/api/admin/session",
    method: "GET",
    headers: { cookie: login.headers["Set-Cookie"] },
    env: adminEnv,
  });
  assert.equal(session.status, 200);
  assert.equal(session.body.user.role, "website_editor");
});
