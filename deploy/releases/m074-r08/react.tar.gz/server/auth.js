import { createHmac, randomBytes, scrypt as scryptCallback, timingSafeEqual } from "node:crypto";
import { promisify } from "node:util";
import { getRuntimeConfig } from "./config.js";

const scrypt = promisify(scryptCallback);
const SESSION_COOKIE = "cp_staff_session";
const SESSION_SECONDS = 8 * 60 * 60;

function safeEqual(left, right) {
  const leftBuffer = Buffer.from(String(left));
  const rightBuffer = Buffer.from(String(right));
  return leftBuffer.length === rightBuffer.length && timingSafeEqual(leftBuffer, rightBuffer);
}

function adminIsConfigured(config) {
  return Boolean(
    config.adminEmail
    && config.adminPasswordHash.startsWith("scrypt$")
    && config.adminSessionSecret.length >= 32,
  );
}

export async function createPasswordHash(password, salt = randomBytes(16).toString("base64url")) {
  if (typeof password !== "string" || password.length < 12 || password.length > 256) {
    throw new Error("Admin password must contain between 12 and 256 characters");
  }
  const derived = await scrypt(password, salt, 64);
  return `scrypt$${salt}$${Buffer.from(derived).toString("base64url")}`;
}

async function verifyPassword(password, encodedHash) {
  const [algorithm, salt, expected] = String(encodedHash).split("$");
  if (algorithm !== "scrypt" || !salt || !expected || typeof password !== "string" || password.length > 256) return false;
  const derived = await scrypt(password, salt, 64);
  return safeEqual(Buffer.from(derived).toString("base64url"), expected);
}

export async function authenticateAdmin(email, password, env = process.env) {
  const config = getRuntimeConfig(env);
  if (!adminIsConfigured(config)) {
    throw Object.assign(new Error("Admin access is not configured"), { status: 503, code: "admin_not_configured" });
  }

  const emailMatches = safeEqual(String(email || "").trim().toLowerCase(), config.adminEmail);
  const passwordMatches = await verifyPassword(String(password || ""), config.adminPasswordHash);
  if (!emailMatches || !passwordMatches) {
    throw Object.assign(new Error("Invalid credentials"), { status: 401, code: "invalid_credentials" });
  }

  return { email: config.adminEmail, role: "website_editor" };
}

export function createSessionToken(user, env = process.env, now = Date.now()) {
  const config = getRuntimeConfig(env);
  if (!adminIsConfigured(config)) throw new Error("Admin access is not configured");
  const payload = Buffer.from(JSON.stringify({ email: user.email, role: user.role, exp: Math.floor(now / 1000) + SESSION_SECONDS })).toString("base64url");
  const signature = createHmac("sha256", config.adminSessionSecret).update(payload).digest("base64url");
  return `${payload}.${signature}`;
}

function parseCookies(headers) {
  const cookieHeader = typeof headers?.get === "function"
    ? headers.get("cookie") || ""
    : Object.entries(headers || {}).find(([key]) => key.toLowerCase() === "cookie")?.[1] || "";
  return new Map(String(cookieHeader).split(";").map((part) => {
    const index = part.indexOf("=");
    return index > 0 ? [part.slice(0, index).trim(), part.slice(index + 1).trim()] : ["", ""];
  }).filter(([key]) => key));
}

export function readAdminSession(headers, env = process.env, now = Date.now()) {
  const config = getRuntimeConfig(env);
  if (!adminIsConfigured(config)) return null;
  const token = parseCookies(headers).get(SESSION_COOKIE);
  if (!token) return null;
  const [payload, signature] = token.split(".");
  if (!payload || !signature) return null;
  const expected = createHmac("sha256", config.adminSessionSecret).update(payload).digest("base64url");
  if (!safeEqual(signature, expected)) return null;

  try {
    const parsed = JSON.parse(Buffer.from(payload, "base64url").toString("utf8"));
    if (parsed.exp <= Math.floor(now / 1000) || parsed.email !== config.adminEmail || parsed.role !== "website_editor") return null;
    return { email: parsed.email, role: parsed.role };
  } catch {
    return null;
  }
}

export function sessionCookie(token, env = process.env) {
  const config = getRuntimeConfig(env);
  const secure = config.nodeEnv === "production" ? "; Secure" : "";
  return `${SESSION_COOKIE}=${token}; Path=/; HttpOnly; SameSite=Strict; Max-Age=${SESSION_SECONDS}${secure}`;
}

export function clearSessionCookie(env = process.env) {
  const config = getRuntimeConfig(env);
  const secure = config.nodeEnv === "production" ? "; Secure" : "";
  return `${SESSION_COOKIE}=; Path=/; HttpOnly; SameSite=Strict; Max-Age=0${secure}`;
}

export function getAdminConfigurationState(env = process.env) {
  return adminIsConfigured(getRuntimeConfig(env));
}
