import { createHmac, randomUUID } from "node:crypto";
import { getRuntimeConfig } from "./config.js";

const B2B_TERMS_VERSION = "2026-08-29";
const ISO_COUNTRY_CODES = new Set("AD AE AF AG AI AL AM AO AQ AR AS AT AU AW AX AZ BA BB BD BE BF BG BH BI BJ BL BM BN BO BQ BR BS BT BV BW BY BZ CA CC CD CF CG CH CI CK CL CM CN CO CR CU CV CW CX CY CZ DE DJ DK DM DO DZ EC EE EG EH ER ES ET FI FJ FK FM FO FR GA GB GD GE GF GG GH GI GL GM GN GP GQ GR GS GT GU GW GY HK HM HN HR HT HU ID IE IL IM IN IO IQ IR IS IT JE JM JO JP KE KG KH KI KM KN KP KR KW KY KZ LA LB LC LI LK LR LS LT LU LV LY MA MC MD ME MF MG MH MK ML MM MN MO MP MQ MR MS MT MU MV MW MX MY MZ NA NC NE NF NG NI NL NO NP NR NU NZ OM PA PE PF PG PH PK PL PM PN PR PS PT PW PY QA RE RO RS RU RW SA SB SC SD SE SG SH SI SJ SK SL SM SN SO SR SS ST SV SX SY SZ TC TD TF TG TH TJ TK TL TM TN TO TR TT TV TW TZ UA UG UM US UY UZ VA VC VE VG VI VN VU WF WS YE YT ZA ZM ZW".split(" "));

function integrationError(message, code = "b2b_integration_error", status = 502) {
  return Object.assign(new Error(message), { code, status });
}

function cleanText(value, maxLength) {
  return String(value || "").trim().replace(/\s+/g, " ").slice(0, maxLength);
}

function strictInteger(value, min, max) {
  if (value === null || value === undefined || value === "") return null;
  const number = Number(value);
  return Number.isInteger(number) && number >= min && number <= max ? number : null;
}

function normalizeLines(input) {
  if (!Array.isArray(input) || input.length === 0) {
    throw integrationError("At least one B2B request line is required", "empty_b2b_request", 422);
  }
  if (input.length > 100) {
    throw integrationError("Too many B2B request lines", "too_many_b2b_lines", 422);
  }
  let totalCartons = 0;
  const lineIds = new Set();
  const lines = input.map((line) => {
    const lineId = cleanText(line?.lineId, 100);
    const productId = strictInteger(line?.productId, 1, Number.MAX_SAFE_INTEGER);
    const variationId = strictInteger(line?.variationId ?? 0, 0, Number.MAX_SAFE_INTEGER);
    const cartons = strictInteger(line?.cartons, 1, 2_000);
    if (!/^[A-Za-z0-9][A-Za-z0-9._:-]{7,99}$/.test(lineId) || lineIds.has(lineId) || productId === null || cartons === null) {
      throw integrationError("A B2B request line is invalid", "invalid_b2b_line", 422);
    }
    lineIds.add(lineId);
    if (variationId === null) {
      throw integrationError("A B2B product option is invalid", "invalid_b2b_variation", 422);
    }
    totalCartons += cartons;
    return { lineId, productId, variationId, cartons };
  });
  if (totalCartons > 5_000) {
    throw integrationError("The request exceeds the carton calculation limit", "b2b_carton_limit", 422);
  }
  return lines;
}

function normalizeContainer(value) {
  const container = cleanText(value || "auto", 24).toLowerCase();
  if (!["auto", "20gp", "40gp", "40hq"].includes(container)) {
    throw integrationError("The selected container is invalid", "invalid_b2b_container", 422);
  }
  return container;
}

function normalizeLocale(value) {
  const locale = cleanText(value || "ar", 12).toLowerCase().slice(0, 2);
  return ["ar", "en", "fr"].includes(locale) ? locale : "ar";
}

function normalizePackingSource(value, variationId) {
  const source = cleanText(value, 40).toLowerCase();
  if (["woocommerce_product", "woocommerce_variation"].includes(source)) return source;
  return variationId > 0 ? "woocommerce_variation" : "woocommerce_product";
}

function nullablePositiveNumber(value, max = 1_000_000_000) {
  if (value === null || value === undefined || value === "") return null;
  const number = Number(value);
  return Number.isFinite(number) && number > 0 && number <= max ? number : null;
}

function nullableNonNegativeNumber(value, max = 1_000_000_000) {
  if (value === null || value === undefined || value === "") return null;
  const number = Number(value);
  return Number.isFinite(number) && number >= 0 && number <= max ? number : null;
}

function safeContainer(value) {
  const source = value && typeof value === "object" ? value : {};
  const id = cleanText(source.id, 24).toLowerCase();
  if (id && !["20gp", "40gp", "40hq"].includes(id)) return null;
  return {
    id: id || null,
    label: cleanText(source.label, 80) || null,
    name: cleanText(source.name, 80) || null,
    length: nullablePositiveNumber(source.length ?? source.internalLength ?? source.internal_length, 100_000),
    width: nullablePositiveNumber(source.width ?? source.internalWidth ?? source.internal_width, 100_000),
    height: nullablePositiveNumber(source.height ?? source.internalHeight ?? source.internal_height, 100_000),
  };
}

function safePlacement(value, knownLineIds) {
  const lineId = cleanText(value?.lineId || value?.line_key, 100);
  const x = nullableNonNegativeNumber(value?.x, 100_000);
  const y = nullableNonNegativeNumber(value?.y, 100_000);
  const z = nullableNonNegativeNumber(value?.z, 100_000);
  const length = nullablePositiveNumber(value?.length ?? value?.l, 100_000);
  const width = nullablePositiveNumber(value?.width ?? value?.w, 100_000);
  const height = nullablePositiveNumber(value?.height ?? value?.h, 100_000);
  if (!knownLineIds.has(lineId) || [x, y, z, length, width, height].some((item) => item === null)) return null;
  return {
    lineId, line_key: lineId,
    cartonIndex: Number.isInteger(Number(value?.cartonIndex ?? value?.carton_index)) ? Number(value?.cartonIndex ?? value?.carton_index) : null,
    x, y, z, length, width, height,
    orientation: cleanText(value?.orientation, 8) || null,
    color: /^#[0-9a-f]{6}$/i.test(String(value?.color || "")) ? String(value.color).toLowerCase() : null,
    visualOnly: value?.visualOnly === true || value?.visual_only === true,
  };
}

function publicPlanProjection(plan, lines) {
  const source = plan && typeof plan === "object" ? plan : {};
  const readyLineIds = new Set(lines.filter((line) => line.calculationReady).map((line) => line.lineId));
  const totalsSource = source.totals && typeof source.totals === "object" ? source.totals : {};
  const number = (key, max = 1_000_000_000) => nullableNonNegativeNumber(totalsSource[key], max) ?? 0;
  return {
    ok: source.ok === true,
    success: source.success === true,
    reason: cleanText(source.reason, 80) || null,
    container: safeContainer(source.container),
    containers: (Array.isArray(source.containers) ? source.containers : []).map(safeContainer).filter(Boolean).slice(0, 10),
    placements: (Array.isArray(source.placements) ? source.placements : []).map((item) => safePlacement(item, readyLineIds)).filter(Boolean).slice(0, 5_000),
    totals: {
      cartons: number("cartons", 5_000), calculated_cartons: number("calculated_cartons", 5_000), units: number("units"),
      cbm: number("cbm", 100_000), gross_weight: number("gross_weight"), remaining_cbm: number("remaining_cbm", 100_000), remaining_payload: number("remaining_payload"),
      units_complete: totalsSource.units_complete === true, weight_complete: totalsSource.weight_complete === true,
      missing_weight_cartons: number("missing_weight_cartons", 5_000),
    },
    selectionMode: ["auto", "20gp", "40gp", "40hq"].includes(cleanText(source.selectionMode, 24).toLowerCase()) ? cleanText(source.selectionMode, 24).toLowerCase() : "auto",
    visual_mode: ["dimensional", "aggregate_volume", "hybrid_volume"].includes(cleanText(source.visual_mode || source.visualMode, 32)) ? cleanText(source.visual_mode || source.visualMode, 32) : null,
    calculationReadyLines: lines.filter((line) => line.calculationReady).length,
    excludedItems: lines.filter((line) => !line.calculationReady).map((line) => ({ lineId: line.lineId, reason: "packing_data_missing", missingFields: [...line.missingFields] })),
    warnings: (Array.isArray(source.warnings) ? source.warnings : []).map((item) => cleanText(item, 240)).filter(Boolean).slice(0, 20),
  };
}

function normalizeAuthoritativeLines(response, requestedLines) {
  const upstreamLines = Array.isArray(response?.lines) ? response.lines : [];
  if (upstreamLines.length !== requestedLines.length) {
    throw integrationError("The verified product snapshot is incomplete", "invalid_b2b_snapshot", 502);
  }
  const expected = new Map(requestedLines.map((line) => [line.lineId, line]));
  const normalized = upstreamLines.map((line) => {
    const lineId = cleanText(line?.lineId, 100);
    const productId = strictInteger(line?.productId, 1, Number.MAX_SAFE_INTEGER);
    const variationId = strictInteger(line?.variationId ?? 0, 0, Number.MAX_SAFE_INTEGER);
    const cartons = strictInteger(line?.cartons, 1, 2_000);
    const requested = expected.get(lineId);
    if (!requested || requested.productId !== productId || requested.variationId !== variationId || requested.cartons !== cartons) {
      throw integrationError("The verified product snapshot does not match the request", "invalid_b2b_snapshot", 502);
    }
    expected.delete(lineId);
    let image = cleanText(line?.image, 1_000);
    try {
      if (image && new URL(image).protocol !== "https:") image = "";
    } catch {
      image = "";
    }
    const unitsPerCarton = strictInteger(line?.unitsPerCarton, 1, 1_000_000);
    const cbmPerCarton = nullablePositiveNumber(line?.cbmPerCarton, 1_000_000);
    const grossWeightKg = nullablePositiveNumber(line?.grossWeightKg, 1_000_000);
    const packingComplete = line?.packingComplete === true;
    const missingFields = [];
    if (unitsPerCarton === null) missingFields.push("unitsPerCarton");
    if (cbmPerCarton === null) missingFields.push("cbmPerCarton");
    if (grossWeightKg === null) missingFields.push("grossWeightKg");
    if (!packingComplete) missingFields.push("packingComplete");
    const upstreamMissing = Array.isArray(line?.missingFields) ? line.missingFields.map((field) => cleanText(field, 40)) : [];
    if (upstreamMissing.length !== missingFields.length || upstreamMissing.some((field, index) => field !== missingFields[index])) {
      throw integrationError("The verified packing status is inconsistent", "invalid_b2b_snapshot", 502);
    }
    const calculationReady = missingFields.length === 0;
    if ((line?.calculationReady === true) !== calculationReady) throw integrationError("The verified packing status is inconsistent", "invalid_b2b_snapshot", 502);
    const visibility = ["public", "hidden", "login_required", "request_quote"].includes(line?.price?.visibility) ? line.price.visibility : "request_quote";
    const priceMode = ["fixed", "range", "request", "unavailable"].includes(line?.price?.mode) ? line.price.mode : "request";
    const currency = /^[A-Z]{3}$/.test(String(line?.price?.currency || "")) ? String(line.price.currency) : null;
    const unitPrice = visibility === "public" ? nullablePositiveNumber(line?.price?.unitPrice) : null;
    const minUnitPrice = visibility === "public" ? nullablePositiveNumber(line?.price?.minUnitPrice) : null;
    const maxUnitPrice = visibility === "public" ? nullablePositiveNumber(line?.price?.maxUnitPrice) : null;
    if (visibility !== "public" && (line?.price?.currency != null || line?.price?.unitPrice != null || line?.price?.minUnitPrice != null || line?.price?.maxUnitPrice != null)) throw integrationError("A hidden price was exposed", "invalid_b2b_snapshot", 502);
    if (visibility === "public" && (!currency || (priceMode === "fixed" && unitPrice === null) || (priceMode === "range" && (minUnitPrice === null || maxUnitPrice === null || minUnitPrice > maxUnitPrice)))) throw integrationError("The verified public price is invalid", "invalid_b2b_snapshot", 502);
    const requestedPieces = unitsPerCarton === null ? null : unitsPerCarton * cartons;
    return {
      lineId, productId, variationId, cartons,
      sku: cleanText(line?.sku, 128),
      name: cleanText(line?.name, 255),
      optionLabel: cleanText(line?.optionLabel, 255),
      image,
      unitsPerCarton,
      requestedPieces,
      cbmPerCarton,
      totalCbm: calculationReady ? cbmPerCarton * cartons : null,
      grossWeightKg,
      totalGrossWeightKg: calculationReady ? grossWeightKg * cartons : null,
      packingComplete,
      packingSource: normalizePackingSource(line?.packingSource, variationId),
      calculationReady,
      missingFields,
      price: { visibility, mode: priceMode, unit: "piece", currency, unitPrice, minUnitPrice, maxUnitPrice },
      sourceSnapshot: {
        provider: "woocommerce",
        productId,
        variationId,
        sku: cleanText(line?.sourceSnapshot?.sku || line?.sku, 128),
        name: cleanText(line?.sourceSnapshot?.name || line?.name, 255),
      },
    };
  });
  if (expected.size !== 0) throw integrationError("The verified product snapshot is incomplete", "invalid_b2b_snapshot", 502);
  return normalized;
}

function contractLine(line) {
  return {
    lineId: line.lineId,
    source: "woocommerce",
    productId: line.productId,
    variationId: line.variationId,
    sku: line.sku,
    name: line.name,
    optionLabel: line.optionLabel,
    image: line.image || null,
    cartons: line.cartons,
    unitsPerCarton: line.unitsPerCarton,
    cbmPerCarton: line.cbmPerCarton,
    grossWeightKg: line.grossWeightKg,
    packingComplete: line.packingComplete,
    packingSource: line.packingSource,
    calculationReady: line.calculationReady,
    missingFields: [...line.missingFields],
    price: { ...line.price },
  };
}

function contractPackingPlan(plan, lines, requestedContainer) {
  const source = plan && typeof plan === "object" ? plan : {};
  const readyLineIds = new Set(lines.filter((line) => line.calculationReady).map((line) => line.lineId));
  const placements = (Array.isArray(source.placements) ? source.placements : []).map((placement) => safePlacement(placement, readyLineIds)).filter(Boolean);
  return {
    container: requestedContainer,
    calculationAvailable: lines.some((line) => line.calculationReady),
    requestCartons: lines.reduce((sum, line) => sum + line.cartons, 0),
    calculatedCartons: lines.filter((line) => line.calculationReady).reduce((sum, line) => sum + line.cartons, 0),
    placements,
    excludedItems: lines.filter((line) => !line.calculationReady).map((line) => ({ lineId: line.lineId, reason: "packing_data_missing", missingFields: [...line.missingFields] })),
  };
}

async function enrichAuthoritativeLines(lines, { env, fetchImpl }) {
  const config = getRuntimeConfig(env);
  return Promise.all(lines.map(async (line) => {
    const url = endpoint(config, "catalog");
    url.searchParams.set("page", "1");
    url.searchParams.set("per_page", "12");
    url.searchParams.set("search", line.sku || String(line.productId));
    const response = await fetchImpl(url, { headers: { Accept: "application/json" }, redirect: "error", signal: AbortSignal.timeout(20_000) });
    assertUpstreamOrigin(response, url);
    const catalog = await parseUpstream(response);
    const product = (Array.isArray(catalog?.products) ? catalog.products : []).find((item) => Number(item?.id) === line.productId);
    if (!product) return line;
    const variation = line.variationId > 0
      ? (Array.isArray(product.variations) ? product.variations : []).find((item) => Number(item?.id) === line.variationId)
      : null;
    let image = cleanText(variation?.image || product?.images?.[0], 1_000);
    try { if (image && new URL(image).protocol !== "https:") image = ""; } catch { image = ""; }
    return {
      ...line,
      name: cleanText(product?.name || line.name, 255),
      optionLabel: cleanText(variation?.label || line.optionLabel, 255),
      image,
    };
  }));
}

function normalizeCustomer(value) {
  const customer = value && typeof value === "object" ? value : {};
  const normalized = {
    name: cleanText(customer.name, 120),
    phone: cleanText(customer.phone, 40),
    email: cleanText(customer.email, 190).toLowerCase(),
    company: cleanText(customer.company, 160),
    country: cleanText(customer.country, 8).toUpperCase(),
    notes: cleanText(customer.notes, 2_000),
    consent: customer.consent === true,
    consentAcceptedAt: cleanText(customer.consentAcceptedAt, 40),
  };
  const consentDate = new Date(normalized.consentAcceptedAt);
  if (normalized.name.length < 2 || normalized.phone.length < 6 || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(normalized.email) || !normalized.consent || Number.isNaN(consentDate.getTime())) {
    throw integrationError("Name, phone, email and consent are required", "invalid_b2b_customer", 422);
  }
  if (!ISO_COUNTRY_CODES.has(normalized.country)) throw integrationError("A valid destination country is required", "invalid_b2b_country", 422);
  normalized.consentAcceptedAt = consentDate.toISOString();
  return normalized;
}

function endpoint(config, pathname) {
  if (!config.wordpressBaseUrl) throw integrationError("WordPress is not configured", "b2b_not_configured", 503);
  return new URL(`/wp-json/chinaplanet-b2b/v1/${pathname}`, config.wordpressBaseUrl);
}

async function parseUpstream(response) {
  const payload = await response.json().catch(() => ({}));
  if (!response.ok) {
    const upstreamStatus = Number(response.status) || 502;
    const status = upstreamStatus >= 500 ? 502 : upstreamStatus;
    throw integrationError(
      payload?.message || "The B2B service could not complete the request",
      payload?.code || "b2b_upstream_error",
      status,
    );
  }
  return payload;
}

function assertUpstreamOrigin(response, expectedUrl) {
  if (!response?.url) return;
  let finalUrl;
  try {
    finalUrl = new URL(response.url);
  } catch {
    throw integrationError("The B2B service returned an invalid destination", "b2b_upstream_origin", 502);
  }
  if (finalUrl.origin !== expectedUrl.origin) throw integrationError("The B2B service changed destination", "b2b_upstream_origin", 502);
}

function signedHeaders(body, config, idempotencyKey = "") {
  if (String(config.b2bApiSecret || "").length < 32) {
    throw integrationError("The B2B server integration is not configured", "b2b_not_configured", 503);
  }
  const timestamp = String(Math.floor(Date.now() / 1_000));
  const signature = createHmac("sha256", config.b2bApiSecret).update(`${timestamp}.${body}`).digest("hex");
  return {
    Accept: "application/json",
    "Content-Type": "application/json",
    "X-ChinaPlanet-Timestamp": timestamp,
    "X-ChinaPlanet-Signature": `sha256=${signature}`,
    ...(idempotencyKey ? { "Idempotency-Key": idempotencyKey } : {}),
  };
}

async function signedPost(pathname, payload, { env, fetchImpl, idempotencyKey = "" }) {
  const config = getRuntimeConfig(env);
  const body = JSON.stringify(payload);
  const url = endpoint(config, pathname);
  const response = await fetchImpl(url, {
    method: "POST",
    headers: signedHeaders(body, config, idempotencyKey),
    body,
    redirect: "error",
    signal: AbortSignal.timeout(20_000),
  });
  assertUpstreamOrigin(response, url);
  return parseUpstream(response);
}

export async function fetchB2bCatalog({ query = {}, env = process.env, fetchImpl = fetch } = {}) {
  const config = getRuntimeConfig(env);
  const url = endpoint(config, "catalog");
  const page = Math.max(1, Number.parseInt(query.page || "1", 10) || 1);
  const perPage = Math.min(48, Math.max(1, Number.parseInt(query.per_page || query.perPage || "24", 10) || 24));
  const search = cleanText(query.search, 120);
  const category = cleanText(query.category, 120);
  url.searchParams.set("page", String(page));
  url.searchParams.set("per_page", String(perPage));
  if (search) url.searchParams.set("search", search);
  if (category) url.searchParams.set("category", category);
  const response = await fetchImpl(url, { headers: { Accept: "application/json" }, redirect: "error", signal: AbortSignal.timeout(20_000) });
  assertUpstreamOrigin(response, url);
  return parseUpstream(response);
}

export async function calculateB2bPlan(input, { env = process.env, fetchImpl = fetch } = {}) {
  const payload = {
    request_type: "catalog_order",
    schema_version: 2,
    container: normalizeContainer(input?.container),
    lines: normalizeLines(input?.lines),
  };
  const plan = await signedPost("plan", payload, { env, fetchImpl });
  const lines = normalizeAuthoritativeLines(plan, payload.lines);
  return {
    ok: plan?.ok === true,
    plan: publicPlanProjection(plan?.plan, lines),
    lines,
  };
}

export async function createB2bRequest(input, { env = process.env, fetchImpl = fetch, idempotencyKey = "" } = {}) {
  const safeIdempotencyKey = cleanText(idempotencyKey, 100) || randomUUID();
  if (safeIdempotencyKey.length < 16) {
    throw integrationError("The request identifier is invalid", "invalid_idempotency_key", 422);
  }
  const payload = {
    request_type: "catalog_order",
    schema_version: 2,
    container: normalizeContainer(input?.container),
    lines: normalizeLines(input?.lines),
    customer: normalizeCustomer(input?.customer),
  };
  const plan = await signedPost("plan", { request_type: "catalog_order", schema_version: 2, container: payload.container, lines: payload.lines }, { env, fetchImpl });
  const authoritativeLines = await enrichAuthoritativeLines(normalizeAuthoritativeLines(plan, payload.lines), { env, fetchImpl });
  const contractLines = authoritativeLines.map(contractLine);
  const packingPlan = contractPackingPlan(publicPlanProjection(plan?.plan, contractLines), contractLines, payload.container);
  const planCurrency = contractLines.find((line) => line.price?.currency)?.price.currency || null;
  const { submitWebsiteRequest } = await import("./dolibarr.js");
  return submitWebsiteRequest({
    request_type: "catalog_order",
    schema_version: 2,
    idempotency_key: safeIdempotencyKey,
    locale: normalizeLocale(input?.locale),
    contact: {
      name: payload.customer.name, company: payload.customer.company, phone: payload.customer.phone,
      email: payload.customer.email, country_code: payload.customer.country,
    },
    consent: { privacy: true, terms_version: B2B_TERMS_VERSION, accepted_at: payload.customer.consentAcceptedAt },
    details: { message: payload.customer.notes, lines: contractLines, packing_plan: packingPlan, currency: planCurrency, source_reference: "woocommerce" },
  }, { env, fetchImpl });
}

export const __test = { normalizeLines, normalizeContainer, normalizeCustomer, normalizeAuthoritativeLines, publicPlanProjection, signedHeaders, assertUpstreamOrigin };
