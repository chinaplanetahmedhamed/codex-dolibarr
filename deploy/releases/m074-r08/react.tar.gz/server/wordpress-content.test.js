import test from "node:test";
import assert from "node:assert/strict";
import { createHmac } from "node:crypto";
import {
  fetchChinaGuide,
  fetchChinaGuidePlaceDetail,
  fetchWordPressPosts,
  sanitizeWordPressHtml,
  stripMarkdownArtifacts,
  verifyWordPressContentWebhook,
} from "./wordpress-content.js";

function response(value) {
  return { ok: true, status: 200, json: async () => value };
}

test("WordPress HTML sanitizer removes scripts and unsafe browser attributes", () => {
  const html = sanitizeWordPressHtml('<head><script>alert(1)</script></head><h2 onclick="steal()">عنوان</h2><img src="https://images.example/photo.jpg" onerror="steal()"><a href="javascript:steal()">bad</a>');
  assert.match(html, /<h2>عنوان<\/h2>/);
  assert.match(html, /loading="lazy"/);
  assert.doesNotMatch(html, /script|onclick|onerror|javascript:/i);
});

test("public excerpts do not expose Markdown control markers", () => {
  assert.equal(stripMarkdownArtifacts('## دليل **فحص المصنع** مع [التفاصيل](https://example.com)'), 'دليل فحص المصنع مع التفاصيل');
});

test("post adapter fetches only approved categories and returns sanitized content", async () => {
  const fetchImpl = async (url) => {
    const endpoint = new URL(url);
    if (endpoint.pathname.endsWith("/categories")) {
      return response([
        { id: 34, slug: "importing-from-china", name: "الاستيراد من الصين", count: 1 },
        { id: 999, slug: "unapproved", name: "غير معتمد", count: 50 },
      ]);
    }
    assert.equal(endpoint.searchParams.get("categories"), "34");
    return response([{
      id: 7,
      slug: "safe-post",
      date: "2026-07-01T10:00:00",
      modified: "2026-07-02T10:00:00",
      title: { rendered: "دليل آمن" },
      excerpt: { rendered: "<p>ملخص المقال</p>" },
      content: { rendered: "<p>محتوى مفيد</p><script>bad()</script>" },
      categories: [34],
      _embedded: { author: [{ name: "فريق كوكب الصين" }] },
    }]);
  };

  const result = await fetchWordPressPosts({
    env: {
      WORDPRESS_BASE_URL: "https://wordpress.example.com",
      WP_POST_CATEGORY_ALLOWLIST: "importing-from-china",
      WP_CONTENT_MAX_PAGES: "1",
    },
    fetchImpl,
  });
  assert.equal(result.posts.length, 1);
  assert.equal(result.posts[0].category, "الاستيراد من الصين");
  assert.doesNotMatch(result.posts[0].contentHtml, /script/i);
});

test("China Guide adapter preserves the city and place-type relationship", async () => {
  const fetchImpl = async (url) => {
    const endpoint = new URL(url);
    const pathname = endpoint.pathname;
    if (pathname.endsWith("/china_guide")) {
      assert.equal(endpoint.searchParams.has("_embed"), false);
      assert.match(endpoint.searchParams.get("_fields"), /chinaplanet_headless\.excerpt/);
      assert.doesNotMatch(endpoint.searchParams.get("_fields"), /chinaplanet_headless\.content/);
      return response([{ id: 10, slug: "market", title: { rendered: "\u0633\u0648\u0642 \u062a\u062c\u0627\u0631\u064a" }, status: "publish", china_city: [2], place_type: [3], place_tag: [], meta: { _main_image_url: "https://images.example.com/place.jpg", _place_desc: "\u0648\u0635\u0641 \u0642\u0635\u064a\u0631 \u0648\u0645\u0641\u064a\u062f", _address_en: "No. 1 Market Road, Guangzhou", _address_zh: "\u5e7f\u5dde\u5e02\u5e02\u573a\u8def1\u53f7", _phone_number: "020-12345678", _map_url: "https://uri.amap.com/search?keyword=market&city=guangzhou" }, chinaplanet_headless: { excerpt: "\u0645\u0644\u062e\u0635 \u0642\u062f\u064a\u0645 \u0637\u0648\u064a\u0644", publicMeta: [] } }]);
    }
    if (pathname.endsWith("/china_city")) return response([{ id: 2, slug: "guangzhou", name: "Guangzhou", count: 1, meta: { kcg_city_image_id: 55 } }]);
    if (pathname.endsWith("/place_type")) return response([{ id: 3, slug: "wholesale-markets", name: "أسواق جملة", count: 1 }]);
    if (pathname.endsWith("/place_tag")) return response([]);
    if (pathname.endsWith("/media")) {
      return endpoint.searchParams.get("include") === "55"
        ? response([{ id: 55, source_url: "https://images.example.com/city.jpg" }])
        : response([]);
    }
    throw new Error(`Unexpected endpoint ${pathname}`);
  };
  const result = await fetchChinaGuide({ env: { WORDPRESS_BASE_URL: "https://wordpress.example.com", WP_CONTENT_MAX_PAGES: "1" }, fetchImpl });
  assert.equal(result.places[0].city, "Guangzhou");
  assert.equal(result.places[0].type, "أسواق جملة");
  assert.equal(result.places[0].address, "No. 1 Market Road, Guangzhou");
  assert.equal(result.places[0].addressZh, "\u5e7f\u5dde\u5e02\u5e02\u573a\u8def1\u53f7");
  assert.equal(result.places[0].phone, "020-12345678");
  assert.equal(result.places[0].mapUrl, "https://uri.amap.com/search?keyword=market&city=guangzhou");
  assert.equal(result.places[0].excerpt, "\u0648\u0635\u0641 \u0642\u0635\u064a\u0631 \u0648\u0645\u0641\u064a\u062f");
  assert.equal(result.places[0].contentHtml, "<p>\u0648\u0635\u0641 \u0642\u0635\u064a\u0631 \u0648\u0645\u0641\u064a\u062f</p>");
  assert.equal(result.places[0].image, "https://images.example.com/place.jpg");
  assert.equal(result.cities[0].image, "https://images.example.com/city.jpg");
  assert.equal(result.detailsAvailable, true);
});

test("Guide detail adapter extracts and sanitizes the existing WordPress page", async () => {
  const html = `<!doctype html><html><head>
    <meta name="description" content="دليل سوق كوانزو">
    <meta property="og:image" content="https://images.example/market.jpg">
    </head><body><div class="entry-content"><p>## 1. معلومات السوق<br><strong>العنوان:</strong> Guangzhou, China</p><script>bad()</script><p>رابط الخريطة: https://www.google.com/maps/search/market</p></div></body></html>`;
  const detail = await fetchChinaGuidePlaceDetail({
    id: "guide-1",
    slug: "market",
    title: "سوق كوانزو",
    city: "Guangzhou",
    type: "أسواق جملة",
    image: "/images/hero.webp",
    sourceUrl: "https://wordpress.example.com/china_guide/market/",
  }, {
    env: { WORDPRESS_BASE_URL: "https://wordpress.example.com" },
    fetchImpl: async () => ({ ok: true, status: 200, text: async () => html }),
  });
  assert.equal(detail.image, "https://images.example/market.jpg");
  assert.equal(detail.address, "Guangzhou, China");
  assert.match(detail.contentHtml, /<h2>1\. معلومات السوق<\/h2>/);
  assert.doesNotMatch(detail.contentHtml, /script|bad\(\)/i);
  assert.match(detail.mapUrl, /^https:\/\/www\.google\.com\/maps/);
});

test("Guide detail keeps the current headless CMS image over a stale social image", async () => {
  const html = `<!doctype html><html><head>
    <meta property="og:image" content="https://legacy.example/old-guide.jpg">
    <meta name="description" content="Stale guide summary">
    </head><body><div class="entry-content"><p>Stale guide details</p></div></body></html>`;
  const detail = await fetchChinaGuidePlaceDetail({
    id: "guide-2",
    slug: "updated-market",
    title: "Updated market",
    image: "https://wordpress.example.com/wp-content/uploads/2026/08/new-guide.jpg",
    excerpt: "Current concise summary",
    contentHtml: "<p>Current concise details</p>",
    address: "Current address",
    mapUrl: "https://uri.amap.com/search?keyword=updated-market",
    sourceUrl: "https://wordpress.example.com/china_guide/updated-market/",
  }, {
    env: { WORDPRESS_BASE_URL: "https://wordpress.example.com" },
    fetchImpl: async () => ({ ok: true, status: 200, text: async () => html }),
  });

  assert.equal(detail.image, "https://wordpress.example.com/wp-content/uploads/2026/08/new-guide.jpg");
  assert.equal(detail.excerpt, "Current concise summary");
  assert.equal(detail.metaDescription, "Current concise summary");
  assert.equal(detail.contentHtml, "<p>Current concise details</p>");
  assert.equal(detail.address, "Current address");
  assert.equal(detail.mapUrl, "https://uri.amap.com/search?keyword=updated-market");
});

test("WordPress content webhook requires the shared HMAC signature", () => {
  const body = JSON.stringify({ post_id: 10, event: "updated" });
  const secret = "content-webhook-secret";
  const signature = createHmac("sha256", secret).update(body).digest("base64");
  assert.equal(verifyWordPressContentWebhook(body, signature, secret), true);
  assert.equal(verifyWordPressContentWebhook(body, "wrong", secret), false);
});
