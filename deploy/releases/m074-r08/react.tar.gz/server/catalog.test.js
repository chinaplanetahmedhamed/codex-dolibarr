import test from "node:test";
import assert from "node:assert/strict";
import { fetchWooCatalog, mapWooCategory, mapWooProduct, mapWooStoreProduct } from "./catalog.js";

test("mapWooProduct exposes customer-safe catalog and carton fields", () => {
  const mapped = mapWooProduct({
    id: 42,
    sku: "CP-42",
    name: "<strong>آلة تعبئة</strong>",
    short_description: "<p>وصف المنتج</p>",
    price: "100",
    stock_status: "instock",
    categories: [{ id: 7, name: "الآلات" }],
    images: [{ src: "https://images.example.com/product.jpg" }],
    meta_data: [
      { key: "_b2bclp_units_per_carton", value: "12" },
      { key: "_b2bclp_carton_length", value: "50" },
      { key: "_b2bclp_carton_width", value: "40" },
      { key: "_b2bclp_carton_height", value: "30" },
      { key: "_internal_supplier_cost", value: "25" },
    ],
  });

  assert.equal(mapped.id, "wc-42");
  assert.equal(mapped.title, "آلة تعبئة");
  assert.equal(mapped.pcsPerCarton, 12);
  assert.equal(mapped.cbmPerCarton, 0.06);
  assert.equal("_internal_supplier_cost" in mapped, false);
});

test("mapWooStoreProduct maps public products and carton quantities per variation", () => {
  const mapped = mapWooStoreProduct({
    id: 108151,
    sku: "WP-E1003",
    name: "FEMALE THREADED COUPLING",
    permalink: "https://wordpress.example.com/product/coupling/",
    short_description: "<p>Public description</p>",
    prices: { price: "1250", currency_code: "USD", currency_minor_unit: 2 },
    is_in_stock: true,
    has_options: true,
    categories: [{ id: 413, name: "Fittings" }],
    images: [{ src: "https://images.example.com/fitting.jpg" }],
    variations: [
      { id: 2001, attributes: [{ name: "size", value: "20*3/4" }, { name: "PCS/CTN", value: "560" }] },
      { id: 2002, attributes: [{ name: "size", value: "25*1" }, { name: "PCS/CTN", value: "320" }] },
    ],
  });

  assert.equal(mapped.price, "12.50");
  assert.equal(mapped.currency, "USD");
  assert.equal(mapped.pcsPerCarton, null);
  assert.equal(mapped.variants.length, 2);
  assert.equal(mapped.variants[0].label, "20*3/4");
  assert.equal(mapped.variants[0].pcsPerCarton, 560);
  assert.equal(mapped.variants[0].wooVariationId, 2001);
  assert.deepEqual(mapped.categoryIds, ["413"]);
});

test("mapWooCategory preserves the WooCommerce parent relationship", () => {
  const mapped = mapWooCategory({
    id: 413,
    parent: 377,
    name: "&#8211; PP Fittings",
    slug: "pp-fittings",
    count: 39,
    image: { src: "https://images.example.com/category.jpg" },
  });

  assert.deepEqual(mapped, {
    id: "413",
    parentId: "377",
    name: "– PP Fittings",
    slug: "pp-fittings",
    count: 39,
    image: "https://images.example.com/category.jpg",
  });
});

test("fetchWooCatalog sends credentials in an Authorization header, not the URL", async () => {
  const capturedUrls = [];
  let capturedHeaders = {};
  const fetchImpl = async (url, options) => {
    capturedUrls.push(String(url));
    capturedHeaders = options.headers;
    return { ok: true, status: 200, json: async () => [] };
  };

  const result = await fetchWooCatalog({
    env: {
      WORDPRESS_BASE_URL: "https://wordpress.example.com",
      WC_CONSUMER_KEY: "ck_test",
      WC_CONSUMER_SECRET: "cs_test",
      CATALOG_MAX_PAGES: "1",
    },
    fetchImpl,
  });

  assert.deepEqual(result.products, []);
  assert.equal(capturedUrls.every((url) => !url.includes("consumer_key")), true);
  assert.equal(capturedUrls.some((url) => url.includes("/products/categories")), true);
  assert.match(capturedHeaders.Authorization, /^Basic /);
});

test("fetchWooCatalog uses the public Store API when read-only credentials are absent", async () => {
  const capturedUrls = [];
  let capturedHeaders = {};
  const fetchImpl = async (url, options) => {
    capturedUrls.push(String(url));
    capturedHeaders = options.headers;
    return { ok: true, status: 200, json: async () => [] };
  };

  const result = await fetchWooCatalog({
    env: {
      WORDPRESS_BASE_URL: "https://wordpress.example.com",
      CATALOG_MAX_PAGES: "1",
    },
    fetchImpl,
  });

  assert.equal(result.mode, "store_api");
  assert.equal(capturedUrls.some((url) => /\/wp-json\/wc\/store\/v1\/products\?/.test(url)), true);
  assert.equal(capturedUrls.some((url) => /\/products\/categories\?/.test(url)), true);
  assert.equal(capturedHeaders.Authorization, undefined);
});
