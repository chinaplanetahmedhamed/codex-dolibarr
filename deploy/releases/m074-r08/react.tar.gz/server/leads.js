import { randomUUID } from "node:crypto";
import { submitWebsiteRequest } from "./dolibarr.js";

function cleanText(value, maxLength) {
  return stripControlCharacters(value, false).replace(/\s+/g, " ").trim().slice(0, maxLength);
}

function cleanMultiline(value, maxLength) {
  return stripControlCharacters(value, true).trim().slice(0, maxLength);
}

function stripControlCharacters(value, preserveLineBreaks) {
  return Array.from(String(value || ""), (character) => {
    const code = character.charCodeAt(0);
    if (preserveLineBreaks && (code === 10 || code === 13 || code === 9)) return character;
    return code < 32 || code === 127 ? " " : character;
  }).join("");
}

function isEmail(value) {
  return !value || /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value);
}

export function validateLeadPayload(input) {
  const type = input?.type === "catalog_order" ? "catalog_order" : "quote_request";
  const clientName = cleanText(input?.clientName, 120);
  const phone = cleanText(input?.phone, 40);
  const email = cleanText(input?.email, 180).toLowerCase();
  const website = cleanText(input?.website, 200);

  if (website) throw Object.assign(new Error("Request rejected"), { status: 400, code: "invalid_request" });
  if (clientName.length < 2) throw Object.assign(new Error("Client name is required"), { status: 422, code: "invalid_client_name" });
  if (phone.replace(/\D/g, "").length < 7) throw Object.assign(new Error("A valid phone number is required"), { status: 422, code: "invalid_phone" });
  if (!isEmail(email)) throw Object.assign(new Error("A valid email address is required"), { status: 422, code: "invalid_email" });
  if (input?.consent !== true) throw Object.assign(new Error("Consent is required"), { status: 422, code: "consent_required" });

  const items = (Array.isArray(input?.items) ? input.items : []).slice(0, 100).map((item) => ({
    productId: cleanText(item?.id || item?.productId, 80),
    wooProductId: Number.isInteger(Number(item?.wooProductId)) ? Number(item.wooProductId) : null,
    wooVariationId: Number.isInteger(Number(item?.wooVariationId)) ? Number(item.wooVariationId) : null,
    sku: cleanText(item?.sku, 100),
    title: cleanText(item?.title, 240),
    selectedOptionLabel: cleanText(item?.selectedOptionLabel, 240),
    quantity: cleanText(item?.quantity, 80),
    cartons: Number.isFinite(Number(item?.cartons)) ? Number(item.cartons) : null,
    piecesPerCarton: Number.isFinite(Number(item?.pcsPerCarton)) ? Number(item.pcsPerCarton) : null,
    cbmPerCarton: Number.isFinite(Number(item?.cbmPerCarton)) ? Number(item.cbmPerCarton) : null,
    comment: cleanMultiline(item?.comment, 1000),
  })).filter((item) => item.productId || item.title);

  const productName = cleanText(input?.productName, 240);
  if (type === "catalog_order" && items.length === 0) {
    throw Object.assign(new Error("At least one catalog item is required"), { status: 422, code: "empty_catalog_order" });
  }
  if (type === "quote_request" && !productName) {
    throw Object.assign(new Error("Product or service is required"), { status: 422, code: "missing_product" });
  }

  return {
    type,
    clientName,
    phone,
    email,
    company: cleanText(input?.company, 180),
    country: cleanText(input?.country, 100),
    productName,
    quantity: cleanText(input?.quantity, 120),
    targetPrice: cleanText(input?.targetPrice, 120),
    serviceRequired: cleanText(input?.serviceRequired, 240),
    notes: cleanMultiline(input?.notes || input?.generalNotes, 4000),
    items,
    consent: input?.consent === true,
  };
}

export async function deliverLead(input, { env = process.env, fetchImpl = fetch, idempotencyKey = "" } = {}) {
  const lead = validateLeadPayload(input);
  const safeKey = cleanText(idempotencyKey, 100) || randomUUID();
  if (safeKey.length < 16) throw Object.assign(new Error("Invalid request identifier"), { status: 422, code: "invalid_idempotency_key" });
  const countryCode = /^[A-Za-z]{2}$/.test(lead.country) ? lead.country.toUpperCase() : "";
  const payload = {
    request_type: lead.type,
    idempotency_key: safeKey,
    locale: cleanText(input?.locale || "ar", 12),
    contact: { name: lead.clientName, company: lead.company, phone: lead.phone, email: lead.email, country_code: countryCode },
    details: lead.type === "catalog_order"
      ? { message: lead.notes, lines: lead.items, currency: "", packing_plan: {} }
      : { service: lead.serviceRequired, message: lead.notes, product_summary: lead.productName, quantity: lead.quantity, target_country: lead.country },
  };
  const result = await submitWebsiteRequest(payload, { env, fetchImpl });
  return { reference: result.request_ref, status: result.status, duplicate: Boolean(result.duplicate) };
}
