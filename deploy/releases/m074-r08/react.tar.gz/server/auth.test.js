import test from "node:test";
import assert from "node:assert/strict";
import {
  authenticateAdmin,
  createPasswordHash,
  createSessionToken,
  readAdminSession,
  sessionCookie,
} from "./auth.js";

const password = "a-long-test-password-2026";
const passwordHash = await createPasswordHash(password, "fixed-test-salt");
const env = {
  ADMIN_EMAIL: "admin@example.com",
  ADMIN_PASSWORD_HASH: passwordHash,
  ADMIN_SESSION_SECRET: "12345678901234567890123456789012",
};

test("admin authentication verifies the server-side scrypt hash", async () => {
  const user = await authenticateAdmin("ADMIN@example.com", password, env);
  assert.equal(user.role, "website_editor");
  await assert.rejects(() => authenticateAdmin("admin@example.com", "wrong-password", env), (error) => error.code === "invalid_credentials");
});

test("admin authentication accepts a provider-safe base64 hash", async () => {
  const encodedEnv = {
    ...env,
    ADMIN_PASSWORD_HASH: "",
    ADMIN_PASSWORD_HASH_B64: Buffer.from(passwordHash, "utf8").toString("base64"),
  };
  const user = await authenticateAdmin("admin@example.com", password, encodedEnv);
  assert.equal(user.role, "website_editor");
});

test("admin session is signed, HttpOnly, and expires", () => {
  const user = { email: "admin@example.com", role: "website_editor" };
  const token = createSessionToken(user, env, 1_000);
  const cookie = sessionCookie(token, env);
  assert.match(cookie, /HttpOnly/);
  assert.match(cookie, /SameSite=Strict/);
  assert.deepEqual(readAdminSession({ cookie }, env, 2_000), user);
  assert.equal(readAdminSession({ cookie: cookie.replace(token, `${token.slice(0, -1)}x`) }, env, 2_000), null);
  assert.equal(readAdminSession({ cookie }, env, 9 * 60 * 60 * 1_000), null);
});
