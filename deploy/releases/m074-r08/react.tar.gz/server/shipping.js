import { randomUUID } from "node:crypto";
import { fetchWebsiteRateTrend, fetchWebsiteRouteOptions, searchWebsiteRates, submitWebsiteRequest } from "./dolibarr.js";

function shippingError(message, code, status = 422) {
  return Object.assign(new Error(message), { code, status });
}

function clean(value, max) {
  return Array.from(String(value || ""), (character) => {
    const code = character.charCodeAt(0);
    return code < 32 || code === 127 ? " " : character;
  }).join("").trim().replace(/\s+/g, " ").slice(0, max);
}

function exactPort(value) {
  const result = clean(value, 80);
  if (!result || /[%*_]/.test(result)) throw shippingError("An exact port is required", "invalid_rate_search");
  return result;
}

export function normalizeRateSearch(input) {
  const containerType = clean(input?.container_type, 16).toUpperCase();
  if (!["20GP", "40GP", "40HQ"].includes(containerType)) throw shippingError("Invalid container type", "invalid_rate_search");
  return {
    pol: exactPort(input?.pol), pod: exactPort(input?.pod), container_type: containerType,
    country_code: clean(input?.country_code, 2).toUpperCase(),
    service_type: clean(input?.service_type, 16).toLowerCase(), incoterm: clean(input?.incoterm || "FOB", 8).toUpperCase(),
  };
}

function normalizeContact(input) {
  const value = input && typeof input === "object" ? input : {};
  const contact = {
    name: clean(value.name, 160), company: clean(value.company, 190), phone: clean(value.phone, 40),
    email: clean(value.email, 254).toLowerCase(), country_code: clean(value.country_code, 2).toUpperCase(),
  };
  if (contact.name.length < 2 || (contact.phone.replace(/\D/g, "").length < 7 && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(contact.email))) {
    throw shippingError("Valid contact details are required", "invalid_contact");
  }
  if (contact.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(contact.email)) throw shippingError("Invalid email", "invalid_contact");
  return contact;
}

export async function findShippingRates(input, options = {}) {
  return searchWebsiteRates(normalizeRateSearch(input), options);
}

export function normalizeRouteOptions(input) {
  const countryCode = clean(input?.country_code, 2).toUpperCase();
  if (countryCode && !/^[A-Z]{2}$/.test(countryCode)) throw shippingError("Invalid country", "invalid_route_options");
  return countryCode;
}

export async function findShippingRouteOptions(input, options = {}) {
  return fetchWebsiteRouteOptions(normalizeRouteOptions(input), options);
}

export async function findShippingRateTrend(input, options = {}) {
  return fetchWebsiteRateTrend(normalizeRateSearch(input), options);
}

export async function createShippingBooking(input, { env = process.env, fetchImpl = fetch, idempotencyKey = "" } = {}) {
  const safeKey = clean(idempotencyKey, 100) || randomUUID();
  if (safeKey.length < 16) throw shippingError("Invalid request identifier", "invalid_idempotency_key");
  const quantity = Number.parseInt(input?.container_quantity || "1", 10);
  if (!Number.isInteger(quantity) || quantity < 1 || quantity > 100) throw shippingError("Invalid container quantity", "invalid_container_quantity");
  if (input?.terms_accepted !== true) throw shippingError("Terms acknowledgement is required", "terms_acknowledgement_required");
  const dangerousGoods = ["no", "yes", "unknown"].includes(input?.dangerous_goods) ? input.dangerous_goods : "unknown";
  return submitWebsiteRequest({
    request_type: "shipping_booking", idempotency_key: safeKey, locale: clean(input?.locale || "ar", 12),
    contact: normalizeContact(input?.contact), rate_token: clean(input?.rate_token, 4096),
    parties: {
      shipper: clean(input?.parties?.shipper, 1000), consignee: clean(input?.parties?.consignee, 1000), notify_party: clean(input?.parties?.notify_party, 1000),
    },
    details: {
      container_quantity: quantity, cargo_type: clean(input?.cargo_type || "normal", 80), dangerous_goods: dangerousGoods,
      restricted_cargo: dangerousGoods !== "no" || input?.restricted_cargo === true, cargo_summary: clean(input?.cargo_summary, 4000),
      gross_weight: clean(input?.gross_weight, 255), hs_code: clean(input?.hs_code, 255), final_destination: clean(input?.final_destination, 255),
      required_services: Array.isArray(input?.required_services) ? input.required_services.slice(0, 20).map((item) => clean(item, 80)) : [],
      terms_acknowledged_at: new Date().toISOString(),
    },
  }, { env, fetchImpl });
}

export const __test = { normalizeContact, exactPort };
