import { getRuntimeConfig } from "./config.js";

const MAX_RESPONSE_BYTES = 256 * 1024;

function integrationError(message, code = "dolibarr_gateway_error", status = 502) {
  return Object.assign(new Error(message), { code, status });
}

function endpoint(config, resource) {
  if (!config.dolibarrApiBaseUrl || config.dolibarrApiKey.length < 20 || !config.dolibarrAllowedHost) {
    throw integrationError("Dolibarr gateway is not configured", "dolibarr_not_configured", 503);
  }
  const base = new URL(config.dolibarrApiBaseUrl);
  const loopback = base.hostname === "127.0.0.1" || base.hostname === "localhost";
  if (base.protocol !== "https:" && !loopback) throw integrationError("Dolibarr HTTPS is required", "dolibarr_not_configured", 503);
  if (base.hostname.toLowerCase() !== config.dolibarrAllowedHost) throw integrationError("Dolibarr host is not allowed", "dolibarr_not_configured", 503);
  const baseWithSlash = new URL(base.toString().replace(/\/?$/, "/"));
  const url = new URL(resource.replace(/^\//, ""), baseWithSlash);
  if (url.hostname.toLowerCase() !== config.dolibarrAllowedHost) throw integrationError("Dolibarr host is not allowed", "dolibarr_not_configured", 503);
  return url;
}

async function parseResponse(response) {
  const announcedLength = Number.parseInt(response.headers?.get?.("content-length") || "0", 10);
  if (announcedLength > MAX_RESPONSE_BYTES) throw integrationError("Dolibarr response is too large");
  const text = await response.text();
  if (Buffer.byteLength(text) > MAX_RESPONSE_BYTES) throw integrationError("Dolibarr response is too large");
  const payload = text ? JSON.parse(text) : {};
  if (!response.ok) {
    const upstreamStatus = Number(response.status) || 502;
    const status = upstreamStatus >= 500 ? 502 : upstreamStatus;
    const code = typeof payload?.error?.message === "string" ? payload.error.message : (payload?.code || "dolibarr_request_failed");
    throw integrationError("Dolibarr rejected the request", code, status);
  }
  return payload;
}

async function request(resource, { method = "GET", query, payload, env, fetchImpl }) {
  const config = getRuntimeConfig(env);
  const url = endpoint(config, resource);
  Object.entries(query || {}).forEach(([key, value]) => { if (value !== "" && value != null) url.searchParams.set(key, String(value)); });
  const response = await fetchImpl(url, {
    method,
    redirect: "error",
    headers: {
      Accept: "application/json",
      DOLAPIKEY: config.dolibarrApiKey,
      ...(payload ? { "Content-Type": "application/json" } : {}),
    },
    ...(payload ? { body: JSON.stringify(payload) } : {}),
    signal: AbortSignal.timeout(12_000),
  });
  return parseResponse(response);
}

export function submitWebsiteRequest(payload, { env = process.env, fetchImpl = fetch } = {}) {
  return request("chinaplanetoperations/website-requests", { method: "POST", payload, env, fetchImpl });
}

export function searchWebsiteRates(filters, { env = process.env, fetchImpl = fetch } = {}) {
  return request("chinaplanetshippingprices/website-rates", { query: filters, env, fetchImpl });
}

export function fetchWebsiteRouteOptions(countryCode = "", { env = process.env, fetchImpl = fetch } = {}) {
  return request("chinaplanetshippingprices/website-route-options", { query: { country_code: countryCode }, env, fetchImpl });
}

export function fetchWebsiteRateTrend(filters, { env = process.env, fetchImpl = fetch } = {}) {
  return request("chinaplanetshippingprices/website-rate-trend", { query: filters, env, fetchImpl });
}

export const __test = { endpoint, parseResponse };
