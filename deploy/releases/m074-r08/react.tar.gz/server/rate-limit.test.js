import test from "node:test";
import assert from "node:assert/strict";
import { mkdtempSync, readFileSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { consumeRateLimit, resetRateLimitStoresForTests } from "./rate-limit.js";

test("durable limiter survives an in-process store reload", () => {
  const directory = mkdtempSync(join(tmpdir(), "m043-rate-limit-"));
  const storePath = join(directory, "limits.json");
  const request = { storePath, bucket: "shipping-booking", clientKey: "203.0.113.7", limit: 2, now: 1_000, windowMs: 60_000 };
  assert.equal(consumeRateLimit(request), 0);
  assert.equal(consumeRateLimit({ ...request, now: 2_000 }), 0);
  resetRateLimitStoresForTests();
  assert.equal(consumeRateLimit({ ...request, now: 3_000 }), 58);
  assert.equal(JSON.parse(readFileSync(storePath, "utf8")).buckets["shipping-booking"]["203.0.113.7"].count, 3);
});

test("configured limiter fails closed when durable storage is unavailable", () => {
  resetRateLimitStoresForTests();
  const retryAfter = consumeRateLimit({ storePath: "/dev/null/limits.json", bucket: "shipping", clientKey: "unknown", limit: 5, now: 1_000 });
  assert.equal(retryAfter, 900);
});
