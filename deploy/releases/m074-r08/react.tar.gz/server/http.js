import { fetchWooCatalog } from "./catalog.js";
import { calculateB2bPlan, createB2bRequest, fetchB2bCatalog } from "./b2b.js";
import { getRuntimeConfig } from "./config.js";
import { deliverLead } from "./leads.js";
import { createShippingBooking, findShippingRates, findShippingRateTrend, findShippingRouteOptions } from "./shipping.js";
import {
  authenticateAdmin,
  clearSessionCookie,
  createSessionToken,
  getAdminConfigurationState,
  readAdminSession,
  sessionCookie,
} from "./auth.js";
import { readSiteContent, writeSiteContent } from "./content.js";
import { writeWebsiteImage } from "./media.js";
import { isWooProductTopic, isWooWebhookPing, verifyWooWebhookSignature } from "./woocommerce-webhook.js";
import { fetchChinaGuide, fetchChinaGuidePlaceDetail, fetchWordPressPosts, verifyWordPressContentWebhook } from "./wordpress-content.js";
import { consumeRateLimit } from "./rate-limit.js";

let catalogCache = null;
let catalogRefreshPromise = null;
let catalogRevision = 1;
let catalogInvalidatedAt = null;
let wordpressPostsCache = null;
let chinaGuideCache = null;
let wordpressPostsRefreshPromise = null;
let chinaGuideRefreshPromise = null;
const chinaGuideDetailCache = new Map();
const chinaGuideDetailRefreshPromises = new Map();
let wordpressContentRevision = 1;
let wordpressContentInvalidatedAt = null;

function json(status, body, extraHeaders = {}) {
  return {
    status,
    headers: {
      "Content-Type": "application/json; charset=utf-8",
      "Cache-Control": "no-store",
      "X-Content-Type-Options": "nosniff",
      "Referrer-Policy": "strict-origin-when-cross-origin",
      ...extraHeaders,
    },
    body,
  };
}

function headerValue(headers, name) {
  if (!headers) return "";
  if (typeof headers.get === "function") return headers.get(name) || "";
  const key = Object.keys(headers).find((entry) => entry.toLowerCase() === name.toLowerCase());
  return key ? String(headers[key]) : "";
}

function isAllowedOrigin(headers, config) {
  const origin = headerValue(headers, "origin");
  if (!config.publicSiteOrigin) return true;
  if (!origin) return false;
  return origin.replace(/\/$/, "") === config.publicSiteOrigin;
}

function clientAddress(headers, trustedProxyHops = 0, remoteAddress = "") {
  if (trustedProxyHops > 0) {
    const chain = headerValue(headers, "x-forwarded-for").split(",").map((value) => value.trim()).filter(Boolean);
    if (String(remoteAddress || "").trim()) chain.push(String(remoteAddress).trim());
    const index = chain.length - trustedProxyHops - 1;
    if (index >= 0 && chain[index]) return chain[index];
  }
  return String(remoteAddress || "unknown").trim() || "unknown";
}

function isRateLimited(headers, bucket, limit = 8, config = {}, remoteAddress = "") {
  const clientKey = clientAddress(headers, config.trustedProxyHops || 0, remoteAddress);
  return consumeRateLimit({ storePath: config.rateLimitStorePath, bucket, clientKey, limit });
}

export const __test = { clientAddress };

function rateLimitReply(retryAfter, message) {
  return json(429, { ok: false, code: "rate_limited", message }, { "Retry-After": String(retryAfter) });
}

function refreshCatalog({ env, fetchImpl, cacheSeconds }) {
  if (catalogRefreshPromise) return catalogRefreshPromise;
  const requestedRevision = catalogRevision;
  catalogRefreshPromise = fetchWooCatalog({ env, fetchImpl })
    .then((value) => {
      const versionedValue = { ...value, revision: requestedRevision };
      if (requestedRevision === catalogRevision) {
        catalogCache = { value: versionedValue, expiresAt: Date.now() + cacheSeconds * 1000 };
      }
      return versionedValue;
    })
    .finally(() => { catalogRefreshPromise = null; });
  return catalogRefreshPromise;
}

function refreshWordPressPosts({ env, fetchImpl, cacheSeconds }) {
  if (wordpressPostsRefreshPromise) return wordpressPostsRefreshPromise;
  const requestedRevision = wordpressContentRevision;
  wordpressPostsRefreshPromise = fetchWordPressPosts({ env, fetchImpl })
    .then((result) => {
      const value = { ...result, revision: requestedRevision };
      if (requestedRevision === wordpressContentRevision) {
        wordpressPostsCache = { value, expiresAt: Date.now() + cacheSeconds * 1000 };
      }
      return value;
    })
    .finally(() => { wordpressPostsRefreshPromise = null; });
  return wordpressPostsRefreshPromise;
}

function refreshChinaGuide({ env, fetchImpl, cacheSeconds }) {
  if (chinaGuideRefreshPromise) return chinaGuideRefreshPromise;
  const requestedRevision = wordpressContentRevision;
  chinaGuideRefreshPromise = fetchChinaGuide({ env, fetchImpl })
    .then((result) => {
      const value = { ...result, revision: requestedRevision };
      if (requestedRevision === wordpressContentRevision) {
        chinaGuideCache = { value, expiresAt: Date.now() + cacheSeconds * 1000 };
      }
      return value;
    })
    .finally(() => { chinaGuideRefreshPromise = null; });
  return chinaGuideRefreshPromise;
}

function refreshChinaGuideDetail(slug, place, { env, fetchImpl, cacheSeconds }) {
  const currentRefresh = chinaGuideDetailRefreshPromises.get(slug);
  if (currentRefresh) return currentRefresh;
  const refresh = fetchChinaGuidePlaceDetail(place, { env, fetchImpl })
    .then((value) => {
      chinaGuideDetailCache.set(slug, { value, expiresAt: Date.now() + cacheSeconds * 1000 });
      return value;
    })
    .finally(() => { chinaGuideDetailRefreshPromises.delete(slug); });
  chinaGuideDetailRefreshPromises.set(slug, refresh);
  return refresh;
}

export async function warmWordPressContent({ env = process.env, fetchImpl = fetch } = {}) {
  const config = getRuntimeConfig(env);
  if (!config.wordpressBaseUrl) return;
  await refreshChinaGuide({ env, fetchImpl, cacheSeconds: config.wordpressContentCacheSeconds }).catch(() => null);
  await refreshWordPressPosts({ env, fetchImpl, cacheSeconds: config.wordpressContentCacheSeconds }).catch(() => null);
}

export async function processApiRequest({ path, query = {}, method, headers, body, remoteAddress = "", env = process.env, fetchImpl = fetch }) {
  const config = getRuntimeConfig(env);

  if (path === "/api/health" && method === "GET") {
    return json(config.releaseMetadataValid ? 200 : 503, {
      ok: config.releaseMetadataValid,
      service: "chinaplanet-main-website",
      releaseId: config.releaseId,
      releaseMetadataValid: config.releaseMetadataValid,
      deploySha: config.deploySha,
      catalogConfigured: Boolean(config.wordpressBaseUrl),
      catalogAuthenticated: Boolean(config.wordpressBaseUrl && config.wooConsumerKey && config.wooConsumerSecret),
      catalogWebhookConfigured: Boolean(config.wooWebhookSecret),
      wordpressContentConfigured: Boolean(config.wordpressBaseUrl),
      wordpressContentWebhookConfigured: Boolean(config.wordpressContentWebhookSecret),
      b2bIntegrationConfigured: Boolean(config.wordpressBaseUrl && config.b2bApiSecret.length >= 32),
      dolibarrGatewayConfigured: Boolean(config.dolibarrApiBaseUrl && config.dolibarrApiKey && config.dolibarrAllowedHost),
      durableRateLimitConfigured: Boolean(config.rateLimitStorePath),
      adminConfigured: getAdminConfigurationState(env),
      adminEmailConfigured: Boolean(config.adminEmail),
      adminPasswordHashConfigured: config.adminPasswordHash.startsWith("scrypt$"),
      adminSessionSecretConfigured: config.adminSessionSecret.length >= 32,
    });
  }

  if (path === "/api/wordpress-content-version" && method === "GET") {
    return json(200, { revision: wordpressContentRevision, invalidatedAt: wordpressContentInvalidatedAt });
  }

  if (path === "/api/webhooks/wordpress/content" && method === "POST") {
    if (!config.wordpressContentWebhookSecret) return json(503, { ok: false, code: "webhook_not_configured" });
    const signature = headerValue(headers, "x-chinaplanet-signature");
    if (!verifyWordPressContentWebhook(body, signature, config.wordpressContentWebhookSecret)) {
      return json(401, { ok: false, code: "invalid_webhook_signature" });
    }
    if (wordpressPostsCache) wordpressPostsCache.expiresAt = 0;
    if (chinaGuideCache) chinaGuideCache.expiresAt = 0;
    chinaGuideDetailCache.forEach((cached) => { cached.expiresAt = 0; });
    wordpressContentRevision += 1;
    wordpressContentInvalidatedAt = new Date().toISOString();
    return json(200, { ok: true, revision: wordpressContentRevision });
  }

  if (path === "/api/posts" && method === "GET") {
    try {
      const now = Date.now();
      if (wordpressPostsCache && wordpressPostsCache.expiresAt > now) {
        return json(200, wordpressPostsCache.value, { "Cache-Control": "public, max-age=60, stale-while-revalidate=300", "X-Content-Source": "cache" });
      }
      if (wordpressPostsCache) {
        void refreshWordPressPosts({ env, fetchImpl, cacheSeconds: config.wordpressContentCacheSeconds }).catch(() => null);
        return json(200, { ...wordpressPostsCache.value, stale: true, refreshing: true }, { "Cache-Control": "public, max-age=15, stale-while-revalidate=300", "X-Content-Source": "stale" });
      }
      const value = await refreshWordPressPosts({ env, fetchImpl, cacheSeconds: config.wordpressContentCacheSeconds });
      return json(200, value, { "Cache-Control": "public, max-age=60, stale-while-revalidate=300", "X-Content-Source": "wordpress" });
    } catch (error) {
      return json(error.status || 500, { ok: false, code: error.code || "wordpress_posts_error", message: "تعذر تحميل المقالات حالياً." });
    }
  }

  if (path === "/api/china-guide" && method === "GET") {
    try {
      const now = Date.now();
      if (chinaGuideCache && chinaGuideCache.expiresAt > now) {
        return json(200, chinaGuideCache.value, { "Cache-Control": "public, max-age=60, stale-while-revalidate=300", "X-Content-Source": "cache" });
      }
      if (chinaGuideCache) {
        void refreshChinaGuide({ env, fetchImpl, cacheSeconds: config.wordpressContentCacheSeconds }).catch(() => null);
        return json(200, { ...chinaGuideCache.value, stale: true, refreshing: true }, { "Cache-Control": "public, max-age=15, stale-while-revalidate=300", "X-Content-Source": "stale" });
      }
      const value = await refreshChinaGuide({ env, fetchImpl, cacheSeconds: config.wordpressContentCacheSeconds });
      return json(200, value, { "Cache-Control": "public, max-age=60, stale-while-revalidate=300", "X-Content-Source": "wordpress" });
    } catch (error) {
      return json(error.status || 500, { ok: false, code: error.code || "china_guide_error", message: "تعذر تحميل دليل الصين حالياً." });
    }
  }

  if (path.startsWith("/api/china-guide/") && method === "GET") {
    try {
      let slug = path.slice("/api/china-guide/".length);
      try { slug = decodeURIComponent(slug); } catch { /* Keep the original slug. */ }
      const cached = chinaGuideDetailCache.get(slug);
      const now = Date.now();
      if (cached && cached.expiresAt > now) {
        return json(200, cached.value, { "Cache-Control": "public, max-age=60, stale-while-revalidate=300", "X-Content-Source": "cache" });
      }
      let guide = chinaGuideCache?.value;
      if (!guide || chinaGuideCache.expiresAt <= now) {
        try {
          guide = await refreshChinaGuide({ env, fetchImpl, cacheSeconds: config.wordpressContentCacheSeconds });
        } catch (error) {
          if (!guide) throw error;
        }
      }
      const place = guide.places.find((entry) => entry.slug === slug || entry.id === slug);
      if (!place) return json(404, { ok: false, code: "guide_place_not_found", message: "المكان غير موجود في دليل الصين." });
      if (cached) {
        try {
          const value = await refreshChinaGuideDetail(slug, place, { env, fetchImpl, cacheSeconds: config.wordpressContentCacheSeconds });
          return json(200, value, { "Cache-Control": "public, max-age=60, stale-while-revalidate=300", "X-Content-Source": "wordpress" });
        } catch {
          return json(200, { ...cached.value, stale: true }, { "Cache-Control": "public, max-age=15, stale-while-revalidate=300", "X-Content-Source": "stale" });
        }
      }
      const value = await refreshChinaGuideDetail(slug, place, { env, fetchImpl, cacheSeconds: config.wordpressContentCacheSeconds });
      return json(200, value, { "Cache-Control": "public, max-age=60, stale-while-revalidate=300", "X-Content-Source": "wordpress" });
    } catch (error) {
      return json(error.status || 500, { ok: false, code: error.code || "china_guide_detail_error", message: "تعذر تحميل تفاصيل المكان حالياً." });
    }
  }

  if (path === "/api/catalog-version" && method === "GET") {
    return json(200, {
      revision: catalogRevision,
      invalidatedAt: catalogInvalidatedAt,
    });
  }

  if (path === "/api/webhooks/woocommerce/catalog" && method === "POST") {
    if (!config.wooWebhookSecret) {
      return json(503, { ok: false, code: "webhook_not_configured" });
    }

    if (isWooWebhookPing(body, headers)) {
      return json(200, { ok: true, ping: true, invalidated: false, revision: catalogRevision });
    }

    const signature = headerValue(headers, "x-wc-webhook-signature");
    if (!verifyWooWebhookSignature(body, signature, config.wooWebhookSecret)) {
      return json(401, { ok: false, code: "invalid_webhook_signature" });
    }

    const topic = headerValue(headers, "x-wc-webhook-topic");
    const resource = headerValue(headers, "x-wc-webhook-resource");
    const event = headerValue(headers, "x-wc-webhook-event");
    const invalidated = isWooProductTopic(topic, resource, event);
    if (invalidated) {
      if (catalogCache) catalogCache.expiresAt = 0;
      catalogRevision += 1;
      catalogInvalidatedAt = new Date().toISOString();
    }

    return json(200, { ok: true, invalidated, revision: catalogRevision });
  }

  if (path === "/api/content" && method === "GET") {
    try {
      const stored = await readSiteContent(env);
      return json(200, stored, { "Cache-Control": "no-store" });
    } catch (error) {
      return json(error.status || 500, { ok: false, code: error.code || "content_error", message: "تعذر تحميل محتوى الموقع حالياً." });
    }
  }

  if (path === "/api/catalog" && method === "GET") {
    try {
      const now = Date.now();
      if (catalogCache && catalogCache.expiresAt > now) {
        return json(200, catalogCache.value, { "Cache-Control": "public, max-age=60, stale-while-revalidate=300", "X-Content-Source": "cache" });
      }
      if (catalogCache) {
        void refreshCatalog({ env, fetchImpl, cacheSeconds: config.catalogCacheSeconds }).catch(() => null);
        return json(200, { ...catalogCache.value, stale: true, refreshing: true }, { "Cache-Control": "public, max-age=15, stale-while-revalidate=300", "X-Content-Source": "stale" });
      }
      const value = await refreshCatalog({ env, fetchImpl, cacheSeconds: config.catalogCacheSeconds });
      return json(200, value, { "Cache-Control": "public, max-age=60, stale-while-revalidate=300", "X-Content-Source": "woocommerce" });
    } catch (error) {
      return json(error.status || 500, { ok: false, code: error.code || "catalog_error", message: "تعذر تحميل الكتالوج حالياً." });
    }
  }

  if (path === "/api/b2b/catalog" && method === "GET") {
    const limited = isRateLimited(headers, "b2b-catalog", 120, config, remoteAddress); if (limited) return rateLimitReply(limited, "طلبات بحث كثيرة. حاول مرة أخرى لاحقاً.");
    try {
      const value = await fetchB2bCatalog({ query, env, fetchImpl });
      return json(200, value, { "Cache-Control": "public, max-age=30, stale-while-revalidate=120", "X-Content-Source": "woocommerce-b2b" });
    } catch (error) {
      return json(error.status || 500, { ok: false, code: error.code || "b2b_catalog_error", message: "تعذر تحميل كتالوج الجملة حالياً." });
    }
  }

  if (path === "/api/b2b/plan" && method === "POST") {
    if (!isAllowedOrigin(headers, config)) return json(403, { ok: false, code: "origin_not_allowed", message: "مصدر الطلب غير مسموح." });
    const limited = isRateLimited(headers, "b2b-plan", 30, config, remoteAddress); if (limited) return rateLimitReply(limited, "طلبات حساب كثيرة. حاول مرة أخرى لاحقاً.");
    try {
      const parsedBody = typeof body === "string" ? JSON.parse(body || "{}") : (body || {});
      const value = await calculateB2bPlan(parsedBody, { env, fetchImpl });
      return json(200, value);
    } catch (error) {
      const status = error instanceof SyntaxError ? 400 : (error.status || 500);
      return json(status, { ok: false, code: error.code || "b2b_plan_error", message: status >= 500 ? "تعذر حساب الحمولة حالياً." : "يرجى مراجعة المنتجات والكميات." });
    }
  }

  if (path === "/api/b2b/request" && method === "POST") {
    if (!isAllowedOrigin(headers, config)) return json(403, { ok: false, code: "origin_not_allowed", message: "مصدر الطلب غير مسموح." });
    const limited = isRateLimited(headers, "b2b-request", 5, config, remoteAddress); if (limited) return rateLimitReply(limited, "عدد كبير من الطلبات. حاول مرة أخرى لاحقاً.");
    try {
      const parsedBody = typeof body === "string" ? JSON.parse(body || "{}") : (body || {});
      const value = await createB2bRequest(parsedBody, { env, fetchImpl, idempotencyKey: headerValue(headers, "idempotency-key") });
      return json(value.duplicate ? 200 : 201, value);
    } catch (error) {
      const status = error instanceof SyntaxError ? 400 : (error.status || 500);
      return json(status, { ok: false, code: error.code || "b2b_request_error", message: status >= 500 ? "تعذر إرسال طلب المراجعة حالياً." : "يرجى مراجعة بيانات الطلب." });
    }
  }

  if (path === "/api/leads" && method === "POST") {
    if (!isAllowedOrigin(headers, config)) return json(403, { ok: false, code: "origin_not_allowed", message: "مصدر الطلب غير مسموح." });
    const limited = isRateLimited(headers, "leads", 8, config, remoteAddress); if (limited) return rateLimitReply(limited, "عدد كبير من الطلبات. حاول مرة أخرى لاحقاً.");

    try {
      const parsedBody = typeof body === "string" ? JSON.parse(body || "{}") : (body || {});
      const result = await deliverLead(parsedBody, {
        env,
        fetchImpl,
        idempotencyKey: headerValue(headers, "idempotency-key"),
      });
      return json(201, { ok: true, ...result });
    } catch (error) {
      const status = error instanceof SyntaxError ? 400 : (error.status || 500);
      return json(status, {
        ok: false,
        code: error.code || "lead_error",
        message: status >= 500 ? "تعذر إرسال الطلب حالياً. يرجى المحاولة لاحقاً أو التواصل عبر واتساب." : "يرجى مراجعة البيانات المطلوبة.",
      });
    }
  }

  if (path === "/api/shipping/rates" && method === "GET") {
    const limited = isRateLimited(headers, "shipping-search", 60, config, remoteAddress); if (limited) return rateLimitReply(limited, "طلبات بحث كثيرة. حاول مرة أخرى لاحقاً.");
    try { return json(200, await findShippingRates(query, { env, fetchImpl })); }
    catch (error) { return json(error.status || 500, { ok: false, code: error.code || "shipping_rate_error", message: (error.status || 500) >= 500 ? "تعذر تحميل أسعار الشحن حالياً." : "يرجى إدخال ميناء الشحن والوصول ونوع الحاوية بدقة." }); }
  }

  if (path === "/api/shipping/route-options" && method === "GET") {
    const limited = isRateLimited(headers, "shipping-search", 60, config, remoteAddress); if (limited) return rateLimitReply(limited, "طلبات بحث كثيرة. حاول مرة أخرى لاحقاً.");
    try { return json(200, await findShippingRouteOptions(query, { env, fetchImpl }), { "Cache-Control": "public, max-age=300, stale-while-revalidate=600" }); }
    catch (error) { return json(error.status || 500, { ok: false, code: error.code || "shipping_route_options_error", message: (error.status || 500) >= 500 ? "تعذر تحميل الموانئ حالياً." : "يرجى اختيار دولة صحيحة." }); }
  }

  if (path === "/api/shipping/rate-trend" && method === "GET") {
    const limited = isRateLimited(headers, "shipping-search", 60, config, remoteAddress); if (limited) return rateLimitReply(limited, "طلبات بحث كثيرة. حاول مرة أخرى لاحقاً.");
    try { return json(200, await findShippingRateTrend(query, { env, fetchImpl }), { "Cache-Control": "public, max-age=300, stale-while-revalidate=600" }); }
    catch (error) { return json(error.status || 500, { ok: false, code: error.code || "shipping_rate_trend_error", message: (error.status || 500) >= 500 ? "تعذر تحميل اتجاه الأسعار حالياً." : "يرجى اختيار مسار صحيح." }); }
  }

  if (path === "/api/shipping/booking-requests" && method === "POST") {
    if (!isAllowedOrigin(headers, config)) return json(403, { ok: false, code: "origin_not_allowed", message: "مصدر الطلب غير مسموح." });
    const limited = isRateLimited(headers, "shipping-booking", 5, config, remoteAddress); if (limited) return rateLimitReply(limited, "عدد كبير من الطلبات. حاول مرة أخرى لاحقاً.");
    try {
      const parsedBody = typeof body === "string" ? JSON.parse(body || "{}") : (body || {});
      const value = await createShippingBooking(parsedBody, { env, fetchImpl, idempotencyKey: headerValue(headers, "idempotency-key") });
      return json(value.duplicate ? 200 : 201, value);
    } catch (error) {
      const status = error instanceof SyntaxError ? 400 : (error.status || 500);
      return json(status, { ok: false, code: error.code || "shipping_booking_error", message: status >= 500 ? "تعذر إرسال طلب الحجز حالياً." : "يرجى مراجعة بيانات الشحنة والموافقة على الشروط." });
    }
  }

  if (path === "/api/admin/login" && method === "POST") {
    if (!isAllowedOrigin(headers, config)) return json(403, { ok: false, code: "origin_not_allowed", message: "مصدر الطلب غير مسموح." });
    const limited = isRateLimited(headers, "admin-login", 5, config, remoteAddress); if (limited) return rateLimitReply(limited, "محاولات دخول كثيرة. حاول لاحقاً.");
    try {
      const parsedBody = typeof body === "string" ? JSON.parse(body || "{}") : (body || {});
      const user = await authenticateAdmin(parsedBody.email, parsedBody.password, env);
      const token = createSessionToken(user, env);
      return json(200, { ok: true, user }, { "Set-Cookie": sessionCookie(token, env) });
    } catch (error) {
      const status = error instanceof SyntaxError ? 400 : (error.status || 500);
      return json(status, {
        ok: false,
        code: error.code || "login_error",
        message: status === 503 ? "لوحة التحرير لم تُهيأ بعد على الخادم." : "بيانات الدخول غير صحيحة.",
      });
    }
  }

  if (path === "/api/admin/session" && method === "GET") {
    const user = readAdminSession(headers, env);
    return user ? json(200, { ok: true, user }) : json(401, { ok: false, code: "not_authenticated" });
  }

  if (path === "/api/admin/logout" && method === "POST") {
    if (!isAllowedOrigin(headers, config)) return json(403, { ok: false, code: "origin_not_allowed" });
    return json(200, { ok: true }, { "Set-Cookie": clearSessionCookie(env) });
  }

  if (path === "/api/admin/content" && method === "PUT") {
    if (!isAllowedOrigin(headers, config)) return json(403, { ok: false, code: "origin_not_allowed", message: "مصدر الطلب غير مسموح." });
    const user = readAdminSession(headers, env);
    if (!user) return json(401, { ok: false, code: "not_authenticated", message: "انتهت جلسة الدخول." });
    try {
      const parsedBody = typeof body === "string" ? JSON.parse(body || "{}") : (body || {});
      const stored = await writeSiteContent(parsedBody.content, user, env);
      return json(200, { ok: true, ...stored });
    } catch (error) {
      const status = error instanceof SyntaxError ? 400 : (error.status || 500);
      return json(status, { ok: false, code: error.code || "content_save_failed", message: "تعذر حفظ محتوى الموقع." });
    }
  }

  if (path === "/api/admin/media" && method === "POST") {
    if (!isAllowedOrigin(headers, config)) return json(403, { ok: false, code: "origin_not_allowed", message: "مصدر الطلب غير مسموح." });
    const user = readAdminSession(headers, env);
    if (!user) return json(401, { ok: false, code: "not_authenticated", message: "انتهت جلسة الدخول." });
    try {
      const parsedBody = typeof body === "string" ? JSON.parse(body || "{}") : (body || {});
      const uploaded = await writeWebsiteImage(parsedBody, env);
      return json(201, { ok: true, ...uploaded });
    } catch (error) {
      const status = error instanceof SyntaxError ? 400 : (error.status || 500);
      return json(status, { ok: false, code: error.code || "media_upload_failed", message: "تعذر رفع الصورة." });
    }
  }

  return json(404, { ok: false, code: "not_found" });
}
