import test from "node:test";
import assert from "node:assert/strict";
import { canonicalHostRedirect, legacyRedirect, renderRobots, renderSitemap } from "./seo.js";

test("robots blocks staging while advertising the canonical sitemap", () => {
  const robots = renderRobots({ origin: "https://new.chinaplanet.org", allowIndexing: false });
  assert.match(robots, /Disallow: \//);
  assert.match(robots, /Sitemap: https:\/\/new\.chinaplanet\.org\/sitemap\.xml/);
  assert.match(robots, /Disallow: \/api\//);
});

test("sitemap de-duplicates paths and publishes Arabic, English and French alternates", () => {
  const sitemap = renderSitemap({
    origin: "https://chinaplanet.org",
    entries: [{ path: "/blog/a&b" }, { path: "/blog/a&b" }, { path: "/about", lastModified: "2026-08-03T00:00:00Z" }],
  });
  assert.equal((sitemap.match(/<url>/g) || []).length, 6);
  assert.match(sitemap, /https:\/\/chinaplanet\.org\/blog\/a&amp;b/);
  assert.match(sitemap, /https:\/\/chinaplanet\.org\/en\/blog\/a&amp;b/);
  assert.match(sitemap, /hreflang="fr"/);
  assert.match(sitemap, /hreflang="x-default"/);
  assert.match(sitemap, /2026-08-03T00:00:00\.000Z/);
});

test("legacy WordPress routes redirect only to safe React destinations", () => {
  assert.equal(legacyRedirect("/index.html"), "/");
  assert.equal(legacyRedirect("/about-us/"), "/about");
  assert.equal(legacyRedirect("/product/some-item/"), "/products");
  assert.equal(legacyRedirect("/2026/04/sample-post/"), "/blog/sample-post");
  assert.equal(legacyRedirect("/china-guide/guangzhou"), "");
});

test("www host redirects to the configured canonical host without losing path or query", () => {
  assert.equal(canonicalHostRedirect({
    host: "www.chinaplanet.org",
    pathname: "/en/blog",
    search: "?page=2",
    origin: "https://chinaplanet.org",
  }), "https://chinaplanet.org/en/blog?page=2");
  assert.equal(canonicalHostRedirect({
    host: "chinaplanet.org",
    pathname: "/en/blog",
    origin: "https://chinaplanet.org",
  }), "");
  assert.equal(canonicalHostRedirect({
    host: "attacker.example",
    pathname: "/",
    origin: "https://chinaplanet.org",
  }), "");
});
