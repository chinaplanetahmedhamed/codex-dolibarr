# موقع كوكب الصين الرئيسي

واجهة عربية/RTL لشركة **China Planet × Vision Trading** لخدمات البحث عن الموردين، التفاوض، فحص الجودة، تجميع الطلبات وترتيب الشحن من الصين للأسواق العربية.

المشروع ليس بديلًا عن Dolibarr/ChinaPlanetOS ولا يخزن حسابات العملاء أو الطلبات التشغيلية في المتصفح.

## توزيع المسؤوليات

- **React/Vite:** الموقع العام، الخدمات، عرض الكتالوج، المدونة، دليل الصين، نماذج طلب التسعير ولوحة تعديل الصفحة الرئيسية.
- **WordPress/WooCommerce:** مصدر المنتجات والصور وبيانات الكراتين والمقالات ونوع المحتوى `china_guide`.
- **Server API:** يخفي مفاتيح WooCommerce وDolibarr ويرسل طلبات الموقع إلى بوابة Dolibarr المحمية.
- **Dolibarr/ChinaPlanetOS:** العملاء، عروض الأسعار، الطلبات، الشحنات، الأرصدة والمستندات.
- **Customer Center:** دخول العملاء ومشاهدة بياناتهم المصرح بها فقط.

## المتطلبات

- Node.js `20.19+` أو `22.12+`.
- مفتاح WooCommerce بصلاحية قراءة فقط.
- مستخدم API مخصص محدود الصلاحيات في Dolibarr لاستقبال طلبات الموقع والبحث عن أسعار FCL العامة. تكامل n8n مؤجل وليس جزءًا من هذا المسار.

## التشغيل المحلي

```bash
npm ci
npm run build
npm test
npm run test:ui
```

لواجهة Vite أثناء التطوير:

```bash
npm run dev
```

لاختبار الخادم الكامل بعد البناء:

```bash
cp .env.example .env.local
npm run build
npm run start:local
```

أمر `start:local` يحمّل `.env.local` ويشغّل الواجهة والـAPI معاً على المنفذ المحدد. في بيئة التشغيل الفعلية يجب توفير المتغيرات من Docker/Portainer/Vercel أو مدير الأسرار في الاستضافة.

## الإعدادات

استخدم [.env.example](./.env.example) كنموذج. أي متغير يبدأ بـ`VITE_` يصل إلى المتصفح؛ لذلك يمنع وضع أسرار داخله.

### متغيرات عامة

- `VITE_CUSTOMER_CENTER_URL`: رابط مركز العملاء الآمن.
- `VITE_STAFF_PORTAL_URL`: رابط دخول فريق العمل.
- `PUBLIC_SITE_ORIGIN`: النطاق المسموح له بإرسال الطلبات.

### متغيرات سرية على الخادم فقط

- `WC_CONSUMER_KEY`
- `WC_CONSUMER_SECRET`
- `DOLIBARR_API_BASE_URL`: رابط REST index في Dolibarr وينتهي بـ`/api/index.php/`.
- `DOLIBARR_ALLOWED_HOST`: اسم مضيف Dolibarr المسموح حرفيًا، دون مسار.
- `DOLIBARR_API_KEY`: مفتاح مستخدم الموقع المخصص؛ لا يوضع في أي متغير `VITE_`.
- `TRUSTED_PROXY_HOPS`: صفر محليًا، ويُغيّر فقط عند وجود Reverse Proxy معروف.
- `ADMIN_EMAIL`: بريد موظف تحرير الموقع.
- `ADMIN_PASSWORD_HASH`: بصمة Scrypt لكلمة المرور، وليس كلمة المرور نفسها.
- `ADMIN_SESSION_SECRET`: قيمة عشوائية بطول 32 حرفاً على الأقل لتوقيع الجلسة.
- `CONTENT_STORE_PATH`: مسار ملف محتوى الموقع الدائم، والافتراضي في Docker هو `/app/data/site-content.json`.

## لوحة تحرير الموقع

تتوفر اللوحة من الرابط:

```text
https://your-domain.example/#/admin
```

كما يوجد رابط **دخول فريق الموقع** أسفل الموقع. اللوحة مخصصة للمحتوى الثابت: الهوية، العناوين، الفريق، القطاعات، الصور، السيكشنات والخدمات. نشر المقالات ودليل الصين يتم من WordPress عبر الرابط الموجود داخل اللوحة. الطلبات والعملاء والشحنات لا تُدار منها؛ مكانها ChinaPlanetOS.

لتوليد بصمة كلمة مرور:

```bash
npm run admin:hash -- 'ضع-هنا-كلمة-مرور-طويلة-وعشوائية'
```

انسخ الناتج كاملاً إلى `ADMIN_PASSWORD_HASH`، وأنشئ سر الجلسة مثلاً باستخدام `openssl rand -hex 32`. لا تستخدم القيم التجريبية الموجودة في `.env.example`.

الحماية تشمل جلسة موقعة في Cookie من نوع `HttpOnly` و`SameSite=Strict`، وتحديد محاولات الدخول، وفحص Origin. لا توجد كلمة مرور افتراضية أو جلسة موظف في `localStorage`.

زر **حفظ ونشر التعديلات** يحفظ نسخة مركزية واحدة يقرأها الموقع العام. رفع الصور يدعم JPG وPNG وWebP حتى 5MB، وتُخزن الصور داخل مجلد البيانات الدائم.

## واجهات API

### `GET /api/catalog`

يجلب المنتجات المنشورة من WooCommerce على الخادم، ثم يعيد فقط بيانات الكتالوج الآمنة للعميل. يكفي `WORDPRESS_BASE_URL` لاستخدام Store API العامة. وعند إضافة مفاتيح WooCommerce للقراءة فقط، تُرسل في Authorization header ولا تظهر في URL أو JavaScript.

### `GET /api/posts`

يجلب المقالات المنشورة من تصنيفات WordPress المعتمدة فقط، وينظف HTML على الخادم قبل إرساله إلى React. التصنيفات المسموحة تُحدد في `WP_POST_CATEGORY_ALLOWLIST` حتى لا يظهر محتوى غير مراجع تلقائياً.

### `GET /api/china-guide`

يجلب نوع المحتوى `china_guide` مع المدن وأنواع الأماكن والتصنيفات. التفاصيل العامة الإضافية تأتي من إضافة `ChinaPlanet Headless Bridge` الموجودة داخل `wordpress-plugin/`.

### `GET /api/china-guide/{slug}`

يعرض تفاصيل المكان داخل React، ويستخرج بصورة آمنة المحتوى العام المنشور والصورة والعنوان ورابط الخريطة من صفحة WordPress الحالية أثناء فترة الانتقال. لا يرسل الزائر إلى واجهة WordPress القديمة.

### `POST /api/webhooks/wordpress/content`

يستقبل إشعارًا موقّعًا من إضافة WordPress عند نشر أو تحديث مقال أو مكان، ويبطل Cache المحتوى. الواجهة تفحص رقم الإصدار كل 30 ثانية ولا تعيد تنزيل المحتوى إلا بعد تغيّر فعلي.

### `POST /api/leads`

يستقبل نوعين:

- `quote_request`
- `catalog_order`

الطلب لا يظهر ناجحًا للعميل إلا بعد حفظه في Dolibarr وعودة مرجع دائم `WEB-...`. لا ينشئ المسار Third Party أو Proposal أو Sales Order أو Invoice تلقائيًا.

### `GET /api/shipping/rates`

يبحث عن سعر FCL منشور باستخدام `POL + POD + container_type` بدقة، ويدعم `20GP` و`40GP` و`40HQ` فقط. يعيد السعر البيعي العام ورمز اختيار مؤقتًا، ولا يعيد `rate_id` أو التكلفة أو الهامش.

### `POST /api/shipping/booking-requests`

يرسل طلب حجز حاوية إلى قائمة الاستقبال داخل Dolibarr بعد إعادة التحقق من السعر. النجاح يعني استلام طلب المراجعة فقط؛ لا يعني تأكيد مساحة أو حجزًا من الخط الملاحي.

### واجهات B2B

- `GET /api/b2b/catalog`: قراءة كتالوج WooCommerce الآمن.
- `POST /api/b2b/plan`: حساب التعبئة من WordPress على الخادم.
- `POST /api/b2b/request`: يحسب الخطة ثم يحفظ الطلب في Dolibarr؛ لا ينشئ WooCommerce order.

### `GET /api/health`

يعرض حالة تهيئة الكتالوج وتسليم الطلبات بدون كشف الأسرار.

### واجهات CMS

- `GET /api/content`: محتوى الموقع المنشور.
- `POST /api/admin/login`: تسجيل دخول الموظف.
- `GET /api/admin/session`: التحقق من الجلسة.
- `PUT /api/admin/content`: حفظ ونشر محتوى الموقع.
- `POST /api/admin/media`: رفع صور الموقع.
- `POST /api/admin/logout`: إنهاء الجلسة.

## WooCommerce

تدعم طبقة التحويل حقول الكراتين التالية:

- `_b2bclp_units_per_carton`
- `_b2bclp_carton_length`
- `_b2bclp_carton_width`
- `_b2bclp_carton_height`
- `_b2bclp_carton_cbm`
- `_b2bclp_carton_net_weight`
- `_b2bclp_carton_gross_weight`

### تحديث الكتالوج عبر Webhook

اضبط سرًا عشوائيًا منفصلاً في `WC_WEBHOOK_SECRET` على الخادم، ثم أنشئ Webhooks للمنتج في WooCommerce بنفس السر. رابط الاستلام هو:

```bash
openssl rand -hex 32
```

```text
https://your-public-domain.example/api/webhooks/woocommerce/catalog
```

الموضوعات المدعومة تشمل إنشاء المنتج وتحديثه وحذفه واستعادته. يتحقق الخادم من `X-WC-Webhook-Signature` قبل إبطال Cache. تفحص الواجهة رقم إصدار صغير كل 15 ثانية، ولا تعيد تنزيل الكتالوج إلا بعد تغيير حقيقي.

لا تستخدم `127.0.0.1` أو `localhost` كرابط تسليم داخل WooCommerce؛ يجب أن يكون الرابط عامًا ويعمل عبر HTTPS.

إبطال Cache ورقم الإصدار الحاليان مصممان لخدمة Node طويلة التشغيل عبر Docker/VPS. لا تفعّل هذا Webhook على Vercel Serverless قبل إضافة مخزن حالة مشترك مثل Redis/KV، لأن وظائف Serverless المنفصلة لا تشترك في ذاكرة واحدة.
- `_b2bclp_orientations`
- `_b2bclp_packing_complete`

لا تُعاد تكلفة المورد أو الهوامش أو الحقول الداخلية إلى المتصفح.

## Dolibarr/ChinaPlanetOS

ينفّذ M043 مسار `React → Node → Dolibarr` للاستفسارات وطلبات الكتالوج وطلبات حجز FCL. يسجل Dolibarr الطلب في قائمة استقبال داخلية فقط، ثم يربطه الموظف بعميل موجود ويحوّله يدويًا إلى Operations عند التأهل. يظل إنشاء Third Party أو Proposal أو Sales Order خارج المسار التلقائي، مع:

- منع تكرار العملاء والمنتجات.
- ربط العميل من الجلسة الموثقة عند الطلبات المسجلة.
- حفظ snapshot للكميات وCBM والوزن على سطر الطلب.
- منع إظهار المورد والتكلفة والهامش والملاحظات والملفات الداخلية.
- عدم تحويل طلب زائر إلى Sales Order معتمد تلقائيًا.

## النشر

خطة Hostinger ذات النطاق الواحد، وتجهيز staging، ونقل WordPress إلى `cms.chinaplanet.org` موثقة في [docs/HEADLESS_DEPLOYMENT.md](./docs/HEADLESS_DEPLOYMENT.md). لا تغيّر DNS للنطاق الرئيسي قبل نجاح staging والنسخة الاحتياطية واختبار rollback.

مسار GitHub Actions، النشر الآلي إلى `new.chinaplanet.org`، وبوابة الموافقة للإنتاج موثقة في [docs/RELEASE_RUNBOOK.md](./docs/RELEASE_RUNBOOK.md).

### Docker

```bash
docker compose build
docker compose up -d
```

الخدمة تستمع داخل الحاوية على المنفذ `8080` وتستخدم `/api/health` للفحص. ملف المحتوى والصور محفوظان في Docker volume باسم `site_content`، لذلك يجب تضمين هذا الـvolume في النسخ الاحتياطي الدوري.

### Vercel

ملفات `api/` تعمل كـServerless Functions. أضف المتغيرات السرية من إعدادات المشروع في Vercel ولا تضعها في Git. حفظ CMS ورفع الصور الحاليان مصممان لـDocker/VPS؛ لأن نظام ملفات Vercel مؤقت، يحتاج نشر Vercel إلى قاعدة بيانات وتخزين ملفات خارجيين قبل استخدام اللوحة في الإنتاج.
كما يحتاج تحديث الكتالوج عبر Webhook إلى Redis/KV مشترك قبل تفعيله على Vercel. النشر الحالي الموصى به للموقع الكامل هو Docker/VPS.

## التحقق

```bash
npm run lint
npm test
npm run test:ui
npm run build
```
