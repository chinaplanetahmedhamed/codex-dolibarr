import { handleVercelRequest } from "./_handler.js";

export default function handler(request, response) {
  return handleVercelRequest(request, response, "/api/catalog-version");
}
