import { handleVercelRequest } from "../../_handler.js";

export const config = {
  api: {
    bodyParser: false,
  },
};

async function readRawBody(request, maxBytes = 2_000_000) {
  const chunks = [];
  let size = 0;
  for await (const chunk of request) {
    size += chunk.length;
    if (size > maxBytes) throw Object.assign(new Error("Payload too large"), { status: 413 });
    chunks.push(chunk);
  }
  return Buffer.concat(chunks).toString("utf8");
}

export default async function handler(request, response) {
  if (process.env.VERCEL) {
    return response.status(503).json({
      ok: false,
      code: "shared_catalog_state_required",
    });
  }
  try {
    const rawBody = await readRawBody(request);
    return await handleVercelRequest(request, response, "/api/webhooks/woocommerce/catalog", rawBody);
  } catch (error) {
    return response.status(error.status || 500).json({
      ok: false,
      code: error.status === 413 ? "payload_too_large" : "server_error",
    });
  }
}
