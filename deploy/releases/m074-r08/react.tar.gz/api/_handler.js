import { processApiRequest } from "../server/http.js";

export async function handleVercelRequest(request, response, path, rawBody) {
  const result = await processApiRequest({
    path,
    query: request.query || {},
    method: request.method,
    headers: request.headers,
    body: rawBody === undefined ? request.body : rawBody,
  });

  Object.entries(result.headers).forEach(([name, value]) => response.setHeader(name, value));
  response.status(result.status).json(result.body);
}
