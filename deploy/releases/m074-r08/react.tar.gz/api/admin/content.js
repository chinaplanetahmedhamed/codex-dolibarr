import { handleVercelRequest } from "../_handler.js";

export const config = {
  api: {
    bodyParser: { sizeLimit: "500kb" },
  },
};

export default function handler(request, response) {
  return handleVercelRequest(request, response, "/api/admin/content");
}
