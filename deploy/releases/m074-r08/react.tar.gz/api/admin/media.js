import { handleVercelRequest } from "../_handler.js";

export const config = {
  api: {
    bodyParser: { sizeLimit: "7mb" },
  },
};

export default function handler(request, response) {
  return handleVercelRequest(request, response, "/api/admin/media");
}
