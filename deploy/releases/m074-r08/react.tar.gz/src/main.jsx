import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import '@fontsource-variable/cairo'
import '@fontsource-variable/outfit'
import './index.css'
import App from './App.jsx'
import ErrorBoundary from './components/ErrorBoundary.jsx'
import MetaPixel from './components/MetaPixel.jsx'
import GoogleAnalytics from './components/GoogleAnalytics.jsx'
import { I18nProvider } from './i18n/I18nContext.jsx'

const rootElement = document.getElementById('root')
if (rootElement?.hasAttribute('data-server-seo-snapshot') || rootElement?.querySelector('[data-server-seo-snapshot]')) {
  rootElement.replaceChildren()
}

createRoot(rootElement).render(
  <StrictMode>
    <ErrorBoundary>
      <I18nProvider>
        <MetaPixel />
        <GoogleAnalytics />
        <App />
      </I18nProvider>
    </ErrorBoundary>
  </StrictMode>,
)
