import React from 'react';
import { Cog, Car, Building, FlaskConical, Sprout, ArrowLeft, CheckCircle, ShoppingBag } from 'lucide-react';
import { PRODUCT_CATEGORIES } from '../data/mockData';

export default function ProductsSection({ onOpenQuoteModal, onOpenProductsPage }) {
  const getCategoryIcon = (iconName) => {
    switch (iconName) {
      case 'Cog': return <Cog size={24} color="#FFF" />;
      case 'Car': return <Car size={24} color="#FFF" />;
      case 'Building': return <Building size={24} color="#FFF" />;
      case 'FlaskConical': return <FlaskConical size={24} color="#FFF" />;
      case 'Sprout': return <Sprout size={24} color="#FFF" />;
      default: return <Cog size={24} color="#FFF" />;
    }
  };

  return (
    <section id="products" style={{ padding: '80px 0', background: 'var(--bg-main)' }}>
      <div className="container">
        
        {/* Section Header */}
        <div style={{ textAlign: 'center', maxWidth: '700px', margin: '0 auto 48px auto' }}>
          <div className="badge badge-gold" style={{ marginBottom: '12px' }}>
            خبرتنا تشمل كافة القطاعات
          </div>
          <h2 style={{ fontSize: '2.2rem', fontWeight: 800, marginBottom: '16px' }}>
            دليل القطاعات والمنتجات المستوردة
          </h2>
          <p style={{ color: 'var(--text-muted)', fontSize: '1.05rem', marginBottom: '20px' }}>
            مهما كان المنتج الذي ترغب باستيراده من الصين، لدينا قاعدة بيانات ضخمة لمصانع حقيقية وموثوقة.
          </p>

          {onOpenProductsPage && (
            <button 
              onClick={onOpenProductsPage}
              className="btn-primary"
              style={{ borderRadius: '9999px', padding: '12px 28px', fontSize: '0.98rem' }}
            >
              <ShoppingBag size={18} />
              <span>دخول كتالوج المنتجات وتحديد الكميات والكومنت</span>
            </button>
          )}
        </div>

        {/* Categories Grid */}
        <div 
          style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fit, minmax(320px, 1fr))',
            gap: '28px'
          }}
        >
          {PRODUCT_CATEGORIES.map((cat) => (
            <div 
              key={cat.id}
              className="glass-card"
              style={{
                borderRadius: 'var(--radius-lg)',
                overflow: 'hidden',
                display: 'flex',
                flexDirection: 'column'
              }}
            >
              <div style={{ position: 'relative', height: '180px', overflow: 'hidden' }}>
                <img 
                  src={cat.image} 
                  alt={cat.title} 
                  style={{
                    width: '100%',
                    height: '100%',
                    objectFit: 'cover',
                    transition: 'transform 0.4s ease'
                  }}
                />
                <div style={{ position: 'absolute', inset: 0, background: 'linear-gradient(to top, rgba(15, 23, 42, 0.8) 0%, transparent 60%)' }} />
                
                <div style={{ position: 'absolute', top: '16px', right: '16px', width: '44px', height: '44px', borderRadius: '12px', background: 'var(--primary)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                  {getCategoryIcon(cat.icon)}
                </div>

                <div style={{ position: 'absolute', bottom: '16px', right: '16px', color: '#FFF' }}>
                  <div style={{ fontSize: '1.2rem', fontWeight: 800 }}>{cat.title}</div>
                  <div style={{ fontSize: '0.78rem', opacity: 0.8, fontFamily: 'var(--font-en)' }}>{cat.subtitle}</div>
                </div>
              </div>

              <div style={{ padding: '24px', flex: 1, display: 'flex', flexDirection: 'column', justifyContent: 'space-between' }}>
                <div>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '8px', color: '#10B981', fontSize: '0.88rem', fontWeight: 700, marginBottom: '12px' }}>
                    <CheckCircle size={16} />
                    <span>{cat.itemsCount}</span>
                  </div>
                  <p style={{ color: 'var(--text-muted)', fontSize: '0.92rem', lineHeight: 1.6, marginBottom: '20px' }}>
                    {cat.description}
                  </p>
                </div>

                <button 
                  onClick={onOpenProductsPage || onOpenQuoteModal} 
                  className="btn-outline"
                  style={{ width: '100%', justifyContent: 'center', fontSize: '0.9rem' }}
                >
                  <span>استكشف منتجات هذا القطاع بالكتالوج</span>
                  <ArrowLeft size={16} />
                </button>
              </div>

            </div>
          ))}
        </div>

      </div>
    </section>
  );
}
