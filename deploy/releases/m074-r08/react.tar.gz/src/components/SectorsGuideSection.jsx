import React from 'react';
import { 
  Cpu, 
  Layers, 
  Armchair, 
  Box, 
  Home, 
  Sparkles, 
  ArrowRight,
  Factory
} from 'lucide-react';
import { localizedField, useI18n } from '../i18n/I18nContext';

const defaultSectorIcons = [
  { Icon: Factory, color: "#D32F2F" },
  { Icon: Cpu, color: "#059669" },
  { Icon: Layers, color: "#EAB308" },
  { Icon: Armchair, color: "#3B82F6" },
  { Icon: Box, color: "#8B5CF6" },
  { Icon: Home, color: "#EC4899" }
];

const SECTOR_COPY = {
  en: {
    badge: 'Product sourcing sectors',
    title: 'We source suppliers according to the product, specification and target market',
    subtitle: 'Every request is reviewed individually, including supplier suitability, quotation, inspection scope and destination requirements.',
    items: [
      ['Industrial machinery and equipment', 'Production lines, packaging equipment, CNC and laser systems and factory machinery.'],
      ['Electronics and smart solutions', 'Lighting, displays, communication solutions and electronic components to specification.'],
      ['Building materials and decoration', 'Ceramic, marble, aluminium, finishes and project supplies.'],
      ['Furniture and fit-out', 'Office, hospitality and residential furniture, including custom production.'],
      ['Packaging and plastic products', 'Packaging, injection moulds and commercial or industrial plastic solutions.'],
      ['Home tools and appliances', 'Household tools, appliances and retail products for commercial quantities.'],
    ],
    explore: 'Explore products',
    browse: 'Browse all catalog products and sectors 📦',
  },
  fr: {
    badge: "Secteurs d'approvisionnement",
    title: 'Nous recherchons les fournisseurs selon le produit, les spécifications et le marché cible',
    subtitle: "Chaque demande est étudiée individuellement : fournisseur, offre, périmètre d'inspection et exigences de destination.",
    items: [
      ['Machines et équipements industriels', "Lignes de production, emballage, systèmes CNC et laser et équipements d'usine."],
      ['Électronique et solutions intelligentes', 'Éclairage, écrans, communication et composants électroniques selon les spécifications.'],
      ['Matériaux de construction et décoration', 'Céramique, marbre, aluminium, finitions et fournitures de projet.'],
      ['Mobilier et aménagement', 'Mobilier de bureau, hôtelier et résidentiel, y compris la fabrication sur mesure.'],
      ['Emballage et produits plastiques', "Emballages, moules d'injection et solutions plastiques commerciales ou industrielles."],
      ['Articles et appareils ménagers', 'Articles ménagers, appareils et produits de vente au détail en quantités commerciales.'],
    ],
    explore: 'Explorer les produits',
    browse: 'Voir tous les produits et secteurs du catalogue 📦',
  },
};

export default function SectorsGuideSection({ sectorsInfo, onViewAllProducts, limit, compact = false }) {
  const { locale, isRtl } = useI18n();
  const translated = SECTOR_COPY[locale];
  const badgeText = localizedField(sectorsInfo, 'badge', locale, translated?.badge || '✨ خبرتنا تشمل كافة القطاعات | دليل القطاعات والمنتجات المستوردة');
  const mainTitle = localizedField(sectorsInfo, 'title', locale, translated?.title || 'مهما كان المنتج الذي ترغب باستيراده من الصين، لدينا قاعدة بيانات ضخمة لمصانع حقيقية وموثوقة.');
  const subtitleText = localizedField(sectorsInfo, 'subtitle', locale, translated?.subtitle || 'نربطك بالمورد المناسب مع مراجعة العرض والفحص والتفاوض المباشر.');
  
  const sectorsList = (sectorsInfo?.sectorsList && Array.isArray(sectorsInfo.sectorsList) && sectorsInfo.sectorsList.length > 0)
    ? sectorsInfo.sectorsList
    : [
        {
          title: 'الآلات والمعدات الصناعية',
          badge: 'خطوط إنتاج معتمدة',
          desc: 'خطوط التغليف، أجهزة الليزر، ماكينات CNC، ومعدات المصانع الثقيلة بالتراخيص الفنية.',
          suppliersCount: '340+ مصنع'
        },
        {
          title: 'الإلكترونيات والحلول الذكية',
          badge: 'جودة عالمية ISO',
          desc: 'إضاءات LED، الشاشات التفاعلية، أجهزة الاتصالات، والقطع الإلكترونية الدقيقة.',
          suppliersCount: '280+ مصنع'
        },
        {
          title: 'مواد البناء والرخام والديكور',
          badge: 'شهادات مطابقة سابر',
          desc: 'السيراميك، الرخام الطبيعي، واجهات الكوبوند، وألواح الألومنيوم والخشب البلاستيكي.',
          suppliersCount: '410+ مصنع'
        },
        {
          title: 'الأثاث والديكورات الفاخرة',
          badge: 'تجهيز فندقي وسكني',
          desc: 'أثاث المكاتب، تجهيزات الفنادق، المفروشات، والقطع الديكورية المصنعة حسب الطلب.',
          suppliersCount: '190+ مصنع'
        },
        {
          title: 'المنتجات البلاستيكية والتعبئة',
          badge: 'قوالب حقن مخصصة',
          desc: 'عبوات التغليف، القوالب الصناعية، أدوات البلاستيك الغذائي والصحي المقاوم.',
          suppliersCount: '150+ مصنع'
        },
        {
          title: 'الأدوات والأجهزة المنزلية',
          badge: 'ضمان فني وفحص جودة',
          desc: 'الأجهزة الكهرومنزلية، أدوات المطبخ العصرية، ومستلزمات المنازل الذكية.',
          suppliersCount: '220+ مصنع'
        }
      ];
  const localizedSectors = sectorsList.map((sector, index) => {
    if (locale === 'ar' || !translated?.items[index]) return sector;
    return {
      ...sector,
      title: localizedField(sector, 'title', locale, translated.items[index][0]),
      desc: localizedField(sector, 'desc', locale, translated.items[index][1]),
    };
  });
  const visibleSectors = Number.isInteger(limit) ? localizedSectors.slice(0, limit) : localizedSectors;

  return (
    <section 
      style={{ 
        padding: compact ? '58px 0' : '70px 0',
        background: 'linear-gradient(180deg, var(--bg-main) 0%, var(--bg-card) 100%)',
        borderTop: '1px solid var(--border-color)',
        borderBottom: '1px solid var(--border-color)',
        position: 'relative',
        overflow: 'hidden'
      }}
    >
      <div className="container">
        
        {/* Header Badge & Titles */}
        <div style={{ textAlign: 'center', maxWidth: '850px', margin: `0 auto ${compact ? '32px' : '48px'} auto` }}>
          <div className="badge badge-gold" style={{ marginBottom: '14px', padding: '6px 18px', fontSize: '0.86rem' }}>
            <Sparkles size={16} color="var(--primary-gold)" />
            <span>{badgeText}</span>
          </div>

          <h2 style={{ fontSize: 'clamp(1.7rem, 4vw, 2.5rem)', fontWeight: 900, lineHeight: 1.3, marginBottom: '16px', color: 'var(--text-main)' }}>
            {mainTitle}
          </h2>

          <p style={{ color: 'var(--text-muted)', fontSize: '1.02rem', lineHeight: 1.7 }}>
            {subtitleText}
          </p>
        </div>

        {/* Sectors Grid Cards */}
        <div className={compact ? 'mobile-preview-carousel' : undefined}
          style={{ 
            display: 'grid', 
            gridTemplateColumns: `repeat(auto-fit, minmax(${Number.isInteger(limit) ? '260px' : '320px'}, 1fr))`,
            gap: '24px',
            marginBottom: '40px' 
          }}
        >
          {visibleSectors.map((sec, idx) => (
            <div 
              key={idx}
              className="glass-card"
              style={{ 
                padding: compact ? '22px' : '28px',
                borderRadius: 'var(--radius-lg)', 
                display: 'flex', 
                flexDirection: 'column', 
                justifyContent: 'space-between',
                border: '1px solid var(--border-color)',
                transition: 'transform 0.3s ease, box-shadow 0.3s ease',
                background: 'var(--bg-card)'
              }}
            >
              <div>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '16px' }}>
                  <div 
                    style={{ 
                      width: '54px', 
                      height: '54px', 
                      borderRadius: '14px', 
                      background: 'rgba(211, 47, 47, 0.08)', 
                      border: '1px solid rgba(211, 47, 47, 0.2)',
                      display: 'flex', 
                      alignItems: 'center', 
                      justifyContent: 'center' 
                    }}
                  >
                    {(() => {
                      const { Icon, color } = defaultSectorIcons[idx % defaultSectorIcons.length];
                      return <Icon size={28} color={color} />;
                    })()}
                  </div>
                  {!compact && <span className="badge badge-gold" style={{ fontSize: '0.74rem' }}>{sec.badge}</span>}
                </div>

                <h3 style={{ fontSize: '1.15rem', fontWeight: 800, color: 'var(--text-main)', marginBottom: '8px' }}>
                  {sec.title}
                </h3>

                <p style={{ color: 'var(--text-muted)', fontSize: '0.88rem', lineHeight: 1.6, marginBottom: compact ? 0 : '16px', ...(compact ? { display: '-webkit-box', WebkitLineClamp: 2, WebkitBoxOrient: 'vertical', overflow: 'hidden' } : {}) }}>
                  {sec.desc}
                </p>
              </div>

              {!compact && <div style={{ borderTop: '1px solid var(--border-color)', paddingTop: '14px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <span style={{ fontSize: '0.82rem', fontWeight: 700, color: 'var(--primary)' }}>
                  🏭 {sec.suppliersCount}
                </span>
                
                <button 
                  onClick={onViewAllProducts} 
                  style={{ background: 'transparent', border: 'none', color: 'var(--text-main)', fontSize: '0.84rem', fontWeight: 800, cursor: 'pointer', display: 'flex', alignItems: 'center', gap: '4px' }}
                >
                  <span>{translated?.explore || 'استكشف المنتجات'}</span>
                  <ArrowRight size={14} style={{ transform: isRtl ? 'none' : 'rotate(180deg)' }} />
                </button>
              </div>}
            </div>
          ))}
        </div>

        {/* CTA Action Bottom */}
        <div style={{ textAlign: 'center' }}>
          <button 
            onClick={onViewAllProducts}
            className="btn-primary"
            style={{ padding: '14px 38px', borderRadius: '9999px', fontSize: '1.05rem', fontWeight: 800, boxShadow: 'var(--shadow-glow)' }}
          >
            <span>{translated?.browse || 'تصفح جميع المنتجات والقطاعات بالكتالوج 📦'}</span>
            <ArrowRight size={20} style={{ transform: isRtl ? 'none' : 'rotate(180deg)' }} />
          </button>
        </div>

      </div>
    </section>
  );
}
