import React, { useState } from 'react';
import { Calculator, Plane, Ship, Info, ArrowLeft } from 'lucide-react';

export default function ShippingCalculator({ onOpenQuoteModal }) {
  const [country, setCountry] = useState('EG'); // EG, SA, AE, KW, JO
  const [method, setMethod] = useState('sea_lcl'); // air_express, air_standard, sea_lcl, sea_fcl
  const [weight, setWeight] = useState(150); // kg
  const [cbm, setCbm] = useState(1.2); // m3
  const [cargoValue, setCargoValue] = useState(3500); // USD
  const [includeInspection, setIncludeInspection] = useState(true);
  const [includeInsurance, setIncludeInsurance] = useState(true);

  // Rates Data per country
  const countryRates = {
    EG: { name: 'مصر (ميناء الإسكندرية / العين السخنة)', currency: 'EGP', rateUSD: 50, airExp: 18, airStd: 12, seaLcl: 220, seaFcl: 2400 },
    SA: { name: 'السعودية (ميناء جدة / الملك عبد العزيز / الرياض)', currency: 'SAR', rateUSD: 3.75, airExp: 20, airStd: 14, seaLcl: 250, seaFcl: 2800 },
    AE: { name: 'الإمارات (دبي / ميناء جبل علي)', currency: 'AED', rateUSD: 3.67, airExp: 16, airStd: 11, seaLcl: 190, seaFcl: 2100 },
    KW: { name: 'الكويت (ميناء الشويخ / المطار)', currency: 'KWD', rateUSD: 0.31, airExp: 22, airStd: 15, seaLcl: 260, seaFcl: 2900 },
    JO: { name: 'الأردن (ميناء العقبة / عمان)', currency: 'JOD', rateUSD: 0.71, airExp: 24, airStd: 16, seaLcl: 280, seaFcl: 3100 }
  };

  const currentRateObj = countryRates[country] || countryRates.EG;

  // Calculate Base Shipping Price
  let baseFreightUSD = 0;
  let estimatedDays = '15-25 يوم';

  if (method === 'air_express') {
    baseFreightUSD = weight * currentRateObj.airExp;
    estimatedDays = '3 - 5 أيام عمل';
  } else if (method === 'air_standard') {
    baseFreightUSD = weight * currentRateObj.airStd;
    estimatedDays = '7 - 10 أيام عمل';
  } else if (method === 'sea_lcl') {
    baseFreightUSD = Math.max(cbm, 1) * currentRateObj.seaLcl;
    estimatedDays = '20 - 30 يوم بحري';
  } else if (method === 'sea_fcl') {
    baseFreightUSD = currentRateObj.seaFcl;
    estimatedDays = '22 - 28 يوم بحري';
  }

  const inspectionFee = includeInspection ? 150 : 0;
  const insuranceFee = includeInsurance ? Math.round(cargoValue * 0.015) : 0;

  const totalUSD = Math.round(baseFreightUSD + inspectionFee + insuranceFee);
  const totalLocal = Math.round(totalUSD * currentRateObj.rateUSD);

  return (
    <section id="calculator" style={{ padding: '80px 0', background: 'var(--bg-main)' }}>
      <div className="container">
        
        {/* Section Header */}
        <div style={{ textAlign: 'center', maxWidth: '700px', margin: '0 auto 48px auto' }}>
          <div className="badge badge-red" style={{ marginBottom: '12px' }}>
            حاسبة التكاليف التفاعلية
          </div>
          <h2 style={{ fontSize: '2.2rem', fontWeight: 800, marginBottom: '16px' }}>
            احسب تكلفة شحنتك وتخليصها التقديري من الصين
          </h2>
          <p style={{ color: 'var(--text-muted)', fontSize: '1.05rem' }}>
            أسعار تقديرية تشمل خدمات التخزين، فحص الجودة بمستودع جوانزو، وتنسيق البوالص الجمركية دون مصاريف خفية.
          </p>
        </div>

        {/* Calculator Grid */}
        <div 
          className="glass-card"
          style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fit, minmax(320px, 1fr))',
            gap: '0',
            overflow: 'hidden',
            borderRadius: 'var(--radius-lg)',
            boxShadow: 'var(--shadow-lg)'
          }}
        >
          {/* Inputs Section */}
          <div style={{ padding: '36px', background: 'var(--bg-card)' }}>
            
            <h3 style={{ fontSize: '1.2rem', fontWeight: 800, marginBottom: '24px', display: 'flex', alignItems: 'center', gap: '10px' }}>
              <Calculator size={22} color="var(--primary)" />
              1. تفاصيل الشحنة والوجهة
            </h3>

            {/* Country Selector */}
            <div style={{ marginBottom: '20px' }}>
              <label style={{ display: 'block', fontWeight: 700, marginBottom: '8px', fontSize: '0.92rem' }}>
                الدولة والميناء المستهدف
              </label>
              <select 
                className="input-field" 
                value={country} 
                onChange={(e) => setCountry(e.target.value)}
                style={{ fontWeight: 600 }}
              >
                <option value="EG">🇪🇬 مصر (ميناء الإسكندرية / العين السخنة)</option>
                <option value="SA">🇸🇦 السعودية (ميناء جدة / الجافة بالرياض)</option>
                <option value="AE">🇦🇪 الإمارات (دبي / ميناء جبل علي)</option>
                <option value="KW">🇰🇼 الكويت (ميناء الشويخ)</option>
                <option value="JO">🇯🇴 الأردن (ميناء العقبة)</option>
              </select>
            </div>

            {/* Shipping Method Selector */}
            <div style={{ marginBottom: '24px' }}>
              <label style={{ display: 'block', fontWeight: 700, marginBottom: '10px', fontSize: '0.92rem' }}>
                طريقة الشحن الدولية
              </label>
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: '10px' }}>
                
                <button
                  type="button"
                  onClick={() => setMethod('sea_lcl')}
                  style={{
                    padding: '12px',
                    borderRadius: 'var(--radius-sm)',
                    border: `2px solid ${method === 'sea_lcl' ? 'var(--primary)' : 'var(--border-color)'}`,
                    background: method === 'sea_lcl' ? 'var(--primary-light)' : 'transparent',
                    color: method === 'sea_lcl' ? 'var(--primary)' : 'var(--text-main)',
                    fontWeight: 700,
                    cursor: 'pointer',
                    display: 'flex',
                    flexDirection: 'column',
                    alignItems: 'center',
                    gap: '4px'
                  }}
                >
                  <Ship size={22} />
                  <span style={{ fontSize: '0.88rem' }}>بحري جزئي LCL</span>
                </button>

                <button
                  type="button"
                  onClick={() => setMethod('sea_fcl')}
                  style={{
                    padding: '12px',
                    borderRadius: 'var(--radius-sm)',
                    border: `2px solid ${method === 'sea_fcl' ? 'var(--primary)' : 'var(--border-color)'}`,
                    background: method === 'sea_fcl' ? 'var(--primary-light)' : 'transparent',
                    color: method === 'sea_fcl' ? 'var(--primary)' : 'var(--text-main)',
                    fontWeight: 700,
                    cursor: 'pointer',
                    display: 'flex',
                    flexDirection: 'column',
                    alignItems: 'center',
                    gap: '4px'
                  }}
                >
                  <Ship size={22} />
                  <span style={{ fontSize: '0.88rem' }}>بحري حاوية FCL</span>
                </button>

                <button
                  type="button"
                  onClick={() => setMethod('air_standard')}
                  style={{
                    padding: '12px',
                    borderRadius: 'var(--radius-sm)',
                    border: `2px solid ${method === 'air_standard' ? 'var(--primary)' : 'var(--border-color)'}`,
                    background: method === 'air_standard' ? 'var(--primary-light)' : 'transparent',
                    color: method === 'air_standard' ? 'var(--primary)' : 'var(--text-main)',
                    fontWeight: 700,
                    cursor: 'pointer',
                    display: 'flex',
                    flexDirection: 'column',
                    alignItems: 'center',
                    gap: '4px'
                  }}
                >
                  <Plane size={22} />
                  <span style={{ fontSize: '0.88rem' }}>جوي اقتصادي</span>
                </button>

                <button
                  type="button"
                  onClick={() => setMethod('air_express')}
                  style={{
                    padding: '12px',
                    borderRadius: 'var(--radius-sm)',
                    border: `2px solid ${method === 'air_express' ? 'var(--primary)' : 'var(--border-color)'}`,
                    background: method === 'air_express' ? 'var(--primary-light)' : 'transparent',
                    color: method === 'air_express' ? 'var(--primary)' : 'var(--text-main)',
                    fontWeight: 700,
                    cursor: 'pointer',
                    display: 'flex',
                    flexDirection: 'column',
                    alignItems: 'center',
                    gap: '4px'
                  }}
                >
                  <Plane size={22} />
                  <span style={{ fontSize: '0.88rem' }}>جوي سريع جداً</span>
                </button>

              </div>
            </div>

            {/* Inputs: Weight & Volume & Value */}
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '12px', marginBottom: '24px' }}>
              <div>
                <label style={{ display: 'block', fontWeight: 700, marginBottom: '6px', fontSize: '0.82rem' }}>الوزن (كجم)</label>
                <input 
                  type="number" 
                  className="input-field" 
                  value={weight} 
                  onChange={(e) => setWeight(Number(e.target.value))}
                  min={1}
                />
              </div>
              <div>
                <label style={{ display: 'block', fontWeight: 700, marginBottom: '6px', fontSize: '0.82rem' }}>الحجم (CBM م³)</label>
                <input 
                  type="number" 
                  step="0.1"
                  className="input-field" 
                  value={cbm} 
                  onChange={(e) => setCbm(Number(e.target.value))}
                  min={0.1}
                />
              </div>
              <div>
                <label style={{ display: 'block', fontWeight: 700, marginBottom: '6px', fontSize: '0.82rem' }}>قيمة البضاعة ($)</label>
                <input 
                  type="number" 
                  className="input-field" 
                  value={cargoValue} 
                  onChange={(e) => setCargoValue(Number(e.target.value))}
                  min={100}
                />
              </div>
            </div>

            {/* Addon Services Checkboxes */}
            <div style={{ display: 'flex', flexDirection: 'column', gap: '10px', borderTop: '1px solid var(--border-color)', paddingTop: '16px' }}>
              
              <label style={{ display: 'flex', alignItems: 'center', gap: '10px', cursor: 'pointer' }}>
                <input 
                  type="checkbox" 
                  checked={includeInspection} 
                  onChange={(e) => setIncludeInspection(e.target.checked)}
                  style={{ width: '18px', height: '18px', accentColor: 'var(--primary)' }}
                />
                <span style={{ fontSize: '0.92rem', fontWeight: 600 }}>إضافة تقرير فحص الجودة والتفتيش بمكتب جوانزو ($150)</span>
              </label>

              <label style={{ display: 'flex', alignItems: 'center', gap: '10px', cursor: 'pointer' }}>
                <input 
                  type="checkbox" 
                  checked={includeInsurance} 
                  onChange={(e) => setIncludeInsurance(e.target.checked)}
                  style={{ width: '18px', height: '18px', accentColor: 'var(--primary)' }}
                />
                <span style={{ fontSize: '0.92rem', fontWeight: 600 }}>إضافة التأمين الشامل ضد المخاطر البحرية (1.5%)</span>
              </label>

            </div>

          </div>

          {/* Result Output Column */}
          <div 
            style={{
              padding: '36px',
              background: 'linear-gradient(135deg, #0F172A 0%, #1E293B 100%)',
              color: '#FFFFFF',
              display: 'flex',
              flexDirection: 'column',
              justifyContent: 'space-between'
            }}
          >
            <div>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '24px' }}>
                <span className="badge badge-gold">النتيجة التقديرية</span>
                <span style={{ fontSize: '0.85rem', color: '#94A3B8', display: 'flex', alignItems: 'center', gap: '4px' }}>
                  <Info size={14} /> المدة: {estimatedDays}
                </span>
              </div>

              <div style={{ marginBottom: '24px' }}>
                <div style={{ fontSize: '0.9rem', color: '#94A3B8', marginBottom: '4px' }}>التكلفة التقديرية الشاملة:</div>
                <div style={{ fontSize: '3rem', fontWeight: 900, color: '#FFFFFF', lineHeight: 1.1, fontFamily: 'var(--font-en)' }}>
                  ${totalUSD.toLocaleString()} <span style={{ fontSize: '1.2rem', color: '#F59E0B' }}>USD</span>
                </div>
                <div style={{ fontSize: '1.25rem', fontWeight: 700, color: '#6EE7B7', marginTop: '6px' }}>
                  ≈ {totalLocal.toLocaleString()} {currentRateObj.currency}
                </div>
              </div>

              {/* Price Breakdown details */}
              <div style={{ background: 'rgba(255, 255, 255, 0.06)', borderRadius: 'var(--radius-sm)', padding: '16px', marginBottom: '24px' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.88rem', marginBottom: '8px' }}>
                  <span style={{ color: '#CBD5E1' }}>رسوم الشحن الأساسية ({method}):</span>
                  <span style={{ fontWeight: 700 }}>${Math.round(baseFreightUSD).toLocaleString()}</span>
                </div>
                <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.88rem', marginBottom: '8px' }}>
                  <span style={{ color: '#CBD5E1' }}>فحص الجودة والتفتيش:</span>
                  <span style={{ fontWeight: 700 }}>${inspectionFee}</span>
                </div>
                <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.88rem', marginBottom: '8px' }}>
                  <span style={{ color: '#CBD5E1' }}>التأمين الشامل على البضاعة:</span>
                  <span style={{ fontWeight: 700 }}>${insuranceFee}</span>
                </div>
              </div>
            </div>

            {/* Action button */}
            <button 
              onClick={onOpenQuoteModal} 
              className="btn-primary"
              style={{ width: '100%', padding: '14px', justifyContent: 'center', fontSize: '1.05rem' }}
            >
              <span>طلب دراسة تكلفة دقيقة لمشروعك</span>
              <ArrowLeft size={18} />
            </button>

          </div>

        </div>

      </div>
    </section>
  );
}
