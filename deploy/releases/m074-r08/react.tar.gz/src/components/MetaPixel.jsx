import { useEffect } from 'react';
import { startMetaPixelTracking } from '../lib/metaPixel';

export default function MetaPixel() {
  useEffect(() => startMetaPixelTracking(), []);
  return null;
}
