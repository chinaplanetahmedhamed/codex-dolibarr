import React from 'react';
import { X, Plus, Sparkles } from 'lucide-react';
import { useI18n } from '../i18n/I18nContext';

export default function ProductDetailsModal({ isOpen, onClose, product, onAddToCartClick }) {
  const { isRtl, locale } = useI18n();
  const copy = locale === 'fr'
    ? { moq: 'Quantité/options minimum :', byRequest: 'Selon votre demande', source: 'Origine :', sourceFallback: 'Fournisseurs vérifiés en Chine', specs: 'Caractéristiques techniques :', description: 'Description détaillée :', noDescription: 'Aucune description détaillée supplémentaire.', add: 'Définir la quantité et ajouter à la demande de devis', close: 'Fermer' }
    : locale === 'en'
      ? { moq: 'Minimum quantity/options:', byRequest: 'Based on your request', source: 'Source:', sourceFallback: 'Verified suppliers in China', specs: 'Technical specifications:', description: 'Detailed product description:', noDescription: 'No additional detailed description is available.', add: 'Set quantity and add to quote request', close: 'Close' }
      : { moq: 'أدنى كمية/الميزات:', byRequest: 'حسب طلب العميل', source: 'المصدر:', sourceFallback: 'المصانع المعتمدة بالصين', specs: 'المواصفات والخصائص الفنية:', description: 'الشرح والوصف التفصيلي للمنتج:', noDescription: 'لا يوجد شرح تفصيلي إضافي لهذا المنتج.', add: 'تحديد الكمية والملاحظات لإضافة المنتج لطلب التسعير', close: 'إغلاق' };
  if (!isOpen || !product) return null;

  return (
    <div 
      style={{
        position: 'fixed',
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        zIndex: 9999,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        padding: '16px',
        background: 'rgba(15, 23, 42, 0.85)',
        backdropFilter: 'blur(8px)',
        WebkitBackdropFilter: 'blur(8px)'
      }}
      onClick={onClose}
    >
      <div 
        onClick={(e) => e.stopPropagation()}
        style={{
          width: '100%',
          maxWidth: '680px',
          maxHeight: '85vh',
          overflowY: 'auto',
          padding: '28px',
          borderRadius: 'var(--radius-lg)',
          boxShadow: '0 20px 50px rgba(0, 0, 0, 0.5)',
          border: '1px solid var(--border-color)',
          background: 'var(--bg-card, #FFFFFF)',
          color: 'var(--text-main, #0F172A)',
          position: 'relative',
          zIndex: 10000
        }}
      >
        {/* Close Button */}
        <button
          type="button"
          onClick={onClose}
          style={{
            position: 'absolute',
            top: '20px',
            [isRtl ? 'left' : 'right']: '20px',
            background: 'var(--bg-main)',
            border: '1px solid var(--border-color)',
            borderRadius: '50%',
            width: '36px',
            height: '36px',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            color: 'var(--text-main)',
            cursor: 'pointer',
            zIndex: 20
          }}
        >
          <X size={20} />
        </button>

        {/* Large Product Image Banner */}
        <div style={{ position: 'relative', height: '280px', borderRadius: 'var(--radius-md)', overflow: 'hidden', marginBottom: '24px', background: '#0F172A' }}>
          <img 
            src={product.image || '/images/hero.webp'}
            alt={product.title} 
            style={{ width: '100%', height: '100%', objectFit: 'cover' }} 
          />
          <span className="badge badge-gold" style={{ position: 'absolute', top: '16px', right: '16px', background: 'rgba(15, 23, 42, 0.85)', color: '#FFF', padding: '6px 14px', fontSize: '0.85rem' }}>
            {product.categoryName || 'WooCommerce'}
          </span>
        </div>

        {/* Product Details Header */}
        <div style={{ marginBottom: '20px' }}>
          <h2 style={{ fontSize: '1.4rem', fontWeight: 900, color: 'var(--text-main)', marginBottom: '10px', lineHeight: 1.35 }}>
            {product.title}
          </h2>

          <div style={{ display: 'flex', gap: '16px', flexWrap: 'wrap', fontSize: '0.88rem', marginBottom: '16px' }}>
            <div style={{ color: 'var(--primary)', fontWeight: 800 }}>
              📦 {copy.moq} {product.moq || copy.byRequest}
            </div>
            <div style={{ color: 'var(--text-muted)' }}>
              🇨🇳 {copy.source} {product.origin || copy.sourceFallback}
            </div>
          </div>
        </div>

        {/* Specs Box */}
        {product.specs && !product.specs.includes('مزامن') && !product.specs.includes('WooCommerce') && (
          <div style={{ background: 'var(--bg-main)', padding: '16px', borderRadius: 'var(--radius-md)', border: '1px solid var(--border-color)', marginBottom: '20px' }}>
            <div style={{ fontSize: '0.9rem', fontWeight: 800, color: 'var(--primary)', marginBottom: '6px', display: 'flex', alignItems: 'center', gap: '6px' }}>
              <Sparkles size={16} />
              <span>{copy.specs}</span>
            </div>
            <p style={{ fontSize: '0.88rem', color: 'var(--text-main)', lineHeight: 1.6 }}>
              {product.specs}
            </p>
          </div>
        )}

        {/* Full Description */}
        <div style={{ marginBottom: '28px' }}>
          <div style={{ fontSize: '0.92rem', fontWeight: 800, marginBottom: '8px', color: 'var(--text-main)' }}>
            📝 {copy.description}
          </div>
          <p style={{ fontSize: '0.9rem', color: 'var(--text-muted)', lineHeight: 1.7, whiteSpace: 'pre-line' }}>
            {product.description || copy.noDescription}
          </p>
        </div>

        {/* Action Buttons */}
        <div style={{ borderTop: '1px solid var(--border-color)', paddingTop: '20px', display: 'flex', gap: '12px', flexWrap: 'wrap' }}>
          <button
            onClick={() => {
              onClose();
              onAddToCartClick(product);
            }}
            className="btn-primary"
            style={{ flex: 1, justifyContent: 'center', padding: '14px 24px', borderRadius: '9999px', fontSize: '0.95rem' }}
          >
            <Plus size={18} />
            <span>{copy.add}</span>
          </button>
          
          <button
            onClick={onClose}
            className="btn-outline"
            style={{ padding: '14px 24px', borderRadius: '9999px' }}
          >
            {copy.close}
          </button>
        </div>

      </div>
    </div>
  );
}
