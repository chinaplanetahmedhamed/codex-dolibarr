import React, { useState } from 'react';
import { 
  Search, 
  Truck, 
  Package, 
  Calendar, 
  MapPin, 
  CheckCircle2, 
  Clock, 
  ArrowLeft,
  FileCheck,
  Building2,
  Container,
  Anchor
} from 'lucide-react';
import { INITIAL_SHIPMENTS } from '../data/mockData';

export default function ShipmentTracker({ initialQuery = 'CP-884920' }) {
  const [searchQuery, setSearchQuery] = useState(initialQuery);
  const [activeShipment, setActiveShipment] = useState(INITIAL_SHIPMENTS[0]);
  const [searched, setSearched] = useState(true);

  const handleSearch = (e) => {
    e.preventDefault();
    const found = INITIAL_SHIPMENTS.find(
      s => s.id.toLowerCase() === searchQuery.trim().toLowerCase() ||
           (s.containerNo && s.containerNo.toLowerCase().includes(searchQuery.trim().toLowerCase()))
    );

    if (found) {
      setActiveShipment(found);
      setSearched(true);
    } else {
      // Mock fallback shipment for custom tracking IDs
      setActiveShipment({
        id: searchQuery.trim().toUpperCase() || 'CP-NEW-2026',
        clientName: 'استعلام عميل',
        destination: 'ميناء الوصول الرئيسي',
        status: 'قيد التتبع والمتابعة المباشرة من مكتب جوانزو',
        progress: 50,
        containerNo: 'CONTAINER-PENDING',
        origin: 'مستودع جوانزو المركزية',
        etd: '2026-07-28',
        eta: '2026-08-15',
        itemsCount: 'حسب البوليصة',
        type: 'شحن بحري / جوي'
      });
      setSearched(true);
    }
  };

  // Safe fallback for history steps
  const historySteps = (activeShipment && Array.isArray(activeShipment.history))
    ? activeShipment.history
    : [
        { date: activeShipment?.etd || '2026-07-20', title: 'تم استلام وتجهيز الشحنة بالمستودع', desc: 'مستودع جوانزو الرئيسي', done: true },
        { date: '2026-07-24', title: 'إنهاء الفحص والتستيف الفني', desc: 'مكتب الجودة والتفتيش', done: true },
        { date: activeShipment?.etd || '2026-07-28', title: 'مغادرة ميناء التصدير بالصين', desc: activeShipment?.origin || 'ميناء جوانزو', done: true },
        { date: activeShipment?.eta || '2026-08-10', title: 'الوصول لميناء التفريغ والتخليص', desc: activeShipment?.destination || 'الميناء المستهدف', done: activeShipment?.progress === 100 }
      ];

  return (
    <section id="tracker" style={{ padding: '80px 0', background: 'var(--bg-main)' }}>
      <div className="container">
        
        {/* Section Header */}
        <div style={{ textAlign: 'center', maxWidth: '700px', margin: '0 auto 40px auto' }}>
          <div className="badge badge-red" style={{ marginBottom: '12px' }}>
            متابعة فورية ومباشرة
          </div>
          <h2 style={{ fontSize: '2.2rem', fontWeight: 800, marginBottom: '16px' }}>
            نظام تتبع الشحنات الميداني Live Tracker
          </h2>
          <p style={{ color: 'var(--text-muted)', fontSize: '1.05rem' }}>
            أدخل رقم التتبع الخاص بشحنتك (مثال: CP-884920) للاطلاع على حالة الحاوية وميعاد الوصول المتوقع.
          </p>
        </div>

        {/* Search Input Box */}
        <div style={{ maxWidth: '640px', margin: '0 auto 48px auto' }}>
          <form 
            onSubmit={handleSearch}
            className="glass-card"
            style={{
              padding: '8px 12px',
              borderRadius: '9999px',
              display: 'flex',
              alignItems: 'center',
              gap: '10px',
              boxShadow: 'var(--shadow-md)'
            }}
          >
            <Search size={22} color="var(--primary)" style={{ marginRight: '12px' }} />
            <input 
              type="text" 
              placeholder="أدخل رقم البوليصة أو رقم التتبع..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              style={{
                flex: 1,
                border: 'none',
                background: 'transparent',
                outline: 'none',
                color: 'var(--text-main)',
                fontSize: '1rem',
                fontWeight: 700
              }}
            />
            <button 
              type="submit" 
              className="btn-primary"
              style={{ borderRadius: '9999px', padding: '10px 24px' }}
            >
              تتبع الشحنة
            </button>
          </form>
        </div>

        {/* Shipment Progress Card Result */}
        {searched && activeShipment && (
          <div 
            className="glass-card animate-fade-in"
            style={{
              maxWidth: '960px',
              margin: '0 auto',
              padding: '36px',
              borderRadius: 'var(--radius-lg)',
              border: '1px solid var(--border-color)'
            }}
          >
            {/* Header info */}
            <div 
              style={{
                display: 'flex',
                justify: 'space-between',
                alignItems: 'center',
                flexWrap: 'wrap',
                gap: '16px',
                borderBottom: '1px solid var(--border-color)',
                paddingBottom: '24px',
                marginBottom: '28px'
              }}
            >
              <div>
                <div style={{ fontSize: '0.85rem', color: 'var(--text-muted)', marginBottom: '4px' }}>رقم التتبع المسجل:</div>
                <div style={{ fontSize: '1.6rem', fontWeight: 900, color: 'var(--primary)', fontFamily: 'var(--font-en)' }}>
                  {activeShipment.id}
                </div>
              </div>

              <div style={{ textAlign: 'left' }}>
                <span className="badge badge-gold" style={{ fontSize: '0.9rem', padding: '6px 16px' }}>
                  {activeShipment.status}
                </span>
                <div style={{ fontSize: '0.82rem', color: 'var(--text-muted)', marginTop: '6px' }}>
                  الحاوية: <strong style={{ fontFamily: 'var(--font-en)' }}>{activeShipment.containerNo}</strong>
                </div>
              </div>
            </div>

            {/* Key Grid Stats */}
            <div 
              style={{
                display: 'grid',
                gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))',
                gap: '20px',
                marginBottom: '36px'
              }}
            >
              <div style={{ background: 'var(--bg-main)', padding: '16px', borderRadius: 'var(--radius-md)', border: '1px solid var(--border-color)' }}>
                <div style={{ fontSize: '0.8rem', color: 'var(--text-muted)', marginBottom: '4px' }}>جهة الإنطلاق:</div>
                <div style={{ fontWeight: 800, fontSize: '0.98rem' }}>{activeShipment.origin}</div>
              </div>

              <div style={{ background: 'var(--bg-main)', padding: '16px', borderRadius: 'var(--radius-md)', border: '1px solid var(--border-color)' }}>
                <div style={{ fontSize: '0.8rem', color: 'var(--text-muted)', marginBottom: '4px' }}>جهة الوصول:</div>
                <div style={{ fontWeight: 800, fontSize: '0.98rem' }}>{activeShipment.destination}</div>
              </div>

              <div style={{ background: 'var(--bg-main)', padding: '16px', borderRadius: 'var(--radius-md)', border: '1px solid var(--border-color)' }}>
                <div style={{ fontSize: '0.8rem', color: 'var(--text-muted)', marginBottom: '4px' }}>تاريخ المغادرة (ETD):</div>
                <div style={{ fontWeight: 800, fontSize: '0.98rem', fontFamily: 'var(--font-en)' }}>{activeShipment.etd}</div>
              </div>

              <div style={{ background: 'var(--bg-main)', padding: '16px', borderRadius: 'var(--radius-md)', border: '1px solid var(--border-color)' }}>
                <div style={{ fontSize: '0.8rem', color: 'var(--text-muted)', marginBottom: '4px' }}>تاريخ الوصول التقديري (ETA):</div>
                <div style={{ fontWeight: 800, fontSize: '0.98rem', color: 'var(--primary)', fontFamily: 'var(--font-en)' }}>{activeShipment.eta}</div>
              </div>
            </div>

            {/* Visual Timeline Steps (100% Safe Array Map) */}
            <div style={{ marginTop: '24px' }}>
              <h4 style={{ fontSize: '1.1rem', fontWeight: 800, marginBottom: '20px' }}>خط زمني لمراحل الترانزيت:</h4>
              
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: '16px' }}>
                {historySteps.map((step, idx) => (
                  <div 
                    key={idx}
                    style={{
                      background: 'var(--bg-main)',
                      padding: '16px',
                      borderRadius: 'var(--radius-md)',
                      border: step.done ? '1px solid var(--primary)' : '1px solid var(--border-color)',
                      opacity: step.done ? 1 : 0.6
                    }}
                  >
                    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '8px' }}>
                      <span style={{ fontSize: '0.78rem', color: 'var(--text-muted)', fontFamily: 'var(--font-en)' }}>{step.date}</span>
                      <CheckCircle2 size={16} color={step.done ? '#10B981' : 'var(--text-muted)'} />
                    </div>
                    <div style={{ fontWeight: 800, fontSize: '0.9rem', marginBottom: '4px' }}>{step.title}</div>
                    <div style={{ fontSize: '0.8rem', color: 'var(--text-muted)' }}>{step.desc}</div>
                  </div>
                ))}
              </div>
            </div>

          </div>
        )}

      </div>
    </section>
  );
}
