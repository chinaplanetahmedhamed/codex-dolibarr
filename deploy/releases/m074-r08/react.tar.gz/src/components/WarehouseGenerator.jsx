import React, { useState } from 'react';
import { Warehouse, Copy, Check, Sparkles, MapPin, Phone, User, ShieldCheck } from 'lucide-react';

export default function WarehouseGenerator() {
  const [clientName, setClientName] = useState('شركة التجار المتحدين');
  const [copied, setCopied] = useState(false);

  // Guangzhou Address Template
  const warehouseAddress = {
    chineseName: "广州市越秀区东风西路132-1号1011-1012室 (China Planet Warehouse)",
    clientMark: `CP-HUB-${clientName.replace(/\s+/g, '-').toUpperCase()}`,
    consignee: "Omar Mohamed / Vision Trading Warehouse Receiver",
    phone: "+86 13480652510 / +86 020 81290382",
    district: "Yuexiu District, Guangzhou City, Guangdong Province, China",
    postalCode: "510000"
  };

  const handleCopy = () => {
    const fullText = `
收货人 (Consignee): ${warehouseAddress.consignee} (${warehouseAddress.clientMark})
电话 (Phone): ${warehouseAddress.phone}
地址 (Address): ${warehouseAddress.chineseName}
邮编 (Postal): ${warehouseAddress.postalCode}
    `.trim();

    navigator.clipboard.writeText(fullText);
    setCopied(true);
    setTimeout(() => setCopied(false), 3000);
  };

  return (
    <section id="warehouse" style={{ padding: '80px 0', background: 'var(--bg-main)' }}>
      <div className="container">
        
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(320px, 1fr))', gap: '48px', alignItems: 'center' }}>
          
          {/* Text Column */}
          <div>
            <div className="badge badge-gold" style={{ marginBottom: '12px' }}>
              عنوانك المباشر في الصين
            </div>
            <h2 style={{ fontSize: '2.2rem', fontWeight: 800, marginBottom: '20px' }}>
              الآن أنت تمتلك عنواناً رسمياً ومستودعاً بملايين الطرود في جوانزو 🇨🇳
            </h2>
            <p style={{ color: 'var(--text-muted)', fontSize: '1.05rem', lineHeight: 1.7, marginBottom: '28px' }}>
              اشترِ مباشرة من 1688، Taobao، Alibaba، أو المصانع الصينية وقّم بطلب شحن البضائع إلى عنوان مستودعنا في مدينة جوانزو. سنقوم فوراً بتلقي الطرود، وزرع الباركود، وتصويرها لك، وتجميعها لتقليل مصاريف الشحن الدولية!
            </p>

            {/* Benefits list */}
            <div style={{ display: 'flex', flexDirection: 'column', gap: '14px', marginBottom: '32px' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
                <div style={{ width: '28px', height: '28px', borderRadius: '50%', background: 'rgba(16, 185, 129, 0.15)', color: '#10B981', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                  <Check size={16} />
                </div>
                <span style={{ fontWeight: 700 }}>30 يوماً تخزين مجاني كلياً بدون أي مصاريف</span>
              </div>
              <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
                <div style={{ width: '28px', height: '28px', borderRadius: '50%', background: 'rgba(16, 185, 129, 0.15)', color: '#10B981', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                  <Check size={16} />
                </div>
                <span style={{ fontWeight: 700 }}>تجميع طرود من عدة مصانع في شحنة واحدة</span>
              </div>
              <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
                <div style={{ width: '28px', height: '28px', borderRadius: '50%', background: 'rgba(16, 185, 129, 0.15)', color: '#10B981', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                  <Check size={16} />
                </div>
                <span style={{ fontWeight: 700 }}>تنبيه فور ورود أي طرد مع تصوير فوتوغرافي محترف</span>
              </div>
            </div>
          </div>

          {/* Generator Card */}
          <div 
            className="glass-card"
            style={{
              padding: '32px',
              borderRadius: 'var(--radius-lg)',
              border: '1px solid var(--border-color)',
              boxShadow: 'var(--shadow-lg)'
            }}
          >
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '20px' }}>
              <h3 style={{ fontSize: '1.2rem', fontWeight: 800, display: 'flex', alignItems: 'center', gap: '8px' }}>
                <Warehouse size={22} color="var(--primary)" />
                عنوان مستودع جوانزو الصيني الخاص بك
              </h3>
              <span className="badge badge-red">مفعل</span>
            </div>

            <div style={{ marginBottom: '20px' }}>
              <label style={{ display: 'block', fontSize: '0.85rem', fontWeight: 700, marginBottom: '6px' }}>
                اسم مؤسستك / كود العميل المميز:
              </label>
              <input 
                type="text" 
                className="input-field" 
                value={clientName}
                onChange={(e) => setClientName(e.target.value)}
                placeholder="أدخل اسم شركتك لتوليد الكود"
              />
            </div>

            {/* Generated Address Box */}
            <div 
              style={{
                background: 'linear-gradient(135deg, #0F172A 0%, #1E293B 100%)',
                color: '#FFF',
                borderRadius: 'var(--radius-md)',
                padding: '20px',
                marginBottom: '20px',
                position: 'relative'
              }}
            >
              <div style={{ fontSize: '0.8rem', color: '#94A3B8', textTransform: 'uppercase', marginBottom: '12px' }}>
                العنوان باللغة الصينية المقبولة لدى 1688 / المصانع:
              </div>

              <div style={{ fontFamily: 'monospace', fontSize: '0.95rem', lineHeight: 1.6, color: '#F1F5F9', marginBottom: '14px' }}>
                <strong>收货人 (المستلم):</strong> {warehouseAddress.consignee} <span style={{ color: '#F59E0B' }}>({warehouseAddress.clientMark})</span><br />
                <strong>电话 (الهاتف):</strong> {warehouseAddress.phone}<br />
                <strong>地址 (العنوان):</strong> {warehouseAddress.chineseName}<br />
                <strong>邮编 (الرمز البريدي):</strong> {warehouseAddress.postalCode}
              </div>

              <div style={{ fontSize: '0.8rem', color: '#6EE7B7', borderTop: '1px solid rgba(255, 255, 255, 0.1)', paddingTop: '10px' }}>
                💡 يرجى كتابة كود العميل <span style={{ fontWeight: 800, color: '#FFF' }}>{warehouseAddress.clientMark}</span> على كرتونة البضاعة لتخصيصها لك مباشرة فور استلامها.
              </div>
            </div>

            {/* Copy Button */}
            <button 
              onClick={handleCopy} 
              className={copied ? "btn-secondary" : "btn-primary"}
              style={{ width: '100%', justifyContent: 'center', padding: '12px', fontSize: '1rem' }}
            >
              {copied ? (
                <>
                  <Check size={18} color="#10B981" />
                  <span>تم نسخ العنوان الصيني بنجاح!</span>
                </>
              ) : (
                <>
                  <Copy size={18} />
                  <span>نسخ العنوان باللغة الصينية لإرساله للمورد</span>
                </>
              )}
            </button>

          </div>

        </div>

      </div>
    </section>
  );
}
