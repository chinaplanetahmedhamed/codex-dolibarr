import React, { useState, useEffect } from 'react';
import {
  Menu,
  X,
  ShieldCheck,
  Building2,
  Search,
  Warehouse,
  Truck,
  CircleDollarSign,
  BriefcaseBusiness,
  FileCheck2,
  Sparkles,
  ShoppingBag,
  UserRoundCheck,
  Languages
} from 'lucide-react';
import { SERVICES_DATA as DEFAULT_SERVICES } from '../data/mockData';
import { ChinaPlanetLogo } from './BrandLogos';
import { useI18n } from '../i18n/I18nContext';
import { LOCALE_LABELS } from '../i18n/translations';
import { localizeService } from '../i18n/serviceCopy';
import { routeForNavigationTab } from '../lib/appRoute';
import AppLink from './AppLink';

export default function Navbar({ 
  currentTab, 
  setCurrentTab, 
  theme, 
  toggleTheme, 
  onOpenQuoteModal,
  onSelectService,
  servicesData,
  siteInfo,
  cartCount,
  onOpenCart,
  customerCenterUrl
}) {
  const { locale, setLocale, t, isRtl } = useI18n();
  const [scrolled, setScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [servicesDropdownOpen, setServicesDropdownOpen] = useState(false);

  const activeServicesList = (servicesData && servicesData.length ? servicesData : DEFAULT_SERVICES).map((service) => localizeService(service, locale));

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { id: 'home', label: t('nav.home') },
    { id: 'about', label: t('nav.about') },
    { id: 'services', label: t('nav.services'), hasDropdown: true },
    { id: 'products', label: t('nav.products') },
    { id: 'b2b', label: t('nav.b2b') },
    { id: 'shipping-rates', label: t('nav.shipping') },
    { id: 'how-we-work', label: t('nav.howWeWork') },
    { id: 'china-guide', label: t('nav.chinaGuide') },
    { id: 'blog', label: t('nav.blog') },
    { id: 'faq', label: t('nav.faq') },
    { id: 'contact', label: t('nav.contact') },
  ];
  const primaryNavIds = new Set(['services', 'products', 'b2b', 'shipping-rates', 'how-we-work', 'china-guide', 'blog']);
  const desktopNavLinks = navLinks.filter((link) => primaryNavIds.has(link.id));
  const moreNavLinks = navLinks.filter((link) => ['about', 'faq', 'contact'].includes(link.id));

  const handleNavClick = (id) => {
    setCurrentTab(id);
    setMobileMenuOpen(false);
    setServicesDropdownOpen(false);

    if (id !== 'products' && id !== 'b2b' && id !== 'shipping-rates' && id !== 'blog' && id !== 'china-guide') {
      const elem = document.getElementById(id);
      if (elem) {
        elem.scrollIntoView({ behavior: 'smooth' });
      }
    } else {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  const getServiceIcon = (iconName) => {
    switch (iconName) {
      case 'ShieldCheck': return <ShieldCheck size={18} color="#D32F2F" />;
      case 'Building2': return <Building2 size={18} color="#D32F2F" />;
      case 'Search': return <Search size={18} color="#D32F2F" />;
      case 'Warehouse': return <Warehouse size={18} color="#D32F2F" />;
      case 'Truck': return <Truck size={18} color="#D32F2F" />;
      case 'CircleDollarSign': return <CircleDollarSign size={18} color="#D32F2F" />;
      case 'BriefcaseBusiness': return <BriefcaseBusiness size={18} color="#D32F2F" />;
      case 'FileCheck2': return <FileCheck2 size={18} color="#D32F2F" />;
      default: return <ShieldCheck size={18} color="#D32F2F" />;
    }
  };

  return (
    <header 
      className="site-header"
      style={{
        position: 'fixed',
        top: 0,
        left: 0,
        right: 0,
        width: '100%',
        zIndex: 1000,
        padding: scrolled ? '6px 0' : '10px 0',
        transition: 'all 0.3s ease',
        background: scrolled 
          ? (theme === 'dark' ? 'rgba(19, 26, 41, 0.95)' : 'rgba(255, 255, 255, 0.95)')
          : (theme === 'dark' ? 'rgba(9, 13, 22, 0.92)' : 'rgba(255, 255, 255, 0.92)'),
        backdropFilter: 'blur(16px)',
        WebkitBackdropFilter: 'blur(16px)',
        boxShadow: scrolled ? 'var(--shadow-md)' : '0 2px 10px rgba(0,0,0,0.04)',
        borderBottom: '1px solid var(--border-color)'
      }}
    >
      {/* Top Announcement Bar */}
      <div 
        className="site-announcement"
        style={{
          background: 'linear-gradient(90deg, #B71C1C 0%, #D32F2F 50%, #0F172A 100%)',
          color: '#FFFFFF',
          fontSize: '0.78rem',
          fontWeight: 700,
          padding: '6px 0',
          textAlign: 'center',
          marginTop: scrolled ? '-6px' : '-10px',
          marginBottom: '8px',
          overflow: 'hidden',
          transition: 'all 0.3s ease'
        }}
      >
        <div className="container site-announcement-container" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '6px' }}>
          <div className="site-announcement-content" style={{ display: 'flex', alignItems: 'center', gap: '6px', flexWrap: 'wrap', justifyContent: 'center', width: '100%', maxWidth: '100%' }}>
            <span className="badge badge-gold site-announcement-prefix" style={{ background: '#FFF', color: '#B71C1C', padding: '2px 8px', fontSize: '0.72rem' }}>
              {locale === 'ar' ? (siteInfo?.announcementPrefix || t('announcement.prefix')) : t('announcement.prefix')}
            </span>
            <span className="site-announcement-text" style={{ fontSize: '0.78rem', whiteSpace: 'normal', wordBreak: 'break-word' }}>
              {locale === 'ar' ? (siteInfo?.heroBadge || siteInfo?.announcementText || t('announcement.text')) : t('announcement.text')}
            </span>
          </div>
        </div>
      </div>

      {/* Main Header Container */}
      <div className="container site-header-row" style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: '12px' }}>
        
        {/* Standalone Logo */}
        <AppLink
          to="/"
          className="site-brand"
          onNavigate={() => handleNavClick('home')}
          aria-label={t('nav.homeAria')}
          style={{ 
            display: 'flex', 
            alignItems: 'center', 
            cursor: 'pointer',
            userSelect: 'none',
            border: 0,
            padding: 0,
            background: 'transparent'
            ,textDecoration: 'none'
          }}
        >
          <ChinaPlanetLogo
            variant={theme === 'dark' ? 'white' : 'black'}
            className="site-brand-logo"
          />
        </AppLink>

        {/* Floating Pill Nav Links (Desktop) */}
        <ul 
          className="hide-mobile site-desktop-nav"
          style={{
            position: 'relative',
            display: 'flex',
            alignItems: 'center',
            gap: '4px',
            borderRadius: '9999px',
            border: theme === 'dark' 
              ? '1px solid rgba(255, 255, 255, 0.15)' 
              : '1px solid rgba(15, 23, 42, 0.12)',
            padding: '6px 10px',
            boxShadow: '0 4px 16px rgba(0, 0, 0, 0.08)',
            backdropFilter: 'blur(16px)',
            WebkitBackdropFilter: 'blur(16px)',
            background: theme === 'dark' 
              ? 'rgba(0, 0, 0, 0.35)' 
              : 'rgba(255, 255, 255, 0.85)',
            listStyle: 'none',
            margin: 0
          }}
        >
          {desktopNavLinks.map((link) => {
            const isActive = currentTab === link.id;

            if (link.hasDropdown) {
              return (
                <li key={link.id} style={{ position: 'relative' }}>
                  <button
                    onClick={() => setServicesDropdownOpen(!servicesDropdownOpen)}
                    aria-expanded={servicesDropdownOpen}
                    aria-haspopup="menu"
                    style={{
                      background: isActive 
                        ? 'linear-gradient(135deg, #D32F2F 0%, #B71C1C 100%)' 
                        : 'transparent',
                      color: isActive ? '#FFFFFF' : 'var(--text-main)',
                      border: 'none',
                      padding: '6px 11px',
                      borderRadius: '9999px',
                      fontWeight: 700,
                      fontSize: '0.86rem',
                      whiteSpace: 'nowrap',
                      cursor: 'pointer',
                      display: 'flex',
                      alignItems: 'center',
                      gap: '4px',
                      transition: 'all 0.3s ease',
                      boxShadow: isActive ? '0 4px 12px rgba(211, 47, 47, 0.35)' : 'none'
                    }}
                  >
                    <span>{link.label}</span>
                    <span style={{ fontSize: '11px', transform: servicesDropdownOpen ? 'rotate(180deg)' : 'none', transition: 'transform 0.3s ease' }}>⌄</span>
                  </button>

                  {/* Dropdown Floating Card */}
                  {servicesDropdownOpen && (
                    <div 
                      className="glass-card animate-fade-in"
                      style={{
                        position: 'absolute',
                        top: 'calc(100% + 14px)',
                        [isRtl ? 'right' : 'left']: '50%',
                        transform: `translateX(${isRtl ? '50%' : '-50%'})`,
                        width: '320px',
                        padding: '14px',
                        borderRadius: 'var(--radius-lg)',
                        boxShadow: '0 20px 40px rgba(0, 0, 0, 0.35)',
                        border: '1px solid var(--border-color)',
                        zIndex: 1200,
                        background: theme === 'dark' ? 'rgba(19, 26, 41, 0.96)' : 'rgba(255, 255, 255, 0.96)',
                        backdropFilter: 'blur(24px)'
                      }}
                    >
                      <div style={{ padding: '6px 10px', fontSize: '0.8rem', color: 'var(--text-muted)', fontWeight: 800, borderBottom: '1px solid var(--border-color)', marginBottom: '8px', display: 'flex', justifyContent: 'space-between' }}>
                        <span>{t('nav.servicePages')}</span>
                        <Sparkles size={14} color="var(--primary)" />
                      </div>

                      <div style={{ display: 'flex', flexDirection: 'column', gap: '4px' }}>
                        <AppLink
                          to="/services"
                          onNavigate={() => handleNavClick('services')}
                          style={{ display: 'flex', alignItems: 'center', gap: '12px', padding: '10px 12px', borderRadius: 'var(--radius-sm)', border: '1px solid var(--border-color)', background: 'var(--primary-light)', color: 'var(--primary)', fontWeight: 800, fontSize: '0.9rem', cursor: 'pointer', textAlign: 'right', marginBottom: '4px', textDecoration: 'none' }}
                        >
                          <Sparkles size={18} />
                          <span>{t('nav.allServices')}</span>
                        </AppLink>
                        {activeServicesList.map((service) => (
                          <AppLink
                            key={service.id}
                            to={`/service/${encodeURIComponent(service.id)}`}
                            onNavigate={() => {
                              onSelectService(service.id);
                              setServicesDropdownOpen(false);
                            }}
                            style={{
                              display: 'flex',
                              alignItems: 'center',
                              gap: '12px',
                              padding: '10px 12px',
                              borderRadius: 'var(--radius-sm)',
                              border: 'none',
                              background: 'transparent',
                              color: 'var(--text-main)',
                              fontWeight: 700,
                              fontSize: '0.9rem',
                              cursor: 'pointer',
                              textAlign: 'right',
                              transition: 'all 0.2s ease'
                              ,textDecoration: 'none'
                            }}
                            onMouseEnter={(e) => e.currentTarget.style.background = 'var(--primary-light)'}
                            onMouseLeave={(e) => e.currentTarget.style.background = 'transparent'}
                          >
                            {getServiceIcon(service.icon)}
                            <span>{service.title}</span>
                          </AppLink>
                        ))}
                      </div>
                    </div>
                  )}
                </li>
              );
            }

            return (
              <li key={link.id}>
                <AppLink
                  to={routeForNavigationTab(link.id)}
                  onNavigate={() => handleNavClick(link.id)}
                  style={{
                    background: isActive 
                      ? 'linear-gradient(135deg, #D32F2F 0%, #B71C1C 100%)' 
                      : 'transparent',
                    color: isActive ? '#FFFFFF' : 'var(--text-main)',
                    border: 'none',
                    padding: '6px 11px',
                    borderRadius: '9999px',
                    fontWeight: 700,
                    fontSize: '0.86rem',
                    whiteSpace: 'nowrap',
                    cursor: 'pointer',
                    transition: 'all 0.3s ease',
                    boxShadow: isActive ? '0 4px 12px rgba(211, 47, 47, 0.35)' : 'none'
                    ,textDecoration: 'none'
                  }}
                >
                  {link.label}
                </AppLink>
              </li>
            );
          })}
          <li className="site-more-menu">
            <details>
              <summary>{t('nav.more')}</summary>
              <div>{moreNavLinks.map((link) => <AppLink key={link.id} to={routeForNavigationTab(link.id)} onNavigate={() => handleNavClick(link.id)}>{link.label}</AppLink>)}</div>
            </details>
          </li>
        </ul>

        {/* Controls */}
        <div className="site-header-controls" style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
          <label className="site-language-select" title={t('language')}>
            <Languages size={17} aria-hidden="true" />
            <select value={locale} onChange={(event) => setLocale(event.target.value)} aria-label={t('language')}>
              {Object.entries(LOCALE_LABELS).map(([code, label]) => <option key={code} value={code}>{label}</option>)}
            </select>
          </label>
          
          {/* Cart Icon Button */}
          {onOpenCart && (
            <button
              className="site-cart-button"
              type="button"
              aria-label={t('nav.cartAria')}
              onClick={onOpenCart}
              style={{
                borderRadius: '9999px',
                border: '1px solid var(--primary)',
                background: 'var(--primary-light)',
                color: 'var(--primary)',
                padding: '6px 14px',
                fontSize: '0.85rem',
                fontWeight: 800,
                cursor: 'pointer',
                display: 'flex',
                alignItems: 'center',
                gap: '6px',
                position: 'relative'
              }}
            >
              <ShoppingBag size={18} />
              <span className="site-cart-label">{t('nav.cart')}</span>
              {cartCount > 0 && (
                <span style={{ background: 'var(--primary)', color: '#FFF', borderRadius: '50%', padding: '2px 6px', fontSize: '0.72rem' }}>
                  {cartCount}
                </span>
              )}
            </button>
          )}

          {customerCenterUrl && (
            <a
              href={customerCenterUrl}
              className="btn-secondary hide-mobile"
              style={{ padding: '8px 14px', borderRadius: '9999px', fontSize: '0.82rem', textDecoration: 'none' }}
            >
              <UserRoundCheck size={17} />
              <span>{t('nav.customerLogin')}</span>
            </a>
          )}

          {/* Theme Toggle Button */}
          <button 
            className="site-theme-toggle"
            type="button"
            onClick={toggleTheme}
            style={{
              width: '36px',
              height: '36px',
              borderRadius: '50%',
              border: theme === 'dark' ? '1px solid rgba(255, 255, 255, 0.2)' : '1px solid rgba(15, 23, 42, 0.15)',
              background: theme === 'dark' ? 'rgba(0, 0, 0, 0.3)' : 'rgba(255, 255, 255, 0.8)',
              backdropFilter: 'blur(12px)',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              cursor: 'pointer',
              fontSize: '1rem'
            }}
            aria-label={t('nav.themeToggle')}
          >
            {theme === 'dark' ? '☀️' : '🌙'}
          </button>

          {/* Mobile Drawer Icon */}
          <button 
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="btn-outline show-mobile-only site-mobile-menu-toggle"
            aria-label={mobileMenuOpen ? t('nav.closeMenu') : t('nav.openMenu')}
            aria-expanded={mobileMenuOpen}
            style={{ padding: '6px 10px', borderRadius: '9999px' }}
          >
            {mobileMenuOpen ? <X size={20} /> : <Menu size={20} />}
          </button>
        </div>

      </div>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div className="container" style={{ marginTop: '10px' }}>
          <div 
            className="glass-card animate-fade-in site-mobile-nav-drawer"
            style={{
              padding: '16px',
              borderRadius: 'var(--radius-lg)',
              display: 'flex',
              flexDirection: 'column',
              gap: '6px'
            }}
          >
            {navLinks.map((link) => (
              <AppLink
                key={link.id}
                to={routeForNavigationTab(link.id)}
                onNavigate={() => handleNavClick(link.id)}
                style={{
                  background: currentTab === link.id ? 'var(--primary-light)' : 'transparent',
                  color: currentTab === link.id ? 'var(--primary)' : 'var(--text-main)',
                  border: 'none',
                  padding: '10px 14px',
                  borderRadius: 'var(--radius-sm)',
                  fontWeight: 800,
                  textAlign: isRtl ? 'right' : 'left',
                  fontSize: '0.95rem',
                  cursor: 'pointer'
                  ,textDecoration: 'none'
                }}
              >
                {link.label}
              </AppLink>
            ))}

            <div style={{ padding: '8px 0', borderTop: '1px solid var(--border-color)', marginTop: '6px' }}>
              <div style={{ fontSize: '0.82rem', fontWeight: 800, marginBottom: '6px', color: 'var(--primary)', textAlign: isRtl ? 'right' : 'left' }}>{t('nav.servicePages')}</div>
              {activeServicesList.map((srv) => (
                <AppLink
                  key={srv.id}
                  to={`/service/${encodeURIComponent(srv.id)}`}
                  onNavigate={() => {
                    onSelectService(srv.id);
                    setMobileMenuOpen(false);
                  }}
                  style={{
                    display: 'block',
                    width: '100%',
                    textAlign: isRtl ? 'right' : 'left',
                    padding: '8px 10px',
                    background: 'none',
                    border: 'none',
                    fontWeight: 600,
                    fontSize: '0.88rem',
                    color: 'var(--text-main)',
                    cursor: 'pointer'
                    ,textDecoration: 'none'
                  }}
                >
                  • {srv.title}
                </AppLink>
              ))}
            </div>

            <div style={{ display: 'flex', gap: '10px', marginTop: '10px' }}>
              {customerCenterUrl && (
                <a
                  href={customerCenterUrl}
                  className="btn-secondary"
                  style={{ flex: 1, justifyContent: 'center', borderRadius: '9999px', fontSize: '0.85rem', textDecoration: 'none' }}
                >
                  {t('nav.customerLogin')}
                </a>
              )}
              <button 
                onClick={() => { onOpenQuoteModal(); setMobileMenuOpen(false); }} 
                className="btn-primary" 
                style={{ flex: 1, justifyContent: 'center', borderRadius: '9999px', fontSize: '0.85rem' }}
              >
                {t('nav.quote')}
              </button>
            </div>

          </div>
        </div>
      )}
    </header>
  );
}
