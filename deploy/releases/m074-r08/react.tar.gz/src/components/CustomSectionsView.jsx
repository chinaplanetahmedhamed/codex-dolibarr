import React from 'react';
import { PhoneCall, CheckCircle2 } from 'lucide-react';

export default function CustomSectionsView({ customSections, sections, positionFilter, onOpenQuoteModal }) {
  const sectionList = customSections || sections || [];
  if (sectionList.length === 0) return null;

  // Filter sections by position order ('top', 'middle', 'bottom') if positionFilter is provided, else render all!
  const sectionsToRender = positionFilter 
    ? sectionList.filter(sec => (sec.position || 'top') === positionFilter)
    : sectionList;

  if (sectionsToRender.length === 0) return null;

  const getBgStyle = (themeStyle) => {
    switch (themeStyle) {
      case 'dark':
        return { background: 'linear-gradient(135deg, #0F172A 0%, #1E293B 100%)', color: '#FFFFFF' };
      case 'red-gradient':
        return { background: 'linear-gradient(135deg, #B71C1C 0%, #D32F2F 100%)', color: '#FFFFFF' };
      case 'glass':
        return { background: 'var(--bg-card)', color: 'var(--text-main)' };
      default:
        return { background: 'var(--bg-main)', color: 'var(--text-main)' };
    }
  };

  const handleButtonClick = (sec) => {
    const link = sec.buttonLink;
    if (link && (link.startsWith('http://') || link.startsWith('https://') || link.startsWith('tel:') || link.startsWith('mailto:') || link.startsWith('https://wa.me/'))) {
      window.open(link, '_blank');
    } else if (link && link.startsWith('#')) {
      const elem = document.getElementById(link.substring(1));
      if (elem) {
        elem.scrollIntoView({ behavior: 'smooth' });
      } else {
        onOpenQuoteModal();
      }
    } else {
      onOpenQuoteModal();
    }
  };

  return (
    <>
      {sectionsToRender.map((sec, idx) => {
        const template = sec.template || 'img-left'; // img-left | img-right | centered | 3-columns | glow-banner
        const bgStyle = getBgStyle(sec.themeStyle);

        // TEMPLATE 1: Image Left, Content Right (صورة ع الشمال، كلام ع اليمين)
        if (template === 'img-left') {
          return (
            <section key={sec.id || idx} style={{ padding: '80px 0', borderTop: '1px solid var(--border-color)', ...bgStyle }}>
              <div className="container">
                <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(320px, 1fr))', gap: '44px', alignItems: 'center' }}>
                  
                  {/* Content on Right (in RTL) */}
                  <div>
                    {sec.badge && <span className="badge badge-gold" style={{ marginBottom: '14px' }}>{sec.badge}</span>}
                    <h2 style={{ fontSize: '2.2rem', fontWeight: 800, marginBottom: '16px', lineHeight: 1.2 }}>{sec.title}</h2>
                    <p style={{ fontSize: '1.05rem', lineHeight: 1.7, opacity: 0.9, marginBottom: '28px', whiteSpace: 'pre-line' }}>{sec.content}</p>
                    <button onClick={() => handleButtonClick(sec)} className="btn-primary" style={{ padding: '12px 24px' }}>
                      <PhoneCall size={18} />
                      <span>{sec.buttonText || 'تواصل معنا الآن'}</span>
                    </button>
                  </div>

                  {/* Image on Left (in RTL) */}
                  {sec.image && (
                    <div style={{ borderRadius: 'var(--radius-lg)', overflow: 'hidden', height: '360px', boxShadow: 'var(--shadow-md)', border: '1px solid var(--border-color)' }}>
                      <img src={sec.image} alt={sec.title} style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
                    </div>
                  )}

                </div>
              </div>
            </section>
          );
        }

        // TEMPLATE 2: Image Right, Content Left (صورة ع اليمين، كلام ع الشمال)
        if (template === 'img-right') {
          return (
            <section key={sec.id || idx} style={{ padding: '80px 0', borderTop: '1px solid var(--border-color)', ...bgStyle }}>
              <div className="container">
                <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(320px, 1fr))', gap: '44px', alignItems: 'center' }}>
                  
                  {/* Image on Right (in RTL) */}
                  {sec.image && (
                    <div style={{ borderRadius: 'var(--radius-lg)', overflow: 'hidden', height: '360px', boxShadow: 'var(--shadow-md)', border: '1px solid var(--border-color)' }}>
                      <img src={sec.image} alt={sec.title} style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
                    </div>
                  )}

                  {/* Content on Left (in RTL) */}
                  <div>
                    {sec.badge && <span className="badge badge-gold" style={{ marginBottom: '14px' }}>{sec.badge}</span>}
                    <h2 style={{ fontSize: '2.2rem', fontWeight: 800, marginBottom: '16px', lineHeight: 1.2 }}>{sec.title}</h2>
                    <p style={{ fontSize: '1.05rem', lineHeight: 1.7, opacity: 0.9, marginBottom: '28px', whiteSpace: 'pre-line' }}>{sec.content}</p>
                    <button onClick={() => handleButtonClick(sec)} className="btn-primary" style={{ padding: '12px 24px' }}>
                      <PhoneCall size={18} />
                      <span>{sec.buttonText || 'تواصل معنا الآن'}</span>
                    </button>
                  </div>

                </div>
              </div>
            </section>
          );
        }

        // TEMPLATE 3: Full Width Centered Glass Card (كارت عريض متمركز بالنص)
        if (template === 'centered') {
          return (
            <section key={sec.id || idx} style={{ padding: '80px 0', borderTop: '1px solid var(--border-color)', ...bgStyle }}>
              <div className="container" style={{ textAlign: 'center', maxWidth: '850px' }}>
                {sec.badge && <span className="badge badge-red" style={{ marginBottom: '16px', display: 'inline-flex' }}>{sec.badge}</span>}
                <h2 style={{ fontSize: '2.4rem', fontWeight: 900, marginBottom: '20px', lineHeight: 1.2 }}>{sec.title}</h2>
                <p style={{ fontSize: '1.1rem', lineHeight: 1.8, opacity: 0.9, marginBottom: '32px', whiteSpace: 'pre-line' }}>{sec.content}</p>
                {sec.image && (
                  <div style={{ borderRadius: 'var(--radius-lg)', overflow: 'hidden', height: '340px', margin: '0 auto 32px auto', border: '1px solid var(--border-color)' }}>
                    <img src={sec.image} alt={sec.title} style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
                  </div>
                )}
                <button onClick={() => handleButtonClick(sec)} className="btn-primary" style={{ padding: '14px 32px', fontSize: '1rem', margin: '0 auto' }}>
                  <PhoneCall size={18} />
                  <span>{sec.buttonText || 'اطلب الخدمة الآن'}</span>
                </button>
              </div>
            </section>
          );
        }

        // TEMPLATE 4: 3-Columns Grid Cards (كروت أعمدة متعددة)
        if (template === '3-columns') {
          return (
            <section key={sec.id || idx} style={{ padding: '80px 0', borderTop: '1px solid var(--border-color)', ...bgStyle }}>
              <div className="container">
                <div style={{ textAlign: 'center', maxWidth: '700px', margin: '0 auto 48px auto' }}>
                  {sec.badge && <span className="badge badge-gold" style={{ marginBottom: '12px' }}>{sec.badge}</span>}
                  <h2 style={{ fontSize: '2.2rem', fontWeight: 800, marginBottom: '16px' }}>{sec.title}</h2>
                  <p style={{ fontSize: '1.05rem', opacity: 0.9 }}>{sec.content}</p>
                </div>

                <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))', gap: '24px' }}>
                  {[1, 2, 3].map((num) => (
                    <div key={num} className="glass-card" style={{ padding: '28px', borderRadius: 'var(--radius-md)' }}>
                      <CheckCircle2 size={28} color="var(--primary)" style={{ marginBottom: '14px' }} />
                      <h3 style={{ fontSize: '1.2rem', fontWeight: 800, marginBottom: '8px' }}>ميزة خاصة رقم 0{num}</h3>
                      <p style={{ fontSize: '0.9rem', color: 'var(--text-muted)', lineHeight: 1.6 }}>خدمة مخصصة وموثقة رسمياً من مكتب جوانزو لحماية جميع الموردين.</p>
                    </div>
                  ))}
                </div>
              </div>
            </section>
          );
        }

        // TEMPLATE 5: Glow Banner with Gradient (بنر داكن متوهج)
        return (
          <section key={sec.id || idx} style={{ padding: '80px 0', borderTop: '1px solid var(--border-color)', ...bgStyle }}>
            <div className="container">
              <div className="glass-card" style={{ padding: '48px', borderRadius: 'var(--radius-lg)', border: '2px solid var(--primary)', display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: '32px' }}>
                <div style={{ maxWidth: '600px' }}>
                  {sec.badge && <span className="badge badge-red" style={{ marginBottom: '12px' }}>{sec.badge}</span>}
                  <h2 style={{ fontSize: '2.2rem', fontWeight: 900, marginBottom: '14px', lineHeight: 1.2 }}>{sec.title}</h2>
                  <p style={{ fontSize: '1.05rem', opacity: 0.9, lineHeight: 1.7 }}>{sec.content}</p>
                </div>

                <button onClick={() => handleButtonClick(sec)} className="btn-primary" style={{ padding: '14px 28px', fontSize: '1rem' }}>
                  <PhoneCall size={18} />
                  <span>{sec.buttonText || 'اطلب الخدمة مباشرة'}</span>
                </button>
              </div>
            </div>
          </section>
        );
      })}
    </>
  );
}
