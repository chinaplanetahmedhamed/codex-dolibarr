import React, { useEffect, useRef } from 'react';

const COLORS = ['#D32F2F', '#2563EB', '#F59E0B', '#10B981', '#8B5CF6', '#EC4899'];

function number(value, fallback = 0) {
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : fallback;
}

function colorFor(placement, index) {
  const value = String(placement?.line_key || placement?.sku || placement?.product_id || index);
  let hash = index;
  for (let cursor = 0; cursor < value.length; cursor += 1) hash = ((hash << 5) - hash) + value.charCodeAt(cursor);
  return COLORS[Math.abs(hash) % COLORS.length];
}

function shade(hex, amount) {
  const value = String(hex).replace('#', '');
  if (value.length !== 6) return hex;
  const numeric = Number.parseInt(value, 16);
  const channels = [numeric >> 16, (numeric >> 8) & 255, numeric & 255]
    .map((channel) => Math.max(0, Math.min(255, channel + amount)).toString(16).padStart(2, '0'));
  return `#${channels.join('')}`;
}

export default function B2BContainerVisual({ plan, label, labels = {} }) {
  const canvasRef = useRef(null);
  const drawRef = useRef(null);
  const frameRef = useRef(0);
  const viewRef = useRef({ angle: -0.72, elevation: 0.58, zoom: 0.92 });

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return undefined;
    const context = canvas.getContext('2d');
    if (!context) return undefined;

    const draw = () => {
      const bounds = canvas.getBoundingClientRect();
      const width = Math.max(280, Math.round(bounds.width || 600));
      const height = Math.max(240, Math.round(bounds.height || 320));
      const ratio = Math.min(globalThis.devicePixelRatio || 1, 2);
      if (canvas.width !== Math.round(width * ratio) || canvas.height !== Math.round(height * ratio)) {
        canvas.width = Math.round(width * ratio);
        canvas.height = Math.round(height * ratio);
      }
      context.setTransform(ratio, 0, 0, ratio, 0, 0);
      context.clearRect(0, 0, width, height);

      const container = plan?.container || {};
      const dimensions = {
        length: number(container.length || container.internalLength || container.internal_length, 1),
        width: number(container.width || container.internalWidth || container.internal_width, 1),
        height: number(container.height || container.internalHeight || container.internal_height, 1),
      };
      const placements = Array.isArray(plan?.placements) ? plan.placements : [];
      const view = viewRef.current;
      const maxDimension = Math.max(dimensions.length, dimensions.width, dimensions.height, 1);
      const scale = (Math.min(width * 0.72, height * 0.7) / maxDimension) * view.zoom;
      const cameraDistance = maxDimension * 3.2;

      const depthAt = (x, y) => {
        const dx = x - (dimensions.length / 2);
        const dy = y - (dimensions.width / 2);
        return (dx * Math.sin(view.angle)) + (dy * Math.cos(view.angle));
      };
      const project = (x, y, z) => {
        const dx = x - (dimensions.length / 2);
        const dy = y - (dimensions.width / 2);
        const dz = z - (dimensions.height / 2);
        const horizontal = (dx * Math.cos(view.angle)) - (dy * Math.sin(view.angle));
        const depth = (dx * Math.sin(view.angle)) + (dy * Math.cos(view.angle));
        const perspective = cameraDistance / (cameraDistance + depth);
        const vertical = (depth * Math.sin(view.elevation)) - (dz * Math.cos(view.elevation));
        return { x: (width / 2) + (horizontal * scale * perspective), y: (height * 0.54) + (vertical * scale * perspective) };
      };
      const vertices = (box) => {
        const x = number(box.x); const y = number(box.y); const z = number(box.z);
        const length = number(box.length || box.l); const boxWidth = number(box.width || box.w); const boxHeight = number(box.height || box.h);
        return [
          project(x, y, z), project(x + length, y, z), project(x + length, y + boxWidth, z), project(x, y + boxWidth, z),
          project(x, y, z + boxHeight), project(x + length, y, z + boxHeight), project(x + length, y + boxWidth, z + boxHeight), project(x, y + boxWidth, z + boxHeight),
        ];
      };
      const polygon = (points, fill, stroke, alpha = 1, lineWidth = 1) => {
        context.beginPath(); context.moveTo(points[0].x, points[0].y);
        points.slice(1).forEach((point) => context.lineTo(point.x, point.y));
        context.closePath(); context.globalAlpha = alpha; context.fillStyle = fill; context.fill();
        context.strokeStyle = stroke; context.lineWidth = lineWidth; context.stroke(); context.globalAlpha = 1;
      };
      const line = (start, end, color, lineWidth = 1, alpha = 1) => {
        context.beginPath(); context.moveTo(start.x, start.y); context.lineTo(end.x, end.y);
        context.strokeStyle = color; context.lineWidth = lineWidth; context.globalAlpha = alpha; context.stroke(); context.globalAlpha = 1;
      };

      const background = context.createLinearGradient(0, 0, 0, height);
      background.addColorStop(0, '#eef6ff'); background.addColorStop(0.58, '#f8fbff'); background.addColorStop(1, '#dce7f0');
      context.fillStyle = background; context.fillRect(0, 0, width, height);
      const shadow = context.createRadialGradient(width / 2, height * 0.76, 10, width / 2, height * 0.76, width * 0.42);
      shadow.addColorStop(0, 'rgba(15,23,42,.22)'); shadow.addColorStop(1, 'rgba(15,23,42,0)');
      context.fillStyle = shadow; context.fillRect(0, height * 0.5, width, height * 0.5);

      const containerVertices = vertices({ x: 0, y: 0, z: 0, ...dimensions });
      polygon([containerVertices[0], containerVertices[1], containerVertices[2], containerVertices[3]], 'rgba(71,85,105,.16)', 'rgba(51,65,85,.45)');
      for (let x = 1; x < 6; x += 1) line(project(dimensions.length * x / 6, 0, 0), project(dimensions.length * x / 6, dimensions.width, 0), '#64748b', 0.7, 0.24);
      for (let y = 1; y < 4; y += 1) line(project(0, dimensions.width * y / 4, 0), project(dimensions.length, dimensions.width * y / 4, 0), '#64748b', 0.7, 0.24);
      polygon([containerVertices[0], containerVertices[3], containerVertices[7], containerVertices[4]], 'rgba(148,163,184,.09)', 'rgba(71,85,105,.22)', 1, 0.8);
      polygon([containerVertices[3], containerVertices[2], containerVertices[6], containerVertices[7]], 'rgba(148,163,184,.07)', 'rgba(71,85,105,.2)', 1, 0.8);

      placements.slice().sort((first, second) => (
        depthAt(number(second.x) + (number(second.length) / 2), number(second.y) + (number(second.width) / 2))
        - depthAt(number(first.x) + (number(first.length) / 2), number(first.y) + (number(first.width) / 2))
      )).forEach((box, index) => {
        const points = vertices(box);
        const color = box.color || colorFor(box, index);
        const edge = 'rgba(15,23,42,.58)';
        polygon([points[0], points[1], points[5], points[4]], shade(color, -20), edge, 0.92, 0.75);
        polygon([points[1], points[2], points[6], points[5]], shade(color, -38), edge, 0.9, 0.75);
        polygon([points[4], points[5], points[6], points[7]], shade(color, 25), edge, 0.96, 0.75);
        line(points[4], points[6], 'rgba(255,255,255,.5)', 0.6, 0.45);
      });
      [[0, 1], [1, 2], [2, 3], [3, 0], [4, 5], [5, 6], [6, 7], [7, 4], [0, 4], [1, 5], [2, 6], [3, 7]]
        .forEach(([start, end]) => line(containerVertices[start], containerVertices[end], '#334155', 1.55, 0.82));

      context.fillStyle = 'rgba(15,23,42,.8)'; context.font = '600 11px system-ui, sans-serif'; context.textAlign = 'left';
      const containerName = container.label || container.name || container.id || '';
      context.fillText(`${containerName}  ${dimensions.length.toFixed(0)} × ${dimensions.width.toFixed(0)} × ${dimensions.height.toFixed(0)} cm`, 12, height - 14);
      const visualMode = plan?.visual_mode || plan?.visualMode || '';
      const visualDescription = visualMode === 'aggregate_volume' || visualMode === 'hybrid_volume'
        ? (labels.aggregateBlock || 'estimated aggregate volume block')
        : `${placements.length} ${labels.placed || 'cartons placed'}`;
      canvas.setAttribute('aria-label', `${label}. ${visualDescription}.`);
    };

    const scheduleDraw = () => {
      if (frameRef.current) return;
      frameRef.current = globalThis.requestAnimationFrame(() => { frameRef.current = 0; draw(); });
    };
    drawRef.current = scheduleDraw;
    const dragging = { active: false, x: 0, y: 0, pinchDistance: 0 };
    const pointers = new Map();
    const pointerDistance = () => {
      const points = [...pointers.values()];
      return points.length > 1 ? Math.hypot(points[0].x - points[1].x, points[0].y - points[1].y) : 0;
    };
    const pointerDown = (event) => {
      pointers.set(event.pointerId, { x: event.clientX, y: event.clientY });
      dragging.active = pointers.size === 1; dragging.x = event.clientX; dragging.y = event.clientY;
      if (pointers.size === 2) dragging.pinchDistance = pointerDistance();
      canvas.setPointerCapture?.(event.pointerId);
    };
    const pointerMove = (event) => {
      if (!pointers.has(event.pointerId)) return;
      pointers.set(event.pointerId, { x: event.clientX, y: event.clientY });
      if (pointers.size > 1) {
        const distance = pointerDistance();
        if (dragging.pinchDistance > 0 && distance > 0) {
          viewRef.current.zoom = Math.max(0.42, Math.min(2.4, viewRef.current.zoom * (distance / dragging.pinchDistance)));
        }
        dragging.pinchDistance = distance; dragging.active = false; scheduleDraw(); return;
      }
      if (!dragging.active) { dragging.active = true; dragging.x = event.clientX; dragging.y = event.clientY; return; }
      viewRef.current.angle += (event.clientX - dragging.x) * 0.012;
      viewRef.current.elevation = Math.max(0.12, Math.min(1.25, viewRef.current.elevation + ((event.clientY - dragging.y) * 0.008)));
      dragging.x = event.clientX; dragging.y = event.clientY; scheduleDraw();
    };
    const pointerUp = (event) => {
      pointers.delete(event.pointerId); dragging.pinchDistance = 0;
      const remaining = [...pointers.values()][0];
      if (remaining) { dragging.active = true; dragging.x = remaining.x; dragging.y = remaining.y; }
      else dragging.active = false;
    };
    const wheel = (event) => {
      event.preventDefault();
      viewRef.current.zoom = Math.max(0.42, Math.min(2.4, viewRef.current.zoom * (event.deltaY > 0 ? 0.9 : 1.1)));
      scheduleDraw();
    };
    const keyDown = (event) => {
      if (event.key === '+' || event.key === '=') viewRef.current.zoom = Math.min(2.4, viewRef.current.zoom * 1.1);
      else if (event.key === '-') viewRef.current.zoom = Math.max(0.42, viewRef.current.zoom * 0.9);
      else if (event.key === 'ArrowLeft' || event.key === 'ArrowRight') viewRef.current.angle += event.key === 'ArrowLeft' ? -0.12 : 0.12;
      else if (event.key === 'ArrowUp' || event.key === 'ArrowDown') viewRef.current.elevation = Math.max(0.12, Math.min(1.25, viewRef.current.elevation + (event.key === 'ArrowUp' ? -0.08 : 0.08)));
      else return;
      event.preventDefault(); scheduleDraw();
    };

    canvas.addEventListener('pointerdown', pointerDown); canvas.addEventListener('pointermove', pointerMove);
    canvas.addEventListener('pointerup', pointerUp); canvas.addEventListener('pointercancel', pointerUp);
    canvas.addEventListener('wheel', wheel, { passive: false }); canvas.addEventListener('keydown', keyDown);
    const observer = globalThis.ResizeObserver ? new ResizeObserver(scheduleDraw) : null;
    observer?.observe(canvas); globalThis.addEventListener('resize', scheduleDraw); draw();

    return () => {
      canvas.removeEventListener('pointerdown', pointerDown); canvas.removeEventListener('pointermove', pointerMove);
      canvas.removeEventListener('pointerup', pointerUp); canvas.removeEventListener('pointercancel', pointerUp);
      canvas.removeEventListener('wheel', wheel); canvas.removeEventListener('keydown', keyDown);
      observer?.disconnect(); globalThis.removeEventListener('resize', scheduleDraw);
      if (frameRef.current) globalThis.cancelAnimationFrame(frameRef.current);
      drawRef.current = null;
    };
  }, [label, labels, plan]);

  const adjustView = (action) => {
    if (action === 'left') viewRef.current.angle -= 0.22;
    if (action === 'right') viewRef.current.angle += 0.22;
    if (action === 'zoom-in') viewRef.current.zoom = Math.min(2.4, viewRef.current.zoom * 1.12);
    if (action === 'zoom-out') viewRef.current.zoom = Math.max(0.42, viewRef.current.zoom * 0.88);
    if (action === 'reset') viewRef.current = { angle: -0.72, elevation: 0.58, zoom: 0.92 };
    drawRef.current?.();
  };

  return (
    <figure className="b2b-visual" aria-label={label}>
      <div className="b2b-visual-header">
        <strong>{label}</strong>
        <div className="b2b-view-controls" role="group" aria-label={labels.viewControls || label}>
          <button type="button" onClick={() => adjustView('left')} aria-label={labels.rotateLeft || 'Rotate left'}>↶</button>
          <button type="button" onClick={() => adjustView('reset')} aria-label={labels.reset || 'Reset view'}>⌂</button>
          <button type="button" onClick={() => adjustView('right')} aria-label={labels.rotateRight || 'Rotate right'}>↷</button>
          <button type="button" onClick={() => adjustView('zoom-out')} aria-label={labels.zoomOut || 'Zoom out'}>−</button>
          <button type="button" onClick={() => adjustView('zoom-in')} aria-label={labels.zoomIn || 'Zoom in'}>+</button>
        </div>
      </div>
      <canvas ref={canvasRef} role="img" tabIndex="0" aria-label={label} />
      <figcaption>{labels.visualHelp || label}</figcaption>
    </figure>
  );
}
