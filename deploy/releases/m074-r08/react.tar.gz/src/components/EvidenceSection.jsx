import React from 'react';
import { Building2, ClipboardCheck, Factory, Warehouse } from 'lucide-react';
import { useI18n } from '../i18n/I18nContext';

const COPY = {
  ar: { badge:'دليل قابل للمراجعة', title:'صور عمل ميداني ومستندات منزوعة البيانات الخاصة', intro:'نعرض ما يمكن نشره بأمان. التقارير الكاملة وبيانات العميل والمورد تبقى داخل Customer Center أو تُشارك ضمن نطاق العمل المعتمد.', legalTitle:'من تتعاقد معه؟', legal:'China Planet هي العلامة العامة للموقع والتواصل. عرض العمل أو العقد أو الفاتورة يحدد اسم الكيان القانوني المتعاقد — مثل Vision Trading Ltd. عندما تكون هي الطرف المذكور — ونطاق الخدمة والرسوم والمسؤوليات.', cards:[['مكتب وتنسيق جوانزو','وجود ميداني لمتابعة الموردين والاجتماعات وفق كل مهمة.'],['تجميع المستودع','صور عمليات التجميع العامة فقط؛ بيانات العملاء والموردين لا تُعرض.'],['فحص الجودة','نماذج الفحص تُنزع منها الأسماء والأسعار والمعرّفات الخاصة قبل المشاركة.']] },
  en: { badge:'Reviewable evidence', title:'Field-work images and privacy-safe sample records', intro:'We publish only what can be shown safely. Full reports and customer or supplier data stay in Customer Center or within the approved engagement.', legalTitle:'Who do you contract with?', legal:'China Planet is the public website and communication brand. The proposal, contract or invoice names the contracting legal entity—such as Vision Trading Ltd. when it is the named party—and defines scope, fees and responsibilities.', cards:[['Guangzhou office coordination','On-the-ground supplier and meeting follow-up within each approved assignment.'],['Warehouse consolidation','Only general consolidation images are public; customer and supplier details remain private.'],['Quality inspection','Sample reports are redacted before sharing to remove names, prices and private identifiers.']] },
  fr: { badge:'Preuves vérifiables', title:'Images de terrain et exemples respectueux de la confidentialité', intro:"Nous ne publions que les éléments pouvant être montrés en sécurité. Les rapports complets et données client ou fournisseur restent dans l'Espace client ou le périmètre approuvé.", legalTitle:'Avec qui contractez-vous ?', legal:"China Planet est la marque publique du site et de communication. L'offre, le contrat ou la facture nomme l'entité juridique contractante — par exemple Vision Trading Ltd. lorsqu'elle est désignée — et définit périmètre, frais et responsabilités.", cards:[['Coordination à Guangzhou','Suivi local des fournisseurs et réunions selon chaque mission approuvée.'],['Groupage en entrepôt','Seules des images générales sont publiques ; les données client et fournisseur restent privées.'],['Contrôle qualité','Les exemples de rapports sont anonymisés avant partage : noms, prix et identifiants privés sont retirés.']] },
};

const ITEMS = [
  { image:'/images/china_planet_hero_banner_1785418012119.jpg', icon:Building2 },
  { image:'/images/guangzhou_warehouse_1785418026628.jpg', icon:Warehouse },
  { image:'/images/quality_inspection_1785418041351.jpg', icon:ClipboardCheck },
];

export default function EvidenceSection() {
  const { locale } = useI18n(); const copy = COPY[locale] || COPY.ar;
  return <section className="evidence-section"><div className="container"><span className="badge badge-gold"><Factory size={16}/>{copy.badge}</span><h2>{copy.title}</h2><p className="evidence-intro">{copy.intro}</p><div className="evidence-grid">{ITEMS.map(({image,icon:Icon},index)=><article key={image}><img src={image} alt={copy.cards[index][0]} loading="lazy" decoding="async"/><div><Icon size={20}/><h3>{copy.cards[index][0]}</h3><p>{copy.cards[index][1]}</p></div></article>)}</div><aside className="legal-identity"><Building2 size={26}/><div><h3>{copy.legalTitle}</h3><p>{copy.legal}</p></div></aside></div></section>;
}
