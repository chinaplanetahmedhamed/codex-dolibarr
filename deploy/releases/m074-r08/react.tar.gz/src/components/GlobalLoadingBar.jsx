import React, { useEffect, useState, useSyncExternalStore } from 'react';
import { LoaderCircle } from 'lucide-react';
import { useI18n } from '../i18n/I18nContext';
import { getLoadingSnapshot, subscribeLoading } from '../lib/loadingTracker';

export default function GlobalLoadingBar() {
  const loading = useSyncExternalStore(subscribeLoading, getLoadingSnapshot, getLoadingSnapshot);
  const { t } = useI18n();
  const [visible, setVisible] = useState(false);
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    if (!loading.active) {
      setProgress((current) => current > 0 ? 100 : 0);
      const hideTimer = window.setTimeout(() => {
        setVisible(false);
        setProgress(0);
      }, 320);
      return () => window.clearTimeout(hideTimer);
    }

    setProgress((current) => Math.max(current, 9));
    const showTimer = window.setTimeout(() => setVisible(true), 140);
    const progressTimer = window.setInterval(() => {
      setProgress((current) => {
        if (current >= 88) return current;
        const increment = current < 35 ? 9 : current < 65 ? 4 : 1.5;
        return Math.min(88, current + increment);
      });
    }, 360);
    return () => {
      window.clearTimeout(showTimer);
      window.clearInterval(progressTimer);
    };
  }, [loading.active]);

  if (!visible && progress === 0) return null;
  const label = loading.primary?.label || 'loading.website';

  return (
    <div className={`global-loading${loading.active ? ' is-active' : ' is-complete'}`} role="status" aria-live="polite">
      <div className="global-loading-track" aria-hidden="true">
        <span style={{ width: `${progress}%` }} />
      </div>
      {visible && loading.active && (
        <div className="global-loading-pill">
          <LoaderCircle size={16} aria-hidden="true" />
          <span>{t(label)}</span>
          {loading.count > 1 && <bdi>+{loading.count - 1}</bdi>}
        </div>
      )}
    </div>
  );
}
