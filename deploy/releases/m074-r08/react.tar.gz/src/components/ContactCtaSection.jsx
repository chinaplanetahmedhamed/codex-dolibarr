import React from 'react';
import { ArrowLeft, Mail, MessageSquare } from 'lucide-react';
import { useI18n } from '../i18n/I18nContext';

export default function ContactCtaSection({ onOpenQuoteModal, onOpenContact, siteInfo }) {
  const { t, isRtl } = useI18n();
  return (
    <section style={{ padding: '66px 0', background: 'var(--bg-main)' }}>
      <div className="container">
        <div className="contact-cta-panel">
          <div>
            <div className="badge badge-gold" style={{ marginBottom: '10px' }}>{t('cta.badge')}</div>
            <h2>{t('cta.title')}</h2>
            <p>{t('cta.description')}</p>
          </div>
          <div className="contact-cta-actions">
            <button type="button" className="btn-primary" onClick={onOpenQuoteModal}>
              <MessageSquare size={18} />
              <span>{t('cta.start')}</span>
            </button>
            {onOpenContact ? (
              <button type="button" className="btn-outline contact-cta-outline" onClick={onOpenContact}>
                <Mail size={18} />
                <span>{t('cta.contact')}</span>
                <ArrowLeft size={17} style={{ transform: isRtl ? 'none' : 'rotate(180deg)' }} />
              </button>
            ) : (
              <a className="btn-outline contact-cta-outline" href={`mailto:${siteInfo?.email || 'info@chinaplanet.org'}`}>
                <Mail size={18} />
                <span>{siteInfo?.email || 'info@chinaplanet.org'}</span>
              </a>
            )}
          </div>
        </div>
      </div>
    </section>
  );
}
