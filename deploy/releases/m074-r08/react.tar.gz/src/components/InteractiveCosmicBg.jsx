import React, { useEffect, useRef } from 'react';

export default function InteractiveCosmicBg({ cosmicSettings }) {
  const canvasRef = useRef(null);

  const enabled = cosmicSettings?.enabled !== false;
  const themeStyle = cosmicSettings?.themeStyle || 'cosmic-red-gold';
  const intensity = cosmicSettings?.intensity || 'high';

  useEffect(() => {
    if (!enabled) return;

    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationFrameId;
    let width = (canvas.width = window.innerWidth);
    let height = (canvas.height = window.innerHeight);

    const mouse = {
      x: width / 2,
      y: height / 2,
      targetX: width / 2,
      targetY: height / 2,
      radius: intensity === 'subtle' ? 150 : 230
    };

    const handleMouseMove = (e) => {
      mouse.targetX = e.clientX;
      mouse.targetY = e.clientY;
    };

    window.addEventListener('mousemove', handleMouseMove);

    const handleResize = () => {
      width = canvas.width = window.innerWidth;
      height = canvas.height = window.innerHeight;
    };

    window.addEventListener('resize', handleResize);

    // Dynamic Color Palettes
    let colors = [
      'rgba(239, 68, 68, ',   // Crimson Red
      'rgba(245, 158, 11, ',  // Gold
      'rgba(59, 130, 246, ',  // Sapphire
      'rgba(244, 63, 94, '    // Coral
    ];

    if (themeStyle === 'cyan-nebula') {
      colors = [
        'rgba(6, 182, 212, ',   // Cyan
        'rgba(59, 130, 246, ',  // Blue
        'rgba(16, 185, 129, ',  // Emerald Green
        'rgba(99, 102, 241, '   // Indigo
      ];
    } else if (themeStyle === 'golden-luxury') {
      colors = [
        'rgba(245, 158, 11, ',  // Amber Gold
        'rgba(251, 191, 36, ',  // Yellow Gold
        'rgba(217, 119, 6, ',   // Deep Bronze Gold
        'rgba(255, 237, 213, '  // Warm White
      ];
    } else if (themeStyle === 'purple-galaxy') {
      colors = [
        'rgba(168, 85, 247, ',  // Purple
        'rgba(236, 72, 153, ',  // Pink
        'rgba(99, 102, 241, ',  // Indigo
        'rgba(244, 114, 182, '  // Light Pink
      ];
    }

    // Dynamic Alpha and Sizes based on intensity
    let baseAlphaMultiplier = 1.0;
    let lineOpacityMultiplier = 1.0;
    let particleSizeBase = 3.0;

    if (intensity === 'subtle') {
      baseAlphaMultiplier = 0.5;
      lineOpacityMultiplier = 0.4;
      particleSizeBase = 2.0;
    } else if (intensity === 'behind') {
      baseAlphaMultiplier = 0.7;
      lineOpacityMultiplier = 0.6;
      particleSizeBase = 2.5;
    }

    const particleCount = Math.min(Math.floor((width * height) / 9500), 90);
    const particles = [];

    for (let i = 0; i < particleCount; i++) {
      particles.push({
        x: Math.random() * width,
        y: Math.random() * height,
        vx: (Math.random() - 0.5) * 0.8,
        vy: (Math.random() - 0.5) * 0.8,
        radius: Math.random() * particleSizeBase + 1.5,
        colorPrefix: colors[Math.floor(Math.random() * colors.length)],
        baseAlpha: (Math.random() * 0.4 + 0.4) * baseAlphaMultiplier,
        alpha: (Math.random() * 0.4 + 0.4) * baseAlphaMultiplier
      });
    }

    const render = () => {
      ctx.clearRect(0, 0, width, height);

      mouse.x += (mouse.targetX - mouse.x) * 0.12;
      mouse.y += (mouse.targetY - mouse.y) * 0.12;

      // Draw Cursor Aura Glow
      const auraGradient = ctx.createRadialGradient(
        mouse.x,
        mouse.y,
        0,
        mouse.x,
        mouse.y,
        mouse.radius * 1.5
      );
      auraGradient.addColorStop(0, `${colors[0]}${0.18 * baseAlphaMultiplier})`);
      auraGradient.addColorStop(0.5, `${colors[1]}${0.08 * baseAlphaMultiplier})`);
      auraGradient.addColorStop(1, 'rgba(0, 0, 0, 0)');
      ctx.fillStyle = auraGradient;
      ctx.beginPath();
      ctx.arc(mouse.x, mouse.y, mouse.radius * 1.5, 0, Math.PI * 2);
      ctx.fill();

      for (let i = 0; i < particles.length; i++) {
        const p = particles[i];

        p.x += p.vx;
        p.y += p.vy;

        if (p.x < 0 || p.x > width) p.vx *= -1;
        if (p.y < 0 || p.y > height) p.vy *= -1;

        const dx = mouse.x - p.x;
        const dy = mouse.y - p.y;
        const dist = Math.sqrt(dx * dx + dy * dy);

        if (dist < mouse.radius) {
          const force = (mouse.radius - dist) / mouse.radius;
          p.x -= (dx / dist) * force * 2.0;
          p.y -= (dy / dist) * force * 2.0;
          p.alpha = Math.min((p.baseAlpha + force * 0.6) * baseAlphaMultiplier, 1.0);

          ctx.beginPath();
          ctx.moveTo(p.x, p.y);
          ctx.lineTo(mouse.x, mouse.y);
          ctx.strokeStyle = `${p.colorPrefix}${(1 - dist / mouse.radius) * 0.65 * lineOpacityMultiplier})`;
          ctx.lineWidth = 1.4;
          ctx.stroke();
        } else {
          p.alpha = p.baseAlpha;
        }

        for (let j = i + 1; j < particles.length; j++) {
          const p2 = particles[j];
          const pdx = p.x - p2.x;
          const pdy = p.y - p2.y;
          const pdist = Math.sqrt(pdx * pdx + pdy * pdy);

          if (pdist < 130) {
            ctx.beginPath();
            ctx.moveTo(p.x, p.y);
            ctx.lineTo(p2.x, p2.y);
            ctx.strokeStyle = `${colors[1]}${(1 - pdist / 130) * 0.3 * lineOpacityMultiplier})`;
            ctx.lineWidth = 1.0;
            ctx.stroke();
          }
        }

        ctx.beginPath();
        ctx.arc(p.x, p.y, p.radius, 0, Math.PI * 2);
        ctx.fillStyle = `${p.colorPrefix}${p.alpha})`;
        ctx.shadowBlur = p.radius * 3.5;
        ctx.shadowColor = `${p.colorPrefix}0.7)`;
        ctx.fill();
        ctx.shadowBlur = 0;
      }

      animationFrameId = requestAnimationFrame(render);
    };

    render();

    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('resize', handleResize);
      cancelAnimationFrame(animationFrameId);
    };
  }, [enabled, themeStyle, intensity]);

  if (!enabled) return null;

  const zIndexVal = intensity === 'behind' ? 0 : 9999;

  return (
    <canvas
      ref={canvasRef}
      style={{
        position: 'fixed',
        inset: 0,
        pointerEvents: 'none',
        zIndex: zIndexVal,
        opacity: 1.0
      }}
    />
  );
}
