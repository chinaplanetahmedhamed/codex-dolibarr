import React from 'react';
import { 
  ShieldCheck, 
  Building2, 
  Search, 
  Warehouse, 
  Truck, 
  CircleDollarSign, 
  BriefcaseBusiness,
  FileCheck2,
  Check, 
  ArrowLeft
} from 'lucide-react';
import { SERVICES_DATA as DEFAULT_SERVICES } from '../data/mockData';
import { useI18n } from '../i18n/I18nContext';
import { localizeService } from '../i18n/serviceCopy';
import AppLink from './AppLink';

export default function ServicesSection({ onSelectService, servicesData, limit, compact = false, onViewAllServices }) {
  const { locale, t, isRtl } = useI18n();
  const sourceList = servicesData && servicesData.length ? servicesData : DEFAULT_SERVICES;
  const listToRender = sourceList.map((service) => localizeService(service, locale));
  const visibleServices = Number.isInteger(limit) ? listToRender.slice(0, limit) : listToRender;

  const getIcon = (iconName) => {
    switch (iconName) {
      case 'ShieldCheck': return <ShieldCheck size={28} color="var(--primary)" />;
      case 'Building2': return <Building2 size={28} color="var(--primary)" />;
      case 'Search': return <Search size={28} color="var(--primary)" />;
      case 'Warehouse': return <Warehouse size={28} color="var(--primary)" />;
      case 'Truck': return <Truck size={28} color="var(--primary)" />;
      case 'CircleDollarSign': return <CircleDollarSign size={28} color="var(--primary)" />;
      case 'BriefcaseBusiness': return <BriefcaseBusiness size={28} color="var(--primary)" />;
      case 'FileCheck2': return <FileCheck2 size={28} color="var(--primary)" />;
      default: return <ShieldCheck size={28} color="var(--primary)" />;
    }
  };

  return (
    <section id="services" style={{ padding: compact ? '64px 0' : '80px 0', background: 'var(--bg-card)' }}>
      <div className="container">
        
        {/* Section Header */}
        <div style={{ textAlign: 'center', maxWidth: '700px', margin: '0 auto 48px auto' }}>
          <div className="badge badge-red" style={{ marginBottom: '12px' }}>
            {locale === 'ar' ? 'خدمات متكاملة لإدارة التوريد' : locale === 'fr' ? "Services intégrés d'approvisionnement" : 'Integrated sourcing services'}
          </div>
          <h2 style={{ fontSize: '2.2rem', fontWeight: 800, marginBottom: '16px' }}>
            {locale === 'ar' ? 'خدماتنا المتخصصة في الأسواق الصينية' : locale === 'fr' ? 'Nos services spécialisés en Chine' : 'Our specialized services in China'}
          </h2>
          <p style={{ color: 'var(--text-muted)', fontSize: '1.05rem' }}>
            {locale === 'ar' ? 'اضغط على أي خدمة لمعرفة نطاق العمل والخطوات وطريقة احتساب الرسوم.' : locale === 'fr' ? 'Sélectionnez un service pour consulter son périmètre, ses étapes et son mode de tarification.' : 'Select any service to review its scope, stages and pricing approach.'}
          </p>
        </div>

        {/* Services Grid */}
        <div className={compact ? 'mobile-preview-carousel' : undefined}
          style={{
            display: 'grid',
            gridTemplateColumns: `repeat(auto-fit, minmax(${compact ? '260px' : '320px'}, 1fr))`,
            gap: '28px'
          }}
        >
          {visibleServices.map((service) => (
            <div 
              key={service.id}
              className="glass-card"
              style={{
                padding: compact ? '25px' : '32px',
                borderRadius: 'var(--radius-md)',
                display: 'flex',
                flexDirection: 'column',
                justifyContent: 'space-between',
                position: 'relative'
              }}
            >
              <div>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '20px' }}>
                  <div 
                    style={{
                      width: '60px',
                      height: '60px',
                      borderRadius: '16px',
                      background: 'var(--primary-light)',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center'
                    }}
                  >
                    {getIcon(service.icon)}
                  </div>
                  <span className="badge badge-gold">
                    {service.badge}
                  </span>
                </div>

                <h3 style={{ fontSize: '1.3rem', fontWeight: 800, marginBottom: '4px' }}>
                  {service.title}
                </h3>
                <div style={{ fontSize: '0.8rem', color: 'var(--text-muted)', fontFamily: 'var(--font-en)', marginBottom: '16px' }}>
                  {service.subtitle}
                </div>

                <p style={{ color: 'var(--text-muted)', fontSize: '0.94rem', lineHeight: 1.6, marginBottom: compact ? '16px' : '20px', ...(compact ? { display: '-webkit-box', WebkitLineClamp: 3, WebkitBoxOrient: 'vertical', overflow: 'hidden' } : {}) }}>
                  {service.description}
                </p>

                {/* Top Features */}
                {!compact && <div style={{ display: 'flex', flexDirection: 'column', gap: '8px', marginBottom: '24px' }}>
                  {service.features && service.features.slice(0, 3).map((feat, i) => (
                    <div key={i} style={{ display: 'flex', alignItems: 'center', gap: '8px', fontSize: '0.85rem' }}>
                      <Check size={16} color="#10B981" />
                      <span style={{ fontWeight: 600 }}>{feat}</span>
                    </div>
                  ))}
                </div>}
              </div>

              <div style={{ display: 'flex', gap: '10px', borderTop: '1px solid var(--border-color)', paddingTop: '16px' }}>
                <AppLink
                  to={`/service/${encodeURIComponent(service.id)}`}
                  onNavigate={() => onSelectService(service.id)}
                  className="btn-primary"
                  style={{ flex: 1, justifyContent: 'center', padding: '10px 14px', fontSize: '0.92rem', textDecoration: 'none' }}
                >
                  <span>{compact ? (locale === 'ar' ? 'تفاصيل الخدمة' : locale === 'fr' ? 'Détails' : 'Service details') : (locale === 'ar' ? 'عرض الصفحة المستقلة للخدمة' : locale === 'fr' ? 'Voir la page du service' : 'View service page')}</span>
                  <ArrowLeft size={16} style={{ transform: isRtl ? 'none' : 'rotate(180deg)' }} />
                </AppLink>
              </div>

            </div>
          ))}
        </div>

        {visibleServices.length < listToRender.length && onViewAllServices && (
          <div style={{ textAlign: 'center', marginTop: '34px' }}>
            <AppLink to="/services" className="btn-outline" onNavigate={onViewAllServices} style={{ padding: '12px 24px', textDecoration: 'none' }}>
              <span>{t('nav.allServices')}</span>
              <ArrowLeft size={17} style={{ transform: isRtl ? 'none' : 'rotate(180deg)' }} />
            </AppLink>
          </div>
        )}

      </div>
    </section>
  );
}
