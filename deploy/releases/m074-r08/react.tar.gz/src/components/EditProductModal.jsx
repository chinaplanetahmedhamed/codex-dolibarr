import ImageUploaderInput from "./ImageUploaderInput";
import React, { useState, useEffect } from 'react';
import { X, Save, Sparkles, Image as ImageIcon, Tag, FileText, Check } from 'lucide-react';

export default function EditProductModal({ isOpen, product, onClose, onSave }) {
  const [title, setTitle] = useState('');
  const [categoryName, setCategoryName] = useState('');
  const [subCategoryName, setSubCategoryName] = useState('');
  const [image, setImage] = useState('');
  const [moq, setMoq] = useState('');
  const [specs, setSpecs] = useState('');
  const [description, setDescription] = useState('');

  useEffect(() => {
    if (product) {
      setTitle(product.title || '');
      setCategoryName(product.categoryName || product.category || 'قسم عام');
      setSubCategoryName(product.subCategoryName || '');
      setImage(product.image || '');
      setMoq(product.moq || 'حسب طلب العميل');
      setSpecs(product.specs || '');
      setDescription(product.description || '');
    } else {
      setTitle('');
      setCategoryName('قسم عام');
      setSubCategoryName('');
      setImage('');
      setMoq('حسب طلب العميل');
      setSpecs('');
      setDescription('');
    }
  }, [product, isOpen]);

  if (!isOpen) return null;

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!title.trim()) {
      alert('يرجى كتابة اسم المنتج!');
      return;
    }

    const updated = {
      ...product,
      id: product?.id || `wc-custom-${Date.now()}`,
      title: title.trim(),
      category: categoryName.trim(),
      categoryName: categoryName.trim(),
      subCategoryName: subCategoryName.trim(),
      image: image.trim() || '/images/hero.webp',
      moq: moq.trim() || 'حسب طلب العميل',
      specs: specs.trim(),
      description: description.trim()
    };

    onSave(updated);
    onClose();
  };

  return (
    <div 
      className="animate-fade-in"
      style={{
        position: 'fixed',
        inset: 0,
        zIndex: 99999,
        background: 'rgba(15, 23, 42, 0.8)',
        backdropFilter: 'blur(8px)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        padding: '20px'
      }}
    >
      <div 
        style={{
          background: 'var(--bg-card)',
          color: 'var(--text-main)',
          borderRadius: '20px',
          width: '100%',
          maxWidth: '620px',
          maxHeight: '90vh',
          overflowY: 'auto',
          border: '1px solid var(--border-color)',
          boxShadow: '0 25px 50px -12px rgba(0, 0, 0, 0.35)',
          padding: '28px'
        }}
      >
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '20px', borderBottom: '1px solid var(--border-color)', paddingBottom: '14px' }}>
          <h3 style={{ fontSize: '1.2rem', fontWeight: 800 }}>
            {product ? '✏️ تعديل تفاصيل المنتج' : '➕ إضافة منتج جديد لكتالوج التسعير'}
          </h3>
          <button onClick={onClose} style={{ background: 'none', border: 'none', color: 'var(--text-muted)', cursor: 'pointer' }}>
            <X size={22} />
          </button>
        </div>

        <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
          
          <div>
            <label style={{ display: 'block', fontSize: '0.86rem', fontWeight: 700, marginBottom: '6px' }}>اسم المنتج *</label>
            <input 
              type="text" 
              required
              className="input-field"
              placeholder="مثال: شاشة تفاعلية للمدارس 75 بوصة 4K"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
            />
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '14px' }}>
            <div>
              <label style={{ display: 'block', fontSize: '0.86rem', fontWeight: 700, marginBottom: '6px' }}>القسم الرئيسي *</label>
              <input 
                type="text" 
                required
                className="input-field"
                placeholder="مثال: إلكترونيات"
                value={categoryName}
                onChange={(e) => setCategoryName(e.target.value)}
              />
            </div>

            <div>
              <label style={{ display: 'block', fontSize: '0.86rem', fontWeight: 700, marginBottom: '6px' }}>القسم الفرعي (إن وجد)</label>
              <input 
                type="text" 
                className="input-field"
                placeholder="مثال: شاشات تفاعلية"
                value={subCategoryName}
                onChange={(e) => setSubCategoryName(e.target.value)}
              />
            </div>
          </div>

          <ImageUploaderInput 
            label="🖼️ صورة المنتج (رابط أو رفع من جهازك)"
            value={image}
            onChange={(val) => setImage(val)}
          />

          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '14px' }}>
            <div>
              <label style={{ display: 'block', fontSize: '0.86rem', fontWeight: 700, marginBottom: '6px' }}>الكمية/الميزات المستهدفة</label>
              <input 
                type="text" 
                className="input-field"
                placeholder="مثال: أدنى كمية 10 قطع"
                value={moq}
                onChange={(e) => setMoq(e.target.value)}
              />
            </div>

            <div>
              <label style={{ display: 'block', fontSize: '0.86rem', fontWeight: 700, marginBottom: '6px' }}>المواصفات والخصائص</label>
              <input 
                type="text" 
                className="input-field"
                placeholder="مثال: كود SKU: CP-8821"
                value={specs}
                onChange={(e) => setSpecs(e.target.value)}
              />
            </div>
          </div>

          <div>
            <label style={{ display: 'block', fontSize: '0.86rem', fontWeight: 700, marginBottom: '6px' }}>وصف المنتج التفصيلي</label>
            <textarea 
              rows={3}
              className="input-field"
              placeholder="اكتب وصفاً شاملاً للمنتج ومزاياه..."
              value={description}
              onChange={(e) => setDescription(e.target.value)}
            />
          </div>

          <div style={{ borderTop: '1px solid var(--border-color)', paddingTop: '16px', display: 'flex', justifyContent: 'flex-end', gap: '12px' }}>
            <button type="button" onClick={onClose} className="btn-outline" style={{ padding: '10px 20px' }}>
              إلغاء
            </button>

            <button type="submit" className="btn-primary" style={{ padding: '10px 24px', borderRadius: '9999px' }}>
              <Save size={18} />
              <span>حفظ التعديلات</span>
            </button>
          </div>

        </form>
      </div>
    </div>
  );
}
