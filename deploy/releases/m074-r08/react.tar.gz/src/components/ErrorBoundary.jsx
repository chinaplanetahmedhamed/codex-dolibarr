import React from 'react';

export default class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error) {
    return { hasError: true, error };
  }

  componentDidCatch(error, errorInfo) {
    console.error("React ErrorBoundary caught an error:", error, errorInfo);
  }

  handleReset = () => {
    window.location.reload();
  };

  handleGoHome = () => {
    window.location.assign('/#/');
  };

  render() {
    if (this.state.hasError) {
      return (
        <div 
          style={{
            minHeight: '100vh',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            background: '#0F172A',
            color: '#FFFFFF',
            padding: '24px',
            textAlign: 'center',
            fontFamily: 'Cairo, sans-serif'
          }}
        >
          <div 
            style={{
              maxWidth: '500px',
              padding: '36px',
              background: 'rgba(30, 41, 59, 0.9)',
              borderRadius: '16px',
              border: '1px solid rgba(255,255,255,0.1)',
              boxShadow: '0 20px 40px rgba(0,0,0,0.5)'
            }}
          >
            <div style={{ fontSize: '3rem', marginBottom: '16px' }}>⚠️</div>
            <h2 style={{ fontSize: '1.4rem', fontWeight: 800, marginBottom: '12px', color: '#F59E0B' }}>
              حدث خطأ في عرض الصفحة
            </h2>
            <p style={{ color: '#94A3B8', fontSize: '0.95rem', lineHeight: 1.6, marginBottom: '24px' }}>
              تعذر عرض هذه الصفحة حالياً. يمكنك إعادة تحميلها أو العودة إلى الصفحة الرئيسية.
            </p>
            <button 
              onClick={this.handleReset}
              style={{
                background: 'linear-gradient(135deg, #D32F2F 0%, #B71C1C 100%)',
                color: '#FFF',
                border: 'none',
                padding: '12px 28px',
                borderRadius: '9999px',
                fontWeight: 800,
                fontSize: '1rem',
                cursor: 'pointer'
              }}
            >
              إعادة تحميل الصفحة
            </button>
            <button
              onClick={this.handleGoHome}
              style={{
                marginRight: '10px',
                background: 'transparent',
                color: '#CBD5E1',
                border: '1px solid rgba(255,255,255,0.2)',
                padding: '12px 24px',
                borderRadius: '9999px',
                fontWeight: 800,
                fontSize: '1rem',
                cursor: 'pointer'
              }}
            >
              العودة للرئيسية
            </button>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}
