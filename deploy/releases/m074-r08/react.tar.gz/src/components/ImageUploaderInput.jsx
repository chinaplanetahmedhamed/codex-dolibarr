import React, { useRef, useState } from "react";
import { Upload, X } from "lucide-react";
import { uploadWebsiteImage } from "../lib/api";

export default function ImageUploaderInput({
  value,
  onChange,
  label = "صورة المكون (رابط أو رفع من الجهاز)",
  placeholder = "أدخل رابط الصورة (https://...) أو ارفع ملفاً من جهازك",
}) {
  const fileInputRef = useRef(null);
  const [uploadState, setUploadState] = useState("idle");
  const [uploadError, setUploadError] = useState("");

  const handleFileSelect = async (event) => {
    const file = event.target.files?.[0];
    if (!file) return;
    setUploadError("");
    if (!["image/jpeg", "image/png", "image/webp"].includes(file.type) || file.size > 5_000_000) {
      setUploadError("استخدم صورة JPG أو PNG أو WebP بحجم لا يتجاوز 5MB.");
      event.target.value = "";
      return;
    }

    setUploadState("uploading");
    try {
      const result = await uploadWebsiteImage(file);
      onChange(result.url);
      setUploadState("done");
    } catch (error) {
      setUploadError(error?.message || "تعذر رفع الصورة.");
      setUploadState("error");
    } finally {
      event.target.value = "";
    }
  };

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: "8px" }}>
      {label && <label style={{ fontSize: ".88rem", fontWeight: 800, color: "var(--text-main)" }}>{label}</label>}

      <div style={{ display: "flex", gap: "10px", alignItems: "center", flexWrap: "wrap" }}>
        <div style={{ flex: 1, minWidth: "220px", position: "relative" }}>
          <input type="url" className="input-field" placeholder={placeholder} value={value || ""} onChange={(event) => onChange(event.target.value)} style={{ paddingLeft: value ? "36px" : "14px" }} />
          {value && <button type="button" aria-label="إزالة الصورة" onClick={() => onChange("")} style={{ position: "absolute", left: "10px", top: "50%", transform: "translateY(-50%)", background: "transparent", border: 0, color: "#D32F2F", cursor: "pointer" }}><X size={16} /></button>}
        </div>

        <button type="button" disabled={uploadState === "uploading"} onClick={() => fileInputRef.current?.click()} className="btn-outline" style={{ padding: "8px 16px", fontSize: ".84rem", background: "var(--bg-card)", whiteSpace: "nowrap", opacity: uploadState === "uploading" ? .7 : 1 }}>
          <Upload size={16} color="var(--primary)" />
          <span>{uploadState === "uploading" ? "جاري رفع الصورة..." : "رفع صورة من الجهاز"}</span>
        </button>
        <input ref={fileInputRef} type="file" accept="image/jpeg,image/png,image/webp" onChange={handleFileSelect} style={{ display: "none" }} />
      </div>

      {uploadError && <div role="alert" style={{ color: "#DC2626", fontSize: ".8rem", fontWeight: 700 }}>{uploadError}</div>}

      {value && (
        <div style={{ marginTop: "6px", display: "flex", alignItems: "center", gap: "12px", background: "var(--bg-main)", padding: "8px 12px", borderRadius: "12px", border: "1px solid var(--border-color)" }}>
          <img src={value} alt="معاينة الصورة" style={{ width: "56px", height: "42px", borderRadius: "6px", objectFit: "cover", border: "1px solid var(--border-color)" }} />
          <div style={{ fontSize: ".78rem", color: "var(--text-muted)", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap", flex: 1 }}>معاينة حية: {value}</div>
        </div>
      )}
    </div>
  );
}
