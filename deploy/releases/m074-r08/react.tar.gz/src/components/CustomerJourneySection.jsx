import React from "react";
import { ArrowLeft, Boxes, ClipboardCheck, FileSearch, Ship, UserRoundCheck } from "lucide-react";
import { useI18n } from '../i18n/I18nContext';

const STEP_ICONS = [FileSearch, ClipboardCheck, Boxes, Ship];
const STEP_COPY = {
  ar: [
    ['أرسل المنتج أو المواصفات', 'شارك صورة المنتج، الرابط، الكمية والدولة المستقبلة لبدء الدراسة.'],
    ['ندقق المورد والعرض', 'يتولى فريق الصين البحث والتفاوض والتحقق من تفاصيل المصنع والعرض.'],
    ['ننفذ ونفحص الطلب', 'نتابع الإنتاج، الفحص، التجميع والتجهيز وفق الخدمة المتفق عليها.'],
    ['تابع الشحنة من حسابك', 'الطلبات المعتمدة والشحنات والمستندات تظهر للعميل داخل Customer Center الآمن.'],
  ],
  en: [
    ['Send the product or specifications', 'Share the product image or link, quantity and destination to begin the review.'],
    ['We verify the supplier and quotation', 'Our China team sources, negotiates and checks the factory and offer details.'],
    ['We execute and inspect', 'We follow production, inspection, consolidation and preparation within the agreed scope.'],
    ['Track approved operations securely', 'Approved orders, shipments and documents belong in the secure Customer Center.'],
  ],
  fr: [
    ['Envoyez le produit ou les spécifications', "Partagez l'image ou le lien, la quantité et la destination pour commencer l'étude."],
    ["Nous vérifions le fournisseur et l'offre", "Notre équipe en Chine recherche, négocie et vérifie l'usine et les détails de l'offre."],
    ['Nous exécutons et contrôlons', "Nous suivons la production, l'inspection, le groupage et la préparation selon le périmètre convenu."],
    ['Suivez les opérations en toute sécurité', "Les commandes, expéditions et documents approuvés sont disponibles dans l'espace client sécurisé."],
  ],
};

export default function CustomerJourneySection({ onOpenQuoteModal, customerCenterUrl, compact = false, onViewAll }) {
  const { locale, isRtl } = useI18n();
  const steps = STEP_ICONS.map((icon, index) => ({ icon, title: STEP_COPY[locale][index][0], text: STEP_COPY[locale][index][1] }));
  const copy = locale === 'ar' ? {
    badge: 'رحلة واضحة من الطلب إلى التسليم', title: 'مكتب واحد في الصين يتابع الصفقة معك خطوة بخطوة', description: 'الموقع لاستقبال طلبك وتعريفك بالخدمات، بينما تُدار الطلبات المعتمدة والشحنات والملفات داخل ChinaPlanetOS.', details: 'عرض مراحل العمل بالتفصيل', existing: 'عميل حالي؟', existingText: 'ادخل إلى مركز العملاء لمتابعة الطلبات والشحنات والمستندات.', login: 'دخول مركز العملاء', start: 'ابدأ طلبًا جديدًا',
  } : locale === 'fr' ? {
    badge: "Un parcours clair de la demande à la livraison", title: 'Un seul bureau en Chine suit votre opération étape par étape', description: "Le site reçoit votre demande et présente les services. Les commandes, expéditions et dossiers approuvés sont gérés dans ChinaPlanetOS.", details: 'Voir toutes les étapes', existing: 'Déjà client ?', existingText: "Connectez-vous à l'espace client pour suivre commandes, expéditions et documents.", login: "Ouvrir l'espace client", start: 'Nouvelle demande',
  } : {
    badge: 'A clear journey from request to delivery', title: 'One China office follows your transaction step by step', description: 'The website receives your request and explains services, while approved orders, shipments and files are managed in ChinaPlanetOS.', details: 'View the full process', existing: 'Existing customer?', existingText: 'Open the Customer Center to follow orders, shipments and documents.', login: 'Customer Center login', start: 'Start a new request',
  };
  return (
    <section id="journey" style={{ padding: compact ? "62px 0" : "82px 0", background: "var(--bg-card)" }}>
      <div className="container">
        <div style={{ maxWidth: "760px", margin: "0 auto 42px", textAlign: "center" }}>
          <div className="badge badge-red" style={{ marginBottom: "12px" }}>{copy.badge}</div>
          <h2 style={{ fontSize: "clamp(1.8rem, 4vw, 2.55rem)", fontWeight: 900, marginBottom: "12px" }}>
            {copy.title}
          </h2>
          <p style={{ color: "var(--text-muted)", lineHeight: 1.8 }}>
            {copy.description}
          </p>
        </div>

        <div className={compact ? 'mobile-preview-carousel' : undefined} style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(220px, 1fr))", gap: "18px" }}>
          {steps.map((step, index) => {
            const Icon = step.icon;
            return (
              <article key={step.title} className="glass-card" style={{ padding: "24px", position: "relative" }}>
                <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: "18px" }}>
                  <div style={{ width: "48px", height: "48px", borderRadius: "14px", background: "var(--primary-light)", color: "var(--primary)", display: "grid", placeItems: "center" }}>
                    <Icon size={24} />
                  </div>
                  <span style={{ fontFamily: "var(--font-en)", fontSize: "0.78rem", fontWeight: 900, color: "var(--text-muted)" }}>0{index + 1}</span>
                </div>
                <h3 style={{ fontSize: "1.05rem", fontWeight: 900, marginBottom: "8px" }}>{step.title}</h3>
                <p style={{ color: "var(--text-muted)", fontSize: "0.9rem", lineHeight: 1.7 }}>{step.text}</p>
              </article>
            );
          })}
        </div>

        {compact ? (
          <div style={{ textAlign: 'center', marginTop: '28px' }}>
            <button type="button" className="btn-outline" onClick={onViewAll}>{copy.details} <ArrowLeft size={17} style={{ transform: isRtl ? 'none' : 'rotate(180deg)' }} /></button>
          </div>
        ) : <div style={{ marginTop: "30px", padding: "26px", borderRadius: "var(--radius-lg)", background: "linear-gradient(135deg, #0F172A, #1E293B)", color: "#fff", display: "flex", alignItems: "center", justifyContent: "space-between", gap: "20px", flexWrap: "wrap" }}>
          <div>
            <div style={{ display: "flex", alignItems: "center", gap: "8px", fontWeight: 900, marginBottom: "6px" }}>
              <UserRoundCheck size={20} color="#F59E0B" />
              <span>{copy.existing}</span>
            </div>
            <p style={{ color: "#CBD5E1", fontSize: "0.9rem" }}>{copy.existingText}</p>
          </div>
          <div style={{ display: "flex", gap: "10px", flexWrap: "wrap" }}>
            {customerCenterUrl && (
              <a className="btn-secondary" href={customerCenterUrl} rel="noreferrer" style={{ textDecoration: "none" }}>
                {copy.login}
              </a>
            )}
            <button type="button" className="btn-primary" onClick={onOpenQuoteModal}>
              {copy.start} <ArrowLeft size={17} style={{ transform: isRtl ? 'none' : 'rotate(180deg)' }} />
            </button>
          </div>
        </div>}
      </div>
    </section>
  );
}
