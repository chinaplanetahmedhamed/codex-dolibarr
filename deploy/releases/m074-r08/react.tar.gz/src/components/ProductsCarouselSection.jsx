import React, { useState, useRef } from 'react';
import { Package, ChevronRight, ChevronLeft, ArrowRight, Plus, Flame } from 'lucide-react';
import AddToCartModal from './AddToCartModal';
import { useI18n } from '../i18n/I18nContext';

function decodeHtmlEntities(str) {
  if (!str) return '';
  return str
    .replace(/&amp;/g, '&')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"')
    .replace(/&#039;/g, "'")
    .replace(/&nbsp;/g, ' ');
}

export default function ProductsCarouselSection({ 
  catalogProducts, 
  onViewAllProducts, 
  onAddToCart 
}) {
  const { locale, isRtl } = useI18n();
  const copy = locale === 'ar' ? {
    badge: 'الأكثر تصفحاً وطلباً بين المستوردين 🔥', title: 'أحدث منتجات ومواصفات المصانع الصينية', description: 'عينات مباشرة من المنتجات المتزامنة مع مكتب جوانزو، تصفح الصور والمواصفات وأضفها لطلب التسعير.', previous: 'السابق', next: 'التالي', all: 'عرض جميع المنتجات بالكتالوج', empty: 'لا توجد منتجات متاحة بالعرض حالياً', add: 'إضافة لطلب التسعير', browse: 'استكشف كافة أقسام ومنتجات الكتالوج الكامل 📦', piece: 'قطعة',
  } : locale === 'fr' ? {
    badge: 'Produits les plus consultés et demandés 🔥', title: 'Derniers produits et spécifications des usines chinoises', description: 'Consultez les produits synchronisés avec notre bureau de Guangzhou et ajoutez-les à votre demande de devis.', previous: 'Précédent', next: 'Suivant', all: 'Voir tous les produits', empty: 'Aucun produit disponible actuellement', add: 'Ajouter à la demande', browse: 'Explorer toutes les catégories et tous les produits 📦', piece: 'pièces',
  } : {
    badge: 'Most viewed and requested products 🔥', title: 'Latest products and specifications from Chinese factories', description: 'Browse products synchronized with our Guangzhou office and add them to your quotation request.', previous: 'Previous', next: 'Next', all: 'View all catalog products', empty: 'No products are currently available', add: 'Add to quotation request', browse: 'Explore all catalog categories and products 📦', piece: 'pcs',
  };
  const scrollContainerRef = useRef(null);
  const [modalProduct, setModalProduct] = useState(null);

  // Take top 12 products for the carousel
  const featuredProducts = (catalogProducts || []).slice(0, 12);

  const handleScrollLeft = () => {
    if (scrollContainerRef.current) {
      scrollContainerRef.current.scrollBy({ left: -340, behavior: 'smooth' });
    }
  };

  const handleScrollRight = () => {
    if (scrollContainerRef.current) {
      scrollContainerRef.current.scrollBy({ left: 340, behavior: 'smooth' });
    }
  };

  return (
    <section style={{ padding: '70px 0', background: 'var(--bg-main)', borderTop: '1px solid var(--border-color)', borderBottom: '1px solid var(--border-color)', position: 'relative' }}>
      <div className="container">
        
        {/* Section Header with Carousel Navigation & CTA */}
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end', flexWrap: 'wrap', gap: '20px', marginBottom: '32px' }}>
          <div>
            <div className="badge badge-gold" style={{ marginBottom: '12px' }}>
              <Flame size={14} color="#D32F2F" />
              <span>{copy.badge}</span>
            </div>
            <h2 style={{ fontSize: 'clamp(1.6rem, 3.5vw, 2.3rem)', fontWeight: 900, lineHeight: 1.25 }}>
              {copy.title}
            </h2>
            <p style={{ color: 'var(--text-muted)', fontSize: '0.94rem', marginTop: '6px', maxWidth: '600px' }}>
              {copy.description}
            </p>
          </div>

          <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
            {/* Carousel Arrow Controls */}
            <div style={{ display: 'flex', gap: '8px' }}>
              <button 
                onClick={handleScrollRight}
                className="btn-outline"
                style={{ width: '42px', height: '42px', padding: 0, borderRadius: '50%', justifyContent: 'center' }}
                title={copy.previous}
              >
                <ChevronRight size={22} />
              </button>
              <button 
                onClick={handleScrollLeft}
                className="btn-outline"
                style={{ width: '42px', height: '42px', padding: 0, borderRadius: '50%', justifyContent: 'center' }}
                title={copy.next}
              >
                <ChevronLeft size={22} />
              </button>
            </div>

            {/* View All Products Page Button */}
            <button 
              onClick={onViewAllProducts}
              className="btn-primary"
              style={{ padding: '10px 22px', borderRadius: '9999px', fontSize: '0.88rem' }}
            >
              <span>{copy.all} ({catalogProducts ? catalogProducts.length : 0})</span>
              <ArrowRight size={16} style={{ transform: isRtl ? 'none' : 'rotate(180deg)' }} />
            </button>
          </div>
        </div>

        {/* Carousel Horizon Container */}
        {featuredProducts.length === 0 ? (
          <div className="glass-card" style={{ padding: '50px 20px', textAlign: 'center', color: 'var(--text-muted)' }}>
            <Package size={44} style={{ opacity: 0.3, marginBottom: '12px' }} />
            <div style={{ fontWeight: 800, fontSize: '1rem' }}>{copy.empty}</div>
          </div>
        ) : (
          <div 
            ref={scrollContainerRef}
            style={{
              display: 'flex',
              gap: '24px',
              overflowX: 'auto',
              scrollSnapType: 'x mandatory',
              scrollBehavior: 'smooth',
              paddingBottom: '16px',
              paddingTop: '8px',
              msOverflowStyle: 'none',
              scrollbarWidth: 'none'
            }}
          >
            {featuredProducts.map((product) => {
              const cleanTitle = decodeHtmlEntities(product.title);
              const cleanMainCat = decodeHtmlEntities(product.categoryName || product.category);

              return (
                <div 
                  key={product.id}
                  className="glass-card"
                  style={{
                    minWidth: '290px',
                    maxWidth: '290px',
                    borderRadius: 'var(--radius-lg)',
                    overflow: 'hidden',
                    display: 'flex',
                    flexDirection: 'column',
                    justifyContent: 'space-between',
                    scrollSnapAlign: 'start',
                    border: '1px solid var(--border-color)',
                    background: 'var(--bg-card)',
                    flexShrink: 0
                  }}
                >
                  <div>
                    {/* Image Header */}
                    <div style={{ position: 'relative', height: '190px', overflow: 'hidden', background: '#0F172A' }}>
                      <img 
                        src={product.image || '/images/hero.webp'}
                        alt={cleanTitle} 
                        loading="lazy"
                        decoding="async"
                        style={{ width: '100%', height: '100%', objectFit: 'cover' }} 
                      />
                      <span className="badge badge-gold" style={{ position: 'absolute', top: '10px', right: '10px', background: 'rgba(15, 23, 42, 0.85)', color: '#FFF', fontSize: '0.72rem' }}>
                        {cleanMainCat}
                      </span>
                    </div>

                    {/* Body */}
                    <div style={{ padding: '16px 18px' }}>
                      <h4 style={{ fontSize: '0.98rem', fontWeight: 800, color: 'var(--text-main)', marginBottom: '6px', lineHeight: 1.4, height: '44px', overflow: 'hidden', display: '-webkit-box', WebkitLineClamp: 2, WebkitBoxOrient: 'vertical' }}>
                        {cleanTitle}
                      </h4>
                      
                      {product.pcsPerCarton && (
                        <div style={{ fontSize: '0.76rem', color: '#059669', fontWeight: 800, marginBottom: '8px' }}>
                          📦 QTY/CTN: {product.pcsPerCarton} {copy.piece} {product.cbmPerCarton ? `| ${product.cbmPerCarton} CBM` : ''}
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Add Button */}
                  <div style={{ padding: '0 18px 18px 18px' }}>
                    <button
                      onClick={() => setModalProduct(product)}
                      className="btn-primary"
                      style={{ width: '100%', justifyContent: 'center', padding: '9px 14px', borderRadius: '9999px', fontSize: '0.82rem' }}
                    >
                      <Plus size={15} />
                      <span>{copy.add}</span>
                    </button>
                  </div>

                </div>
              );
            })}
          </div>
        )}

        {/* Bottom Navigation CTA Banner */}
        <div style={{ marginTop: '36px', textAlign: 'center' }}>
          <button 
            onClick={onViewAllProducts}
            className="btn-primary"
            style={{ padding: '14px 36px', borderRadius: '9999px', fontSize: '1.05rem', fontWeight: 800, boxShadow: 'var(--shadow-glow)' }}
          >
            <span>{copy.browse}</span>
            <ArrowRight size={20} style={{ transform: isRtl ? 'none' : 'rotate(180deg)' }} />
          </button>
        </div>

      </div>

      {/* Add To Cart Quantity Modal */}
      <AddToCartModal 
        isOpen={!!modalProduct}
        product={modalProduct}
        onClose={() => setModalProduct(null)}
        onConfirm={(itemData) => {
          onAddToCart(itemData);
        }}
      />

    </section>
  );
}
