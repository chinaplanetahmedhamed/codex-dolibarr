import React from 'react';
import { Award, Building2, ClipboardCheck, Languages } from 'lucide-react';
import { useI18n } from '../i18n/I18nContext';

const STAT_COPY = {
  ar: [
    ['منذ 2007', 'خبرة متواصلة من قلب الصين', 'إدارة أعمال التوريد والمتابعة للمستورد العربي'],
    ['جوانزو', 'متابعة ميدانية داخل الصين', 'بحث موردين، تفاوض، فحص وتجميع طلبات'],
    ['مسار واحد', 'من الطلب حتى مستندات الشحن', 'نقطة تواصل واضحة ومتابعة منظمة لكل مرحلة'],
    ['AR · EN · FR', 'واجهة الموقع بثلاث لغات', 'العربية والإنجليزية والفرنسية مع اتجاه صحيح لكل لغة'],
  ],
  en: [
    ['Since 2007', 'Continuous China trade experience', 'Sourcing and operational follow-up for international importers'],
    ['Guangzhou', 'On-the-ground support in China', 'Supplier sourcing, negotiation, inspection and consolidation'],
    ['One workflow', 'From request to shipping documents', 'One clear contact point and structured follow-up at every stage'],
    ['AR · EN · FR', 'Three-language website', 'Arabic, English and French with the correct reading direction'],
  ],
  fr: [
    ['Depuis 2007', 'Une expérience continue en Chine', 'Achats et suivi opérationnel pour les importateurs internationaux'],
    ['Guangzhou', 'Suivi de terrain en Chine', 'Recherche, négociation, inspection et groupage'],
    ['Un seul parcours', "De la demande jusqu'aux documents d'expédition", 'Un interlocuteur clair et un suivi structuré à chaque étape'],
    ['AR · EN · FR', 'Site en trois langues', 'Arabe, anglais et français avec le bon sens de lecture'],
  ],
};

export default function StatsBar() {
  const { locale } = useI18n();
  const icons = [Award, Building2, ClipboardCheck, Languages];
  const stats = STAT_COPY[locale].map(([value, label, desc], index) => ({ value, label, desc, icon: React.createElement(icons[index], { size: 32, color: '#D32F2F' }) }));

  return (
    <section 
      style={{
        background: 'var(--secondary)',
        color: '#FFFFFF',
        padding: '50px 0',
        position: 'relative'
      }}
    >
      <div className="container">
        <div className="home-stats-grid"
          style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fit, minmax(240px, 1fr))',
            gap: '32px'
          }}
        >
          {stats.map((stat) => (
            <div className="home-stat-card"
              key={stat.label}
              style={{
                display: 'flex',
                alignItems: 'flex-start',
                gap: '16px',
                padding: '20px',
                borderRadius: 'var(--radius-md)',
                background: 'rgba(255, 255, 255, 0.04)',
                border: '1px solid rgba(255, 255, 255, 0.08)',
                transition: 'transform 0.2s ease'
              }}
            >
              <div className="home-stat-icon"
                style={{
                  width: '56px',
                  height: '56px',
                  borderRadius: '14px',
                  background: 'rgba(211, 47, 47, 0.15)',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  flexShrink: 0
                }}
              >
                {stat.icon}
              </div>
              <div>
                <div style={{ fontSize: '1.8rem', fontWeight: 900, color: '#FFFFFF', lineHeight: 1.1, fontFamily: 'var(--font-en)' }}>
                  {stat.value}
                </div>
                <div style={{ fontSize: '1.05rem', fontWeight: 700, marginTop: '4px', color: '#F1F5F9' }}>
                  {stat.label}
                </div>
                <div style={{ fontSize: '0.82rem', color: '#94A3B8', marginTop: '4px' }}>
                  {stat.desc}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
