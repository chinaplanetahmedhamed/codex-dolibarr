import React from 'react';
import { BookOpen, ArrowLeft, Calendar, Clock } from 'lucide-react';
import { useI18n } from '../i18n/I18nContext';
import AppLink from './AppLink';

export default function ChinaGuideSection({ blogPosts, onOpenBlog, onSelectPost, limit = 3, compact = false }) {
  const postsToRender = Array.isArray(blogPosts) ? blogPosts : [];
  const { isRtl, t } = useI18n();
  const DirectionArrow = isRtl ? ArrowLeft : ArrowLeft;

  return (
    <section id="guide" style={{ padding: compact ? '60px 0' : '80px 0', background: 'var(--bg-main)' }}>
      <div className="container">
        
        {/* Section Header */}
        <div style={{ textAlign: 'center', maxWidth: '750px', margin: '0 auto 48px auto' }}>
          <div className="badge badge-gold" style={{ marginBottom: '12px' }}>
            {t('blog.sectionBadge')}
          </div>
          <h2 style={{ fontSize: '2.2rem', fontWeight: 800, marginBottom: '16px' }}>
            {t('blog.sectionTitle')}
          </h2>
          <p style={{ color: 'var(--text-muted)', fontSize: '1.05rem' }}>
            {t('blog.sectionDescription')}
          </p>
        </div>

        {/* Articles Grid */}
        <div 
          style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fit, minmax(320px, 1fr))',
            gap: '28px',
            marginBottom: '40px'
          }}
        >
          {postsToRender.slice(0, limit).map((article) => (
            <AppLink
              key={article.id}
              to={`/blog/${encodeURIComponent(article.slug || article.id)}`}
              onNavigate={() => onSelectPost && onSelectPost(article.slug || article.id)}
              className="glass-card"
              style={{
                borderRadius: 'var(--radius-lg)',
                overflow: 'hidden',
                display: 'flex',
                flexDirection: 'column',
                justifyContent: 'space-between',
                cursor: 'pointer',
                transition: 'all 0.3s ease',
                color: 'inherit',
                textDecoration: 'none'
              }}
            >
              <div>
                <div style={{ height: compact ? '145px' : '180px', overflow: 'hidden', position: 'relative' }}>
                  <img 
                    src={article.image} 
                    alt={article.title}
                    style={{ width: '100%', height: '100%', objectFit: 'cover' }}
                  />
                  <div style={{ position: 'absolute', top: '12px', right: '12px' }}>
                    <span className="badge badge-red" style={{ fontSize: '0.75rem' }}>
                      {article.category}
                    </span>
                  </div>
                </div>

                <div style={{ padding: compact ? '19px' : '24px' }}>
                  <div style={{ display: 'flex', gap: '12px', fontSize: '0.8rem', color: 'var(--text-muted)', marginBottom: '10px' }}>
                    <span style={{ display: 'flex', alignItems: 'center', gap: '4px' }}><Calendar size={13} /> {article.date}</span>
                    <span style={{ display: 'flex', alignItems: 'center', gap: '4px' }}><Clock size={13} /> {article.readTime}</span>
                  </div>

                  <h3 style={{ fontSize: '1.15rem', fontWeight: 800, marginBottom: '10px', lineHeight: 1.4 }}>
                    {article.title}
                  </h3>

                  <p style={{ color: 'var(--text-muted)', fontSize: '0.9rem', lineHeight: 1.6, ...(compact ? { display: '-webkit-box', WebkitLineClamp: 2, WebkitBoxOrient: 'vertical', overflow: 'hidden' } : {}) }}>
                    {article.excerpt}
                  </p>
                </div>
              </div>

              <div style={{ padding: '16px 24px', borderTop: '1px solid var(--border-color)', display: 'flex', alignItems: 'center', justifyContent: 'space-between', color: 'var(--primary)', fontWeight: 700, fontSize: '0.9rem' }}>
                <span>{t('common.readMore')}</span>
                <DirectionArrow size={16} style={{ transform: isRtl ? 'none' : 'rotate(180deg)' }} />
              </div>

            </AppLink>
          ))}
        </div>

        {/* View All Blog Link */}
        <div style={{ textAlign: 'center' }}>
          <AppLink
            to="/blog"
            onNavigate={onOpenBlog}
            className="btn-primary"
            style={{ padding: '12px 32px', fontSize: '1rem', textDecoration: 'none' }}
          >
            <BookOpen size={18} />
            <span>{t('blog.viewAll')}</span>
          </AppLink>
        </div>

      </div>
    </section>
  );
}
