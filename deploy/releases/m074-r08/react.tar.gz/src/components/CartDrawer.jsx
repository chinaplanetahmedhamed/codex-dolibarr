import React, { useMemo, useRef, useState } from 'react';
import { ShoppingBag, X, Trash2, Send, CheckCircle2, User, Phone, Mail, FileText } from 'lucide-react';
import { submitB2bRequest } from '../lib/api';
import { trackMetaEvent } from '../lib/metaPixel';
import { trackGoogleEvent } from '../lib/googleAnalytics';
import { COUNTRY_CODES } from '../lib/countryCodes';
import { freezeB2bSubmission } from '../lib/b2bSubmission';
import { localizePath } from '../lib/navigation';
import { useI18n } from '../i18n/I18nContext';

const CART_COPY = {
  ar: { required: 'يرجى إدخال الاسم ورقم الواتساب والبريد الإلكتروني.', consentError: 'يرجى الموافقة على استخدام بيانات التواصل لمتابعة الطلب.', sendError: 'تعذر إرسال الطلب. يرجى المحاولة لاحقاً أو التواصل عبر واتساب.', noNotes: 'لا توجد ملاحظات إضافية', title: 'سلة طلبات التسعير', subtitle: 'منتجات الكتالوج المجمعة لطلب التسعير المباشر من الصين', close: 'إغلاق السلة', success: 'تم إرسال طلب الكتالوج بنجاح!', successText: 'تم تسليم طلبك إلى قناة المتابعة المعتمدة. سيراجع فريق جوانزو المنتجات والكميات ثم يتواصل معك عبر واتساب.', reference: 'رقم الطلب:', back: 'العودة للموقع', empty: 'سلة الكتالوج فارغة حتى الآن', emptyText: 'تصفح منتجات الكتالوج وأضف المنتجات التي ترغب باستيرادها وتسعيرها من الصين.', selected: 'المنتجات المحددة', clear: 'مسح الكل', option: 'المقاس/الخيار:', quantity: 'الكمية:', contact: 'أدخل بيانات التواصل لإرسال الطلب:', name: 'الاسم بالكامل *', namePh: 'مثال: المهندس أحمد علي', phone: 'رقم الجوال والواتساب *', phonePh: 'مثال: +966501234567', email: 'البريد الإلكتروني الرسمي *', notes: 'ملاحظات عامة', notesPh: 'المواصفات أو موعد الشراء أو أي تفاصيل إضافية', consent: 'أوافق على استخدام بيانات التواصل لمراجعة هذا الطلب والرد عليه.', sending: 'جاري الإرسال بأمان...', send: 'إرسال طلب التسعير لمكتب جوانزو' },
  en: { required: 'Please enter your name, WhatsApp number and email.', consentError: 'Please consent to the use of your contact details for this request.', sendError: 'The request could not be sent. Please try later or contact us on WhatsApp.', noNotes: 'No additional notes', title: 'Quote cart', subtitle: 'Catalogue products selected for a direct China quotation', close: 'Close cart', success: 'Your catalogue request was sent!', successText: 'Your request reached our secure follow-up channel. The Guangzhou team will review products and quantities, then contact you on WhatsApp.', reference: 'Request reference:', back: 'Return to website', empty: 'Your quote cart is empty', emptyText: 'Browse the catalogue and add products you want us to source and quote from China.', selected: 'Selected products', clear: 'Clear all', option: 'Option:', quantity: 'Quantity:', contact: 'Enter your contact details to send the request:', name: 'Full name *', namePh: 'Example: Ahmed Ali', phone: 'Mobile and WhatsApp number *', phonePh: 'Example: +966501234567', email: 'Business email *', notes: 'General notes', notesPh: 'Specifications, purchasing date or other details', consent: 'I consent to the use of my contact details to review and answer this request.', sending: 'Sending securely...', send: 'Send quote request to Guangzhou' },
  fr: { required: 'Veuillez indiquer votre nom, numéro WhatsApp et e-mail.', consentError: "Veuillez accepter l'utilisation de vos coordonnées pour cette demande.", sendError: "La demande n'a pas pu être envoyée. Réessayez plus tard ou contactez-nous sur WhatsApp.", noNotes: 'Aucune remarque supplémentaire', title: 'Panier de devis', subtitle: 'Produits sélectionnés pour une demande de devis en Chine', close: 'Fermer le panier', success: 'Votre demande de catalogue a été envoyée !', successText: "Votre demande a été transmise au canal de suivi sécurisé. L'équipe de Guangzhou étudiera les produits et quantités avant de vous contacter sur WhatsApp.", reference: 'Référence :', back: 'Retour au site', empty: 'Votre panier de devis est vide', emptyText: 'Parcourez le catalogue et ajoutez les produits à rechercher et chiffrer en Chine.', selected: 'Produits sélectionnés', clear: 'Tout effacer', option: 'Option :', quantity: 'Quantité :', contact: 'Saisissez vos coordonnées pour envoyer la demande :', name: 'Nom complet *', namePh: 'Exemple : Ahmed Ali', phone: 'Téléphone et WhatsApp *', phonePh: 'Exemple : +33612345678', email: 'E-mail professionnel *', notes: 'Remarques générales', notesPh: "Spécifications, date d'achat ou autres détails", consent: "J'accepte l'utilisation de mes coordonnées pour étudier cette demande et y répondre.", sending: 'Envoi sécurisé...', send: 'Envoyer la demande à Guangzhou' },
};

const COUNTRY_COPY = {
  ar: { label: 'بلد الوصول *', choose: 'اختر بلد الوصول', privacy: 'سياسة الخصوصية' },
  en: { label: 'Destination country *', choose: 'Choose destination country', privacy: 'Privacy Policy' },
  fr: { label: 'Pays de destination *', choose: 'Choisir le pays de destination', privacy: 'Politique de confidentialité' },
};

export default function CartDrawer({ isOpen, onClose, cartItems, onRemoveItem, onSubmitOrder, onClearCart }) {
  const { isRtl, locale } = useI18n();
  const copy = CART_COPY[locale];
  const countryNames = useMemo(() => new Intl.DisplayNames([locale], { type: 'region' }), [locale]);
  const [clientName, setClientName] = useState('');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [country, setCountry] = useState('');
  const [generalNotes, setGeneralNotes] = useState('');
  const [submittedSuccess, setSubmittedSuccess] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [submitError, setSubmitError] = useState('');
  const [reference, setReference] = useState('');
  const [consent, setConsent] = useState(false);
  const [website, setWebsite] = useState('');
  const formStarted = useRef(false);
  const pendingSubmission = useRef(null);

  if (!isOpen) return null;

  const handleSubmitOrder = async (e) => {
    e.preventDefault();
    if (!cartItems || cartItems.length === 0) return;
    if (!clientName.trim() || !phone.trim() || !email.trim() || !country) {
      setSubmitError(copy.required);
      return;
    }
    if (!consent) {
      setSubmitError(copy.consentError);
      return;
    }

    if (website) return;
    const submissionInput = {
      lines: cartItems.map((item) => ({
        productId: Number(item.wooProductId || item.sourceProductId),
        variationId: Number(item.wooVariationId || 0),
        cartons: Number(item.cartonsCount),
      })),
      container: 'auto',
      customer: {
        name: clientName.trim(), phone: phone.trim(), email: email.trim(),
        company: '', country, notes: generalNotes.trim(), consent,
      },
      locale,
    };
    const frozenSubmission = freezeB2bSubmission(submissionInput, pendingSubmission.current);
    pendingSubmission.current = frozenSubmission;
    const orderData = frozenSubmission.payload;

    setSubmitting(true);
    setSubmitError('');
    try {
      const result = await submitB2bRequest(orderData, frozenSubmission.idempotencyKey);
      trackMetaEvent('Lead', {
        content_name: 'catalog_quote_request',
        content_category: 'catalog_order',
        num_items: cartItems.length,
        status: 'submitted',
      });
      trackGoogleEvent('generate_lead');
      setReference(result.request_ref || '');
      setSubmittedSuccess(true);
      pendingSubmission.current = null;
      onSubmitOrder?.({ ...orderData, reference: result.request_ref });
      onClearCart();
    } catch (error) {
      setSubmitError(error.message || copy.sendError);
    } finally {
      setSubmitting(false);
    }
  };

  const handleFormStart = () => {
    if (formStarted.current) return;
    formStarted.current = true;
    trackMetaEvent('FormStart', {
      content_name: 'catalog_quote_request',
      form_type: 'catalog_order',
      num_items: cartItems.length,
    }, { custom: true });
    trackGoogleEvent('form_start');
  };

  const resetAndClose = () => {
    setSubmittedSuccess(false);
    setClientName('');
    setPhone('');
    setEmail('');
    setCountry('');
    setGeneralNotes('');
    setConsent(false);
    setSubmitError('');
    setReference('');
    formStarted.current = false;
    pendingSubmission.current = null;
    onClose();
  };

  return (
    <div 
      style={{
        position: 'fixed',
        inset: 0,
        zIndex: 2200,
        display: 'flex',
        justifyContent: isRtl ? 'flex-end' : 'flex-start',
        background: 'rgba(15, 23, 42, 0.65)',
        backdropFilter: 'blur(6px)',
        WebkitBackdropFilter: 'blur(6px)'
      }}
      className="animate-fade-in"
    >
      <div 
        style={{
          width: '100%',
          maxWidth: '480px',
          height: '100%',
          background: 'var(--bg-card)',
          [isRtl ? 'borderRight' : 'borderLeft']: '1px solid var(--border-color)',
          boxShadow: 'var(--shadow-lg)',
          display: 'flex',
          flexDirection: 'column',
          position: 'relative',
          overflowY: 'auto'
        }}
      >
        {/* Header */}
        <div style={{ padding: '20px 24px', borderBottom: '1px solid var(--border-color)', display: 'flex', justifyContent: 'space-between', alignItems: 'center', background: 'var(--bg-main)' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
            <ShoppingBag size={22} color="var(--primary)" />
            <div>
              <h3 style={{ fontSize: '1.1rem', fontWeight: 800 }}>{copy.title} ({cartItems.length})</h3>
              <p style={{ fontSize: '0.78rem', color: 'var(--text-muted)' }}>{copy.subtitle}</p>
            </div>
          </div>

          <button onClick={resetAndClose} aria-label={copy.close} style={{ background: 'none', border: 'none', color: 'var(--text-muted)', cursor: 'pointer' }}>
            <X size={22} />
          </button>
        </div>

        {/* Submitted Success Banner */}
        {submittedSuccess ? (
          <div style={{ padding: '40px 24px', textAlign: 'center', display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '16px' }} className="animate-fade-in">
            <div style={{ width: '64px', height: '64px', borderRadius: '50%', background: '#10B981', color: '#FFF', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              <CheckCircle2 size={36} />
            </div>
            <h3 style={{ fontSize: '1.3rem', fontWeight: 800, color: 'var(--text-main)' }}>{copy.success}</h3>
            <p style={{ color: 'var(--text-muted)', fontSize: '0.9rem', lineHeight: 1.6 }}>
              {copy.successText}
            </p>
            {reference && <div style={{ fontFamily: 'var(--font-en)', fontWeight: 900, color: 'var(--primary)' }}>{copy.reference} {reference}</div>}
            <button type="button" className="btn-primary" onClick={resetAndClose}>{copy.back}</button>
          </div>
        ) : (
          <div style={{ padding: '20px 24px', flex: 1, display: 'flex', flexDirection: 'column', gap: '20px' }}>
            
            {/* Cart Items List */}
            {cartItems.length === 0 ? (
              <div style={{ padding: '40px 20px', textAlign: 'center', color: 'var(--text-muted)' }}>
                <ShoppingBag size={48} style={{ opacity: 0.3, marginBottom: '12px' }} />
                <div style={{ fontWeight: 800, fontSize: '1rem', marginBottom: '6px' }}>{copy.empty}</div>
                <div style={{ fontSize: '0.85rem' }}>{copy.emptyText}</div>
              </div>
            ) : (
              <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
                <div style={{ fontSize: '0.85rem', fontWeight: 800, color: 'var(--primary)', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                  <span>{copy.selected} ({cartItems.length}):</span>
                  <button onClick={onClearCart} style={{ background: 'none', border: 'none', color: '#D32F2F', fontSize: '0.78rem', cursor: 'pointer', fontWeight: 700 }}>{copy.clear}</button>
                </div>

                {cartItems.map((item) => (
                  <div key={item.id} style={{ padding: '12px', borderRadius: 'var(--radius-md)', border: '1px solid var(--border-color)', background: 'var(--bg-main)', display: 'flex', gap: '12px', position: 'relative' }}>
                    <img src={item.image || '/images/hero.webp'} alt={item.title} loading="lazy" decoding="async" style={{ width: '60px', height: '60px', borderRadius: 'var(--radius-sm)', objectFit: 'cover' }} />
                    <div style={{ flex: 1 }}>
                      <div style={{ fontSize: '0.88rem', fontWeight: 800, color: 'var(--text-main)', marginBottom: '4px' }}>{item.title}</div>
                      {item.selectedOptionLabel && (
                        <div style={{ fontSize: '0.78rem', color: 'var(--text-main)', fontWeight: 800, marginBottom: '4px' }}>
                          {copy.option} {item.selectedOptionLabel}
                        </div>
                      )}
                      <div style={{ fontSize: '0.78rem', color: 'var(--primary)', fontWeight: 700, marginBottom: '4px' }}>
                        {copy.quantity} {item.quantity}
                      </div>
                      {item.comment && (
                        <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)', background: 'var(--bg-card)', padding: '4px 8px', borderRadius: '4px', border: '1px solid var(--border-color)' }}>
                          💬 {item.comment}
                        </div>
                      )}
                    </div>
                    <button 
                      onClick={() => onRemoveItem(item.id)}
                      style={{ background: 'none', border: 'none', color: '#D32F2F', cursor: 'pointer', opacity: 0.8 }}
                    >
                      <Trash2 size={16} />
                    </button>
                  </div>
                ))}
              </div>
            )}

            {/* Contact Checkout Form */}
            {cartItems.length > 0 && (
              <form onSubmit={handleSubmitOrder} onInputCapture={handleFormStart} onChangeCapture={handleFormStart} style={{ display: 'flex', flexDirection: 'column', gap: '14px', borderTop: '1px solid var(--border-color)', paddingTop: '20px', marginTop: 'auto' }}>
                <div style={{ fontSize: '0.92rem', fontWeight: 800, color: 'var(--text-main)' }}>{copy.contact}</div>

                <div>
                  <label style={{ display: 'flex', alignItems: 'center', gap: '6px', fontSize: '0.82rem', fontWeight: 700, marginBottom: '4px' }}>
                    <User size={14} color="var(--primary)" />
                    <span>{copy.name}</span>
                  </label>
                  <input 
                    type="text" 
                    className="input-field" 
                    placeholder={copy.namePh}
                    value={clientName}
                    onChange={(e) => setClientName(e.target.value)}
                    required
                  />
                </div>

                <div>
                  <label htmlFor="cart-country" style={{ display: 'block', fontSize: '0.82rem', fontWeight: 700, marginBottom: '4px' }}>{COUNTRY_COPY[locale].label}</label>
                  <select id="cart-country" className="input-field" value={country} onChange={(e) => setCountry(e.target.value)} required>
                    <option value="">{COUNTRY_COPY[locale].choose}</option>
                    {COUNTRY_CODES.map((code) => <option key={code} value={code}>{countryNames.of(code) || code}</option>)}
                  </select>
                </div>

                <div>
                  <label style={{ display: 'flex', alignItems: 'center', gap: '6px', fontSize: '0.82rem', fontWeight: 700, marginBottom: '4px' }}>
                    <Phone size={14} color="var(--primary)" />
                    <span>{copy.phone}</span>
                  </label>
                  <input 
                    type="text" 
                    className="input-field" 
                    placeholder={copy.phonePh}
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    required
                  />
                </div>

                <div>
                  <label style={{ display: 'flex', alignItems: 'center', gap: '6px', fontSize: '0.82rem', fontWeight: 700, marginBottom: '4px' }}>
                    <Mail size={14} color="var(--primary)" />
                    <span>{copy.email}</span>
                  </label>
                  <input 
                    type="email" 
                    className="input-field" 
                    placeholder="name@company.com"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    required
                  />
                </div>

                <div>
                  <label style={{ display: 'flex', alignItems: 'center', gap: '6px', fontSize: '0.82rem', fontWeight: 700, marginBottom: '4px' }}>
                    <FileText size={14} color="var(--primary)" />
                    <span>{copy.notes}</span>
                  </label>
                  <textarea className="input-field" rows={3} value={generalNotes} onChange={(e) => setGeneralNotes(e.target.value)} placeholder={copy.notesPh} />
                </div>

                <div aria-hidden="true" style={{ position: 'absolute', left: '-10000px', width: '1px', height: '1px', overflow: 'hidden' }}>
                  <label htmlFor="cart-website">Website</label>
                  <input id="cart-website" type="text" tabIndex={-1} autoComplete="off" value={website} onChange={(e) => setWebsite(e.target.value)} />
                </div>

                <label style={{ display: 'flex', alignItems: 'flex-start', gap: '8px', color: 'var(--text-muted)', fontSize: '0.8rem', lineHeight: 1.55 }}>
                  <input type="checkbox" checked={consent} onChange={(e) => setConsent(e.target.checked)} style={{ marginTop: '4px' }} />
                  <span>{copy.consent} <a href={localizePath('/privacy', locale)} target="_blank" rel="noopener noreferrer">{COUNTRY_COPY[locale].privacy}</a></span>
                </label>

                {submitError && <div role="alert" style={{ padding: '10px 12px', borderRadius: '9px', background: 'rgba(211,47,47,.1)', color: '#D32F2F', fontSize: '0.82rem', fontWeight: 700 }}>{submitError}</div>}

                <button 
                  type="submit" 
                  disabled={submitting}
                  className="btn-primary"
                  style={{ padding: '12px 20px', justifyContent: 'center', borderRadius: '9999px', fontSize: '0.95rem', marginTop: '6px', opacity: submitting ? 0.7 : 1 }}
                >
                  <Send size={18} />
                  <span>{submitting ? copy.sending : copy.send}</span>
                </button>
              </form>
            )}

          </div>
        )}

      </div>
    </div>
  );
}
