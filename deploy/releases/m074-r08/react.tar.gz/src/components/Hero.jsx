import React, { useState, useEffect } from 'react';
import { ArrowLeft, Building2, PackageCheck, Award, ChevronDown, ChevronRight, ChevronLeft } from 'lucide-react';
import { localizedField, useI18n } from '../i18n/I18nContext';

export default function Hero({ onOpenQuoteModal, heroInfo }) {
  const { locale, t, isRtl } = useI18n();
  const title = localizedField(heroInfo, 'title', locale, t('hero.title'));
  const subtitle = localizedField(heroInfo, 'subtitle', locale, t('hero.subtitle'));
  const badge = localizedField(heroInfo, 'badge', locale, t('hero.badge'));
  const rawBgVideo = heroInfo?.bgVideo ? heroInfo.bgVideo.trim() : '';

  // Dynamic Carousel Gallery Images List
  const galleryImages = (heroInfo?.gallery && Array.isArray(heroInfo.gallery) && heroInfo.gallery.length > 0)
    ? heroInfo.gallery
    : [
        heroInfo?.image || '/images/hero.webp',
        '/images/warehouse.webp',
        '/images/inspection.webp'
      ];

  const [activeSlide, setActiveSlide] = useState(0);

  // Auto-play Slider Timer (Every 4.5 seconds)
  useEffect(() => {
    if (galleryImages.length <= 1) return;
    const interval = setInterval(() => {
      setActiveSlide((prev) => (prev + 1) % galleryImages.length);
    }, 4500);
    return () => clearInterval(interval);
  }, [galleryImages.length]);

  const handlePrevSlide = () => {
    setActiveSlide((prev) => (prev - 1 + galleryImages.length) % galleryImages.length);
  };

  const handleNextSlide = () => {
    setActiveSlide((prev) => (prev + 1) % galleryImages.length);
  };

  // Smart Parser for YouTube links vs direct MP4 files
  const getYouTubeId = (url) => {
    if (!url) return null;
    const regExp = /^.*(youtu.be\/|v\/|u\/\w\/|embed\/|watch\?v=|&v=)([^#&?]*).*/;
    const match = url.match(regExp);
    return (match && match[2].length === 11) ? match[2] : null;
  };

  const youtubeId = getYouTubeId(rawBgVideo);
  const isYouTube = !!youtubeId;
  const youtubeEmbedUrl = isYouTube 
    ? `https://www.youtube.com/embed/${youtubeId}?autoplay=1&mute=1&loop=1&playlist=${youtubeId}&controls=0&showinfo=0&autohide=1&modestbranding=1&enablejsapi=1`
    : null;

  return (
    <section 
      className="site-hero"
      style={{
        position: 'relative',
        minHeight: '80vh',
        display: 'flex',
        alignItems: 'center',
        background: rawBgVideo ? '#0F172A' : 'var(--bg-main)',
        color: rawBgVideo ? '#FFFFFF' : 'var(--text-main)',
        overflow: 'hidden',
        padding: '40px 0 70px 0',
        borderBottom: 'none'
      }}
    >
      {/* Dynamic YouTube Video Background */}
      {isYouTube && (
        <div style={{ position: 'absolute', inset: 0, overflow: 'hidden', zIndex: 1, pointerEvents: 'none' }}>
          <iframe
            src={youtubeEmbedUrl}
            title="Hero Background Video"
            style={{
              position: 'absolute',
              top: '50%',
              left: '50%',
              width: '100vw',
              height: '56.25vw',
              minWidth: '177.77vh',
              minHeight: '100vh',
              transform: 'translate(-50%, -50%)',
              border: 'none',
              opacity: 0.75,
              filter: 'brightness(0.9)'
            }}
            allow="autoplay; encrypted-media; picture-in-picture"
          />
          <div style={{ position: 'absolute', inset: 0, background: 'linear-gradient(135deg, rgba(15, 23, 42, 0.4) 0%, rgba(30, 41, 59, 0.45) 100%)' }} />
        </div>
      )}

      {/* Direct MP4 / WebM Video Background */}
      {rawBgVideo && !isYouTube && (
        <div style={{ position: 'absolute', inset: 0, overflow: 'hidden', zIndex: 1 }}>
          <video 
            autoPlay 
            loop 
            muted 
            playsInline 
            style={{ width: '100%', height: '100%', objectFit: 'cover', opacity: 0.75, filter: 'brightness(0.9)' }}
          >
            <source src={rawBgVideo} type="video/mp4" />
          </video>
          <div style={{ position: 'absolute', inset: 0, background: 'linear-gradient(135deg, rgba(15, 23, 42, 0.4) 0%, rgba(30, 41, 59, 0.45) 100%)' }} />
        </div>
      )}

      {/* Decorative Glow Elements */}
      <div 
        style={{
          position: 'absolute',
          top: '-15%',
          right: '-5%',
          width: '500px',
          height: '500px',
          background: 'radial-gradient(circle, rgba(211, 47, 47, 0.15) 0%, transparent 70%)',
          borderRadius: '50%',
          pointerEvents: 'none',
          zIndex: 2
        }}
      />

      <div className="container site-hero-container" style={{ position: 'relative', zIndex: 10 }}>
        <div className="site-hero-grid" style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(290px, 1fr))', gap: '32px', alignItems: 'center' }}>
          
          {/* Main Hero Copywriting */}
          <div className="site-hero-copy" style={{ textAlign: isRtl ? 'right' : 'left' }}>
            
            {/* Top Badge */}
            <div className="badge badge-gold animate-fade-in site-hero-badge" style={{ marginBottom: '16px', fontSize: '0.78rem' }}>
              <Building2 size={13} />
              <span>{badge}</span>
            </div>

            {/* Main Headline */}
            <h1 
              style={{
                fontSize: 'clamp(1.75rem, 5vw, 3.2rem)',
                fontWeight: 900,
                lineHeight: 1.3,
                marginBottom: '16px',
                letterSpacing: '-0.3px',
                color: rawBgVideo ? '#FFFFFF' : 'var(--text-main)',
                textShadow: rawBgVideo ? '0 2px 10px rgba(0,0,0,0.5)' : 'none'
              }}
              className="animate-fade-in"
            >
              {title}
            </h1>

            {/* Subtitle */}
            <p 
              style={{
                fontSize: '0.98rem',
                color: rawBgVideo ? '#E2E8F0' : 'var(--text-muted)',
                lineHeight: 1.65,
                marginBottom: '28px',
                maxWidth: '620px',
                textShadow: rawBgVideo ? '0 1px 8px rgba(0,0,0,0.5)' : 'none'
              }}
              className="animate-fade-in"
            >
              {String(subtitle).replace(/Vision Tradingg/g, 'Vision Trading')}
            </p>

            {/* Action Buttons */}
            <div className="site-hero-actions" style={{ display: 'flex', gap: '12px', flexWrap: 'wrap', marginBottom: '16px' }}>
              <button 
                onClick={onOpenQuoteModal}
                className="btn-primary"
                style={{ padding: '12px 24px', fontSize: '0.95rem', flex: 1, minWidth: '200px', justifyContent: 'center' }}
              >
                <span>{t('hero.primary')}</span>
                <ArrowLeft size={16} style={{ transform: isRtl ? 'none' : 'rotate(180deg)' }} />
              </button>

              <a 
                href="#services"
                className="btn-outline"
                style={{ 
                  padding: '12px 20px', 
                  fontSize: '0.95rem',
                  flex: 1,
                  minWidth: '160px',
                  justify: 'center',
                  color: rawBgVideo ? '#FFF' : 'var(--text-main)',
                  borderColor: rawBgVideo ? 'rgba(255, 255, 255, 0.4)' : 'var(--border-color)',
                  background: rawBgVideo ? 'rgba(15, 23, 42, 0.4)' : 'transparent'
                }}
              >
                <span>{t('hero.secondary')}</span>
              </a>
            </div>

          </div>

          {/* Left Interactive Image Carousel Showcase */}
          <div className="site-hero-media" style={{ position: 'relative' }}>
            <div 
              className="glass-card"
              style={{
                borderRadius: 'var(--radius-lg)',
                overflow: 'hidden',
                position: 'relative',
                boxShadow: 'var(--shadow-lg)',
                border: '1px solid var(--border-color)',
                background: '#0F172A'
              }}
            >
              {/* Carousel Active Image */}
              <div style={{ position: 'relative', height: 'clamp(270px, 35vw, 410px)', overflow: 'hidden' }}>
                {galleryImages.map((imgSrc, idx) => (
                  <img 
                    key={idx}
                    src={imgSrc}
                    alt={t('hero.imageAlt', { number: idx + 1 })}
                    loading={idx === 0 ? 'eager' : 'lazy'}
                    decoding="async"
                    fetchPriority={idx === 0 ? 'high' : 'auto'}
                    style={{ 
                      width: '100%', 
                      height: '100%', 
                      objectFit: 'cover',
                      position: 'absolute',
                      inset: 0,
                      opacity: idx === activeSlide ? 1 : 0,
                      transform: idx === activeSlide ? 'scale(1)' : 'scale(1.05)',
                      transition: 'opacity 0.6s ease-in-out, transform 0.6s ease-in-out'
                    }}
                  />
                ))}

                {/* Left & Right Arrow Navigation Controls */}
                {galleryImages.length > 1 && (
                  <>
                    <button
                      type="button"
                      onClick={handlePrevSlide}
                      style={{
                        position: 'absolute',
                        top: '50%',
                        right: '12px',
                        transform: 'translateY(-50%)',
                        width: '36px',
                        height: '36px',
                        borderRadius: '50%',
                        background: 'rgba(15, 23, 42, 0.65)',
                        color: '#FFFFFF',
                        border: '1px solid rgba(255, 255, 255, 0.3)',
                        backdropFilter: 'blur(8px)',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        cursor: 'pointer',
                        zIndex: 12,
                        transition: 'all 0.2s ease'
                      }}
                      title={t('hero.nextImage')}
                    >
                      <ChevronRight size={20} />
                    </button>

                    <button
                      type="button"
                      onClick={handleNextSlide}
                      style={{
                        position: 'absolute',
                        top: '50%',
                        left: '12px',
                        transform: 'translateY(-50%)',
                        width: '36px',
                        height: '36px',
                        borderRadius: '50%',
                        background: 'rgba(15, 23, 42, 0.65)',
                        color: '#FFFFFF',
                        border: '1px solid rgba(255, 255, 255, 0.3)',
                        backdropFilter: 'blur(8px)',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        cursor: 'pointer',
                        zIndex: 12,
                        transition: 'all 0.2s ease'
                      }}
                      title={t('hero.previousImage')}
                    >
                      <ChevronLeft size={20} />
                    </button>

                    {/* Pagination Dots Indicators */}
                    <div 
                      style={{
                        position: 'absolute',
                        bottom: '12px',
                        left: '50%',
                        transform: 'translateX(-50%)',
                        display: 'flex',
                        gap: '6px',
                        zIndex: 12,
                        background: 'rgba(15, 23, 42, 0.55)',
                        backdropFilter: 'blur(8px)',
                        padding: '4px 10px',
                        borderRadius: '9999px',
                        border: '1px solid rgba(255, 255, 255, 0.2)'
                      }}
                    >
                      {galleryImages.map((_, idx) => (
                        <button
                          key={idx}
                          onClick={() => setActiveSlide(idx)}
                          style={{
                            width: idx === activeSlide ? '20px' : '8px',
                            height: '8px',
                            borderRadius: '9999px',
                            background: idx === activeSlide ? '#D32F2F' : 'rgba(255, 255, 255, 0.5)',
                            border: 'none',
                            cursor: 'pointer',
                            transition: 'all 0.3s ease'
                          }}
                        />
                      ))}
                    </div>
                  </>
                )}

              </div>

              {/* Floating Stat Badge 1 */}
              <div 
                style={{
                  position: 'absolute',
                  bottom: '24px',
                  right: '16px',
                  background: 'rgba(15, 23, 42, 0.9)',
                  backdropFilter: 'blur(8px)',
                  padding: '10px 14px',
                  borderRadius: 'var(--radius-md)',
                  border: '1px solid rgba(255, 255, 255, 0.2)',
                  display: 'flex',
                  alignItems: 'center',
                  gap: '8px',
                  zIndex: 10
                }}
              >
                <Award size={20} color="#F59E0B" />
                <div>
                  <div style={{ fontSize: '0.72rem', color: '#94A3B8' }}>{t('hero.followup')}</div>
                  <div style={{ fontSize: '0.85rem', fontWeight: 800, color: '#FFF' }}>{t('hero.verified')}</div>
                </div>
              </div>

              {/* Floating Stat Badge 2 */}
              <div 
                style={{
                  position: 'absolute',
                  top: '16px',
                  left: '16px',
                  background: 'rgba(211, 47, 47, 0.95)',
                  color: '#FFF',
                  padding: '8px 14px',
                  borderRadius: '9999px',
                  fontWeight: 800,
                  fontSize: '0.78rem',
                  display: 'flex',
                  alignItems: 'center',
                  gap: '6px',
                  boxShadow: '0 10px 20px rgba(211, 47, 47, 0.4)',
                  zIndex: 10
                }}
              >
                <PackageCheck size={16} />
                <span>{t('hero.office')}</span>
              </div>

            </div>
          </div>

        </div>
      </div>

      {/* ANIMATED SCROLL DOWN INDICATOR ICON */}
      <a 
        href="#stats"
        onClick={(e) => {
          e.preventDefault();
          const statsElem = document.getElementById('stats');
          if (statsElem) statsElem.scrollIntoView({ behavior: 'smooth' });
        }}
        style={{
          position: 'absolute',
          bottom: '12px',
          left: '50%',
          transform: 'translateX(-50%)',
          zIndex: 15,
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          gap: '4px',
          color: rawBgVideo ? '#FFFFFF' : 'var(--text-main)',
          cursor: 'pointer',
          textDecoration: 'none',
          opacity: 0.9
        }}
      >
        <div 
          style={{
            width: '34px',
            height: '34px',
            borderRadius: '50%',
            background: rawBgVideo ? 'rgba(255, 255, 255, 0.15)' : 'var(--bg-card)',
            border: '1px solid var(--primary)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            color: 'var(--primary)',
            boxShadow: '0 4px 12px rgba(211, 47, 47, 0.25)'
          }}
          className="animate-bounce"
        >
          <ChevronDown size={18} />
        </div>
      </a>

    </section>
  );
}
