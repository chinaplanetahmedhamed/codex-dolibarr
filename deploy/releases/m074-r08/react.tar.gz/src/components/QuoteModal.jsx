import React, { useEffect, useRef, useState } from 'react';
import { X, Send, CheckCircle2, ShieldCheck } from 'lucide-react';
import { submitLeadRequest } from '../lib/api';
import { trackMetaEvent } from '../lib/metaPixel';
import { trackGoogleEvent } from '../lib/googleAnalytics';
import { useI18n } from '../i18n/I18nContext';
import { localizePath } from '../lib/navigation';

const FORM_COPY = {
  ar: { required: 'يرجى ملء الاسم ورقم الهاتف والمنتج المطلوب.', consentError: 'يرجى الموافقة على استخدام بيانات التواصل لمتابعة هذا الطلب.', sendError: 'تعذر إرسال الطلب. يرجى المحاولة لاحقاً أو التواصل عبر واتساب.', close: 'إغلاق نموذج الطلب', title: 'طلب دراسة وتسعير استيراد مجاني', intro: 'أدخل بيانات الطلب، وسيقوم فريق مكتب جوانزو بمراجعتها والتواصل معك لتأكيد المواصفات والخطوة التالية.', contactStep:'1. بيانات التواصل', productStep:'2. المنتج والوجهة والكمية', serviceStep:'3. نطاق الخدمة والموافقة', name: 'الاسم بالكامل *', namePh: 'مثال: م. أحمد العتيبي', phone: 'رقم الواتساب مع المفتاح *', phonePh: 'مثال: +966501234567', email: 'البريد الإلكتروني', country: 'الدولة المستقبلة', product: 'اسم المنتج أو الآلة المطلوبة *', productPh: 'مثال: خط إنتاج أكياس ورقية أوتوماتيك', quantity: 'الكمية التقديرية', quantityPh: 'مثال: خطان أو حاوية 20 قدم', service: 'الخدمة الرئيسية المطلوبة', notes: 'تفاصيل ومواصفات إضافية', notesPh: 'أدخل المواصفات الفنية أو روابط المنتجات إن وجدت...', privacyHint: 'لا تُدخل كلمات مرور أو بيانات بطاقات دفع أو مستندات خاصة من Customer Center أو ERP.', consentPrefix: 'أوافق على استخدام بيانات التواصل لمراجعة الطلب والرد عليه وفق ', privacy:'سياسة الخصوصية', consentSuffix: '. لن تُعرض معلومات الموردين أو البيانات الداخلية.', sending: 'جاري إرسال الطلب بأمان...', send: 'إرسال الطلب لمكتب جوانزو', success: 'تم استلام طلبك بنجاح!', thanks: 'شكراً لك {name}. تم تحويل طلب {product} إلى فريق المشتريات بمكتب جوانزو، وسنتواصل معك عبر واتساب.', reference: 'رقم الطلب:', done: 'تم، العودة للموقع', countries: ['المملكة العربية السعودية', 'جمهورية مصر العربية', 'الإمارات العربية المتحدة', 'دولة الكويت', 'دولة قطر', 'المملكة الأردنية', 'دولة أخرى'], services: ['البحث عن المصانع + التخليص والشحن الباب للباب', 'فحص الجودة وتدقيق المصنع فقط', 'استقبال وتجميع الطرود بمستودع جوانزو', 'التخليص الجمركي وإصدار الشهادات الرسمية'] },
  en: { required: 'Please enter your name, phone number and requested product.', consentError: 'Please consent to the use of your contact details for this request.', sendError: 'The request could not be sent. Please try later or contact us on WhatsApp.', close: 'Close request form', title: 'Request a free import review and quotation', intro: 'Share your requirements. Our Guangzhou team will review them and contact you to confirm specifications and the next step.', contactStep:'1. Contact details', productStep:'2. Product, destination and quantity', serviceStep:'3. Service scope and consent', name: 'Full name *', namePh: 'Example: Ahmed Ali', phone: 'WhatsApp number with country code *', phonePh: 'Example: +966501234567', email: 'Email', country: 'Destination country', product: 'Required product or machinery *', productPh: 'Example: automatic paper bag production line', quantity: 'Estimated quantity', quantityPh: 'Example: 2 lines or one 20-foot container', service: 'Main service required', notes: 'Additional details and specifications', notesPh: 'Add technical specifications or product links if available...', privacyHint: 'Do not enter passwords, payment-card details, or private Customer Center or ERP documents.', consentPrefix: 'I consent to the use of my contact details under the ', privacy:'Privacy Policy', consentSuffix: '. Supplier and internal information will not be exposed.', sending: 'Sending securely...', send: 'Send request to Guangzhou office', success: 'Your request has been received!', thanks: 'Thank you {name}. Your request for {product} was sent to our Guangzhou sourcing team. We will contact you on WhatsApp.', reference: 'Request reference:', done: 'Return to website', countries: ['Saudi Arabia', 'Egypt', 'United Arab Emirates', 'Kuwait', 'Qatar', 'Jordan', 'Other country'], services: ['Factory sourcing, customs and door-to-door shipping', 'Quality inspection and factory audit only', 'Parcel receipt and consolidation in Guangzhou', 'Customs clearance and official certificates'] },
  fr: { required: 'Veuillez indiquer votre nom, téléphone et le produit recherché.', consentError: "Veuillez accepter l'utilisation de vos coordonnées pour cette demande.", sendError: "La demande n'a pas pu être envoyée. Réessayez plus tard ou contactez-nous sur WhatsApp.", close: 'Fermer le formulaire', title: "Demander une étude et un devis d'importation gratuits", intro: "Présentez votre demande. Notre équipe de Guangzhou l'étudiera et vous contactera pour confirmer les spécifications et la prochaine étape.", contactStep:'1. Coordonnées', productStep:'2. Produit, destination et quantité', serviceStep:'3. Périmètre et consentement', name: 'Nom complet *', namePh: 'Exemple : Ahmed Ali', phone: 'Numéro WhatsApp avec indicatif *', phonePh: 'Exemple : +33612345678', email: 'E-mail', country: 'Pays de destination', product: 'Produit ou machine recherché *', productPh: "Exemple : ligne automatique de sacs en papier", quantity: 'Quantité estimée', quantityPh: 'Exemple : 2 lignes ou un conteneur de 20 pieds', service: 'Service principal souhaité', notes: 'Détails et spécifications supplémentaires', notesPh: 'Ajoutez les spécifications techniques ou liens produits disponibles...', privacyHint: "Ne saisissez aucun mot de passe, donnée de carte bancaire ou document privé du Customer Center ou de l'ERP.", consentPrefix: "J'accepte l'utilisation de mes coordonnées selon la ", privacy:'Politique de confidentialité', consentSuffix: ". Les informations fournisseur et internes ne seront pas exposées.", sending: 'Envoi sécurisé...', send: 'Envoyer au bureau de Guangzhou', success: 'Votre demande a bien été reçue !', thanks: "Merci {name}. Votre demande concernant {product} a été transmise à notre équipe achats de Guangzhou. Nous vous contacterons sur WhatsApp.", reference: 'Référence :', done: 'Retour au site', countries: ['Arabie saoudite', 'Égypte', 'Émirats arabes unis', 'Koweït', 'Qatar', 'Jordanie', 'Autre pays'], services: ["Recherche d'usines, douane et livraison porte-à-porte", "Contrôle qualité et audit d'usine uniquement", 'Réception et groupage à Guangzhou', 'Dédouanement et certificats officiels'] },
};

export default function QuoteModal({ isOpen, onClose, onSubmitSuccess, initialRequest = {} }) {
  const { isRtl, locale } = useI18n();
  const copy = FORM_COPY[locale];
  const [formData, setFormData] = useState({
    clientName: '',
    phone: '',
    email: '',
    country: 'السعودية',
    productName: '',
    quantity: '',
    targetPrice: '',
    serviceRequired: 'البحث عن المنتجات والشحن الباب للباب',
    notes: '',
    website: '',
    consent: false
  });

  const [submitted, setSubmitted] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [submitError, setSubmitError] = useState('');
  const [reference, setReference] = useState('');
  const formStarted = useRef(false);

  useEffect(() => {
    if (!isOpen || !initialRequest || typeof initialRequest !== 'object') return;
    setFormData((current) => ({
      ...current,
      productName: initialRequest.productName || current.productName,
      quantity: initialRequest.quantity || current.quantity,
      notes: initialRequest.notes || current.notes,
    }));
  }, [isOpen, initialRequest]);

  if (!isOpen) return null;

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!formData.clientName || !formData.phone || !formData.productName) {
      setSubmitError(copy.required);
      return;
    }
    if (!formData.consent) {
      setSubmitError(copy.consentError);
      return;
    }

    setSubmitting(true);
    setSubmitError('');
    try {
      const result = await submitLeadRequest({ type: 'quote_request', ...formData });
      trackMetaEvent('Lead', {
        content_name: 'general_quote_request',
        content_category: 'quote_request',
        status: 'submitted',
      });
      trackGoogleEvent('generate_lead');
      setReference(result.reference || '');
      setSubmitted(true);
      onSubmitSuccess?.({ ...formData, reference: result.reference });
    } catch (error) {
      setSubmitError(error.message || copy.sendError);
    } finally {
      setSubmitting(false);
    }
  };

  const handleFormStart = () => {
    if (formStarted.current) return;
    formStarted.current = true;
    trackMetaEvent('FormStart', {
      content_name: 'general_quote_request',
      form_type: 'quote_request',
    }, { custom: true });
    trackGoogleEvent('form_start');
  };

  const resetAndClose = () => {
    setSubmitted(false);
    setSubmitError('');
    setReference('');
    formStarted.current = false;
    onClose();
  };

  return (
    <div role="dialog" aria-modal="true" aria-labelledby="quote-modal-title" aria-describedby="quote-modal-intro"
      style={{
        position: 'fixed',
        inset: 0,
        zIndex: 3000,
        background: 'rgba(0, 0, 0, 0.7)',
        backdropFilter: 'blur(8px)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        padding: '20px'
      }}
    >
      <div 
        className="glass-card animate-fade-in"
        style={{
          maxWidth: '680px',
          width: '100%',
          maxHeight: '90vh',
          overflowY: 'auto',
          borderRadius: 'var(--radius-lg)',
          padding: '36px',
          position: 'relative'
        }}
      >
        <button 
          onClick={resetAndClose}
          aria-label={copy.close}
          style={{
            position: 'absolute',
            [isRtl ? 'left' : 'right']: '24px',
            top: '24px',
            background: 'none',
            border: 'none',
            color: 'var(--text-main)',
            cursor: 'pointer'
          }}
        >
          <X size={24} />
        </button>

        {!submitted ? (
          <div>
            <div style={{ display: 'flex', alignItems: 'center', gap: '10px', marginBottom: '8px' }}>
              <ShieldCheck size={26} color="var(--primary)" />
              <h2 id="quote-modal-title" style={{ fontSize: '1.6rem', fontWeight: 800 }}>{copy.title}</h2>
            </div>
            <p id="quote-modal-intro" style={{ color: 'var(--text-muted)', fontSize: '0.94rem', marginBottom: '28px' }}>
              {copy.intro}
            </p>

            <form onSubmit={handleSubmit} onInputCapture={handleFormStart} onChangeCapture={handleFormStart} style={{ display: 'flex', flexDirection: 'column', gap: '18px' }}>
              <h3 className="intake-step-title">{copy.contactStep}</h3>
              
              {/* Name & Phone */}
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(240px, 1fr))', gap: '16px' }}>
                <div>
                  <label htmlFor="quote-client-name" style={{ display: 'block', fontSize: '0.88rem', fontWeight: 700, marginBottom: '6px' }}>{copy.name}</label>
                  <input 
                    id="quote-client-name"
                    type="text" 
                    className="input-field" 
                    placeholder={copy.namePh}
                    value={formData.clientName}
                    onChange={(e) => setFormData({ ...formData, clientName: e.target.value })}
                    required
                  />
                </div>
                <div>
                  <label htmlFor="quote-phone" style={{ display: 'block', fontSize: '0.88rem', fontWeight: 700, marginBottom: '6px' }}>{copy.phone}</label>
                  <input 
                    id="quote-phone"
                    type="text" 
                    className="input-field" 
                    placeholder={copy.phonePh}
                    value={formData.phone}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                    required
                  />
                </div>
              </div>

              {/* Email & Country */}
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(240px, 1fr))', gap: '16px' }}>
                <div>
                  <label htmlFor="quote-email" style={{ display: 'block', fontSize: '0.88rem', fontWeight: 700, marginBottom: '6px' }}>{copy.email}</label>
                  <input 
                    id="quote-email"
                    type="email" 
                    className="input-field" 
                    placeholder="name@company.com"
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  />
                </div>
                <div>
                  <label htmlFor="quote-country" style={{ display: 'block', fontSize: '0.88rem', fontWeight: 700, marginBottom: '6px' }}>{copy.country}</label>
                  <select 
                    id="quote-country"
                    className="input-field"
                    value={formData.country}
                    onChange={(e) => setFormData({ ...formData, country: e.target.value })}
                  >
                    {['السعودية', 'مصر', 'الإمارات', 'الكويت', 'قطر', 'الأردن', 'أخرى'].map((value, index) => <option key={value} value={value}>{copy.countries[index]}</option>)}
                  </select>
                </div>
              </div>

              {/* Product Name & Quantity */}
              <h3 className="intake-step-title">{copy.productStep}</h3>
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(240px, 1fr))', gap: '16px' }}>
                <div>
                  <label htmlFor="quote-product" style={{ display: 'block', fontSize: '0.88rem', fontWeight: 700, marginBottom: '6px' }}>{copy.product}</label>
                  <input 
                    id="quote-product"
                    type="text" 
                    className="input-field" 
                    placeholder={copy.productPh}
                    value={formData.productName}
                    onChange={(e) => setFormData({ ...formData, productName: e.target.value })}
                    required
                  />
                </div>
                <div>
                  <label htmlFor="quote-quantity" style={{ display: 'block', fontSize: '0.88rem', fontWeight: 700, marginBottom: '6px' }}>{copy.quantity}</label>
                  <input 
                    id="quote-quantity"
                    type="text" 
                    className="input-field" 
                    placeholder={copy.quantityPh}
                    value={formData.quantity}
                    onChange={(e) => setFormData({ ...formData, quantity: e.target.value })}
                  />
                </div>
              </div>

              {/* Required Service */}
              <h3 className="intake-step-title">{copy.serviceStep}</h3>
              <div>
                <label htmlFor="quote-service" style={{ display: 'block', fontSize: '0.88rem', fontWeight: 700, marginBottom: '6px' }}>{copy.service}</label>
                <select 
                  id="quote-service"
                  className="input-field"
                  value={formData.serviceRequired}
                  onChange={(e) => setFormData({ ...formData, serviceRequired: e.target.value })}
                >
                  {['البحث عن المنتجات والشحن الباب للباب', 'فحص الجودة وتدقيق المصانع فقط', 'استقبال وجمع الشحنات بمستودع جوانزو', 'التخليص الجمركي وإصدار الشهادات'].map((value, index) => <option key={value} value={value}>{copy.services[index]}</option>)}
                </select>
              </div>

              {/* Notes */}
              <div>
                <label htmlFor="quote-notes" style={{ display: 'block', fontSize: '0.88rem', fontWeight: 700, marginBottom: '6px' }}>{copy.notes}</label>
                <textarea 
                  id="quote-notes"
                  className="input-field" 
                  rows={3}
                  placeholder={copy.notesPh}
                  value={formData.notes}
                  onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                />
              </div>

              <p className="intake-privacy-hint">{copy.privacyHint}</p>

              <div aria-hidden="true" style={{ position: 'absolute', left: '-10000px', width: '1px', height: '1px', overflow: 'hidden' }}>
                <label htmlFor="quote-website">Website</label>
                <input id="quote-website" type="text" tabIndex={-1} autoComplete="off" value={formData.website} onChange={(e) => setFormData({ ...formData, website: e.target.value })} />
              </div>

              <label style={{ display: 'flex', alignItems: 'flex-start', gap: '9px', fontSize: '0.82rem', color: 'var(--text-muted)', lineHeight: 1.6 }}>
                <input type="checkbox" checked={formData.consent} onChange={(e) => setFormData({ ...formData, consent: e.target.checked })} style={{ marginTop: '4px' }} />
                <span>{copy.consentPrefix}<a href={localizePath('/privacy', locale)}>{copy.privacy}</a>{copy.consentSuffix}</span>
              </label>

              {submitError && (
                <div role="alert" style={{ padding: '11px 14px', borderRadius: '10px', background: 'rgba(211,47,47,.1)', border: '1px solid rgba(211,47,47,.35)', color: '#D32F2F', fontSize: '0.86rem', fontWeight: 700 }}>
                  {submitError}
                </div>
              )}

              <button type="submit" disabled={submitting} className="btn-primary" style={{ padding: '14px', justifyContent: 'center', fontSize: '1.05rem', marginTop: '10px', opacity: submitting ? 0.7 : 1 }}>
                <Send size={18} />
                <span>{submitting ? copy.sending : copy.send}</span>
              </button>

            </form>
          </div>
        ) : (
          <div style={{ textAlign: 'center', padding: '30px 0' }}>
            <div 
              style={{
                width: '72px',
                height: '72px',
                borderRadius: '50%',
                background: 'rgba(16, 185, 129, 0.15)',
                color: '#10B981',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                margin: '0 auto 20px auto'
              }}
            >
              <CheckCircle2 size={42} />
            </div>

            <h3 style={{ fontSize: '1.6rem', fontWeight: 800, marginBottom: '12px' }}>
              {copy.success}
            </h3>
            
            <p style={{ color: 'var(--text-muted)', fontSize: '1.05rem', lineHeight: 1.6, maxWidth: '480px', margin: '0 auto 28px auto' }}>
              {copy.thanks.replace('{name}', formData.clientName).replace('{product}', formData.productName)}
            </p>

            {reference && <div style={{ margin: '-12px auto 24px', fontFamily: 'var(--font-en)', fontWeight: 900, color: 'var(--primary)' }}>{copy.reference} {reference}</div>}

            <button onClick={resetAndClose} className="btn-primary" style={{ padding: '12px 32px' }}>
              {copy.done}
            </button>
          </div>
        )}

      </div>
    </div>
  );
}
