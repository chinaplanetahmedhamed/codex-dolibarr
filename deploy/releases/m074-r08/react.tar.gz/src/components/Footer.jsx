import React from 'react';
import { Globe, MapPin, Phone, Mail, MessageSquare, ArrowUp, UserRoundCheck, Building2, LockKeyhole } from 'lucide-react';
import { CompanyBrandLockup } from './BrandLogos';
import { useI18n } from '../i18n/I18nContext';
import { localizePath } from '../lib/navigation';
import { useReleaseVersion } from '../lib/releaseVersion';

export default function Footer({ siteInfo, customerCenterUrl }) {
  const { locale, t } = useI18n();
  const releaseVersion = useReleaseVersion();
  const sectionTitleStyle = {
    fontSize: '1.1rem',
    fontWeight: 800,
    color: '#F1F5F9',
    marginBottom: '18px',
    borderInlineStart: '3px solid var(--primary)',
    paddingInlineStart: '10px',
  };
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer 
      style={{
        background: 'var(--secondary)',
        color: '#FFFFFF',
        borderTop: '1px solid rgba(255, 255, 255, 0.1)',
        paddingTop: '64px',
        paddingBottom: '32px',
        position: 'relative'
      }}
    >
      <div className="container">
        
        <div 
          style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fit, minmax(260px, 1fr))',
            gap: '40px',
            marginBottom: '48px'
          }}
        >
          {/* Brand Info */}
          <div>
            <CompanyBrandLockup surface="dark" />

            <p style={{ color: '#94A3B8', fontSize: '0.92rem', lineHeight: 1.7, margin: '20px 0' }}>
              {t('footer.description')}
            </p>

            <div style={{ display: 'flex', gap: '12px', flexWrap: 'wrap' }}>
              <a 
                href={`https://wa.me/${(siteInfo?.whatsappNumber || '+8613480652510').replace(/[^0-9]/g, '')}`}
                target="_blank" 
                rel="noreferrer" 
                className="btn-primary"
                style={{ padding: '8px 16px', fontSize: '0.85rem' }}
              >
                <MessageSquare size={16} />
                <span>{t('footer.whatsapp')}</span>
              </a>

              {customerCenterUrl && (
                <a
                  href={customerCenterUrl}
                  className="btn-secondary"
                  style={{ padding: '8px 16px', fontSize: '0.85rem', textDecoration: 'none' }}
                >
                  <UserRoundCheck size={16} />
                  <span>{t('footer.customerCenter')}</span>
                </a>
              )}
            </div>
          </div>

          {/* Guangzhou Head Office */}
          <div>
            <h4 style={sectionTitleStyle}>
              {t('footer.chinaOffice')}
            </h4>
            <ul style={{ listStyle: 'none', display: 'flex', flexDirection: 'column', gap: '12px', color: '#CBD5E1', fontSize: '0.88rem' }}>
              <li style={{ display: 'flex', alignItems: 'flex-start', gap: '10px' }}>
                <MapPin size={18} color="#D32F2F" style={{ flexShrink: 0, marginTop: '2px' }} />
                <span>{siteInfo?.chinaOfficeAddress || 'جوانزو، مقاطعة قوانغدونغ، جمهورية الصين الشعبية'}</span>
              </li>
              {siteInfo?.chinaOfficeAddressZh && (
                <li style={{ display: 'flex', alignItems: 'flex-start', gap: '10px' }}>
                  <span style={{ width: '18px', flexShrink: 0, color: '#D32F2F', fontWeight: 800 }}>中</span>
                  <span lang="zh-CN" style={{ fontFamily: 'system-ui, sans-serif', lineHeight: 1.7 }}>{siteInfo.chinaOfficeAddressZh}</span>
                </li>
              )}
              <li style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                <Phone size={16} color="#D32F2F" />
                <span style={{ fontFamily: 'var(--font-en)' }}>{siteInfo?.whatsappNumber || '+86 13480652510'}</span>
              </li>
              <li style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                <Mail size={16} color="#D32F2F" />
                <span style={{ fontFamily: 'var(--font-en)' }}>{siteInfo?.email || 'info@chinaplanet.org'}</span>
              </li>
            </ul>
          </div>

          {/* Egypt Regional Office */}
          <div>
            <h4 style={sectionTitleStyle}>
              {t('footer.egyptOffice')}
            </h4>
            <ul style={{ listStyle: 'none', display: 'flex', flexDirection: 'column', gap: '12px', color: '#CBD5E1', fontSize: '0.88rem' }}>
              <li style={{ display: 'flex', alignItems: 'flex-start', gap: '10px' }}>
                <Building2 size={18} color="#D32F2F" style={{ flexShrink: 0, marginTop: '2px' }} />
                <a
                  href={siteInfo?.egyptOfficeMapUrl || 'https://maps.app.goo.gl/GiGbBYBfSFWKKvva6?g_st=ic'}
                  target="_blank"
                  rel="noreferrer"
                  style={{ color: 'inherit', textDecoration: 'none' }}
                >
                  {siteInfo?.egyptOfficeAddress || '26 شارع السيدة امنه، سيدي جابر، شارع المشير، ميزان شركه البرمجيات، الاسكندرية'}
                </a>
              </li>
              <li style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                <UserRoundCheck size={16} color="#D32F2F" />
                <span>{t('footer.officeManager', { name: siteInfo?.egyptOfficeContactName || 'معاذ محمد' })}</span>
              </li>
              <li style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                <Phone size={16} color="#D32F2F" />
                <a
                  href={`tel:${(siteInfo?.egyptOfficePhone || '01096722199').replace(/[^0-9+]/g, '')}`}
                  style={{ color: 'inherit', textDecoration: 'none', fontFamily: 'var(--font-en)' }}
                >
                  {siteInfo?.egyptOfficePhone || '01096722199'}
                </a>
              </li>
              <li style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                <Globe size={16} color="#D32F2F" />
                <span>chinaplanet.org</span>
              </li>
            </ul>
          </div>

          {/* Main Website Pages */}
          <div>
            <h4 style={sectionTitleStyle}>
              {t('footer.quickLinks')}
            </h4>
            <nav style={{ display: 'grid', gridTemplateColumns: 'repeat(2, minmax(0, 1fr))', gap: '10px 18px' }}>
              {[
                ['/', t('nav.home')],
                ['/about', t('nav.about')],
                ['/services', t('nav.services')],
                ['/products', t('nav.products')],
                ['/how-we-work', t('nav.howWeWork')],
                ['/china-guide', t('nav.chinaGuide')],
                ['/blog', t('nav.blog')],
                ['/faq', t('nav.faq')],
                ['/contact', t('nav.contact')],
              ].map(([href, label]) => (
                <a key={href} href={localizePath(href, locale)} style={{ color: '#CBD5E1', textDecoration: 'none', fontSize: '0.88rem' }}>{label}</a>
              ))}
            </nav>
          </div>

        </div>

        {/* Bottom Rights */}
        <div 
          style={{
            borderTop: '1px solid rgba(255, 255, 255, 0.08)',
            paddingTop: '24px',
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center',
            flexWrap: 'wrap',
            gap: '16px',
            fontSize: '0.84rem',
            color: '#94A3B8'
          }}
        >
          <div style={{ display: 'flex', alignItems: 'center', gap: '10px 14px', flexWrap: 'wrap' }}>
            {t('footer.rights')} <strong>{siteInfo?.siteNameAr || 'كوكب الصين'} ({siteInfo?.siteNameEn || 'China Planet'}) - Vision Trading Ltd.</strong>
            {releaseVersion && (
              <span
                dir="ltr"
                lang="en"
                aria-label={t('footer.versionLabel', { version: releaseVersion.label })}
                style={{
                  display: 'inline-flex',
                  alignItems: 'center',
                  minHeight: '32px',
                  padding: '5px 9px',
                  border: '1px solid rgba(255, 255, 255, 0.14)',
                  borderRadius: '999px',
                  color: '#CBD5E1',
                  fontFamily: 'var(--font-en)',
                  fontSize: '0.75rem',
                  letterSpacing: '0.01em',
                  whiteSpace: 'nowrap',
                }}
              >
                {releaseVersion.label}
              </span>
            )}
          </div>

          <div style={{ display: 'flex', alignItems: 'center', gap: '8px', flexWrap: 'wrap' }}>
            <a href={localizePath('/privacy', locale)} style={{ color: '#CBD5E1', textDecoration: 'none', padding: '8px 6px' }}>{t('footer.privacy')}</a>
            <a href={localizePath('/terms', locale)} style={{ color: '#CBD5E1', textDecoration: 'none', padding: '8px 6px' }}>{t('footer.terms')}</a>
            <a href="/admin" style={{ color: '#CBD5E1', textDecoration: 'none', display: 'flex', alignItems: 'center', gap: '6px', padding: '8px 10px' }}>
              <LockKeyhole size={14} /> {t('footer.staffLogin')}
            </a>
            <button
              onClick={scrollToTop}
              style={{
                background: 'rgba(255, 255, 255, 0.06)',
                color: '#FFF',
                border: '1px solid rgba(255, 255, 255, 0.1)',
                padding: '8px 14px',
                borderRadius: 'var(--radius-sm)',
                cursor: 'pointer',
                display: 'flex',
                alignItems: 'center',
                gap: '6px'
              }}
            >
              <span>{t('footer.top')}</span>
              <ArrowUp size={14} />
            </button>
          </div>
        </div>

      </div>
    </footer>
  );
}
