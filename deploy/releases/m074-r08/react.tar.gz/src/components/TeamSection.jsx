import React from 'react';
import { Users, PhoneCall, CheckCircle2, MapPin, MessageSquare, Star } from 'lucide-react';
import { DEFAULT_TEAM_MEMBERS } from '../data/teamData';
import { localizedField, useI18n } from '../i18n/I18nContext';

const FOUNDER_GALLERY = [
  {
    src: '/images/founder/ahmed-hamed-untitled-3.webp',
    alt: 'أحمد حامد في فعالية للتجارة والصناعة في الصين',
    caption: 'فعاليات التجارة والصناعة في الصين',
  },
  {
    src: '/images/founder/ahmed-hamed-chinaplanet2.webp',
    alt: 'أحمد حامد متحدثاً باسم China Planet',
    caption: 'متحدثاً باسم China Planet',
  },
  {
    src: '/images/founder/ahmed-hamed-personal-2.webp',
    alt: 'أحمد حامد في فعالية أعمال بمدينة جوانزو',
    caption: 'شبكات وفعاليات الأعمال في جوانزو',
  },
];

export default function TeamSection({ onOpenQuoteModal, teamMembers, siteInfo, showContactCta = true }) {
  const { isRtl, locale, t } = useI18n();
  const listToRender = teamMembers && teamMembers.length ? teamMembers : DEFAULT_TEAM_MEMBERS;

  const founder = listToRender.find((member) => member.name === 'أحمد حامد' || member.role?.includes('مؤسس')) || listToRender[0];
  const operationalTeam = listToRender.filter((member) => member !== founder);

  return (
    <section id="team" style={{ padding: '80px 0', background: 'var(--bg-main)', position: 'relative' }}>
      <div className="container">
        
        {/* Section Header */}
        <div style={{ textAlign: 'center', maxWidth: '750px', margin: '0 auto 52px auto' }}>
          <div className="badge badge-gold" style={{ marginBottom: '14px', padding: '6px 16px' }}>
            <Users size={15} color="var(--primary-gold)" />
            <span>{t('team.badge')}</span>
          </div>
          <h2 style={{ fontSize: 'clamp(1.8rem, 4vw, 2.5rem)', fontWeight: 900, marginBottom: '14px', color: 'var(--text-main)' }}>
            {t('team.title')}
          </h2>
          <p style={{ color: 'var(--text-muted)', fontSize: '1.02rem', lineHeight: 1.6 }}>
            {t('team.description')}
          </p>
        </div>

        <article className="founder-spotlight glass-card">
          <div className="founder-main-photo">
            <img
              src={founder?.image || '/images/founder/ahmed-hamed-20260413.webp'}
              alt={founder?.imageAlt || 'أحمد حامد مؤسس China Planet وVision Trading'}
            />
            <div className="founder-photo-badge"><Star size={14} fill="currentColor" /> {t('team.since')}</div>
          </div>

          <div className="founder-spotlight-copy">
            <div className="badge badge-red"><Users size={15} /> {t('team.founderBadge')}</div>
            <h3>{localizedField(founder, 'name', locale, founder?.name || 'Ahmed Hamed')}</h3>
            <strong>{t('team.founderRole')}</strong>
            <p>{localizedField(founder, 'bio', locale, founder?.bio || '')}</p>
            <div className="founder-location"><MapPin size={17} /> {t('team.location')}</div>

            <div className="founder-gallery" aria-label="صور أحمد حامد في الصين وفعاليات الأعمال">
              {FOUNDER_GALLERY.map((photo) => (
                <figure key={photo.src}>
                  <img src={photo.src} alt={photo.alt} loading="lazy" />
                  <figcaption>{photo.caption}</figcaption>
                </figure>
              ))}
            </div>

            <button type="button" onClick={onOpenQuoteModal} className="btn-primary founder-contact-button">
              <MessageSquare size={17} /> {t('team.contactFounder')}
            </button>
          </div>
        </article>

        {/* Operations Team Cards Grid */}
        <div className="team-cards-grid" style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(min(320px, 100%), 1fr))', gap: '30px' }}>
          {operationalTeam.map((member) => (
            <div 
              key={`${member.name}-${member.role}`}
              className="glass-card"
              style={{
                borderRadius: 'var(--radius-lg)',
                overflow: 'hidden',
                display: 'flex',
                flexDirection: 'column',
                justifyContent: 'space-between',
                border: '1px solid var(--border-color)',
                background: 'var(--bg-card)',
                boxShadow: '0 12px 30px rgba(0,0,0,0.06)',
                position: 'relative',
                transition: 'transform 0.3s ease, box-shadow 0.3s ease'
              }}
            >
              {/* ID Card Top Accent */}
              <div style={{ height: '5px', background: 'linear-gradient(90deg, var(--primary) 0%, #F59E0B 100%)' }} />
              
              <div style={{ padding: '20px 20px 24px 20px', flex: 1, display: 'flex', flexDirection: 'column' }}>
                
                {/* Large Portrait Photo Display */}
                <div 
                  style={{ 
                    position: 'relative', 
                    height: '270px', 
                    borderRadius: '16px', 
                    overflow: 'hidden',
                    marginBottom: '20px',
                    border: '1px solid var(--border-color)',
                    background: '#0F172A'
                  }}
                >
                  <img 
                    src={member.image || "/images/hero.webp"}
                    alt={member.imageAlt || member.name}
                    loading="lazy"
                    decoding="async"
                    style={{ width: '100%', height: '100%', objectFit: 'cover', objectPosition: member.imagePosition || 'center top' }}
                  />

                  {/* Gradient Overlay for Text Legibility */}
                  <div style={{ position: 'absolute', inset: 0, background: 'linear-gradient(to top, rgba(15, 23, 42, 0.75) 0%, transparent 50%)' }} />

                  {/* Team Badge Tag */}
                  <div 
                    style={{
                      position: 'absolute',
                      top: '12px',
                      [isRtl ? 'right' : 'left']: '12px',
                      background: 'rgba(15, 23, 42, 0.85)',
                      color: '#FFF',
                      backdropFilter: 'blur(8px)',
                      padding: '6px 12px',
                      borderRadius: '9999px',
                      fontSize: '0.76rem',
                      fontWeight: 800,
                      display: 'flex',
                      alignItems: 'center',
                      gap: '6px',
                      border: '1px solid rgba(255, 255, 255, 0.2)'
                    }}
                  >
                    <CheckCircle2 size={14} color="#059669" />
                    <span>China Planet 🇨🇳</span>
                  </div>

                  {/* Experience Badge Tag */}
                  <div 
                    style={{
                      position: 'absolute',
                      bottom: '12px',
                      [isRtl ? 'right' : 'left']: '12px',
                      background: 'rgba(211, 47, 47, 0.9)',
                      color: '#FFF',
                      padding: '4px 12px',
                      borderRadius: '9999px',
                      fontSize: '0.76rem',
                      fontWeight: 800,
                      display: 'flex',
                      alignItems: 'center',
                      gap: '4px',
                      boxShadow: '0 4px 12px rgba(211, 47, 47, 0.4)'
                    }}
                  >
                    <Star size={12} fill="#FFF" color="#FFF" />
                    <span>{localizedField(member, 'experience', locale, member.experience)}</span>
                  </div>
                </div>

                {/* Member Name & Details */}
                <h3 style={{ fontSize: '1.25rem', fontWeight: 900, color: 'var(--text-main)', marginBottom: '4px' }}>
                  {localizedField(member, 'name', locale, member.name)}
                </h3>

                {/* Role & Position */}
                <div style={{ fontSize: '0.88rem', color: 'var(--primary)', fontWeight: 800, marginBottom: '12px' }}>
                  {localizedField(member, 'role', locale, member.role)}
                </div>

                {/* Bio Summary */}
                <p style={{ color: 'var(--text-muted)', fontSize: '0.88rem', lineHeight: 1.65, marginBottom: '16px', flex: 1 }}>
                  {localizedField(member, 'bio', locale, member.bio)}
                </p>

              </div>

              {/* ID Card Footer Action */}
              <div style={{ borderTop: '1px solid var(--border-color)', padding: '16px 20px', background: 'var(--bg-main)', textAlign: 'center' }}>
                <button 
                  onClick={onOpenQuoteModal} 
                  className="btn-primary" 
                  style={{ width: '100%', justifyContent: 'center', fontSize: '0.88rem', padding: '10px 18px', borderRadius: '9999px' }}
                >
                  <MessageSquare size={16} />
                  <span>{t('team.contactMember')}</span>
                </button>
              </div>

            </div>
          ))}
        </div>

        {/* Contact Us Anchor Banner */}
        {showContactCta && <div
          id="contact"
          className="glass-card" 
          style={{
            marginTop: '60px',
            padding: '36px',
            borderRadius: 'var(--radius-lg)',
            background: 'linear-gradient(135deg, #0F172A 0%, #1E293B 100%)',
            color: '#FFFFFF',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
            flexWrap: 'wrap',
            gap: '24px'
          }}
        >
          <div>
            <div className="badge badge-gold" style={{ marginBottom: '10px' }}>{t('team.contactBadge')}</div>
            <h3 style={{ fontSize: '1.6rem', fontWeight: 800, marginBottom: '8px' }}>
              {t('team.contactTitle')}
            </h3>
            <p style={{ color: '#94A3B8', fontSize: '0.95rem' }}>
              {t('team.contactText', { phone: siteInfo?.guangzhouPhone || '+8613480652510' })}
            </p>
          </div>

          <div style={{ display: 'flex', gap: '12px' }}>
            <button onClick={onOpenQuoteModal} className="btn-primary" style={{ padding: '12px 24px' }}>
              <PhoneCall size={18} />
              <span>{t('team.contactNow')}</span>
            </button>
          </div>
        </div>}

      </div>
    </section>
  );
}
