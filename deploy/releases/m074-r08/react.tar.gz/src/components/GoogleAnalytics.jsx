import { useEffect } from 'react';
import { startGoogleAnalyticsTracking } from '../lib/googleAnalytics';

export default function GoogleAnalytics() {
  useEffect(() => startGoogleAnalyticsTracking(), []);
  return null;
}
