import React from 'react';
import { useI18n } from '../i18n/I18nContext';
import { localizePath } from '../lib/navigation';

export default function AppLink({ to, onNavigate, onClick, children, ...props }) {
  const { locale } = useI18n();
  const href = localizePath(to || '/', locale);

  const handleClick = (event) => {
    onClick?.(event);
    if (event.defaultPrevented || !onNavigate || event.button !== 0 || event.metaKey || event.ctrlKey || event.shiftKey || event.altKey) return;
    event.preventDefault();
    onNavigate();
  };

  return <a {...props} href={href} onClick={handleClick}>{children}</a>;
}
