import React from 'react';
import {
  BadgeCheck,
  Building2,
  CheckCircle2,
  Globe2,
  Languages,
  MapPin,
  MessageSquare,
  Network,
  ShieldCheck,
  UsersRound,
} from 'lucide-react';
import { CompanyBrandLockup } from './BrandLogos';
import { useI18n } from '../i18n/I18nContext';

const PROOF_POINTS = [
  { value: 'منذ 2007', label: 'خبرة عملية داخل الصين', icon: Building2 },
  { value: 'جوانزو', label: 'تنسيق ميداني داخل الصين', icon: UsersRound },
  { value: 'تقارير منزوعة البيانات', label: 'أمثلة متاحة للمراجعة', icon: Network },
  { value: 'AR · EN · FR', label: 'لغات الموقع العامة', icon: Globe2 },
];

const REASONS = [
  { title: 'وجود ميداني في جوانزو', text: 'فريق على الأرض للتواصل والزيارة والمتابعة مع الموردين والمصانع.', icon: MapPin },
  { title: 'تواصل عربي وصيني واضح', text: 'نقل المواصفات والشروط بين العميل والمورد بدون فقدان التفاصيل التجارية.', icon: Languages },
  { title: 'شفافية قبل التنفيذ', text: 'نحدد نطاق الخدمة والرسوم ونقاط اعتماد العميل في عرض عمل مكتوب.', icon: BadgeCheck },
  { title: 'الجودة قبل الشحن', text: 'نربط الفحص والتوثيق بقرار الشحن بحسب طبيعة المنتج ونطاق المهمة.', icon: ShieldCheck },
];

const FOUNDER_PORTRAIT = '/images/founder/ahmed-hamed-20260413.webp';

const ABOUT_COPY = {
  en: {
    badge: 'About Us', previewTitle: 'A multilingual team working from Guangzhou since 2007', previewText: 'Ahmed Hamed founded China Planet and Vision Trading to help importers negotiate, verify and manage transactions from inside China.', discuss: 'Discuss your request', story: 'Our story and team', founder: 'Ahmed Hamed', founderRole: 'Founder of China Planet and Vision Trading', title: 'Your commercial team on the ground in China—not just an online intermediary', p1: 'Ahmed Hamed founded China Planet and Vision Trading after beginning work in China in 2007, helping importers overcome language barriers, select suppliers, monitor quality and organize transactions.', p2: "Today we act as an extension of the client's team in Guangzhou: sourcing, negotiating and following production, inspection, consolidation, documents and shipping under a clear scope.", teamCta: 'Meet our team', overlay: 'Multilingual management and on-the-ground China experience', why: 'Why China Planet?', whyTitle: 'Clearer sourcing decisions and lower risk before goods leave China', whyText: 'We do not promise zero risk. We help you decide using verification, documentation and approval at every stage.',
    proof: [['Since 2007', 'Practical experience in China'], ['Guangzhou', 'On-the-ground China coordination'], ['Redacted records', 'Reviewable examples available'], ['AR · EN · FR', 'Public website languages']],
    reasons: [['On-the-ground Guangzhou presence', 'A local team for supplier communication, visits and follow-up.'], ['Clear Arabic, Chinese and English communication', 'Accurate transfer of specifications and commercial terms between buyer and supplier.'], ['Transparency before execution', 'Service scope, fees and approval points are documented in a written proposal.'], ['Quality before shipment', 'Inspection and documentation support the shipping decision according to the agreed scope.']],
  },
  fr: {
    badge: 'À propos', previewTitle: 'Une équipe multilingue basée à Guangzhou depuis 2007', previewText: 'Ahmed Hamed a fondé China Planet et Vision Trading pour aider les importateurs à négocier, vérifier et gérer leurs opérations depuis la Chine.', discuss: 'Discuter de votre demande', story: 'Notre histoire et notre équipe', founder: 'Ahmed Hamed', founderRole: 'Fondateur de China Planet et Vision Trading', title: 'Votre équipe commerciale sur le terrain en Chine, pas seulement un intermédiaire en ligne', p1: "Ahmed Hamed a fondé China Planet et Vision Trading après avoir commencé à travailler en Chine en 2007, afin d'aider les importateurs à surmonter les barrières linguistiques, choisir les fournisseurs et contrôler la qualité.", p2: "Aujourd'hui, nous agissons comme une extension de l'équipe du client à Guangzhou : recherche, négociation, production, inspection, groupage, documents et transport selon un périmètre clair.", teamCta: "Découvrir l'équipe", overlay: 'Gestion multilingue et expérience de terrain en Chine', why: 'Pourquoi China Planet ?', whyTitle: 'Des décisions plus claires et moins de risques avant le départ des marchandises', whyText: "Nous ne promettons pas l'absence totale de risque. Nous vous aidons à décider grâce à la vérification, la documentation et l'approbation à chaque étape.",
    proof: [['Depuis 2007', 'Expérience pratique en Chine'], ['Guangzhou', 'Coordination de terrain en Chine'], ['Documents anonymisés', 'Exemples disponibles'], ['AR · EN · FR', 'Langues publiques du site']],
    reasons: [['Présence à Guangzhou', 'Une équipe locale pour communiquer, visiter et suivre les fournisseurs.'], ['Communication claire en arabe, chinois et anglais', 'Transmission précise des spécifications et conditions commerciales.'], ["Transparence avant l'exécution", 'Le périmètre, les frais et les points de validation sont documentés.'], ['Qualité avant expédition', "L'inspection et la documentation soutiennent la décision d'expédier selon le périmètre convenu."]],
  },
};

export default function AboutTrustSection({ onOpenQuoteModal, compact = false, onViewAll }) {
  const { locale } = useI18n();
  const translated = ABOUT_COPY[locale];
  const copy = translated || {
    badge: 'من نحن', previewTitle: 'فريق عربي يعمل من جوانزو منذ 2007', previewText: 'أسس أحمد حامد China Planet وVision Trading لمساعدة المستورد العربي في التفاوض والتحقق ومتابعة الصفقة من داخل الصين.', discuss: 'ناقش طلبك', story: 'قصتنا وفريق العمل', founder: 'أحمد حامد', founderRole: 'مؤسس كوكب الصين وVision Trading', title: 'شريكك التجاري على الأرض في الصين، وليس مجرد وسيط إلكتروني', p1: 'أسس أحمد حامد China Planet وVision Trading بعد بداية عمله في الصين عام 2007، لمساعدة المستورد العربي على تجاوز عوائق اللغة واختيار المورد ومراقبة الجودة وتنظيم الصفقة من داخل السوق الصيني.', p2: 'اليوم نعمل كامتداد لفريق العميل في جوانزو: نبحث ونتفاوض ونتابع الإنتاج والفحص والتجميع والمستندات والشحن وفق نطاق واضح لكل مشروع.', teamCta: 'تعرّف إلى فريق العمل', overlay: 'إدارة عربية وخبرة ميدانية في الصين', why: 'لماذا كوكب الصين؟', whyTitle: 'قرارات توريد أوضح ومخاطر أقل قبل أن تغادر البضاعة الصين', whyText: 'لا نقدم ضمانات مطلقة؛ نساعدك على اتخاذ القرار اعتماداً على التحقق والتوثيق والموافقة في كل مرحلة.', proof: PROOF_POINTS.map(({ value, label }) => [value, label]), reasons: REASONS.map(({ title, text }) => [title, text]),
  };
  const proofPoints = PROOF_POINTS.map((point, index) => ({ ...point, value: copy.proof[index][0], label: copy.proof[index][1] }));
  const reasons = REASONS.map((reason, index) => ({ ...reason, title: copy.reasons[index][0], text: copy.reasons[index][1] }));
  if (compact) {
    return (
      <section id="about" style={{ padding: '58px 0', background: 'var(--bg-main)' }}>
        <div className="container about-preview-grid">
          <div>
            <div className="badge badge-red" style={{ marginBottom: '12px' }}><Building2 size={16} /> {copy.badge}</div>
            <h2 style={{ fontSize: 'clamp(1.75rem, 4vw, 2.4rem)', fontWeight: 900, lineHeight: 1.35, marginBottom: '14px' }}>
              {copy.previewTitle}
            </h2>
            <p style={{ color: 'var(--text-muted)', lineHeight: 1.85, marginBottom: '22px' }}>
              {copy.previewText}
            </p>
            <CompanyBrandLockup compact />
            <div style={{ display: 'flex', gap: '10px', flexWrap: 'wrap' }}>
              <button type="button" className="btn-primary" onClick={onOpenQuoteModal}><MessageSquare size={17} /> {copy.discuss}</button>
              <button type="button" className="btn-outline" onClick={onViewAll}><UsersRound size={17} /> {copy.story}</button>
            </div>
          </div>
          <div className="about-preview-proof">
            <figure className="home-founder-card">
              <img src={FOUNDER_PORTRAIT} alt={copy.founderRole} loading="lazy" decoding="async" />
              <figcaption>
                <strong>{copy.founder}</strong>
                <span>{copy.founderRole}</span>
              </figcaption>
            </figure>
            <div className="about-preview-stats">
              {proofPoints.map(({ value, label, icon: Icon }) => (
                <div key={label}>
                  <Icon size={19} />
                  <strong>{value}</strong>
                  <span>{label}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>
    );
  }

  return (
    <section id="about" style={{ padding: '88px 0', background: 'var(--bg-main)', position: 'relative' }}>
      <div className="container">
        <div className="about-trust-grid">
          <div>
            <div className="badge badge-red" style={{ marginBottom: '14px' }}>
              <Building2 size={16} />
              <span>{copy.badge}</span>
            </div>
            <h2 style={{ fontSize: 'clamp(2rem, 4vw, 3rem)', fontWeight: 900, lineHeight: 1.3, marginBottom: '18px' }}>
              {copy.title}
            </h2>
            <p style={{ color: 'var(--text-muted)', fontSize: '1.04rem', lineHeight: 1.9, marginBottom: '18px' }}>
              {copy.p1}
            </p>
            <p style={{ color: 'var(--text-muted)', fontSize: '1.04rem', lineHeight: 1.9, marginBottom: '26px' }}>
              {copy.p2}
            </p>
            <CompanyBrandLockup />
            <div style={{ display: 'flex', gap: '12px', flexWrap: 'wrap' }}>
              <button type="button" className="btn-primary" onClick={onOpenQuoteModal}>
                <MessageSquare size={18} />
                <span>{copy.discuss}</span>
              </button>
              <a className="btn-outline" href="#team" style={{ textDecoration: 'none' }}>
                <UsersRound size={18} />
                <span>{copy.teamCta}</span>
              </a>
            </div>
          </div>

          <div className="about-proof-panel">
            <div className="about-proof-image">
              <img src="/images/china_planet_hero_banner_1785418012119.jpg" alt={copy.overlay} loading="lazy" decoding="async" />
              <div className="about-proof-overlay">
                <CheckCircle2 size={20} />
                <span>{copy.overlay}</span>
              </div>
            </div>
            <div className="about-proof-grid">
              {proofPoints.map(({ value, label, icon: Icon }) => (
                <div className="about-proof-stat" key={label}>
                  <Icon size={20} color="var(--primary)" />
                  <strong>{value}</strong>
                  <span>{label}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        <>
            <div style={{ textAlign: 'center', maxWidth: '760px', margin: '72px auto 32px' }}>
              <div className="badge badge-gold" style={{ marginBottom: '12px' }}>{copy.why}</div>
              <h3 style={{ fontSize: 'clamp(1.7rem, 3vw, 2.35rem)', fontWeight: 900, marginBottom: '12px' }}>
                {copy.whyTitle}
              </h3>
              <p style={{ color: 'var(--text-muted)', lineHeight: 1.8 }}>
                {copy.whyText}
              </p>
            </div>

            <div className="why-us-grid">
              {reasons.map(({ title, text, icon: Icon }) => (
                <article className="glass-card why-us-card" key={title}>
                  <div className="why-us-icon"><Icon size={25} /></div>
                  <h4>{title}</h4>
                  <p>{text}</p>
                </article>
              ))}
            </div>
        </>
      </div>
    </section>
  );
}
