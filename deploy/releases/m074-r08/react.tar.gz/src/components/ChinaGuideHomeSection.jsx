import React, { useMemo } from "react";
import { ArrowLeft, Compass, MapPin, Store } from "lucide-react";

import { localizedField, useI18n } from "../i18n/I18nContext";
import AppLink from "./AppLink";
import { selectFeaturedGuidePlaces } from "../lib/homeGuideSelection";

export default function ChinaGuideHomeSection({
  places = [],
  cities = [],
  status = "loading",
  onOpenGuide,
  onSelectPlace,
}) {
  const { isRtl, locale, t } = useI18n();
  const featuredPlaces = useMemo(() => selectFeaturedGuidePlaces(places, 3), [places]);
  const showCards = status === "ready" && featuredPlaces.length > 0;

  return (
    <section id="china-guide-home" style={{ padding: "72px 0", background: "linear-gradient(180deg, var(--bg-main), var(--bg-card))" }}>
      <div className="container">
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "end", gap: "24px", flexWrap: "wrap", marginBottom: "30px" }}>
          <div style={{ maxWidth: "720px" }}>
            <div className="badge badge-gold" style={{ marginBottom: "12px" }}><Compass size={15} />{t("guide.homeBadge")}</div>
            <h2 style={{ fontSize: "clamp(1.85rem, 3vw, 2.45rem)", lineHeight: 1.3, marginBottom: "12px" }}>{t("guide.homeTitle")}</h2>
            <p style={{ color: "var(--text-muted)", fontSize: "1.02rem", lineHeight: 1.8 }}>{t("guide.homeDescription")}</p>
            {status === "ready" && (
              <p style={{ color: "var(--primary)", fontWeight: 800, marginTop: "10px" }}>
                {t("guide.homeStats", { places: places.length, cities: cities.length })}
              </p>
            )}
          </div>
          <button type="button" className="btn-primary" onClick={onOpenGuide}>
            <Store size={18} />{t("guide.homeViewAll")}
          </button>
        </div>

        {status === "loading" ? (
          <div className="guide-home-grid" aria-label={t("guide.loading")} aria-busy="true">
            {Array.from({ length: 3 }, (_, index) => <div key={index} className="guide-home-skeleton loading-shimmer" aria-hidden="true" />)}
          </div>
        ) : showCards ? (
          <div className="guide-home-grid">
            {featuredPlaces.map((place) => (
              <article key={place.id || place.slug} className="glass-card guide-home-card">
                <AppLink to={`/china-guide/${encodeURIComponent(place.slug || place.id)}`} onNavigate={() => onSelectPlace?.(place.slug || place.id)} className="guide-home-card-button">
                  <span className="guide-home-card-image">
                    <img src={place.image || "/images/hero.webp"} alt={localizedField(place, "title", locale, place.title)} loading="lazy" decoding="async" />
                    <span className="guide-home-card-overlay" />
                    <span className="badge badge-red guide-home-card-type"><Store size={13} />{place.type || t("guide.defaultType")}</span>
                    <span className="guide-home-card-city"><MapPin size={15} />{place.city}</span>
                  </span>
                  <span className="guide-home-card-copy">
                    <strong>{localizedField(place, "title", locale, place.title)}</strong>
                    <span>{localizedField(place, "excerpt", locale, place.excerpt || t("guide.homeCardFallback"))}</span>
                    <span className="guide-home-card-link">{t("guide.details")}<ArrowLeft size={16} style={{ transform: isRtl ? "none" : "rotate(180deg)" }} /></span>
                  </span>
                </AppLink>
              </article>
            ))}
          </div>
        ) : (
          <div className="glass-card" style={{ padding: "30px", textAlign: "center" }}>
            <Store size={34} style={{ color: "var(--primary)", marginBottom: "10px" }} />
            <p style={{ color: "var(--text-muted)", marginBottom: "16px" }}>{t("guide.homeFallback")}</p>
            <button type="button" className="btn-outline" onClick={onOpenGuide}>{t("guide.homeViewAll")}</button>
          </div>
        )}
      </div>
    </section>
  );
}
