import React, { useState, useEffect } from 'react';
import { X, Check, Package } from 'lucide-react';
import { useI18n } from '../i18n/I18nContext';
import { fetchB2bCatalog } from '../lib/api';

export default function AddToCartModal({ isOpen, product, onClose, onConfirm }) {
  const { locale } = useI18n();
  const copy = locale === 'fr'
    ? { title: 'Définir le nombre de cartons et la quantité', afterVariant: "À définir après le choix de l'option", cartonSize: 'Dimensions du carton :', variant: 'Taille ou option du produit *', choose: 'Choisir une option...', perCarton: 'pièces/carton', cartons: 'Nombre de cartons souhaité *', cartonsPh: 'Saisir le nombre de cartons...', pieces: 'Pièces par carton', piece: 'pièces', confirmNeeded: 'Chargement depuis le CMS', total: 'Total :', totalPieces: 'pièces au total', notes: 'Remarques pour ce produit (facultatif)', notesPh: "Exemple : confirmer la taille et utiliser des cartons renforcés...", cancel: 'Annuler', add: 'Confirmer et ajouter au panier', cartonsAlert: 'Veuillez indiquer le nombre de cartons.', variantAlert: "Veuillez d'abord choisir une option produit.", packingAlert: "L'emballage de ce produit n'est pas encore défini dans le CMS.", volume: 'Volume total' }
    : locale === 'en'
      ? { title: 'Set carton count and order quantity', afterVariant: 'Set after choosing an option', cartonSize: 'Carton size:', variant: 'Product size or option *', choose: 'Choose an option...', perCarton: 'pcs/carton', cartons: 'Required carton count *', cartonsPh: 'Enter carton count...', pieces: 'Pieces per carton', piece: 'pieces', confirmNeeded: 'Loading from CMS', total: 'Total:', totalPieces: 'pieces total', notes: 'Notes for this product (optional)', notesPh: 'Example: confirm size and use reinforced cartons...', cancel: 'Cancel', add: 'Confirm and add to cart', cartonsAlert: 'Please enter the required carton count.', variantAlert: 'Please choose a product option first.', packingAlert: 'Packing for this product is not defined in the CMS yet.', volume: 'Total volume' }
      : { title: 'تحديد عدد الكراتين وكمية الطلب', afterVariant: 'يُحدد بعد اختيار المقاس', cartonSize: 'مقاس الكرتونة:', variant: 'المقاس أو خيار المنتج *', choose: 'اختر المقاس...', perCarton: 'قطعة/كرتونة', cartons: 'عدد الكراتين المطلوبة *', cartonsPh: 'أدخل عدد الكراتين...', pieces: 'عدد القطع بالكرتونة', piece: 'قطعة', confirmNeeded: 'جاري التحميل من CMS', total: 'الإجمالي:', totalPieces: 'قطعة إجمالية', notes: 'ملاحظات وتوجيهات خاصة بهذا المنتج (اختياري)', notesPh: 'مثال: يرجى تأكيد المقاس والشحن في كراتين مقواة...', cancel: 'إلغاء', add: 'تأكيد الإضافة للسلة', cartonsAlert: 'يرجى تحديد عدد الكراتين المطلوبة!', variantAlert: 'يرجى اختيار مقاس أو خيار المنتج أولاً!', packingAlert: 'بيانات تعبئة هذا المنتج غير مكتملة في CMS حتى الآن.', volume: 'إجمالي الحجم' };
  const [cartonsCount, setCartonsCount] = useState('');
  const [pcsPerCarton, setPcsPerCarton] = useState('');
  const [selectedVariantId, setSelectedVariantId] = useState('');
  const [comment, setComment] = useState('');
  const [verifiedProduct, setVerifiedProduct] = useState(null);
  const [packingLoading, setPackingLoading] = useState(false);
  const displayedProduct = verifiedProduct ? {
    ...product,
    image: verifiedProduct.images?.[0] || product?.image,
    pcsPerCarton: verifiedProduct.packing?.unitsPerCarton || 0,
    cbmPerCarton: verifiedProduct.packing?.cbmPerCarton || 0,
    ctnSize: verifiedProduct.packing?.hasDimensions
      ? `${verifiedProduct.packing.lengthCm} × ${verifiedProduct.packing.widthCm} × ${verifiedProduct.packing.heightCm} cm`
      : product?.ctnSize,
  } : product;
  const variants = Array.isArray(product?.variants) ? product.variants : [];
  const selectedVariant = variants.find((variant) => String(variant.id) === selectedVariantId) || null;

  useEffect(() => {
    if (product) {
      setCartonsCount('');
      setComment('');
      const initialVariant = Array.isArray(product.variants) && product.variants.length === 1
        ? String(product.variants[0].id)
        : '';
      setSelectedVariantId(initialVariant);
      
      // Directly read QTY/CTN from WooCommerce synced attributes
      let defaultPcs = (initialVariant ? product.variants[0].pcsPerCarton : product.pcsPerCarton) || '';
      
      if (!defaultPcs || defaultPcs === 100) {
        const textToSearch = `${product.moq || ''} ${product.specs || ''} ${product.description || ''}`;
        const match = textToSearch.match(/(?:PCS\/CTN|QTY\/CTN|PCS|CTN|كرتونة|قطع)[\s:]*([0-9]+)/i);
        if (match && match[1]) {
          defaultPcs = match[1];
        }
      }

      setPcsPerCarton(defaultPcs || '');
    }
  }, [product, isOpen]);

  useEffect(() => {
    if (!isOpen || !product) return undefined;
    let active = true;
    setVerifiedProduct(null);
    setPackingLoading(true);
    fetchB2bCatalog({ search: product.sku || product.title || '', perPage: 12 })
      .then((payload) => {
        if (!active) return;
        const expectedId = Number(product.wooProductId || product.id);
        const exact = (payload.products || []).find((item) => Number(item.id) === expectedId);
        setVerifiedProduct(exact || null);
        setPcsPerCarton(exact?.packing?.unitsPerCarton || '');
      })
      .catch(() => { if (active) setVerifiedProduct(null); })
      .finally(() => { if (active) setPackingLoading(false); });
    return () => { active = false; };
  }, [isOpen, product]);

  useEffect(() => {
    if (!product || !selectedVariantId) return;
    const variant = (product.variants || []).find((item) => String(item.id) === selectedVariantId);
    setPcsPerCarton(variant?.pcsPerCarton || verifiedProduct?.packing?.unitsPerCarton || product.pcsPerCarton || '');
  }, [product, selectedVariantId, verifiedProduct]);

  if (!isOpen || !product) return null;

  // Calculate total units = cartons * pcsPerCarton
  const totalCartonsNum = parseInt(cartonsCount, 10) || 0;
  const pcsPerCartonNum = parseInt(pcsPerCarton, 10) || 0;
  const calculatedTotalUnits = totalCartonsNum * pcsPerCartonNum;

  // Calculate total CBM if CBM per carton is available
  let totalCbmText = '';
  if (displayedProduct.cbmPerCarton && totalCartonsNum > 0) {
    const cbmVal = parseFloat(displayedProduct.cbmPerCarton);
    if (!isNaN(cbmVal)) {
      totalCbmText = `${copy.volume}: ${(cbmVal * totalCartonsNum).toFixed(3)} CBM`;
    }
  }

  const handleConfirm = (e) => {
    e.preventDefault();
    if (!cartonsCount.trim()) {
      alert(copy.cartonsAlert);
      return;
    }
    if (variants.length > 0 && !selectedVariant) {
      alert(copy.variantAlert);
      return;
    }
    if (pcsPerCartonNum < 1) {
      alert(copy.packingAlert);
      return;
    }

    const quantityFormatted = pcsPerCartonNum > 0
      ? `${cartonsCount} كرتونة (${pcsPerCartonNum} قطعة/كرتونة = إجمالي ${calculatedTotalUnits} قطعة) ${totalCbmText ? `| ${totalCbmText}` : ''}`
      : `${cartonsCount} كرتونة (عدد القطع في الكرتونة يحتاج تأكيد)`;

    onConfirm({
      ...product,
      id: selectedVariant?.wooVariationId ? `${product.id}:${selectedVariant.wooVariationId}` : product.id,
      sourceProductId: product.id,
      wooVariationId: selectedVariant?.wooVariationId || product.wooVariationId || null,
      selectedVariant: selectedVariant || null,
      selectedOptionLabel: selectedVariant?.label || '',
      cartonsCount: totalCartonsNum,
      pcsPerCarton: pcsPerCartonNum,
      totalUnits: calculatedTotalUnits,
      image: displayedProduct.image,
      cbmPerCarton: displayedProduct.cbmPerCarton || '',
      ctnSize: displayedProduct.ctnSize || '',
      quantity: quantityFormatted,
      comment: comment.trim()
    });

    onClose();
  };

  return (
    <div 
      className="animate-fade-in"
      style={{
        position: 'fixed',
        inset: 0,
        zIndex: 99999,
        background: 'rgba(15, 23, 42, 0.8)',
        backdropFilter: 'blur(8px)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        padding: '20px'
      }}
    >
      <div 
        style={{
          background: 'var(--bg-card)',
          color: 'var(--text-main)',
          borderRadius: '20px',
          width: '100%',
          maxWidth: '540px',
          border: '1px solid var(--border-color)',
          boxShadow: '0 25px 50px -12px rgba(0, 0, 0, 0.35)',
          overflow: 'hidden'
        }}
      >
        {/* Header */}
        <div style={{ background: 'linear-gradient(135deg, #0F172A 0%, #1E293B 100%)', color: '#FFF', padding: '20px 24px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
            <Package size={22} color="var(--primary-gold)" />
            <h3 style={{ fontSize: '1.1rem', fontWeight: 800, margin: 0 }}>{copy.title}</h3>
          </div>
          <button onClick={onClose} style={{ background: 'none', border: 'none', color: '#94A3B8', cursor: 'pointer' }}>
            <X size={22} />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleConfirm} style={{ padding: '24px', display: 'flex', flexDirection: 'column', gap: '20px' }}>
          
          {/* Product Summary & WooCommerce Parsed Attributes */}
          <div style={{ display: 'flex', gap: '14px', alignItems: 'center', background: 'var(--bg-main)', padding: '14px 16px', borderRadius: 'var(--radius-md)', border: '1px solid var(--border-color)' }}>
            <img src={displayedProduct.image || '/images/hero.webp'} alt={product.title} style={{ width: '56px', height: '56px', borderRadius: '8px', objectFit: 'cover' }} />
            <div style={{ flex: 1 }}>
              <div style={{ fontSize: '0.94rem', fontWeight: 800, color: 'var(--text-main)', marginBottom: '4px' }}>
                {product.title}{selectedVariant?.label ? ` — ${selectedVariant.label}` : ''}
              </div>
              <div style={{ fontSize: '0.78rem', color: 'var(--primary)', fontWeight: 700, marginBottom: '4px' }}>
                {product.categoryName} {product.subCategoryName ? `➔ ${product.subCategoryName}` : ''}
              </div>
              
              {/* WooCommerce Auto-Detected QTY/CTN & CBM Badge */}
              <div style={{ display: 'flex', gap: '8px', flexWrap: 'wrap', fontSize: '0.75rem', fontWeight: 800, color: '#059669' }}>
                <span>📦 QTY/CTN: {packingLoading ? copy.confirmNeeded : (pcsPerCartonNum || copy.packingAlert)}</span>
                {displayedProduct.cbmPerCarton && <span>| 📐 CBM: {displayedProduct.cbmPerCarton}</span>}
                {displayedProduct.ctnSize && <span>| 📏 {copy.cartonSize} {displayedProduct.ctnSize}</span>}
              </div>
            </div>
          </div>

          {variants.length > 0 && (
            <div>
              <label htmlFor="product-variant" style={{ display: 'block', fontSize: '0.86rem', fontWeight: 800, marginBottom: '6px', color: 'var(--text-main)' }}>
                📏 {copy.variant}
              </label>
              <select
                id="product-variant"
                required
                className="input-field"
                value={selectedVariantId}
                onChange={(event) => setSelectedVariantId(event.target.value)}
              >
                <option value="">{copy.choose}</option>
                {variants.map((variant) => (
                  <option key={variant.id} value={variant.id}>
                    {variant.label}{variant.pcsPerCarton ? ` — ${variant.pcsPerCarton} ${copy.perCarton}` : ''}
                  </option>
                ))}
              </select>
            </div>
          )}

          {/* Cartons & Units Display/Inputs */}
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '16px' }}>
            
            {/* Cartons Count Input (Editable by Customer) */}
            <div>
              <label style={{ display: 'block', fontSize: '0.86rem', fontWeight: 800, marginBottom: '6px', color: 'var(--text-main)' }}>
                📦 {copy.cartons}
              </label>
              <input 
                type="number"
                min="1"
                required
                autoFocus
                className="input-field"
                placeholder={copy.cartonsPh}
                value={cartonsCount}
                onChange={(e) => setCartonsCount(e.target.value)}
                style={{ fontSize: '1.05rem', fontWeight: 800, color: 'var(--primary)' }}
              />
            </div>

            {/* PCS per Carton (Read-Only Fixed Display) */}
            <div>
              <label style={{ display: 'block', fontSize: '0.86rem', fontWeight: 800, marginBottom: '6px', color: 'var(--text-main)' }}>
                🔢 {copy.pieces}
              </label>
              <div 
                style={{ 
                  background: 'var(--bg-main)', 
                  padding: '10px 14px', 
                  borderRadius: 'var(--radius-md)', 
                  border: '1px solid var(--border-color)', 
                  fontSize: '1rem', 
                  fontWeight: 900, 
                  color: '#059669',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'space-between',
                  height: '46px'
                }}
              >
                <span>{packingLoading ? copy.confirmNeeded : (pcsPerCartonNum ? `${pcsPerCartonNum} ${copy.piece}` : copy.packingAlert)}</span>
              </div>
            </div>

          </div>

          {/* Total Calculated Summary Pill */}
          {totalCartonsNum > 0 && pcsPerCartonNum > 0 && (
            <div style={{ background: 'rgba(16, 185, 129, 0.12)', border: '1px solid #10B981', color: '#059669', padding: '12px 16px', borderRadius: 'var(--radius-md)', fontSize: '0.9rem', fontWeight: 800, textAlign: 'center', display: 'flex', flexDirection: 'column', gap: '4px' }}>
              <div>📊 {copy.total} {totalCartonsNum} × {pcsPerCartonNum} = <span style={{ fontSize: '1.05rem', textDecoration: 'underline' }}>{calculatedTotalUnits} {copy.totalPieces}</span></div>
              {totalCbmText && <div style={{ fontSize: '0.82rem', color: 'var(--primary)' }}>📐 {totalCbmText}</div>}
            </div>
          )}

          {/* Product Custom Comment */}
          <div>
            <label style={{ display: 'block', fontSize: '0.86rem', fontWeight: 800, marginBottom: '6px', color: 'var(--text-main)' }}>
              💬 {copy.notes}
            </label>
            <textarea 
              rows={3}
              className="input-field"
              placeholder={copy.notesPh}
              value={comment}
              onChange={(e) => setComment(e.target.value)}
            />
          </div>

          {/* Action Buttons */}
          <div style={{ borderTop: '1px solid var(--border-color)', paddingTop: '16px', display: 'flex', justifyContent: 'flex-end', gap: '12px' }}>
            <button type="button" onClick={onClose} className="btn-outline" style={{ padding: '10px 20px' }}>
              {copy.cancel}
            </button>

            <button type="submit" className="btn-primary" style={{ padding: '10px 24px', borderRadius: '9999px' }}>
              <Check size={18} />
              <span>{copy.add}</span>
            </button>
          </div>

        </form>
      </div>
    </div>
  );
}
