import React, { useState } from 'react';
import { ChevronDown, CircleHelp, MessageSquare } from 'lucide-react';
import { useI18n } from '../i18n/I18nContext';

const FAQ_ITEMS = [
  {
    question: 'كيف أبدأ طلب توريد منتج من الصين؟',
    answer: 'أرسل اسم المنتج أو رابطه والمواصفات والكمية والبلد المستهدف. نراجع الطلب أولاً، ثم نوضح نطاق البحث أو الإدارة والرسوم والخطوة التالية قبل بدء العمل.',
  },
  {
    question: 'هل تبحثون عن المورد فقط أم تديرون الصفقة كاملة؟',
    answer: 'الخدمتان متاحتان. يمكن تنفيذ بحث ومقارنة موردين كمهمة مستقلة، أو إدارة مترابطة تشمل التفاوض والعينة والعقد والإنتاج والفحص والتجميع والمستندات والشحن.',
  },
  {
    question: 'كيف أتأكد من المصنع وجودة البضاعة؟',
    answer: 'بحسب احتياج الصفقة يمكن إجراء تحقق مستندي وزيارة ميدانية للمصنع، ثم فحص البضاعة وفق قائمة مواصفات معتمدة وإصدار تقرير مصور قبل الشحن.',
  },
  {
    question: 'هل يمكن تجميع مشتريات من عدة موردين؟',
    answer: 'نعم. يمكن للموردين إرسال الطرود إلى نقطة الاستلام في جوانزو، ثم توثيقها وتجميعها وإعادة تجهيزها للشحن حسب التعليمات ونطاق الخدمة المتفق عليه.',
  },
  {
    question: 'هل توفرون شحناً بحرياً وجوياً وخدمة من الباب إلى الباب؟',
    answer: 'ننسق الشحن البحري والجوي والشحنات الكاملة أو الجزئية. توفر خدمة الباب إلى الباب ومتطلباتها يعتمد على بلد الوصول ونوع البضاعة والمسار المتاح، لذلك يتم تأكيدها في عرض الشحن.',
  },
  {
    question: 'كيف يتم حساب الرسوم ومدة التنفيذ؟',
    answer: 'تختلف حسب المنتج والكمية وعدد الموردين وموقع المصنع ونطاق الفحص وطريقة الشحن. نقدم عرضاً مكتوباً قبل التنفيذ، بينما تظل أسعار الشحن والمدد تقديرية حتى تأكيد الحجز والمتطلبات.',
  },
  {
    question: 'هل تساعدون في مستندات التصدير وCargoX؟',
    answer: 'ننسق بيانات الفاتورة وقائمة التعبئة وشهادة المنشأ وبوليصة الشحن، وندعم إجراءات CargoX عند الحاجة. المتطلبات النهائية يحددها بلد الوصول ونوع البضاعة والجهات المختصة.',
  },
];

const TRANSLATED_FAQ_ITEMS = {
  en: [
    ['How do I start a product sourcing request from China?', 'Send the product name or link, specifications, quantity and destination country. We review the request and confirm scope, fees and the next step before work starts.'],
    ['Do you only find suppliers or manage the full transaction?', 'Both options are available. We can perform a standalone supplier comparison or manage negotiation, samples, contracts, production, inspection, consolidation, documents and shipping.'],
    ['How can I verify the factory and product quality?', 'Depending on the transaction, we can perform document checks, an on-site factory visit and product inspection against an approved checklist, followed by a visual report before shipment.'],
    ['Can you consolidate purchases from multiple suppliers?', 'Yes. Suppliers can send packages to the Guangzhou receiving point for documentation, consolidation and shipment preparation under the agreed instructions and scope.'],
    ['Do you provide sea, air and door-to-door shipping?', 'We coordinate sea and air freight, full containers and partial loads. Door-to-door availability depends on destination, cargo type and route and is confirmed in the shipping quotation.'],
    ['How are fees and execution time calculated?', 'They depend on product type, quantity, supplier count, factory location, inspection scope and shipping method. A written proposal is provided before execution.'],
    ['Can you help with export documents and CargoX?', 'We coordinate invoice, packing-list, certificate-of-origin and bill-of-lading information and support CargoX where required. Final requirements depend on destination and cargo type.'],
  ],
  fr: [
    ["Comment démarrer une demande d'achat en Chine ?", 'Envoyez le nom ou le lien du produit, les spécifications, la quantité et le pays de destination. Nous confirmons le périmètre, les frais et la prochaine étape avant de commencer.'],
    ['Recherchez-vous seulement les fournisseurs ou gérez-vous toute l’opération ?', 'Les deux options sont possibles : comparaison indépendante de fournisseurs ou gestion de la négociation, des échantillons, du contrat, de la production, du contrôle, du groupage, des documents et du transport.'],
    ["Comment vérifier l'usine et la qualité des produits ?", "Selon l'opération, nous pouvons effectuer une vérification documentaire, une visite sur site et une inspection selon une liste approuvée, puis remettre un rapport visuel avant expédition."],
    ['Pouvez-vous regrouper les achats de plusieurs fournisseurs ?', 'Oui. Les fournisseurs peuvent envoyer les colis à notre point de réception à Guangzhou pour documentation, groupage et préparation selon les instructions convenues.'],
    ['Proposez-vous le transport maritime, aérien et porte-à-porte ?', "Nous coordonnons le fret maritime et aérien, les conteneurs complets et les chargements partiels. Le porte-à-porte dépend de la destination, de la marchandise et de l'itinéraire."],
    ["Comment sont calculés les frais et le délai d'exécution ?", "Ils dépendent du produit, de la quantité, du nombre de fournisseurs, de l'emplacement de l'usine, du périmètre d'inspection et du mode de transport. Une offre écrite est fournie avant exécution."],
    ["Pouvez-vous aider avec les documents d'exportation et CargoX ?", "Nous coordonnons la facture, la liste de colisage, le certificat d'origine et le connaissement, et assistons pour CargoX lorsque nécessaire."],
  ],
};

export default function FaqSection({ onOpenQuoteModal, limit, onViewAll, compact = false }) {
  const { locale } = useI18n();
  const [openIndex, setOpenIndex] = useState(0);
  const localizedItems = locale === 'ar' ? FAQ_ITEMS : TRANSLATED_FAQ_ITEMS[locale].map(([question, answer]) => ({ question, answer }));
  const visibleItems = Number.isInteger(limit) ? localizedItems.slice(0, limit) : localizedItems;
  const copy = locale === 'ar' ? { badge: 'الأسئلة الشائعة', title: 'إجابات مباشرة قبل أن تبدأ الاستيراد', description: 'جمعنا أهم الأسئلة المتكررة من المستوردين حول البحث والفحص والتجميع والشحن. تفاصيل كل صفقة تُثبت في عرض العمل الخاص بها.', ask: 'لدي سؤال عن طلبي', all: 'عرض جميع الأسئلة والإجابات' } : locale === 'fr' ? { badge: 'Questions fréquentes', title: "Des réponses directes avant de commencer l'importation", description: "Les réponses générales aux questions sur la recherche, l'inspection, le groupage et le transport. Chaque opération est précisée dans son offre.", ask: 'Une question sur ma demande', all: 'Voir toutes les questions et réponses' } : { badge: 'Frequently Asked Questions', title: 'Direct answers before you begin importing', description: 'General answers about sourcing, inspection, consolidation and shipping. Each transaction is confirmed in its own proposal.', ask: 'I have a question', all: 'View all questions and answers' };

  return (
    <section id="faq" style={{ padding: compact ? '62px 0' : '88px 0', background: 'var(--bg-card)' }}>
      <div className="container faq-layout">
        <div className="faq-intro">
          <div className="badge badge-red" style={{ marginBottom: '14px' }}>
            <CircleHelp size={16} />
            <span>{copy.badge}</span>
          </div>
          <h2 style={{ fontSize: 'clamp(2rem, 4vw, 2.75rem)', fontWeight: 900, lineHeight: 1.35, marginBottom: '16px' }}>
            {copy.title}
          </h2>
          {!compact && <>
            <p style={{ color: 'var(--text-muted)', lineHeight: 1.85, marginBottom: '24px' }}>
              {copy.description}
            </p>
            <button type="button" className="btn-primary" onClick={onOpenQuoteModal}>
              <MessageSquare size={18} />
              <span>{copy.ask}</span>
            </button>
          </>}
        </div>

        <div className="faq-list">
          {visibleItems.map((item, index) => {
            const isOpen = openIndex === index;
            const answerId = `faq-answer-${index}`;
            return (
              <article className={`faq-item${isOpen ? ' is-open' : ''}`} key={item.question}>
                <button
                  type="button"
                  className="faq-question"
                  aria-expanded={isOpen}
                  aria-controls={answerId}
                  onClick={() => setOpenIndex(isOpen ? -1 : index)}
                >
                  <span>{item.question}</span>
                  <ChevronDown size={21} aria-hidden="true" />
                </button>
                {isOpen && <p id={answerId} className="faq-answer">{item.answer}</p>}
              </article>
            );
          })}
          {visibleItems.length < localizedItems.length && onViewAll && (
            <button type="button" className="btn-outline" onClick={onViewAll} style={{ justifyContent: 'center', marginTop: '8px' }}>
              {copy.all}
            </button>
          )}
        </div>
      </div>
    </section>
  );
}
