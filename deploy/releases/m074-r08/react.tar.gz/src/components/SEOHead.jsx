import React, { useEffect } from 'react';
import { localizePath, parseLocalizedPath } from '../lib/navigation';

export default function SEOHead({
  title = "كوكب الصين – إدارة التوريد والخدمات اللوجستية من جوانزو 🇨🇳",
  description = "شركة كوكب الصين لحلول الاستيراد ومراقبة الجودة وتدقيق المصانع في مدينة جوانزو. خدمات التخليص الجمركي والشحن وفحص المنتجات.",
  keywords = "استيراد من الصين, فحص الجودة بالصين, معرض كانطون, جوانزو, مصانع الصين, شحن من الصين",
  image = "/images/hero.webp",
  url = "",
  type = "website",
  author = "فريق كوكب الصين",
  noIndex = false,
  locale = "ar",
}) {
  useEffect(() => {
    const configuredOrigin = String(import.meta.env.VITE_PUBLIC_SITE_URL || 'https://chinaplanet.org').replace(/\/$/, '');
    const currentPath = `${window.location.pathname || '/'}${window.location.search || ''}`;
    const canonicalUrl = url || `${configuredOrigin}${currentPath === '/' ? '' : currentPath}`;
    const absoluteImage = /^https?:\/\//i.test(image) ? image : `${configuredOrigin}${image.startsWith('/') ? image : `/${image}`}`;

    document.title = title;

    const setMeta = (nameAttr, attrValue, content) => {
      let element = document.querySelector(`meta[${nameAttr}="${attrValue}"]`);
      if (!element) {
        element = document.createElement('meta');
        element.setAttribute(nameAttr, attrValue);
        document.head.appendChild(element);
      }
      element.setAttribute('content', content);
    };

    setMeta('name', 'description', description);
    setMeta('name', 'keywords', keywords);
    setMeta('name', 'author', author);
    setMeta('name', 'robots', noIndex ? 'noindex,nofollow,noarchive' : 'index,follow,max-image-preview:large');

    setMeta('property', 'og:title', title);
    setMeta('property', 'og:description', description);
    setMeta('property', 'og:image', absoluteImage);
    setMeta('property', 'og:url', canonicalUrl);
    setMeta('property', 'og:type', type);
    setMeta('property', 'og:site_name', 'كوكب الصين China Planet');
    setMeta('property', 'og:locale', locale === 'ar' ? 'ar_AR' : locale === 'fr' ? 'fr_FR' : 'en_US');

    setMeta('name', 'twitter:card', 'summary_large_image');
    setMeta('name', 'twitter:title', title);
    setMeta('name', 'twitter:description', description);
    setMeta('name', 'twitter:image', absoluteImage);

    let canonicalElement = document.querySelector('link[rel="canonical"]');
    if (!canonicalElement) {
      canonicalElement = document.createElement('link');
      canonicalElement.setAttribute('rel', 'canonical');
      document.head.appendChild(canonicalElement);
    }
    canonicalElement.setAttribute('href', canonicalUrl);

    const route = parseLocalizedPath(window.location.pathname || '/').route;
    const alternateLocales = { ar: 'ar', en: 'en', fr: 'fr', 'x-default': 'ar' };
    Object.entries(alternateLocales).forEach(([hreflang, targetLocale]) => {
      let alternate = document.querySelector(`link[rel="alternate"][hreflang="${hreflang}"]`);
      if (!alternate) {
        alternate = document.createElement('link');
        alternate.rel = 'alternate';
        alternate.hreflang = hreflang;
        document.head.appendChild(alternate);
      }
      const alternatePath = localizePath(route, targetLocale);
      alternate.href = `${configuredOrigin}${alternatePath === '/' ? '' : alternatePath}`;
    });

    const schemaData = {
      "@context": "https://schema.org",
      "@graph": [
        {
          "@type": "Organization",
          "@id": `${configuredOrigin}/#organization`,
          "name": "كوكب الصين China Planet",
          "url": configuredOrigin,
          "logo": `${configuredOrigin}/brand/china-planet-primary.webp`,
          "email": "info@chinaplanet.org",
          "telephone": "+8613480652510",
        },
        {
          "@type": type === "article" ? "BlogPosting" : "WebPage",
          "headline": title,
          "name": title,
          "description": description,
          "image": absoluteImage,
          "url": canonicalUrl,
          "inLanguage": locale,
          "publisher": { "@id": `${configuredOrigin}/#organization` },
        },
      ],
    };

    let scriptElement = document.getElementById('json-ld-schema');
    if (!scriptElement) {
      scriptElement = document.createElement('script');
      scriptElement.id = 'json-ld-schema';
      scriptElement.type = 'application/ld+json';
      document.head.appendChild(scriptElement);
    }
    scriptElement.textContent = JSON.stringify(schemaData);
  }, [title, description, keywords, image, url, type, author, noIndex, locale]);

  return null;
}
