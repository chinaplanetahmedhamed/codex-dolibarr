import React from 'react';
import { ArrowRight, Sparkles } from 'lucide-react';
import { useI18n } from '../i18n/I18nContext';

export default function PageHero({ badge, title, description, onGoHome, children }) {
  const { t, isRtl } = useI18n();
  return (
    <section className="marketing-page-hero">
      <div className="container">
        <button type="button" onClick={onGoHome} className="marketing-page-back">
          <ArrowRight size={17} style={{ transform: isRtl ? 'none' : 'rotate(180deg)' }} />
          <span>{t('page.home')}</span>
        </button>
        <div className="marketing-page-hero-copy">
          <div className="badge badge-gold" style={{ marginBottom: '15px' }}>
            <Sparkles size={15} />
            <span>{badge}</span>
          </div>
          <h1>{title}</h1>
          <p>{description}</p>
          {children}
        </div>
      </div>
    </section>
  );
}
