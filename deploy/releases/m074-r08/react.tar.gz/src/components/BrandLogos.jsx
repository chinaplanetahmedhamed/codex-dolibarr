import React from 'react';

const CHINA_PLANET_LOGOS = {
  primary: '/brand/china-planet-primary.webp',
  black: '/brand/china-planet-black.webp',
  white: '/brand/china-planet-white.webp',
};

export function ChinaPlanetLogo({ variant = 'primary', className = '' }) {
  return (
    <img
      className={className}
      src={CHINA_PLANET_LOGOS[variant] || CHINA_PLANET_LOGOS.primary}
      alt="كوكب الصين China Planet"
      width="2230"
      height="722"
      decoding="async"
    />
  );
}

export function VisionTradingLogo({ className = '' }) {
  return (
    <img
      className={className}
      src="/brand/vision-trading.webp"
      alt="Vision Trading"
      width="3544"
      height="3544"
      loading="lazy"
      decoding="async"
    />
  );
}

export function CompanyBrandLockup({ surface = 'auto', compact = false }) {
  const fixedVariant = surface === 'dark' ? 'white' : 'primary';

  return (
    <div className={`company-brand-lockup${compact ? ' is-compact' : ''}`} aria-label="China Planet وVision Trading">
      <div className="company-brand-china">
        {surface === 'auto' ? (
          <>
            <ChinaPlanetLogo variant="primary" className="company-brand-china-logo company-brand-logo-light" />
            <ChinaPlanetLogo variant="white" className="company-brand-china-logo company-brand-logo-dark" />
          </>
        ) : (
          <ChinaPlanetLogo variant={fixedVariant} className="company-brand-china-logo" />
        )}
      </div>
      <span className="company-brand-separator" aria-hidden="true">×</span>
      <div className="company-brand-vision-frame">
        <VisionTradingLogo className="company-brand-vision-logo" />
      </div>
    </div>
  );
}
