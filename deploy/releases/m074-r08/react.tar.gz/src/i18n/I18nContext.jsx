/* oxlint-disable react/only-export-components -- The provider and its companion hooks share one public module. */
import React, { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';
import { navigateToLocale, readAppLocale, subscribeToNavigation } from '../lib/navigation';
import { messages } from './translations';

const I18nContext = createContext(null);

function interpolate(template, values) {
  return Object.entries(values || {}).reduce(
    (result, [key, value]) => result.replaceAll(`{${key}}`, String(value)),
    String(template),
  );
}

export function I18nProvider({ children }) {
  const [locale, setLocaleState] = useState(() => readAppLocale());

  useEffect(() => subscribeToNavigation(() => {
    setLocaleState(readAppLocale());
  }), []);

  useEffect(() => {
    const direction = locale === 'ar' ? 'rtl' : 'ltr';
    document.documentElement.lang = locale;
    document.documentElement.dir = direction;
    document.documentElement.dataset.locale = locale;
    try { localStorage.setItem('cp_locale', locale); } catch { /* Preference persistence is optional. */ }
  }, [locale]);

  const setLocale = useCallback((nextLocale) => {
    navigateToLocale(nextLocale);
    setLocaleState(readAppLocale());
  }, []);

  const t = useCallback((key, values = {}, fallback = key) => {
    const template = messages[locale]?.[key] ?? messages.ar[key] ?? fallback;
    return interpolate(template, values);
  }, [locale]);

  const value = useMemo(() => ({
    locale,
    direction: locale === 'ar' ? 'rtl' : 'ltr',
    isRtl: locale === 'ar',
    setLocale,
    t,
  }), [locale, setLocale, t]);

  return <I18nContext.Provider value={value}>{children}</I18nContext.Provider>;
}

export function useI18n() {
  const context = useContext(I18nContext);
  if (!context) throw new Error('useI18n must be used inside I18nProvider');
  return context;
}

export function localizedField(record, field, locale, fallback = '') {
  if (!record || typeof record !== 'object') return fallback;
  if (locale === 'ar') return record[field] || fallback;
  if (locale === 'en') return record[`${field}En`] || fallback || record[field] || '';
  if (locale === 'fr') return record[`${field}Fr`] || fallback || record[field] || '';
  return fallback || record[field] || '';
}
