const SERVICE_COPY = {
  en: {
    inspection: ['Quality Inspection and Product Testing', 'Inspect goods at Chinese factories before shipment against the approved scope and specifications, with documented findings in a visual report.'],
    'factory-audit': ['Factory Audit and Verification', 'On-site verification of the factory, business registration, production capacity and quality system to reduce supplier and intermediary risk.'],
    sourcing: ['Product and Supplier Sourcing', 'We identify suppliers for your specifications, collect and compare quotations, and negotiate commercial and technical terms in Chinese.'],
    warehouse: ['Guangzhou Warehouse and Consolidation', 'A Guangzhou receiving point for goods from multiple suppliers, with documentation, consolidation and shipment preparation according to instructions.'],
    shipping: ['International Freight Coordination', 'Coordination of sea and air freight, full or partial loads, export-document review and logistics follow-up.'],
    'payment-coordination': ['Supplier Payment Coordination', 'Coordination of approved supplier payment schedules with production, inspection and shipment milestones where agreed.'],
    'import-management': ['End-to-End Import Management', 'Connected management of sourcing, negotiation, samples, contracts, production, inspection, consolidation and shipping under a clear scope.'],
    'export-documents': ['Export Documents and CargoX Support', 'Coordination and review of export documents and CargoX procedures where required by the destination country.'],
  },
  fr: {
    inspection: ['Contrôle qualité et inspection des produits', "Contrôle des marchandises dans les usines chinoises avant expédition selon le périmètre et les spécifications approuvés, avec un rapport visuel."],
    'factory-audit': ["Audit et vérification d'usine", "Vérification sur site de l'usine, de son immatriculation, de sa capacité de production et de son système qualité afin de réduire les risques."],
    sourcing: ['Recherche de produits et de fournisseurs', 'Nous identifions les fournisseurs adaptés, comparons les offres et négocions en chinois les conditions commerciales et techniques.'],
    warehouse: ['Entrepôt de Guangzhou et groupage', 'Point de réception à Guangzhou pour documenter, regrouper et préparer les marchandises de plusieurs fournisseurs.'],
    shipping: ['Coordination du transport international', "Coordination du fret maritime et aérien, des chargements complets ou partiels, des documents d'exportation et du suivi logistique."],
    'payment-coordination': ['Coordination des paiements fournisseurs', 'Coordination du calendrier de paiement approuvé avec les étapes de production, de contrôle et de transport convenues.'],
    'import-management': ["Gestion complète de l'importation", "Gestion coordonnée de la recherche, la négociation, les échantillons, le contrat, la production, l'inspection, le groupage et le transport."],
    'export-documents': ["Documents d'exportation et assistance CargoX", "Coordination et vérification des documents d'exportation et des procédures CargoX lorsque le pays de destination l'exige."],
  },
};

export function localizeService(service, locale) {
  if (!service || locale === 'ar') return service;
  const translated = SERVICE_COPY[locale]?.[service.id];
  const customTitle = locale === 'en' ? service.titleEn : service.titleFr;
  const customDescription = locale === 'en' ? service.descriptionEn : service.descriptionFr;
  return {
    ...service,
    title: customTitle || translated?.[0] || service.title,
    description: customDescription || translated?.[1] || service.description,
    fullOverview: (locale === 'en' ? service.fullOverviewEn : service.fullOverviewFr) || service.fullOverview,
    pricingInfo: (locale === 'en' ? service.pricingInfoEn : service.pricingInfoFr) || service.pricingInfo,
  };
}
