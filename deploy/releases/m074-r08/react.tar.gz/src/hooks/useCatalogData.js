import { useEffect, useRef, useState } from "react";

import { fetchCatalog, fetchCatalogVersion } from "../lib/api";
import {
  catalogLoadDelay,
  catalogRefreshDecision,
  normalizeCatalogPayload,
} from "../lib/catalogLifecycle";

export function useCatalogData({ initialRoute, demoEnabled = false, demoProducts = [] }) {
  const [products, setProducts] = useState(() => demoEnabled ? demoProducts : []);
  const [categories, setCategories] = useState([]);
  const [status, setStatus] = useState("loading");
  const revisionRef = useRef(null);

  useEffect(() => {
    let active = true;
    let staleRefreshTimer;

    const loadCatalog = (staleAttempt = 0) => {
      fetchCatalog()
        .then((payload) => {
          if (!active) return;
          const catalog = normalizeCatalogPayload(payload);
          setProducts(catalog.products);
          setCategories(catalog.categories);
          revisionRef.current = catalog.revision;
          setStatus("ready");
          if (payload.stale && staleAttempt < 4) {
            staleRefreshTimer = window.setTimeout(
              () => loadCatalog(staleAttempt + 1),
              1_200 * (staleAttempt + 1),
            );
          }
        })
        .catch(() => {
          if (!active) return;
          if (staleAttempt === 0) setStatus(demoEnabled ? "demo" : "unavailable");
        });
    };

    const timer = window.setTimeout(loadCatalog, catalogLoadDelay(initialRoute));
    return () => {
      active = false;
      window.clearTimeout(timer);
      window.clearTimeout(staleRefreshTimer);
    };
  }, [demoEnabled, initialRoute]);

  useEffect(() => {
    let active = true;
    let refreshInFlight = false;

    const refreshWhenChanged = async () => {
      if (!active || refreshInFlight || document.visibilityState !== "visible") return;
      try {
        const version = await fetchCatalogVersion();
        if (!active) return;
        const decision = catalogRefreshDecision(revisionRef.current, version.revision);
        if (decision.action === "remember") {
          revisionRef.current = decision.revision;
          return;
        }
        if (decision.action !== "reload") return;

        refreshInFlight = true;
        const payload = await fetchCatalog();
        if (!active) return;
        const catalog = normalizeCatalogPayload(payload, decision.revision);
        setProducts(catalog.products);
        setCategories(catalog.categories);
        revisionRef.current = catalog.revision;
        setStatus("ready");
      } catch {
        // Keep the last known catalog and retry on the next lightweight check.
      } finally {
        refreshInFlight = false;
      }
    };

    const timer = window.setInterval(refreshWhenChanged, 15_000);
    window.addEventListener("focus", refreshWhenChanged);
    return () => {
      active = false;
      window.clearInterval(timer);
      window.removeEventListener("focus", refreshWhenChanged);
    };
  }, []);

  return { products, categories, status };
}
