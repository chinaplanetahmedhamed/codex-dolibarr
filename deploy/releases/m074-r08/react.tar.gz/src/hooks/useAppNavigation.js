import { useCallback, useEffect, useRef, useState } from "react";

import {
  activeNavigationTab,
  describeAppRoute,
  routeForNavigationTab,
} from "../lib/appRoute";
import {
  navigateTo,
  readAppRoute,
  subscribeToNavigation,
} from "../lib/navigation";

function readNavigationSnapshot() {
  const route = readAppRoute();
  return { route, ...describeAppRoute(route) };
}

export function useAppNavigation() {
  const initialSnapshotRef = useRef(null);
  if (!initialSnapshotRef.current) initialSnapshotRef.current = readNavigationSnapshot();

  const [routeState, setRouteState] = useState(initialSnapshotRef.current);

  useEffect(() => subscribeToNavigation(() => {
    setRouteState(readNavigationSnapshot());
  }), []);

  const navigate = useCallback((path) => {
    navigateTo(path);
  }, []);

  const navigateTab = useCallback((tabId) => {
    navigateTo(routeForNavigationTab(tabId));
  }, []);

  return {
    ...routeState,
    initialRoute: initialSnapshotRef.current.route,
    activeNavTab: activeNavigationTab(routeState),
    navigate,
    navigateTab,
  };
}
