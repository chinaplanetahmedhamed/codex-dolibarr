import { useCallback, useEffect, useRef, useState } from "react";

import {
  fetchAdminSession,
  fetchSiteContent,
  loginAdmin,
  logoutAdmin,
  saveSiteContent,
} from "../lib/api";
import {
  CONTENT_SAVE_SUCCESS_DURATION_MS,
  createSiteContentSavePayload,
  normalizePublishedSiteContent,
  shouldInvalidateAdminSession,
} from "../lib/siteContentLifecycle";

export function useSiteContentAdmin({ isAdminView, defaults }) {
  const [servicesData, setServicesData] = useState(defaults.servicesData);
  const [siteInfo, setSiteInfo] = useState(defaults.siteInfo);
  const [teamMembers, setTeamMembers] = useState(defaults.teamMembers);
  const [customSections, setCustomSections] = useState(defaults.customSections);
  const [heroInfo, setHeroInfo] = useState(defaults.heroInfo);
  const [sectorsInfo, setSectorsInfo] = useState(defaults.sectorsInfo);
  const [adminUser, setAdminUser] = useState(null);
  const [adminSessionStatus, setAdminSessionStatus] = useState("idle");
  const [contentSaveState, setContentSaveState] = useState("idle");
  const [contentLoadStatus, setContentLoadStatus] = useState("loading");
  const [lastSavedAt, setLastSavedAt] = useState(null);
  const saveSuccessTimerRef = useRef(null);

  useEffect(() => {
    let active = true;
    fetchSiteContent()
      .then((payload) => {
        if (!active || !payload.content) return;
        const content = normalizePublishedSiteContent(payload.content, defaults);
        setServicesData(content.servicesData);
        setSiteInfo(content.siteInfo);
        setTeamMembers(content.teamMembers);
        setCustomSections(content.customSections);
        setHeroInfo(content.heroInfo);
        setSectorsInfo(content.sectorsInfo);
        setLastSavedAt(payload.updatedAt || null);
      })
      .catch(() => {})
      .finally(() => {
        if (active) setContentLoadStatus("ready");
      });
    return () => {
      active = false;
    };
  }, [defaults]);

  useEffect(() => {
    if (!isAdminView) {
      setAdminSessionStatus("idle");
      return;
    }
    let active = true;
    setAdminSessionStatus("checking");
    fetchAdminSession()
      .then((payload) => {
        if (!active) return;
        setAdminUser(payload.user);
        setAdminSessionStatus("ready");
      })
      .catch(() => {
        if (!active) return;
        setAdminUser(null);
        setAdminSessionStatus("ready");
      });
    return () => {
      active = false;
    };
  }, [isAdminView]);

  useEffect(() => () => {
    window.clearTimeout(saveSuccessTimerRef.current);
  }, []);

  const handleAdminLogin = useCallback(async (email, password) => {
    const payload = await loginAdmin(email, password);
    setAdminUser(payload.user);
    setAdminSessionStatus("ready");
  }, []);

  const handleAdminLogout = useCallback(async () => {
    await logoutAdmin().catch(() => {});
    setAdminUser(null);
    setAdminSessionStatus("ready");
  }, []);

  const handleSaveSiteContent = useCallback(async () => {
    if (contentLoadStatus !== "ready") return;
    setContentSaveState("saving");
    try {
      const payload = await saveSiteContent(createSiteContentSavePayload({
        siteInfo,
        teamMembers,
        customSections,
        heroInfo,
        sectorsInfo,
        servicesData,
      }));
      setLastSavedAt(payload.updatedAt);
      setContentSaveState("saved");
      window.clearTimeout(saveSuccessTimerRef.current);
      saveSuccessTimerRef.current = window.setTimeout(
        () => setContentSaveState("idle"),
        CONTENT_SAVE_SUCCESS_DURATION_MS,
      );
    } catch (error) {
      if (shouldInvalidateAdminSession(error)) setAdminUser(null);
      setContentSaveState("error");
    }
  }, [
    contentLoadStatus,
    customSections,
    heroInfo,
    sectorsInfo,
    servicesData,
    siteInfo,
    teamMembers,
  ]);

  return {
    servicesData,
    setServicesData,
    siteInfo,
    setSiteInfo,
    teamMembers,
    setTeamMembers,
    customSections,
    setCustomSections,
    heroInfo,
    setHeroInfo,
    sectorsInfo,
    setSectorsInfo,
    adminUser,
    adminSessionStatus,
    contentSaveState,
    contentLoadStatus,
    lastSavedAt,
    handleAdminLogin,
    handleAdminLogout,
    handleSaveSiteContent,
  };
}
