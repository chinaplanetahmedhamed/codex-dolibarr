import { useCallback, useEffect, useRef, useState } from "react";

import {
  fetchChinaGuide,
  fetchWordPressContentVersion,
  fetchWordPressPosts,
} from "../lib/api";
import {
  CONTENT_REFRESH_INTERVAL_MS,
  contentRefreshDecision,
  guideLoadDelay,
  nextContentRevision,
  normalizeGuidePayload,
  normalizePostsPayload,
  postsLoadDelay,
  staleContentRetryDelay,
} from "../lib/wordpressContentLifecycle";

export function useWordPressContent({
  initialRoute,
  demoEnabled = false,
  demoPosts = [],
  defaultCategories = [],
}) {
  const [posts, setPosts] = useState(() => demoEnabled ? demoPosts : []);
  const [categories, setCategories] = useState(defaultCategories);
  const [postsStatus, setPostsStatus] = useState("loading");
  const [guidePlaces, setGuidePlaces] = useState([]);
  const [guideCities, setGuideCities] = useState([]);
  const [guideTypes, setGuideTypes] = useState([]);
  const [guideStatus, setGuideStatus] = useState("loading");
  const [guideRequestId, setGuideRequestId] = useState(0);
  const revisionRef = useRef(null);

  useEffect(() => {
    let active = true;
    let staleRefreshTimer;

    const loadPosts = (staleAttempt = 0) => {
      fetchWordPressPosts()
        .then((payload) => {
          if (!active) return;
          const content = normalizePostsPayload(payload);
          setPosts(content.posts);
          setCategories(content.categories);
          revisionRef.current = nextContentRevision(revisionRef.current, payload.revision);
          setPostsStatus("ready");
          const retryDelay = staleContentRetryDelay(payload.stale, staleAttempt);
          if (retryDelay !== null) {
            staleRefreshTimer = window.setTimeout(() => loadPosts(staleAttempt + 1), retryDelay);
          }
        })
        .catch(() => {
          if (active && staleAttempt === 0) setPostsStatus(demoEnabled ? "demo" : "error");
        });
    };

    const timer = window.setTimeout(loadPosts, postsLoadDelay(initialRoute));
    return () => {
      active = false;
      window.clearTimeout(timer);
      window.clearTimeout(staleRefreshTimer);
    };
  }, [demoEnabled, initialRoute]);

  useEffect(() => {
    let active = true;
    let staleRefreshTimer;
    setGuideStatus("loading");

    const loadGuide = (staleAttempt = 0) => {
      fetchChinaGuide()
        .then((payload) => {
          if (!active) return;
          const guide = normalizeGuidePayload(payload);
          setGuidePlaces(guide.places);
          setGuideCities(guide.cities);
          setGuideTypes(guide.types);
          revisionRef.current = nextContentRevision(revisionRef.current, payload.revision);
          setGuideStatus("ready");
          const retryDelay = staleContentRetryDelay(payload.stale, staleAttempt);
          if (retryDelay !== null) {
            staleRefreshTimer = window.setTimeout(() => loadGuide(staleAttempt + 1), retryDelay);
          }
        })
        .catch(() => {
          if (active && staleAttempt === 0) setGuideStatus("error");
        });
    };

    const timer = window.setTimeout(loadGuide, guideLoadDelay(initialRoute, guideRequestId));
    return () => {
      active = false;
      window.clearTimeout(timer);
      window.clearTimeout(staleRefreshTimer);
    };
  }, [guideRequestId, initialRoute]);

  useEffect(() => {
    let active = true;
    let refreshInFlight = false;

    const refreshWhenChanged = async () => {
      if (!active || refreshInFlight || document.visibilityState !== "visible") return;
      try {
        const version = await fetchWordPressContentVersion();
        const decision = contentRefreshDecision(revisionRef.current, version.revision);
        if (decision.action === "remember") {
          revisionRef.current = decision.revision;
          return;
        }
        if (decision.action !== "reload") return;

        refreshInFlight = true;
        const [postsPayload, guidePayload] = await Promise.all([
          fetchWordPressPosts(),
          fetchChinaGuide(),
        ]);
        if (!active) return;
        const postsContent = normalizePostsPayload(postsPayload);
        const guideContent = normalizeGuidePayload(guidePayload);
        setPosts(postsContent.posts);
        setCategories(postsContent.categories);
        setGuidePlaces(guideContent.places);
        setGuideCities(guideContent.cities);
        setGuideTypes(guideContent.types);
        revisionRef.current = decision.revision;
      } catch {
        // Keep the last published content and retry later.
      } finally {
        refreshInFlight = false;
      }
    };

    const timer = window.setInterval(refreshWhenChanged, CONTENT_REFRESH_INTERVAL_MS);
    window.addEventListener("focus", refreshWhenChanged);
    return () => {
      active = false;
      window.clearInterval(timer);
      window.removeEventListener("focus", refreshWhenChanged);
    };
  }, []);

  const retryGuide = useCallback(() => {
    setGuideRequestId((current) => current + 1);
  }, []);

  return {
    posts,
    categories,
    postsStatus,
    guidePlaces,
    guideCities,
    guideTypes,
    guideStatus,
    retryGuide,
  };
}
