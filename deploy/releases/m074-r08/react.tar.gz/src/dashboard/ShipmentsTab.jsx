import React, { useState } from 'react';
import { Truck, Plus, Edit2, CheckCircle2, Clock, MapPin, Search } from 'lucide-react';

export default function ShipmentsTab({ shipments, setShipments }) {
  const [selectedShipment, setSelectedShipment] = useState(shipments[0]);
  const [showAddModal, setShowAddModal] = useState(false);
  const [newShipment, setNewShipment] = useState({
    id: `CP-${Math.floor(100000 + Math.random() * 900000)}`,
    clientName: '',
    clientPhone: '',
    destination: 'مصر - القليوبية',
    type: 'شحنة تجميعية LCL',
    shippingMethod: 'باب للباب',
    weight: 250,
    cbm: 1.5,
    statusLabel: 'مستودع جوانزو - قيد الفحص والتجميع',
    progress: 25,
    guangzhouDate: new Date().toISOString().split('T')[0],
    estimatedDelivery: '2026-08-20',
    containerNo: 'CMAU-NEW1',
    history: [
      { step: 1, title: "تم الاستلام في مستودع جوانزو", date: new Date().toISOString().split('T')[0], location: "جوانزو، الصين", completed: true },
      { step: 2, title: "فحص الجودة والتطابق", date: "جاري العمل...", location: "جوانزو، الصين", completed: false }
    ]
  });

  const handleUpdateStatus = (shipmentId, newProgress, newLabel) => {
    const updated = shipments.map(s => {
      if (s.id === shipmentId) {
        return {
          ...s,
          progress: newProgress,
          statusLabel: newLabel,
          status: newProgress === 100 ? 'delivered' : 'in_progress'
        };
      }
      return s;
    });
    setShipments(updated);
    if (selectedShipment?.id === shipmentId) {
      setSelectedShipment({
        ...selectedShipment,
        progress: newProgress,
        statusLabel: newLabel
      });
    }
  };

  const handleAddShipment = (e) => {
    e.preventDefault();
    if (!newShipment.clientName) return;
    setShipments([newShipment, ...shipments]);
    setSelectedShipment(newShipment);
    setShowAddModal(false);
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '28px' }}>
      
      {/* Action Header Bar */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '16px' }}>
        <div>
          <h3 style={{ fontSize: '1.25rem', fontWeight: 800 }}>إدارة الشحنات واللوجستيات الدولية</h3>
          <p style={{ color: 'var(--text-muted)', fontSize: '0.9rem' }}>تحديث حالات التتبع المباشر وحاويات الشحن البحرية والجوية.</p>
        </div>

        <button onClick={() => setShowAddModal(true)} className="btn-primary">
          <Plus size={18} />
          <span>إضافة شحنة جديدة للنظام</span>
        </button>
      </div>

      {/* Grid: Shipment List + Selected Shipment Editor */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(320px, 1fr))', gap: '28px' }}>
        
        {/* Left: Shipments Selector List */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: '14px' }}>
          {shipments.map((s) => {
            const isSelected = selectedShipment?.id === s.id;
            return (
              <div 
                key={s.id}
                onClick={() => setSelectedShipment(s)}
                className="glass-card"
                style={{
                  padding: '20px',
                  borderRadius: 'var(--radius-md)',
                  cursor: 'pointer',
                  border: isSelected ? '2px solid var(--primary)' : '1px solid var(--border-color)',
                  background: isSelected ? 'var(--primary-light)' : 'var(--bg-card)'
                }}
              >
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '8px' }}>
                  <span style={{ fontWeight: 900, fontSize: '1.1rem', fontFamily: 'var(--font-en)' }}>{s.id}</span>
                  <span className="badge badge-red">{s.progress}% إنجاز</span>
                </div>
                
                <div style={{ fontSize: '0.92rem', fontWeight: 700, marginBottom: '4px' }}>{s.clientName}</div>
                <div style={{ fontSize: '0.82rem', color: 'var(--text-muted)', marginBottom: '8px' }}>{s.type} | {s.destination}</div>
                
                <div style={{ fontSize: '0.85rem', color: 'var(--primary)', fontWeight: 700 }}>
                  الحالة: {s.statusLabel}
                </div>
              </div>
            );
          })}
        </div>

        {/* Right: Selected Shipment Control Details Panel */}
        {selectedShipment && (
          <div className="glass-card" style={{ padding: '28px', borderRadius: 'var(--radius-md)' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '24px', borderBottom: '1px solid var(--border-color)', paddingBottom: '16px' }}>
              <div>
                <h3 style={{ fontSize: '1.3rem', fontWeight: 800, fontFamily: 'var(--font-en)' }}>{selectedShipment.id}</h3>
                <div style={{ fontSize: '0.85rem', color: 'var(--text-muted)' }}>{selectedShipment.clientName} ({selectedShipment.clientPhone})</div>
              </div>
              <span className="badge badge-gold">{selectedShipment.shippingMethod}</span>
            </div>

            {/* Quick Status Updater Controls */}
            <div style={{ marginBottom: '28px', background: 'var(--bg-main)', padding: '20px', borderRadius: 'var(--radius-md)', border: '1px solid var(--border-color)' }}>
              <label style={{ display: 'block', fontWeight: 800, marginBottom: '12px', fontSize: '0.95rem' }}>
                تحديث مرحلة التتبع الفورية:
              </label>

              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: '10px' }}>
                <button 
                  onClick={() => handleUpdateStatus(selectedShipment.id, 35, 'مستودع جوانزو - قيد الفحص والتجميع')}
                  className="btn-outline" 
                  style={{ fontSize: '0.82rem', padding: '8px' }}
                >
                  1️⃣ التجميع بمستودع جوانزو (35%)
                </button>

                <button 
                  onClick={() => handleUpdateStatus(selectedShipment.id, 55, 'تم التحميل وتجاوز الفحص الجمركي بالصين')}
                  className="btn-outline" 
                  style={{ fontSize: '0.82rem', padding: '8px' }}
                >
                  2️⃣ التحميل والحاويات (55%)
                </button>

                <button 
                  onClick={() => handleUpdateStatus(selectedShipment.id, 75, 'التخليص الجمركي بميناء الوصول')}
                  className="btn-outline" 
                  style={{ fontSize: '0.82rem', padding: '8px' }}
                >
                  3️⃣ التخليص الجمركي (75%)
                </button>

                <button 
                  onClick={() => handleUpdateStatus(selectedShipment.id, 100, 'تم التسليم بنجاح للعميل')}
                  className="btn-primary" 
                  style={{ fontSize: '0.82rem', padding: '8px' }}
                >
                  4️⃣ تم التسليم بالكامل (100%)
                </button>
              </div>
            </div>

            {/* Shipment Meta Table */}
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: '16px', fontSize: '0.88rem' }}>
              <div>
                <span style={{ color: 'var(--text-muted)' }}>رقم الحاوية/الرحلة:</span>
                <div style={{ fontWeight: 700, fontFamily: 'var(--font-en)' }}>{selectedShipment.containerNo}</div>
              </div>
              <div>
                <span style={{ color: 'var(--text-muted)' }}>الوزن الإجمالي:</span>
                <div style={{ fontWeight: 700, fontFamily: 'var(--font-en)' }}>{selectedShipment.weight} kg</div>
              </div>
              <div>
                <span style={{ color: 'var(--text-muted)' }}>الحجم CBM:</span>
                <div style={{ fontWeight: 700, fontFamily: 'var(--font-en)' }}>{selectedShipment.cbm} m³</div>
              </div>
              <div>
                <span style={{ color: 'var(--text-muted)' }}>تاريخ التسليم المتوقع:</span>
                <div style={{ fontWeight: 700, color: 'var(--primary)', fontFamily: 'var(--font-en)' }}>{selectedShipment.estimatedDelivery}</div>
              </div>
            </div>

          </div>
        )}

      </div>

      {/* Add New Shipment Modal */}
      {showAddModal && (
        <div style={{ position: 'fixed', inset: 0, zIndex: 2000, background: 'rgba(0,0,0,0.65)', backdropFilter: 'blur(6px)', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '20px' }}>
          <div className="glass-card animate-fade-in" style={{ maxWidth: '520px', width: '100%', padding: '28px', borderRadius: 'var(--radius-lg)' }}>
            <h3 style={{ fontSize: '1.3rem', fontWeight: 800, marginBottom: '20px' }}>تسجيل شحنة جديدة في جوانزو</h3>
            
            <form onSubmit={handleAddShipment} style={{ display: 'flex', flexDirection: 'column', gap: '14px' }}>
              <div>
                <label style={{ display: 'block', fontSize: '0.85rem', fontWeight: 700, marginBottom: '4px' }}>اسم العميل / المؤسسة</label>
                <input 
                  type="text" 
                  className="input-field" 
                  value={newShipment.clientName}
                  onChange={(e) => setNewShipment({ ...newShipment, clientName: e.target.value })}
                  required
                />
              </div>

              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: '12px' }}>
                <div>
                  <label style={{ display: 'block', fontSize: '0.85rem', fontWeight: 700, marginBottom: '4px' }}>الوزن (كجم)</label>
                  <input 
                    type="number" 
                    className="input-field" 
                    value={newShipment.weight}
                    onChange={(e) => setNewShipment({ ...newShipment, weight: Number(e.target.value) })}
                  />
                </div>
                <div>
                  <label style={{ display: 'block', fontSize: '0.85rem', fontWeight: 700, marginBottom: '4px' }}>الحجم (CBM)</label>
                  <input 
                    type="number" 
                    step="0.1"
                    className="input-field" 
                    value={newShipment.cbm}
                    onChange={(e) => setNewShipment({ ...newShipment, cbm: Number(e.target.value) })}
                  />
                </div>
              </div>

              <div style={{ display: 'flex', gap: '10px', marginTop: '12px' }}>
                <button type="submit" className="btn-primary" style={{ flex: 1, justifyContent: 'center' }}>حفظ وإصدار كود التتبع</button>
                <button type="button" onClick={() => setShowAddModal(false)} className="btn-outline">إلغاء</button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
}
