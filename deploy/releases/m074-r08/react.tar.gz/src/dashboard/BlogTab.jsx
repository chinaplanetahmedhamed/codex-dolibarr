import React, { useState } from 'react';
import { 
  Plus, 
  Edit3, 
  Trash2, 
  Globe, 
  Search, 
  Calendar, 
  Clock, 
  FolderPlus,
  Tag,
  Check,
  X
} from 'lucide-react';
import BlogPostEditor from './BlogPostEditor';

const DEFAULT_CAT_LIST = ['دليل كانطون', 'نصائح الاستيراد', 'الشحن والجمرك', 'أسواق جوانزو', 'دراسات حالة'];

export default function BlogTab({ 
  blogPosts = [], 
  setBlogPosts, 
  blogCategories = DEFAULT_CAT_LIST, 
  setBlogCategories 
}) {
  const categoriesList = Array.isArray(blogCategories) && blogCategories.length ? blogCategories : DEFAULT_CAT_LIST;

  const [editingPostId, setEditingPostId] = useState(null);
  const [isCreatingNew, setIsCreatingNew] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  
  // Categories Modal Manager
  const [showCategoryModal, setShowCategoryModal] = useState(false);
  const [newCatName, setNewCatName] = useState('');
  const [editingCatIndex, setEditingCatIndex] = useState(null);
  const [editCatName, setEditCatName] = useState('');

  const handleOpenAdd = () => {
    setIsCreatingNew(true);
    setEditingPostId(null);
  };

  const handleOpenEdit = (postId) => {
    setEditingPostId(postId);
    setIsCreatingNew(false);
  };

  const handleDeletePost = (postId) => {
    if (window.confirm('هل أنت تأكد من رغبتك في حذف هذا المقال من الداتابيز؟')) {
      const updated = blogPosts.filter(p => p.id !== postId);
      if (setBlogPosts) setBlogPosts(updated);
    }
  };

  const handleSavePost = (savedPost) => {
    if (isCreatingNew) {
      if (setBlogPosts) setBlogPosts([savedPost, ...blogPosts]);
    } else {
      const updated = blogPosts.map(p => p.id === savedPost.id ? { ...savedPost } : p);
      if (setBlogPosts) setBlogPosts(updated);
    }
    setEditingPostId(null);
    setIsCreatingNew(false);
  };

  // Category Actions
  const handleAddCategory = (e) => {
    e.preventDefault();
    if (newCatName.trim() && !categoriesList.includes(newCatName.trim())) {
      if (setBlogCategories) setBlogCategories([...categoriesList, newCatName.trim()]);
      setNewCatName('');
    }
  };

  const handleUpdateCategory = (index) => {
    if (editCatName.trim()) {
      const updated = [...categoriesList];
      const oldCat = updated[index];
      updated[index] = editCatName.trim();
      if (setBlogCategories) setBlogCategories(updated);

      // Update existing posts that used old category
      const updatedPosts = blogPosts.map(p => p.category === oldCat ? { ...p, category: editCatName.trim() } : p);
      if (setBlogPosts) setBlogPosts(updatedPosts);

      setEditingCatIndex(null);
      setEditCatName('');
    }
  };

  const handleDeleteCategory = (catName) => {
    if (categoriesList.length <= 1) {
      alert('يجب الإبقاء على قسم واحد على الأقل للمدونة');
      return;
    }
    if (window.confirm(`هل تريد حذف قسم "${catName}"؟`)) {
      if (setBlogCategories) setBlogCategories(categoriesList.filter(c => c !== catName));
    }
  };

  // If editing or creating, render BlogPostEditor full-page view!
  if (isCreatingNew || editingPostId) {
    const currentPost = blogPosts.find(p => p.id === editingPostId);
    return (
      <BlogPostEditor 
        post={currentPost}
        blogCategories={categoriesList}
        onSave={handleSavePost}
        onCancel={() => { setEditingPostId(null); setIsCreatingNew(false); }}
      />
    );
  }

  const filteredPosts = blogPosts.filter(p => 
    p.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
    (p.category && p.category.toLowerCase().includes(searchTerm.toLowerCase()))
  );

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '28px' }}>
      
      {/* Top Action Bar */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '16px' }}>
        <div>
          <h3 style={{ fontSize: '1.25rem', fontWeight: 800 }}>إدارة المقالات والتصنيفات (Blog & SEO Manager)</h3>
          <p style={{ color: 'var(--text-muted)', fontSize: '0.9rem' }}>أضف مقالات جديدة أو عدّل تصنيفات المدونة وأقسامها الحية.</p>
        </div>

        <div style={{ display: 'flex', gap: '12px' }}>
          <button onClick={() => setShowCategoryModal(true)} className="btn-secondary">
            <FolderPlus size={18} />
            <span>إدارة التصنيفات والـ Categories ({categoriesList.length})</span>
          </button>

          <button onClick={handleOpenAdd} className="btn-primary">
            <Plus size={18} />
            <span>كتابة مقال جديد وتفعيل الـ SEO</span>
          </button>
        </div>
      </div>

      {/* Search Filter */}
      <div style={{ display: 'flex', gap: '12px' }}>
        <div style={{ position: 'relative', flex: 1 }}>
          <Search size={18} style={{ position: 'absolute', right: '14px', top: '50%', transform: 'translateY(-50%)', color: 'var(--text-muted)' }} />
          <input 
            type="text" 
            className="input-field" 
            placeholder="البحث في مقالات المدونة..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            style={{ paddingRight: '40px' }}
          />
        </div>
      </div>

      {/* Categories Bar Preview */}
      <div style={{ display: 'flex', alignItems: 'center', gap: '8px', flexWrap: 'wrap', background: 'var(--bg-card)', padding: '12px 18px', borderRadius: 'var(--radius-md)', border: '1px solid var(--border-color)' }}>
        <Tag size={16} color="var(--primary)" />
        <span style={{ fontSize: '0.85rem', fontWeight: 800, color: 'var(--text-muted)' }}>التصنيفات الحية المعتمدة:</span>
        {categoriesList.map((cat) => (
          <span key={cat} className="badge badge-gold" style={{ fontSize: '0.8rem' }}>
            {cat}
          </span>
        ))}
      </div>

      {/* Posts Cards Grid */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(340px, 1fr))', gap: '24px' }}>
        {filteredPosts.map((post) => (
          <div key={post.id} className="glass-card" style={{ borderRadius: 'var(--radius-lg)', overflow: 'hidden', display: 'flex', flexDirection: 'column', justifyContent: 'space-between' }}>
            <div>
              <div style={{ height: '160px', overflow: 'hidden', position: 'relative' }}>
                <img src={post.image || '/images/hero.webp'} alt={post.title} style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
                <span className="badge badge-gold" style={{ position: 'absolute', top: '12px', right: '12px' }}>{post.category}</span>
              </div>

              <div style={{ padding: '20px' }}>
                <div style={{ display: 'flex', gap: '12px', fontSize: '0.78rem', color: 'var(--text-muted)', marginBottom: '8px' }}>
                  <span style={{ display: 'flex', alignItems: 'center', gap: '4px' }}><Calendar size={12} /> {post.date}</span>
                  <span style={{ display: 'flex', alignItems: 'center', gap: '4px' }}><Clock size={12} /> {post.readTime}</span>
                </div>

                <h4 style={{ fontSize: '1.1rem', fontWeight: 800, marginBottom: '8px', lineHeight: 1.4 }}>{post.title}</h4>
                <p style={{ fontSize: '0.88rem', color: 'var(--text-muted)', lineHeight: 1.5, marginBottom: '14px' }}>
                  {post.excerpt}
                </p>

                <div style={{ fontSize: '0.78rem', background: 'var(--bg-main)', padding: '8px 12px', borderRadius: 'var(--radius-sm)', border: '1px solid var(--border-color)', color: '#10B981', fontWeight: 700, display: 'flex', alignItems: 'center', gap: '6px' }}>
                  <Globe size={14} />
                  <span>SEO: مفعل ومطابق لمعايير Google</span>
                </div>
              </div>
            </div>

            <div style={{ display: 'flex', gap: '10px', padding: '16px 20px', borderTop: '1px solid var(--border-color)' }}>
              <button 
                onClick={() => handleOpenEdit(post.id)}
                className="btn-primary" 
                style={{ flex: 1, justifyContent: 'center', fontSize: '0.88rem' }}
              >
                <Edit3 size={16} />
                <span>تعديل المقال والـ SEO</span>
              </button>

              <button 
                onClick={() => handleDeletePost(post.id)}
                className="btn-outline" 
                style={{ padding: '8px 12px', color: '#D32F2F', borderColor: 'rgba(211, 47, 47, 0.3)' }}
                title="حذف المقال"
              >
                <Trash2 size={16} />
              </button>
            </div>

          </div>
        ))}
      </div>

      {/* Category Manager Modal */}
      {showCategoryModal && (
        <div style={{ position: 'fixed', inset: 0, zIndex: 9999, background: 'rgba(0, 0, 0, 0.75)', backdropFilter: 'blur(8px)', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '20px' }}>
          <div className="glass-card animate-fade-in" style={{ maxWidth: '560px', width: '100%', padding: '32px', borderRadius: 'var(--radius-lg)' }}>
            
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '24px', borderBottom: '1px solid var(--border-color)', paddingBottom: '14px' }}>
              <h3 style={{ fontSize: '1.25rem', fontWeight: 800, display: 'flex', alignItems: 'center', gap: '8px' }}>
                <FolderPlus size={20} color="var(--primary)" />
                إدارة تصنيفات وأقسام المدونة (Categories)
              </h3>
              <button onClick={() => setShowCategoryModal(false)} style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'var(--text-main)' }}>
                <X size={22} />
              </button>
            </div>

            {/* Form to Add Category */}
            <form onSubmit={handleAddCategory} style={{ display: 'flex', gap: '10px', marginBottom: '24px' }}>
              <input 
                type="text" 
                className="input-field" 
                placeholder="اسم تصنيف جديد (مثال: دراسات حالة / أسواق فوشان)"
                value={newCatName}
                onChange={(e) => setNewCatName(e.target.value)}
                required
              />
              <button type="submit" className="btn-primary" style={{ whiteSpace: 'nowrap' }}>
                <Plus size={16} /> إضافة قسم
              </button>
            </form>

            {/* List of Existing Categories */}
            <div style={{ display: 'flex', flexDirection: 'column', gap: '10px', maxHeight: '300px', overflowY: 'auto' }}>
              {categoriesList.map((cat, idx) => (
                <div key={idx} style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', background: 'var(--bg-main)', padding: '10px 14px', borderRadius: 'var(--radius-sm)', border: '1px solid var(--border-color)' }}>
                  
                  {editingCatIndex === idx ? (
                    <div style={{ display: 'flex', gap: '8px', width: '100%' }}>
                      <input 
                        type="text" 
                        className="input-field" 
                        value={editCatName}
                        onChange={(e) => setEditCatName(e.target.value)}
                        style={{ height: '36px', fontSize: '0.88rem' }}
                      />
                      <button type="button" onClick={() => handleUpdateCategory(idx)} className="btn-primary" style={{ padding: '0 12px' }}>
                        <Check size={14} />
                      </button>
                      <button type="button" onClick={() => setEditingCatIndex(null)} className="btn-outline" style={{ padding: '0 10px' }}>
                        <X size={14} />
                      </button>
                    </div>
                  ) : (
                    <>
                      <span style={{ fontWeight: 700, fontSize: '0.92rem' }}>• {cat}</span>
                      <div style={{ display: 'flex', gap: '6px' }}>
                        <button 
                          onClick={() => { setEditingCatIndex(idx); setEditCatName(cat); }}
                          className="btn-outline" 
                          style={{ padding: '4px 8px', fontSize: '0.78rem' }}
                        >
                          <Edit3 size={14} />
                        </button>
                        <button 
                          onClick={() => handleDeleteCategory(cat)}
                          className="btn-outline" 
                          style={{ padding: '4px 8px', fontSize: '0.78rem', color: '#D32F2F', borderColor: 'rgba(211,47,47,0.3)' }}
                        >
                          <Trash2 size={14} />
                        </button>
                      </div>
                    </>
                  )}

                </div>
              ))}
            </div>

            <div style={{ marginTop: '24px', textAlign: 'left' }}>
              <button onClick={() => setShowCategoryModal(false)} className="btn-primary" style={{ width: '100%', justifyContent: 'center' }}>
                تم - حفظ وإغلاق
              </button>
            </div>

          </div>
        </div>
      )}

    </div>
  );
}
