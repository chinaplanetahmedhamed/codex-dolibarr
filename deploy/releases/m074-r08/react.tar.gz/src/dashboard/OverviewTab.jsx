import React from 'react';
import { 
  Truck, 
  Warehouse, 
  ShieldCheck, 
  Search, 
  TrendingUp, 
  Clock, 
  CheckCircle2, 
  ArrowLeft,
  DollarSign
} from 'lucide-react';

export default function OverviewTab({ shipments, warehouseItems, sourcingRequests, onNavigate }) {
  const stats = [
    { title: 'إجمالي الشحنات النشطة', value: shipments.length, badge: 'حاوية وطرود', color: '#D32F2F', tab: 'shipments', icon: <Truck size={24} color="#D32F2F" /> },
    { title: 'طرود مستودع جوانزو', value: warehouseItems.length, badge: 'تخزين مجاني', color: '#F59E0B', tab: 'warehouse', icon: <Warehouse size={24} color="#F59E0B" /> },
    { title: 'طلبات البحث والاستيراد', value: sourcingRequests.length, badge: 'قيد الدراسة', color: '#2563EB', tab: 'sourcing', icon: <Search size={24} color="#2563EB" /> },
    { title: 'تقارير فحص الجودة', value: '14 تقرير', badge: 'نسبة القبول 98.2%', color: '#10B981', tab: 'inspections', icon: <ShieldCheck size={24} color="#10B981" /> },
  ];

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '32px' }}>
      
      {/* Stats Cards */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(240px, 1fr))', gap: '20px' }}>
        {stats.map((st, i) => (
          <div 
            key={i}
            className="glass-card"
            onClick={() => onNavigate(st.tab)}
            style={{
              padding: '24px',
              borderRadius: 'var(--radius-md)',
              cursor: 'pointer',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'space-between'
            }}
          >
            <div>
              <div style={{ fontSize: '0.88rem', color: 'var(--text-muted)', marginBottom: '4px' }}>{st.title}</div>
              <div style={{ fontSize: '2.2rem', fontWeight: 900, fontFamily: 'var(--font-en)', lineHeight: 1.1 }}>{st.value}</div>
              <span className="badge badge-gold" style={{ marginTop: '8px', fontSize: '0.75rem' }}>{st.badge}</span>
            </div>

            <div style={{ width: '52px', height: '52px', borderRadius: '14px', background: 'var(--bg-main)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              {st.icon}
            </div>
          </div>
        ))}
      </div>

      {/* Main Grid: Active Shipments + Guangzhou Warehouse Status */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(340px, 1fr))', gap: '28px' }}>
        
        {/* Active Shipments Card */}
        <div className="glass-card" style={{ padding: '24px', borderRadius: 'var(--radius-md)' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '20px' }}>
            <h3 style={{ fontSize: '1.1rem', fontWeight: 800 }}>حالة الشحنات الرئيسية</h3>
            <button onClick={() => onNavigate('shipments')} className="btn-outline" style={{ padding: '4px 12px', fontSize: '0.8rem' }}>
              عرض الكل
            </button>
          </div>

          <div style={{ display: 'flex', flexDirection: 'column', gap: '14px' }}>
            {shipments.slice(0, 3).map((ship) => (
              <div 
                key={ship.id}
                style={{
                  padding: '16px',
                  borderRadius: 'var(--radius-sm)',
                  background: 'var(--bg-main)',
                  border: '1px solid var(--border-color)',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'space-between'
                }}
              >
                <div>
                  <div style={{ fontWeight: 800, fontSize: '0.98rem', fontFamily: 'var(--font-en)' }}>{ship.id}</div>
                  <div style={{ fontSize: '0.82rem', color: 'var(--text-muted)' }}>{ship.clientName}</div>
                  <div style={{ fontSize: '0.8rem', color: 'var(--primary)', fontWeight: 600, marginTop: '4px' }}>
                    {ship.statusLabel}
                  </div>
                </div>

                <div style={{ textAlign: 'left' }}>
                  <span className="badge badge-blue">{ship.shippingMethod}</span>
                  <div style={{ fontSize: '0.8rem', color: 'var(--text-muted)', marginTop: '4px', fontFamily: 'var(--font-en)' }}>
                    {ship.progress}% إنجاز
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Guangzhou Warehouse Live Packages Log */}
        <div className="glass-card" style={{ padding: '24px', borderRadius: 'var(--radius-md)' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '20px' }}>
            <h3 style={{ fontSize: '1.1rem', fontWeight: 800 }}>أحدث الطرود بمستودع جوانزو</h3>
            <button onClick={() => onNavigate('warehouse')} className="btn-outline" style={{ padding: '4px 12px', fontSize: '0.8rem' }}>
              إدارة المستودع
            </button>
          </div>

          <div style={{ display: 'flex', flexDirection: 'column', gap: '14px' }}>
            {warehouseItems.map((item) => (
              <div 
                key={item.id}
                style={{
                  padding: '14px',
                  borderRadius: 'var(--radius-sm)',
                  background: 'var(--bg-main)',
                  border: '1px solid var(--border-color)',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'space-between'
                }}
              >
                <div>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                    <span style={{ fontWeight: 800, fontSize: '0.9rem', fontFamily: 'var(--font-en)' }}>{item.id}</span>
                    <span className="badge badge-green" style={{ fontSize: '0.72rem' }}>{item.status}</span>
                  </div>
                  <div style={{ fontSize: '0.82rem', color: 'var(--text-muted)', marginTop: '4px' }}>{item.itemDescription}</div>
                </div>

                <div style={{ textAlign: 'left', fontSize: '0.8rem', color: 'var(--text-muted)' }}>
                  <div style={{ fontWeight: 700, color: 'var(--text-main)', fontFamily: 'var(--font-en)' }}>{item.weightKg} kg / {item.cbm} CBM</div>
                  <div>ارفاق: {item.photosCount} صور</div>
                </div>
              </div>
            ))}
          </div>
        </div>

      </div>

    </div>
  );
}
