import React, { useState } from 'react';
import { Warehouse, Plus, Camera, CheckCircle2, Barcode, Package, FileText } from 'lucide-react';

export default function WarehouseTab({ warehouseItems, setWarehouseItems }) {
  const [showAddModal, setShowAddModal] = useState(false);
  const [newItem, setNewItem] = useState({
    id: `GZ-PKG-${Math.floor(1000 + Math.random() * 9000)}`,
    trackingId: 'CP-993012',
    clientCode: 'CP-CLT-881',
    clientName: 'شركة النصر للتجارة',
    supplier: 'Guangzhou Electronics Factory',
    itemDescription: 'شاشات لمس وحساسات حرارة صناعية',
    cartonsCount: 12,
    weightKg: 145,
    cbm: 0.95,
    receivedDate: new Date().toISOString().split('T')[0],
    status: 'تم الاستلام والفحص',
    photosCount: 6,
    shelfLocation: 'B-04-12'
  });

  const handleAddItem = (e) => {
    e.preventDefault();
    setWarehouseItems([newItem, ...warehouseItems]);
    setShowAddModal(false);
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '28px' }}>
      
      {/* Header */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '16px' }}>
        <div>
          <h3 style={{ fontSize: '1.25rem', fontWeight: 800 }}>إدارة مستودع جوانزو وتجمع الطرود</h3>
          <p style={{ color: 'var(--text-muted)', fontSize: '0.9rem' }}>تسجيل استلام الشحنات من المصانع، وزنها، وتحديد الرفوف والتجميع.</p>
        </div>

        <button onClick={() => setShowAddModal(true)} className="btn-primary">
          <Plus size={18} />
          <span>تسجيل طرد وارد جديد بالمستودع</span>
        </button>
      </div>

      {/* Warehouse Logistics Visual Grid */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(320px, 1fr))', gap: '24px' }}>
        {warehouseItems.map((item) => (
          <div key={item.id} className="glass-card" style={{ padding: '24px', borderRadius: 'var(--radius-md)' }}>
            
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '14px' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                <Barcode size={22} color="var(--primary)" />
                <span style={{ fontWeight: 900, fontSize: '1.1rem', fontFamily: 'var(--font-en)' }}>{item.id}</span>
              </div>
              <span className="badge badge-green">{item.status}</span>
            </div>

            <div style={{ fontSize: '0.95rem', fontWeight: 800, marginBottom: '6px' }}>
              {item.itemDescription}
            </div>

            <div style={{ fontSize: '0.82rem', color: 'var(--text-muted)', marginBottom: '16px' }}>
              العميل: <strong>{item.clientName}</strong> ({item.clientCode})<br />
              المورد الصيني: {item.supplier}
            </div>

            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '8px', background: 'var(--bg-main)', padding: '12px', borderRadius: 'var(--radius-sm)', fontSize: '0.8rem', textAlign: 'center', marginBottom: '16px' }}>
              <div>
                <span style={{ color: 'var(--text-muted)' }}>عدد الكراتين</span>
                <div style={{ fontWeight: 800, fontFamily: 'var(--font-en)' }}>{item.cartonsCount}</div>
              </div>
              <div>
                <span style={{ color: 'var(--text-muted)' }}>الوزن (كجم)</span>
                <div style={{ fontWeight: 800, fontFamily: 'var(--font-en)' }}>{item.weightKg}</div>
              </div>
              <div>
                <span style={{ color: 'var(--text-muted)' }}>الحجم CBM</span>
                <div style={{ fontWeight: 800, fontFamily: 'var(--font-en)' }}>{item.cbm}</div>
              </div>
            </div>

            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', fontSize: '0.82rem', color: 'var(--text-muted)' }}>
              <span>موقع الرف: <strong style={{ color: 'var(--primary)', fontFamily: 'var(--font-en)' }}>{item.shelfLocation}</strong></span>
              <span style={{ display: 'flex', alignItems: 'center', gap: '4px', color: '#10B981', fontWeight: 700 }}>
                <Camera size={14} /> {item.photosCount} صور مرفقة
              </span>
            </div>

          </div>
        ))}
      </div>

      {/* Add Package Modal */}
      {showAddModal && (
        <div style={{ position: 'fixed', inset: 0, zIndex: 2000, background: 'rgba(0,0,0,0.65)', backdropFilter: 'blur(6px)', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '20px' }}>
          <div className="glass-card animate-fade-in" style={{ maxWidth: '520px', width: '100%', padding: '28px', borderRadius: 'var(--radius-lg)' }}>
            <h3 style={{ fontSize: '1.3rem', fontWeight: 800, marginBottom: '20px' }}>تسجيل طرد وارد لمستودع جوانزو</h3>

            <form onSubmit={handleAddItem} style={{ display: 'flex', flexDirection: 'column', gap: '14px' }}>
              <div>
                <label style={{ display: 'block', fontSize: '0.85rem', fontWeight: 700, marginBottom: '4px' }}>وصف الشحنة / المنتجات</label>
                <input 
                  type="text" 
                  className="input-field" 
                  value={newItem.itemDescription}
                  onChange={(e) => setNewItem({ ...newItem, itemDescription: e.target.value })}
                  required
                />
              </div>

              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: '12px' }}>
                <div>
                  <label style={{ display: 'block', fontSize: '0.85rem', fontWeight: 700, marginBottom: '4px' }}>المورد الصيني</label>
                  <input 
                    type="text" 
                    className="input-field" 
                    value={newItem.supplier}
                    onChange={(e) => setNewItem({ ...newItem, supplier: e.target.value })}
                  />
                </div>
                <div>
                  <label style={{ display: 'block', fontSize: '0.85rem', fontWeight: 700, marginBottom: '4px' }}>رمز رف المستودع</label>
                  <input 
                    type="text" 
                    className="input-field" 
                    value={newItem.shelfLocation}
                    onChange={(e) => setNewItem({ ...newItem, shelfLocation: e.target.value })}
                  />
                </div>
              </div>

              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '12px' }}>
                <div>
                  <label style={{ display: 'block', fontSize: '0.85rem', fontWeight: 700, marginBottom: '4px' }}>عدد الكراتين</label>
                  <input 
                    type="number" 
                    className="input-field" 
                    value={newItem.cartonsCount}
                    onChange={(e) => setNewItem({ ...newItem, cartonsCount: Number(e.target.value) })}
                  />
                </div>
                <div>
                  <label style={{ display: 'block', fontSize: '0.85rem', fontWeight: 700, marginBottom: '4px' }}>الوزن (kg)</label>
                  <input 
                    type="number" 
                    className="input-field" 
                    value={newItem.weightKg}
                    onChange={(e) => setNewItem({ ...newItem, weightKg: Number(e.target.value) })}
                  />
                </div>
                <div>
                  <label style={{ display: 'block', fontSize: '0.85rem', fontWeight: 700, marginBottom: '4px' }}>الحجم (CBM)</label>
                  <input 
                    type="number" 
                    step="0.1"
                    className="input-field" 
                    value={newItem.cbm}
                    onChange={(e) => setNewItem({ ...newItem, cbm: Number(e.target.value) })}
                  />
                </div>
              </div>

              <div style={{ display: 'flex', gap: '10px', marginTop: '12px' }}>
                <button type="submit" className="btn-primary" style={{ flex: 1, justifyContent: 'center' }}>توليد الباركود وتأكيد الاستلام</button>
                <button type="button" onClick={() => setShowAddModal(false)} className="btn-outline">إلغاء</button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
}
