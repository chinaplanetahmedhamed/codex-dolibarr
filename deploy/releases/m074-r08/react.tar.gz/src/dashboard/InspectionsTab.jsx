import React, { useState } from 'react';
import { ShieldCheck, FileCheck, CheckCircle2, AlertTriangle, FileText, Camera, Building2 } from 'lucide-react';

export default function InspectionsTab() {
  const [reports, setReports] = useState([
    {
      id: "QC-2026-908",
      factoryName: "Guangzhou ShengDa Precision Machinery",
      location: "Foshan City, Guangdong",
      inspectorName: "David Zhang (مفتش معتمد)",
      inspectionDate: "2026-07-28",
      productName: "ماكينة تقطيع ليزر أليافي 4000W",
      samplesTested: 3,
      defectiveCount: 0,
      status: "PASSED",
      score: 98.5,
      notes: "اجتازت جميع اختبارات الجهد والقطع على الفولاذ 12 ملم بدون عيوب"
    },
    {
      id: "QC-2026-909",
      factoryName: "Ningbo Auto Parts Industries",
      location: "Ningbo, Zhejiang",
      inspectorName: "Li Ming (مفتش جودة)",
      inspectionDate: "2026-07-29",
      productName: "مساعدات ومحاور سيارات نقل ثقيل",
      samplesTested: 50,
      defectiveCount: 1,
      status: "PASSED WITH MINOR DEFECT",
      score: 94.0,
      notes: "تم التوجيه باستبدال قطعة واحدة بها خدش بالدهان وتم التعديل بالكامل"
    }
  ]);

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '28px' }}>
      
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '16px' }}>
        <div>
          <h3 style={{ fontSize: '1.25rem', fontWeight: 800 }}>تقارير فحص الجودة وتدقيق المصانع (Quality Control)</h3>
          <p style={{ color: 'var(--text-muted)', fontSize: '0.9rem' }}>متابعة نتائج التفتيش الميداني وإصدار شهادات التفتيش الفنية للعملاء.</p>
        </div>

        <button className="btn-primary" onClick={() => alert('ميزة إصدار تقرير فحص جديد بملفات PDF مصورة مفعّلة بالمستودع')}>
          <FileCheck size={18} />
          <span>إنشاء تقرير فحص جودة جديد</span>
        </button>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(320px, 1fr))', gap: '24px' }}>
        {reports.map((rep) => (
          <div key={rep.id} className="glass-card" style={{ padding: '24px', borderRadius: 'var(--radius-md)' }}>
            
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '14px' }}>
              <span style={{ fontWeight: 900, fontSize: '1.1rem', fontFamily: 'var(--font-en)' }}>{rep.id}</span>
              <span className="badge badge-green" style={{ fontSize: '0.8rem' }}>{rep.status}</span>
            </div>

            <h4 style={{ fontSize: '1.05rem', fontWeight: 800, marginBottom: '6px' }}>{rep.productName}</h4>
            
            <div style={{ fontSize: '0.85rem', color: 'var(--text-muted)', marginBottom: '16px' }}>
              المصنع: <strong>{rep.factoryName}</strong> ({rep.location})<br />
              المفتش الفني: {rep.inspectorName}
            </div>

            <div style={{ background: 'var(--bg-main)', padding: '14px', borderRadius: 'var(--radius-sm)', border: '1px solid var(--border-color)', marginBottom: '16px' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.88rem', fontWeight: 700, marginBottom: '6px' }}>
                <span>تقييم الجودة والتطابق:</span>
                <span style={{ color: '#10B981', fontFamily: 'var(--font-en)' }}>{rep.score}%</span>
              </div>
              <div style={{ fontSize: '0.82rem', color: 'var(--text-muted)' }}>
                العينات الخاضعة للفحص: {rep.samplesTested} قطعة | عيوب: {rep.defectiveCount}
              </div>
            </div>

            <p style={{ fontSize: '0.88rem', color: 'var(--text-main)', lineHeight: 1.5, marginBottom: '16px' }}>
              📝 <strong>ملاحظات التفتيش:</strong> {rep.notes}
            </p>

            <button 
              onClick={() => alert(`تقرير الفحص المكتمل برقم ${rep.id} جاهز للتصدير برابط PDF للعميل`)}
              className="btn-outline" 
              style={{ width: '100%', justifyContent: 'center', fontSize: '0.88rem' }}
            >
              <FileText size={16} />
              <span>تحميل التقرير الفني الشامل PDF</span>
            </button>

          </div>
        ))}
      </div>

    </div>
  );
}
