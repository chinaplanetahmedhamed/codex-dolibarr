import CustomSectionsView from "../components/CustomSectionsView";
import ImageUploaderInput from "../components/ImageUploaderInput";
import React, { useState } from "react";
import { 
  Globe, 
  Users, 
  Plus, 
  Edit3, 
  Trash2, 
  Sparkles, 
  Save, 
  Sliders,
  ArrowRight,
  ArrowUp,
  ArrowDown,
  CheckCircle2,
  Images,
  Package,
  Building,
  Factory
} from "lucide-react";

export default function SiteEditorTab({ 
  siteInfo, 
  setSiteInfo, 
  teamMembers, 
  setTeamMembers, 
  customSections, 
  setCustomSections,
  heroInfo,
  setHeroInfo,
  sectorsInfo,
  setSectorsInfo
}) {
  const [activeSubTab, setActiveSubTab] = useState("branding");
  const [savedSuccess, setSavedSuccess] = useState(false);

  const [newGalleryImgUrl, setNewGalleryImgUrl] = useState("");

  const [isEditingTeam, setIsEditingTeam] = useState(false);
  const [editingTeamIndex, setEditingTeamIndex] = useState(null);
  const [teamForm, setTeamForm] = useState({ name: "", nameEn: "", nameFr: "", role: "", roleEn: "", roleFr: "", experience: "", experienceEn: "", experienceFr: "", bio: "", bioEn: "", bioFr: "", image: "/images/hero.webp" });

  const [isEditingSection, setIsEditingSection] = useState(false);
  const [editingSectionIndex, setEditingSectionIndex] = useState(null);
  const [sectionForm, setSectionForm] = useState({ 
    id: "", 
    title: "", 
    badge: "", 
    content: "", 
    image: "/images/warehouse.webp",
    buttonText: "تواصل معنا الآن",
    buttonLink: "https://wa.me/8613480652510",
    template: "img-left",
    themeStyle: "default",
    position: "top"
  });

  const triggerSaveNotification = () => {
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 2500);
  };

  const heroGalleryList = (heroInfo?.gallery && Array.isArray(heroInfo.gallery))
    ? heroInfo.gallery
    : ["/images/hero.webp", "/images/warehouse.webp", "/images/inspection.webp"];

  const handleAddGalleryImage = () => {
    if (!newGalleryImgUrl.trim()) return;
    const updated = [...heroGalleryList, newGalleryImgUrl.trim()];
    setHeroInfo({ ...heroInfo, gallery: updated });
    setNewGalleryImgUrl("");
    triggerSaveNotification();
  };

  const handleDeleteGalleryImage = (idx) => {
    if (heroGalleryList.length <= 1) {
      alert("يجب الإبقاء على صورة واحدة على الأقل في الكاروسيل!");
      return;
    }
    const updated = heroGalleryList.filter((_, i) => i !== idx);
    setHeroInfo({ ...heroInfo, gallery: updated });
    triggerSaveNotification();
  };

  const handleOpenAddTeam = () => {
    setEditingTeamIndex(null);
    setTeamForm({ name: "", nameEn: "", nameFr: "", role: "مستشار تجاري", roleEn: "", roleFr: "", experience: "10+ سنوات خبرة", experienceEn: "", experienceFr: "", bio: "", bioEn: "", bioFr: "", image: "/images/hero.webp" });
    setIsEditingTeam(true);
  };

  const handleOpenEditTeam = (idx) => {
    setEditingTeamIndex(idx);
    setTeamForm({ ...teamMembers[idx] });
    setIsEditingTeam(true);
  };

  const handleSaveTeamMember = (e) => {
    e.preventDefault();
    if (!teamForm.name.trim()) return;
    if (editingTeamIndex !== null) {
      const updated = [...teamMembers];
      updated[editingTeamIndex] = { ...teamForm };
      setTeamMembers(updated);
    } else {
      setTeamMembers([...teamMembers, { ...teamForm, id: "team-" + Date.now() }]);
    }
    setIsEditingTeam(false);
    triggerSaveNotification();
  };

  const handleDeleteTeamMember = (idx) => {
    if (window.confirm("هل أنت متاكد من حذف هذا العضو من الفريق؟")) {
      const updated = teamMembers.filter((_, i) => i !== idx);
      setTeamMembers(updated);
    }
  };

  const handleOpenAddSection = () => {
    setEditingSectionIndex(null);
    setSectionForm({
      id: "sec-" + Date.now(),
      title: "عنوان السيكشن المخصص الجديد",
      badge: "خدمة مخصصة 🇨🇳",
      content: "وصف تفصيلي يشرح الخدمة أو المميزات التي يوفرها مكتب جوانزو للعملاء المستوردين...",
      image: "/images/warehouse.webp",
      buttonText: "تواصل معنا عبر الواتساب",
      buttonLink: "https://wa.me/8613480652510",
      template: "img-left",
      themeStyle: "default",
      position: "top"
    });
    setIsEditingSection(true);
  };

  const handleOpenEditSection = (idx) => {
    setEditingSectionIndex(idx);
    setSectionForm({ ...customSections[idx] });
    setIsEditingSection(true);
  };

  const handleSaveSection = (e) => {
    e.preventDefault();
    if (!sectionForm.title.trim()) return;

    if (editingSectionIndex !== null) {
      const updated = [...customSections];
      updated[editingSectionIndex] = { ...sectionForm };
      setCustomSections(updated);
    } else {
      setCustomSections([...customSections, { ...sectionForm }]);
    }

    setIsEditingSection(false);
    triggerSaveNotification();
  };

  const handleDeleteSection = (idx) => {
    if (window.confirm("هل تريد حذف هذا السيكشن من الصفحة الرئيسية؟")) {
      const updated = customSections.filter((_, i) => i !== idx);
      setCustomSections(updated);
    }
  };

  const handleMoveSectionUp = (idx) => {
    if (idx <= 0) return;
    const updated = [...customSections];
    const temp = updated[idx];
    updated[idx] = updated[idx - 1];
    updated[idx - 1] = temp;
    setCustomSections(updated);
    triggerSaveNotification();
  };

  const handleMoveSectionDown = (idx) => {
    if (idx >= customSections.length - 1) return;
    const updated = [...customSections];
    const temp = updated[idx];
    updated[idx] = updated[idx + 1];
    updated[idx + 1] = temp;
    setCustomSections(updated);
    triggerSaveNotification();
  };

  const handleSaveSiteInfoField = (updates) => {
    const updated = { ...siteInfo, ...updates };
    setSiteInfo(updated);
    triggerSaveNotification();
  };

  const presetBannerImages = [
    "/images/hero.webp",
    "/images/warehouse.webp",
    "/images/inspection.webp",
    "https://images.unsplash.com/photo-1586528116311-ad8dd3c8310d?auto=format&fit=crop&w=1200&q=80",
    "https://images.unsplash.com/photo-1578575437130-527eed3abbec?auto=format&fit=crop&w=1200&q=80"
  ];

  if (isEditingTeam) {
    return (
      <div style={{ display: "flex", flexDirection: "column", gap: "28px" }} className="animate-fade-in">
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", background: "var(--bg-card)", padding: "20px 28px", borderRadius: "var(--radius-lg)", border: "1px solid var(--border-color)" }}>
          <div style={{ display: "flex", alignItems: "center", gap: "16px" }}>
            <button type="button" onClick={() => setIsEditingTeam(false)} className="btn-outline">
              <ArrowRight size={18} />
              <span>العودة لإعدادات الموقع</span>
            </button>
            <div>
              <h3 style={{ fontSize: "1.3rem", fontWeight: 800 }}>
                {editingTeamIndex !== null ? "تعديل بيانات العضو: " + teamForm.name : "إضافة عضو جديد لفريق العمل"}
              </h3>
              <p style={{ fontSize: "0.82rem", color: "var(--text-muted)" }}>صفحة تعديل العضو المستقلة بالكامل</p>
            </div>
          </div>

          <button onClick={handleSaveTeamMember} className="btn-primary" style={{ padding: "10px 24px" }}>
            <Save size={18} />
            <span>حفظ بيانات العضو</span>
          </button>
        </div>

        <form onSubmit={handleSaveTeamMember} className="glass-card" style={{ padding: "32px", borderRadius: "var(--radius-lg)", display: "flex", flexDirection: "column", gap: "20px" }}>
          <div>
            <label style={{ display: "block", fontSize: "0.88rem", fontWeight: 700, marginBottom: "6px" }}>الاسم بالكامل *</label>
            <input type="text" className="input-field" value={teamForm.name} onChange={(e) => setTeamForm({ ...teamForm, name: e.target.value })} required />
          </div>

          <div style={{ display: "grid", gridTemplateColumns: "repeat(2, 1fr)", gap: "16px" }}>
            <div><label style={{ display: "block", fontSize: "0.88rem", fontWeight: 700, marginBottom: "6px" }}>الاسم بالإنجليزية</label><input type="text" className="input-field" dir="ltr" value={teamForm.nameEn || ""} onChange={(e) => setTeamForm({ ...teamForm, nameEn: e.target.value })} /></div>
            <div><label style={{ display: "block", fontSize: "0.88rem", fontWeight: 700, marginBottom: "6px" }}>الاسم بالفرنسية</label><input type="text" className="input-field" dir="ltr" value={teamForm.nameFr || ""} onChange={(e) => setTeamForm({ ...teamForm, nameFr: e.target.value })} /></div>
          </div>

          <div style={{ display: "grid", gridTemplateColumns: "repeat(2, 1fr)", gap: "16px" }}>
            <div>
              <label style={{ display: "block", fontSize: "0.88rem", fontWeight: 700, marginBottom: "6px" }}>المسمى الوظيفي</label>
              <input type="text" className="input-field" value={teamForm.role} onChange={(e) => setTeamForm({ ...teamForm, role: e.target.value })} />
            </div>
            <div>
              <label style={{ display: "block", fontSize: "0.88rem", fontWeight: 700, marginBottom: "6px" }}>خبرة العضو</label>
              <input type="text" className="input-field" value={teamForm.experience} onChange={(e) => setTeamForm({ ...teamForm, experience: e.target.value })} />
            </div>
          </div>

          <div>
            <ImageUploaderInput 
              label="🖼️ الصورة الشخصية لعضو الفريق (رابط أو رفع ملف من جهازك)"
              value={teamForm.image}
              onChange={(val) => setTeamForm({ ...teamForm, image: val })}
            />
          </div>

          <div>
            <label style={{ display: "block", fontSize: "0.88rem", fontWeight: 700, marginBottom: "6px" }}>السيرة والوصف المختصر</label>
            <textarea className="input-field" rows={4} value={teamForm.bio} onChange={(e) => setTeamForm({ ...teamForm, bio: e.target.value })} />
          </div>

          <div style={{ display: "grid", gridTemplateColumns: "repeat(2, 1fr)", gap: "16px" }}>
            <div><label style={{ display: "block", fontSize: "0.88rem", fontWeight: 700, marginBottom: "6px" }}>الوظيفة والسيرة بالإنجليزية</label><input type="text" className="input-field" dir="ltr" placeholder="Role" value={teamForm.roleEn || ""} onChange={(e) => setTeamForm({ ...teamForm, roleEn: e.target.value })} /><textarea className="input-field" dir="ltr" rows={4} value={teamForm.bioEn || ""} onChange={(e) => setTeamForm({ ...teamForm, bioEn: e.target.value })} style={{ marginTop: "8px" }} /></div>
            <div><label style={{ display: "block", fontSize: "0.88rem", fontWeight: 700, marginBottom: "6px" }}>الوظيفة والسيرة بالفرنسية</label><input type="text" className="input-field" dir="ltr" placeholder="Fonction" value={teamForm.roleFr || ""} onChange={(e) => setTeamForm({ ...teamForm, roleFr: e.target.value })} /><textarea className="input-field" dir="ltr" rows={4} value={teamForm.bioFr || ""} onChange={(e) => setTeamForm({ ...teamForm, bioFr: e.target.value })} style={{ marginTop: "8px" }} /></div>
          </div>

          <div style={{ display: "flex", gap: "12px", marginTop: "12px" }}>
            <button type="submit" className="btn-primary" style={{ padding: "10px 24px" }}>تحديث المسودة</button>
            <button type="button" onClick={() => setIsEditingTeam(false)} className="btn-outline">إلغاء</button>
          </div>
        </form>
      </div>
    );
  }

  if (isEditingSection) {
    return (
      <div style={{ display: "flex", flexDirection: "column", gap: "28px" }} className="animate-fade-in">
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", background: "var(--bg-card)", padding: "20px 28px", borderRadius: "var(--radius-lg)", border: "1px solid var(--border-color)" }}>
          <div style={{ display: "flex", alignItems: "center", gap: "16px" }}>
            <button type="button" onClick={() => setIsEditingSection(false)} className="btn-outline">
              <ArrowRight size={18} />
              <span>العودة لإدارة السيكشنات</span>
            </button>
            <div>
              <h3 style={{ fontSize: "1.3rem", fontWeight: 800 }}>
                {editingSectionIndex !== null ? "تعديل السيكشن: " + sectionForm.title : "إضافة سيكشن مخصص جديد بالصفحة الرئيسية"}
              </h3>
              <p style={{ fontSize: "0.82rem", color: "var(--text-muted)" }}>تصميم مخصص بالكامل بدون أي قوالب جامدة</p>
            </div>
          </div>

          <button onClick={handleSaveSection} className="btn-primary" style={{ padding: "10px 24px" }}>
            <Save size={18} />
            <span>حفظ السيكشن</span>
          </button>
        </div>

        <form onSubmit={handleSaveSection} className="glass-card" style={{ padding: "32px", borderRadius: "var(--radius-lg)", display: "flex", flexDirection: "column", gap: "20px" }}>
          
          <div style={{ display: "grid", gridTemplateColumns: "repeat(2, 1fr)", gap: "16px" }}>
            <div>
              <label style={{ display: "block", fontSize: "0.88rem", fontWeight: 800, marginBottom: "6px" }}>تخطيط وقالب السيكشن (Template Layout)</label>
              <select
                className="input-field"
                value={sectionForm.template || "img-left"}
                onChange={(e) => setSectionForm({ ...sectionForm, template: e.target.value })}
              >
                <option value="img-left">🖼️ صورة على الشمال وكلام على اليمين</option>
                <option value="img-right">🖼️ صورة على اليمين وكلام على الشمال</option>
                <option value="centered">🎯 كارت عريض متمركز في المنتصف</option>
                <option value="glow-banner">⚡ بانر عريض متلألئ</option>
              </select>
            </div>

            <div>
              <label style={{ display: "block", fontSize: "0.88rem", fontWeight: 800, marginBottom: "6px" }}>ثيم ولون الخلفية (Background Style Theme)</label>
              <select
                className="input-field"
                value={sectionForm.themeStyle || "default"}
                onChange={(e) => setSectionForm({ ...sectionForm, themeStyle: e.target.value })}
              >
                <option value="default">⚪ خلفية ناعمة افتراضية</option>
                <option value="dark">🌙 كحلي ورصاصي داكن احترافي</option>
                <option value="red-gradient">🔴 تدرج أحمر قرمزي فاخر</option>
                <option value="glass">🧊 خلفية زجاجية متفاعلة</option>
              </select>
            </div>
          </div>

          <div>
            <label style={{ display: "block", fontSize: "0.88rem", fontWeight: 700, marginBottom: "6px" }}>عنوان السيكشن الرئيسي *</label>
            <input type="text" className="input-field" value={sectionForm.title} onChange={(e) => setSectionForm({ ...sectionForm, title: e.target.value })} required />
          </div>

          <div style={{ display: "grid", gridTemplateColumns: "repeat(2, 1fr)", gap: "16px" }}>
            <div>
              <label style={{ display: "block", fontSize: "0.88rem", fontWeight: 700, marginBottom: "6px" }}>شارة السيكشن (Badge)</label>
              <input type="text" className="input-field" value={sectionForm.badge} onChange={(e) => setSectionForm({ ...sectionForm, badge: e.target.value })} />
            </div>
            <div>
              <ImageUploaderInput 
                label="🖼️ صورة السيكشن (رابط أو رفع ملف من جهازك)"
                value={sectionForm.image}
                onChange={(val) => setSectionForm({ ...sectionForm, image: val })}
              />
            </div>
          </div>

          <div>
            <label style={{ display: "block", fontSize: "0.88rem", fontWeight: 700, marginBottom: "6px" }}>المحتوى والشرح التفصيلي</label>
            <textarea className="input-field" rows={5} value={sectionForm.content} onChange={(e) => setSectionForm({ ...sectionForm, content: e.target.value })} />
          </div>

          <div style={{ display: "grid", gridTemplateColumns: "repeat(2, 1fr)", gap: "16px" }}>
            <div>
              <label style={{ display: "block", fontSize: "0.88rem", fontWeight: 700, marginBottom: "6px" }}>نص الزر التفاعلي</label>
              <input type="text" className="input-field" value={sectionForm.buttonText} onChange={(e) => setSectionForm({ ...sectionForm, buttonText: e.target.value })} />
            </div>
            <div>
              <label style={{ display: "block", fontSize: "0.88rem", fontWeight: 700, marginBottom: "6px" }}>رابط الزر (URL / WhatsApp)</label>
              <input type="text" className="input-field" value={sectionForm.buttonLink} onChange={(e) => setSectionForm({ ...sectionForm, buttonLink: e.target.value })} />
            </div>
          </div>

          <div style={{ display: "flex", gap: "12px", marginTop: "12px" }}>
            <button type="submit" className="btn-primary" style={{ padding: "10px 24px" }}>حفظ السيكشن</button>
            <button type="button" onClick={() => setIsEditingSection(false)} className="btn-outline">إلغاء</button>
          </div>
        </form>

        {/* LIVE SECTION FINAL PREVIEW BEFORE SAVING */}
        <div style={{ borderTop: "2px dashed var(--border-color)", paddingTop: "28px", marginTop: "16px" }}>
          <div style={{ display: "flex", alignItems: "center", gap: "8px", marginBottom: "16px" }}>
            <Sparkles size={20} color="var(--primary)" />
            <h4 style={{ fontSize: "1.2rem", fontWeight: 800 }}>المعاينة الحية والمباشرة للشكل النهائي للسيكشن (Live Final Preview):</h4>
          </div>
          <div style={{ border: "2px solid var(--primary)", borderRadius: "var(--radius-lg)", overflow: "hidden", boxShadow: "var(--shadow-md)" }}>
            <CustomSectionsView customSections={[sectionForm]} onOpenQuoteModal={() => {}} />
          </div>
        </div>
      </div>
    );
  }

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: "28px" }} className="animate-fade-in">
      
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", flexWrap: "wrap", gap: "16px", borderBottom: "1px solid var(--border-color)", paddingBottom: "16px" }}>
        <div>
          <h3 style={{ fontSize: "1.3rem", fontWeight: 800 }}>تعديل الموقع الشامل وترتيب السيكشنات (CMS Customizer)</h3>
          <p style={{ color: "var(--text-muted)", fontSize: "0.88rem" }}>التحكم الكامل بالنصوص، دليل القطاعات، الفيديو، البانرات، وترتيب السيكشنات</p>
        </div>

        {savedSuccess && (
          <div style={{ background: "rgba(16, 185, 129, 0.15)", color: "#059669", border: "1px solid #10B981", padding: "8px 16px", borderRadius: "9999px", fontSize: "0.86rem", fontWeight: 800, display: "flex", alignItems: "center", gap: "6px" }}>
            <CheckCircle2 size={16} />
            <span>تم تحديث المسودة. اضغط «حفظ ونشر التعديلات» لتظهر في الموقع.</span>
          </div>
        )}
      </div>

      <div style={{ display: "flex", gap: "10px", flexWrap: "wrap", borderBottom: "1px solid var(--border-color)", paddingBottom: "14px" }}>
        <button onClick={() => setActiveSubTab("branding")} className={activeSubTab === "branding" ? "btn-primary" : "btn-outline"} style={{ padding: "8px 18px", fontSize: "0.88rem" }}>
          <Globe size={16} />
          <span>تغيير الشعار والهوية</span>
        </button>

        <button onClick={() => setActiveSubTab("contact")} className={activeSubTab === "contact" ? "btn-primary" : "btn-outline"} style={{ padding: "8px 18px", fontSize: "0.88rem" }}>
          <Building size={16} />
          <span>عناوين مكاتب الصين ومصر وأرقام التواصل</span>
        </button>

        <button onClick={() => setActiveSubTab("sectors-editor")} className={activeSubTab === "sectors-editor" ? "btn-primary" : "btn-outline"} style={{ padding: "8px 18px", fontSize: "0.88rem" }}>
          <Factory size={16} />
          <span>تعديل دليل القطاعات والمصانع 🏭</span>
        </button>

        <button onClick={() => setActiveSubTab("catalog-page")} className={activeSubTab === "catalog-page" ? "btn-primary" : "btn-outline"} style={{ padding: "8px 18px", fontSize: "0.88rem" }}>
          <Package size={16} />
          <span>تعديل بانر وخلفية صفحة المنتجات</span>
        </button>

        <button onClick={() => setActiveSubTab("custom-sections")} className={activeSubTab === "custom-sections" ? "btn-primary" : "btn-outline"} style={{ padding: "8px 18px", fontSize: "0.88rem" }}>
          <Sliders size={16} />
          <span>ترتيب وإضافة سيكشنات جديدة ({customSections ? customSections.length : 0})</span>
        </button>

        <button onClick={() => setActiveSubTab("team")} className={activeSubTab === "team" ? "btn-primary" : "btn-outline"} style={{ padding: "8px 18px", fontSize: "0.88rem" }}>
          <Users size={16} />
          <span>إدارة وإضافة فريق العمل ({teamMembers ? teamMembers.length : 0})</span>
        </button>

        <button onClick={() => setActiveSubTab("hero")} className={activeSubTab === "hero" ? "btn-primary" : "btn-outline"} style={{ padding: "8px 18px", fontSize: "0.88rem" }}>
          <Images size={16} />
          <span>معرض صور وفيديو الهيرو</span>
        </button>
      </div>

      {activeSubTab === "branding" && (
        <div className="glass-card" style={{ padding: "32px", borderRadius: "var(--radius-lg)", display: "flex", flexDirection: "column", gap: "20px" }}>
          <h4 style={{ fontSize: "1.2rem", fontWeight: 800, marginBottom: "8px", display: "flex", alignItems: "center", gap: "8px" }}>
            <Globe size={20} color="var(--primary)" />
            اسم الموقع والشعار والبادج الرئيسي
          </h4>

          <div style={{ display: "grid", gridTemplateColumns: "repeat(2, 1fr)", gap: "20px" }}>
            <div>
              <label style={{ display: "block", fontSize: "0.88rem", fontWeight: 700, marginBottom: "6px" }}>اسم الموقع بالعربية</label>
              <input type="text" className="input-field" value={siteInfo?.siteNameAr || "كوكب الصين"} onChange={(e) => handleSaveSiteInfoField({ siteNameAr: e.target.value })} />
            </div>

            <div>
              <label style={{ display: "block", fontSize: "0.88rem", fontWeight: 700, marginBottom: "6px" }}>اسم الموقع بالإنجليزية</label>
              <input type="text" className="input-field" value={siteInfo?.siteNameEn || "China Planet"} onChange={(e) => handleSaveSiteInfoField({ siteNameEn: e.target.value })} />
            </div>
          </div>

          <div style={{ display: "grid", gridTemplateColumns: "repeat(2, 1fr)", gap: "20px" }}>
            <div>
              <label style={{ display: "block", fontSize: "0.88rem", fontWeight: 700, marginBottom: "6px" }}>نص البادج الذهبي بشريط الإعلانات (Prefix Badge)</label>
              <input type="text" className="input-field" placeholder="مثال: مكتب جوانزو المباشر" value={siteInfo?.announcementPrefix || "مكتب جوانزو المباشر"} onChange={(e) => handleSaveSiteInfoField({ announcementPrefix: e.target.value })} />
            </div>

            <div>
              <label style={{ display: "block", fontSize: "0.88rem", fontWeight: 700, marginBottom: "6px" }}>نص شريط الإعلانات العلوي بالموقع (Announcement Bar)</label>
              <input type="text" className="input-field" value={siteInfo?.heroBadge || siteInfo?.announcementText || "كوكب الصين شريكك المعتمد منذ 2007 🇨🇳"} onChange={(e) => handleSaveSiteInfoField({ heroBadge: e.target.value, announcementText: e.target.value })} />
            </div>
          </div>

          <div style={{ borderTop: "1px solid var(--border-color)", paddingTop: "20px", display: "flex", flexDirection: "column", gap: "16px" }}>
            <h5 style={{ fontSize: "1.1rem", fontWeight: 800, display: "flex", alignItems: "center", gap: "8px" }}>
              <Sparkles size={18} color="var(--primary)" />
              التحكم التام بالخلفية المتحركة وتتبع الماوس (Interactive Motion & Theme Control)
            </h5>

            <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(240px, 1fr))", gap: "16px" }}>
              
              {/* Toggle Switch */}
              <div style={{ background: "var(--bg-main)", padding: "16px", borderRadius: "var(--radius-md)", border: "1px solid var(--border-color)" }}>
                <label style={{ display: "block", fontSize: "0.86rem", fontWeight: 800, marginBottom: "8px" }}>حالة الخلفية المتحركة</label>
                <button
                  type="button"
                  onClick={() => {
                    const currentBg = siteInfo?.cosmicBg || { enabled: true, themeStyle: "cosmic-red-gold", intensity: "high" };
                    handleSaveSiteInfoField({
                      cosmicBg: { ...currentBg, enabled: !currentBg.enabled }
                    });
                  }}
                  className={siteInfo?.cosmicBg?.enabled !== false ? "btn-primary" : "btn-outline"}
                  style={{ width: "100%", justifyContent: "center", fontSize: "0.84rem" }}
                >
                  {siteInfo?.cosmicBg?.enabled !== false ? "✨ الخلفية مفعلة وتتتبع الماوس" : "❌ الخلفية معطلة"}
                </button>
              </div>

              {/* Theme Selector */}
              <div style={{ background: "var(--bg-main)", padding: "16px", borderRadius: "var(--radius-md)", border: "1px solid var(--border-color)" }}>
                <label style={{ display: "block", fontSize: "0.86rem", fontWeight: 800, marginBottom: "8px" }}>ثيم وألوان النجوم والشبكة</label>
                <select
                  className="input-field"
                  value={siteInfo?.cosmicBg?.themeStyle || "cosmic-red-gold"}
                  onChange={(e) => {
                    const currentBg = siteInfo?.cosmicBg || { enabled: true, themeStyle: "cosmic-red-gold", intensity: "high" };
                    handleSaveSiteInfoField({
                      cosmicBg: { ...currentBg, themeStyle: e.target.value }
                    });
                  }}
                >
                  <option value="cosmic-red-gold">🔴 🟡 كوكب الصين - أحمر وذهبي (افتراضي)</option>
                  <option value="cyan-nebula">🔵 🌐 سديم تكنولوجي - أزرق وتركواز</option>
                  <option value="golden-luxury">👑 ✨ ذهبي فاخر (Gold Luxury)</option>
                  <option value="purple-galaxy">🟣 🌌 مجرة أرجوانية ملكية (Purple Galaxy)</option>
                </select>
              </div>

              {/* Intensity & Layering Selector */}
              <div style={{ background: "var(--bg-main)", padding: "16px", borderRadius: "var(--radius-md)", border: "1px solid var(--border-color)" }}>
                <label style={{ display: "block", fontSize: "0.86rem", fontWeight: 800, marginBottom: "8px" }}>قوة التباين ومستوى الظهور</label>
                <select
                  className="input-field"
                  value={siteInfo?.cosmicBg?.intensity || "high"}
                  onChange={(e) => {
                    const currentBg = siteInfo?.cosmicBg || { enabled: true, themeStyle: "cosmic-red-gold", intensity: "high" };
                    handleSaveSiteInfoField({
                      cosmicBg: { ...currentBg, intensity: e.target.value }
                    });
                  }}
                >
                  <option value="high">⚡ فوق كل الكروت والسيكشنات (عالي التباين)</option>
                  <option value="behind">🎨 خلف الكروت والطبقات (Under Cards)</option>
                  <option value="subtle">🌙 تباين ناعم وهادئ (Soft Glow)</option>
                </select>
              </div>

            </div>
          </div>

        </div>
      )}

      {activeSubTab === "contact" && (
        <div className="glass-card" style={{ padding: "32px", borderRadius: "var(--radius-lg)", display: "flex", flexDirection: "column", gap: "20px" }}>
          <h4 style={{ fontSize: "1.2rem", fontWeight: 800, marginBottom: "8px", display: "flex", alignItems: "center", gap: "8px" }}>
            <Building size={20} color="var(--primary)" />
            عناوين مكاتب الصين ومصر وأرقام الواتساب المباشرة
          </h4>

          <div style={{ display: "grid", gridTemplateColumns: "repeat(2, 1fr)", gap: "20px" }}>
            <div>
              <label style={{ display: "block", fontSize: "0.88rem", fontWeight: 700, marginBottom: "6px" }}>رقم الواتساب الرئيسي (مع الكود الدولي)</label>
              <input type="text" className="input-field" value={siteInfo?.whatsappNumber || "+8613480652510"} onChange={(e) => handleSaveSiteInfoField({ whatsappNumber: e.target.value })} />
            </div>

            <div>
              <label style={{ display: "block", fontSize: "0.88rem", fontWeight: 700, marginBottom: "6px" }}>البريد الإلكتروني للخدمات</label>
              <input type="email" className="input-field" value={siteInfo?.email || "info@chinaplanet.org"} onChange={(e) => handleSaveSiteInfoField({ email: e.target.value })} />
            </div>
          </div>

          <div>
            <label style={{ display: "block", fontSize: "0.88rem", fontWeight: 800, marginBottom: "6px", color: "var(--text-main)" }}>🇨🇳 عنوان مكتب الصين الرئيسي (جوانزو)</label>
            <input type="text" className="input-field" placeholder="أدخل عنوان مكتب جوانزو بالكامل..." value={siteInfo?.chinaOfficeAddress || "Room 1205, Yuediu Plaza, Yuexiu District, Guangzhou, China"} onChange={(e) => handleSaveSiteInfoField({ chinaOfficeAddress: e.target.value })} />
          </div>

          <div>
            <label style={{ display: "block", fontSize: "0.88rem", fontWeight: 800, marginBottom: "6px", color: "var(--text-main)" }}>العنوان الصيني للمكتب</label>
            <input type="text" lang="zh-CN" className="input-field" placeholder="广州市..." value={siteInfo?.chinaOfficeAddressZh || ""} onChange={(e) => handleSaveSiteInfoField({ chinaOfficeAddressZh: e.target.value })} />
          </div>

          <div>
            <label style={{ display: "block", fontSize: "0.88rem", fontWeight: 800, marginBottom: "6px", color: "var(--text-main)" }}>🇪🇬 عنوان مكتب مصر والإقليمي</label>
            <input type="text" className="input-field" placeholder="أدخل عنوان فرع مصر بالكامل..." value={siteInfo?.egyptOfficeAddress || "26 شارع السيدة امنه، سيدي جابر، شارع المشير، ميزان شركه البرمجيات، الاسكندرية"} onChange={(e) => handleSaveSiteInfoField({ egyptOfficeAddress: e.target.value })} />
          </div>

          <div>
            <label style={{ display: "block", fontSize: "0.88rem", fontWeight: 800, marginBottom: "6px", color: "var(--text-main)" }}>رابط مكتب مصر على خرائط Google</label>
            <input type="url" dir="ltr" className="input-field" placeholder="https://maps.app.goo.gl/..." value={siteInfo?.egyptOfficeMapUrl || "https://maps.app.goo.gl/GiGbBYBfSFWKKvva6?g_st=ic"} onChange={(e) => handleSaveSiteInfoField({ egyptOfficeMapUrl: e.target.value })} />
          </div>

          <div style={{ display: "grid", gridTemplateColumns: "repeat(2, 1fr)", gap: "20px" }}>
            <div>
              <label style={{ display: "block", fontSize: "0.88rem", fontWeight: 700, marginBottom: "6px" }}>رقم هاتف مكتب مصر</label>
              <input type="tel" dir="ltr" className="input-field" value={siteInfo?.egyptOfficePhone || "01096722199"} onChange={(e) => handleSaveSiteInfoField({ egyptOfficePhone: e.target.value })} />
            </div>

            <div>
              <label style={{ display: "block", fontSize: "0.88rem", fontWeight: 700, marginBottom: "6px" }}>مسؤول مكتب مصر</label>
              <input type="text" className="input-field" value={siteInfo?.egyptOfficeContactName || "معاذ محمد"} onChange={(e) => handleSaveSiteInfoField({ egyptOfficeContactName: e.target.value })} />
            </div>
          </div>
        </div>
      )}

      {activeSubTab === "sectors-editor" && (
        <div className="glass-card" style={{ padding: "32px", borderRadius: "var(--radius-lg)", display: "flex", flexDirection: "column", gap: "24px" }}>
          <h4 style={{ fontSize: "1.2rem", fontWeight: 800, marginBottom: "6px", display: "flex", alignItems: "center", gap: "8px" }}>
            <Factory size={20} color="var(--primary)" />
            تعديل سيكشن دليل القطاعات والمنتجات المستوردة بالكامل
          </h4>
          <p style={{ color: "var(--text-muted)", fontSize: "0.88rem", marginBottom: "16px" }}>
            عدّل العنوان الرئيسي، الشارة الذهبية، الوصف، وبيانات القطاعات الـ 6 الظاهرة بالصفحة الرئيسية.
          </p>

          <div>
            <label style={{ display: "block", fontSize: "0.88rem", fontWeight: 700, marginBottom: "6px" }}>نص الشارة الذهبية العلوي (Badge)</label>
            <input 
              type="text" 
              className="input-field" 
              value={sectorsInfo?.badge || "✨ خبرتنا تشمل كافة القطاعات | دليل القطاعات والمنتجات المستوردة"}
              onChange={(e) => {
                const updated = { ...sectorsInfo, badge: e.target.value };
                setSectorsInfo(updated);
                triggerSaveNotification();
              }}
            />
          </div>

          <div>
            <label style={{ display: "block", fontSize: "0.88rem", fontWeight: 700, marginBottom: "6px" }}>العنوان الرئيسي للسيكشن (H2 Headline)</label>
            <textarea 
              rows={2}
              className="input-field" 
              value={sectorsInfo?.title || "مهما كان المنتج الذي ترغب باستيراده من الصين، لدينا قاعدة بيانات ضخمة لمصانع حقيقية وموثوقة."}
              onChange={(e) => {
                const updated = { ...sectorsInfo, title: e.target.value };
                setSectorsInfo(updated);
                triggerSaveNotification();
              }}
            />
          </div>

          <div>
            <label style={{ display: "block", fontSize: "0.88rem", fontWeight: 700, marginBottom: "6px" }}>الوصف والشرح أسفل العنوان</label>
            <textarea 
              rows={3}
              className="input-field" 
              value={sectorsInfo?.subtitle || "نربطك فوراً بأكثر من 1,200 مصنع صيني مباشر في مدينة جوانزو والمحافظات الصناعية المجاورة مع ضمان الفحص والتفاوض المباشر."}
              onChange={(e) => {
                const updated = { ...sectorsInfo, subtitle: e.target.value };
                setSectorsInfo(updated);
                triggerSaveNotification();
              }}
            />
          </div>

          <div style={{ borderTop: "1px solid var(--border-color)", paddingTop: "24px", display: "flex", flexDirection: "column", gap: "20px" }}>
            <h5 style={{ fontSize: "1.05rem", fontWeight: 800 }}>تعديل تفاصيل القطاعات الـ 6:</h5>

            <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(300px, 1fr))", gap: "20px" }}>
              {((sectorsInfo?.sectorsList) || [
                { title: "الآلات والمعدات الصناعية", badge: "خطوط إنتاج معتمدة", desc: "خطوط التغليف، أجهزة الليزر، ماكينات CNC، ومعدات المصانع الثقيلة بالتراخيص الفنية.", suppliersCount: "340+ مصنع" },
                { title: "الإلكترونيات والحلول الذكية", badge: "جودة عالمية ISO", desc: "إضاءات LED، الشاشات التفاعلية، أجهزة الاتصالات، والقطع الإلكترونية الدقيقة.", suppliersCount: "280+ مصنع" },
                { title: "مواد البناء والرخام والديكور", badge: "شهادات مطابقة سابر", desc: "السيراميك، الرخام الطبيعي، واجهات الكوبوند، وألواح الألومنيوم والخشب البلاستيكي.", suppliersCount: "410+ مصنع" },
                { title: "الأثاث والديكورات الفاخرة", badge: "تجهيز فندقي وسكني", desc: "أثاث المكاتب، تجهيزات الفنادق، المفروشات، والقطع الديكورية المصنعة حسب الطلب.", suppliersCount: "190+ مصنع" },
                { title: "المنتجات البلاستيكية والتعبئة", badge: "قوالب حقن مخصصة", desc: "عبوات التغليف، القوالب الصناعية، أدوات البلاستيك الغذائي والصحي المقاوم.", suppliersCount: "150+ مصنع" },
                { title: "الأدوات والأجهزة المنزلية", badge: "ضمان فني وفحص جودة", desc: "الأجهزة الكهرومنزلية، أدوات المطبخ العصرية، ومستلزمات المنازل الذكية.", suppliersCount: "220+ مصنع" }
              ]).map((sec, idx) => (
                <div key={idx} style={{ background: "var(--bg-main)", padding: "18px", borderRadius: "var(--radius-md)", border: "1px solid var(--border-color)", display: "flex", flexDirection: "column", gap: "10px" }}>
                  <div style={{ fontWeight: 800, color: "var(--primary)", fontSize: "0.85rem" }}>القطاع #{idx + 1}</div>
                  
                  <input 
                    type="text" 
                    className="input-field" 
                    placeholder="اسم القطاع" 
                    value={sec.title} 
                    onChange={(e) => {
                      const updatedList = [...(sectorsInfo?.sectorsList || [])];
                      updatedList[idx] = { ...sec, title: e.target.value };
                      const updatedInfo = { ...sectorsInfo, sectorsList: updatedList };
                      setSectorsInfo(updatedInfo);
                      triggerSaveNotification();
                    }} 
                  />

                  <input 
                    type="text" 
                    className="input-field" 
                    placeholder="شارة القطاع (Badge)" 
                    value={sec.badge} 
                    onChange={(e) => {
                      const updatedList = [...(sectorsInfo?.sectorsList || [])];
                      updatedList[idx] = { ...sec, badge: e.target.value };
                      const updatedInfo = { ...sectorsInfo, sectorsList: updatedList };
                      setSectorsInfo(updatedInfo);
                      triggerSaveNotification();
                    }} 
                  />

                  <textarea 
                    rows={2} 
                    className="input-field" 
                    placeholder="وصف القطاع" 
                    value={sec.desc} 
                    onChange={(e) => {
                      const updatedList = [...(sectorsInfo?.sectorsList || [])];
                      updatedList[idx] = { ...sec, desc: e.target.value };
                      const updatedInfo = { ...sectorsInfo, sectorsList: updatedList };
                      setSectorsInfo(updatedInfo);
                      triggerSaveNotification();
                    }} 
                  />

                  <input 
                    type="text" 
                    className="input-field" 
                    placeholder="عدد المصانع (مثال: 340+ مصنع)" 
                    value={sec.suppliersCount} 
                    onChange={(e) => {
                      const updatedList = [...(sectorsInfo?.sectorsList || [])];
                      updatedList[idx] = { ...sec, suppliersCount: e.target.value };
                      const updatedInfo = { ...sectorsInfo, sectorsList: updatedList };
                      setSectorsInfo(updatedInfo);
                      triggerSaveNotification();
                    }} 
                  />
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {activeSubTab === "catalog-page" && (
        <div className="glass-card" style={{ padding: "32px", borderRadius: "var(--radius-lg)", display: "flex", flexDirection: "column", gap: "24px" }}>
          <h4 style={{ fontSize: "1.2rem", fontWeight: 800, marginBottom: "6px", display: "flex", alignItems: "center", gap: "8px" }}>
            <Package size={20} color="var(--primary)" />
            تعديل بانر، صوره الخلفية، ونصوص صفحة المنتجات والكتالوج بالكامل
          </h4>
          <p style={{ color: "var(--text-muted)", fontSize: "0.88rem", marginBottom: "16px" }}>
            عدّل العنوان الرئيسي، الشرح، وصورة خلفية البانر الظاهرة في أعلى صفحة الكتالوج لزوار الموقع.
          </p>

          <div style={{ background: "var(--bg-main)", padding: "20px", borderRadius: "var(--radius-md)", border: "1px solid var(--border-color)", display: "flex", flexDirection: "column", gap: "14px" }}>
            <div>
              <ImageUploaderInput 
                label="🖼️ صورة خلفية البانر لصفحة المنتجات (رابط أو رفع من جهازك)"
                value={siteInfo?.catalogBannerBgImage || ""}
                onChange={(val) => handleSaveSiteInfoField({ catalogBannerBgImage: val })}
              />
            </div>

            <div>
              <label style={{ display: "block", fontSize: "0.8rem", fontWeight: 700, color: "var(--text-muted)", marginBottom: "8px" }}>أو اختر صورة جاهزة للخلفية:</label>
              <div style={{ display: "flex", gap: "10px", flexWrap: "wrap" }}>
                {presetBannerImages.map((img, i) => (
                  <button key={i} type="button" onClick={() => handleSaveSiteInfoField({ catalogBannerBgImage: img })} style={{ border: siteInfo?.catalogBannerBgImage === img ? "2px solid var(--primary)" : "1px solid var(--border-color)", borderRadius: "8px", overflow: "hidden", padding: 0, cursor: "pointer", width: "90px", height: "56px" }}>
                    <img src={img} alt="preset" style={{ width: "100%", height: "100%", objectFit: "cover" }} />
                  </button>
                ))}
                {siteInfo?.catalogBannerBgImage && (
                  <button type="button" onClick={() => handleSaveSiteInfoField({ catalogBannerBgImage: "" })} className="btn-outline" style={{ padding: "6px 12px", fontSize: "0.78rem", color: "#D32F2F", borderColor: "rgba(211,47,47,0.3)" }}>إلغاء الخلفية</button>
                )}
              </div>
            </div>
          </div>

          <div>
            <label style={{ display: "block", fontSize: "0.88rem", fontWeight: 700, marginBottom: "6px" }}>نص البادج الذهبي العلوي بالبانر (Badge)</label>
            <input type="text" className="input-field" value={siteInfo?.catalogBadgeText || "الأقسام الرئيسية والفرعية المزمنة من WooCommerce 🇨🇳"} onChange={(e) => handleSaveSiteInfoField({ catalogBadgeText: e.target.value })} />
          </div>

          <div>
            <label style={{ display: "block", fontSize: "0.88rem", fontWeight: 700, marginBottom: "6px" }}>العنوان الرئيسي لصفحة المنتجات (H1 Header)</label>
            <input type="text" className="input-field" value={siteInfo?.catalogBannerTitle || "كتالوج المنتجات والمصانع (بدون أسعار - طلب تسعير مباشر)"} onChange={(e) => handleSaveSiteInfoField({ catalogBannerTitle: e.target.value })} />
          </div>

          <div>
            <label style={{ display: "block", fontSize: "0.88rem", fontWeight: 700, marginBottom: "6px" }}>الوصف والشرح أسفل العنوان</label>
            <textarea rows={4} className="input-field" value={siteInfo?.catalogBannerSubtitle || "اختر القسم الرئيسي أو الفرعي من الشريط الجانبي الثابت، حدد الكمية والملاحظات للمنتج، وأرسل طلب التسعير المباشر لمكتب جوانزو."} onChange={(e) => handleSaveSiteInfoField({ catalogBannerSubtitle: e.target.value })} />
          </div>
        </div>
      )}

      {activeSubTab === "custom-sections" && (
        <div style={{ display: "flex", flexDirection: "column", gap: "20px" }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", flexWrap: "wrap", gap: "14px" }}>
            <div>
              <h4 style={{ fontSize: "1.15rem", fontWeight: 800 }}>ترتيب السيكشنات وإضافة سيكشنات جديدة بالصفحة الرئيسية</h4>
              <p style={{ fontSize: "0.84rem", color: "var(--text-muted)" }}>استخدم أزرار التقديم والتأخير (⬆️ ⬇️) لإعادة ترتيب ظهور السيكشنات</p>
            </div>

            <button onClick={handleOpenAddSection} className="btn-primary" style={{ padding: "10px 22px" }}>
              <Plus size={18} />
              <span>إضافة سيكشن مخصص جديد</span>
            </button>
          </div>

          {(!customSections || customSections.length === 0) ? (
            <div className="glass-card" style={{ padding: "50px 20px", textAlign: "center", color: "var(--text-muted)" }}>
              <Sliders size={44} style={{ opacity: 0.3, marginBottom: "12px" }} />
              <div style={{ fontWeight: 800, fontSize: "1.05rem", marginBottom: "6px" }}>لا يوجد سيكشنات مخصصة حالياً</div>
              <div style={{ fontSize: "0.88rem" }}>اضغط "إضافة سيكشن مخصص جديد" لإنشاء وترتيب عناصر الصفحة الرئيسية.</div>
            </div>
          ) : (
            <div style={{ display: "flex", flexDirection: "column", gap: "16px" }}>
              {customSections.map((sec, idx) => (
                <div key={sec.id || idx} className="glass-card" style={{ padding: "20px 24px", borderRadius: "var(--radius-lg)", display: "flex", justifyContent: "space-between", alignItems: "center", gap: "20px", border: "1px solid var(--border-color)" }}>
                  <div style={{ display: "flex", flexDirection: "column", gap: "4px" }}>
                    <button disabled={idx === 0} onClick={() => handleMoveSectionUp(idx)} className="btn-outline" style={{ padding: "4px 10px", fontSize: "0.75rem", opacity: idx === 0 ? 0.3 : 1 }} title="تقديم الترتيب لأعلى">
                      <ArrowUp size={14} /> <span>أعلى</span>
                    </button>
                    <button disabled={idx === customSections.length - 1} onClick={() => handleMoveSectionDown(idx)} className="btn-outline" style={{ padding: "4px 10px", fontSize: "0.75rem", opacity: idx === customSections.length - 1 ? 0.3 : 1 }} title="تأخير الترتيب لأسفل">
                      <ArrowDown size={14} /> <span>أسفل</span>
                    </button>
                  </div>

                  <div style={{ flex: 1, display: "flex", gap: "16px", alignItems: "center" }}>
                    {sec.image && (
                      <img src={sec.image} alt={sec.title} style={{ width: "80px", height: "60px", borderRadius: "var(--radius-sm)", objectFit: "cover" }} />
                    )}
                    <div>
                      <div style={{ display: "flex", alignItems: "center", gap: "8px", marginBottom: "4px" }}>
                        <span className="badge badge-gold" style={{ fontSize: "0.72rem" }}>موقع {idx + 1}</span>
                        <h5 style={{ fontSize: "1.05rem", fontWeight: 800, color: "var(--text-main)", margin: 0 }}>{sec.title}</h5>
                      </div>
                      <p style={{ fontSize: "0.84rem", color: "var(--text-muted)", display: "-webkit-box", WebkitLineClamp: 1, WebkitBoxOrient: "vertical", overflow: "hidden" }}>{sec.content}</p>
                    </div>
                  </div>

                  <div style={{ display: "flex", gap: "10px" }}>
                    <button onClick={() => handleOpenEditSection(idx)} className="btn-outline" style={{ padding: "8px 16px", fontSize: "0.84rem" }}>
                      <Edit3 size={16} /> <span>تعديل السيكشن</span>
                    </button>
                    <button onClick={() => handleDeleteSection(idx)} style={{ background: "rgba(211, 47, 47, 0.1)", color: "#D32F2F", border: "1px solid rgba(211, 47, 47, 0.3)", padding: "8px 14px", borderRadius: "var(--radius-sm)", cursor: "pointer", fontWeight: 800, fontSize: "0.84rem" }}>
                      <Trash2 size={16} />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {activeSubTab === "team" && (
        <div style={{ display: "flex", flexDirection: "column", gap: "20px" }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
            <h4 style={{ fontSize: "1.15rem", fontWeight: 800 }}>فريق العمل والمستشارين المعتمدين</h4>
            <button onClick={handleOpenAddTeam} className="btn-primary" style={{ padding: "8px 18px" }}>
              <Plus size={16} /> إضافة عضو جديد
            </button>
          </div>

          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(280px, 1fr))", gap: "20px" }}>
            {(teamMembers || []).map((m, idx) => (
              <div key={m.id || idx} className="glass-card" style={{ padding: "20px", borderRadius: "var(--radius-md)", display: "flex", flexDirection: "column", justifyContent: "space-between" }}>
                <div>
                  <img src={m.image || "/images/hero.webp"} alt={m.name} style={{ width: "60px", height: "60px", borderRadius: "50%", objectFit: "cover", marginBottom: "12px", border: "2px solid var(--primary)" }} />
                  <h5 style={{ fontSize: "1.05rem", fontWeight: 800, marginBottom: "4px" }}>{m.name}</h5>
                  <div style={{ fontSize: "0.82rem", color: "var(--primary)", fontWeight: 700, marginBottom: "8px" }}>{m.role} - {m.experience}</div>
                  <p style={{ fontSize: "0.82rem", color: "var(--text-muted)", lineHeight: 1.5 }}>{m.bio}</p>
                </div>

                <div style={{ borderTop: "1px solid var(--border-color)", paddingTop: "12px", marginTop: "16px", display: "flex", gap: "8px" }}>
                  <button onClick={() => handleOpenEditTeam(idx)} className="btn-outline" style={{ flex: 1, padding: "6px", fontSize: "0.8rem" }}>
                    <Edit3 size={14} /> تعديل
                  </button>
                  <button onClick={() => handleDeleteTeamMember(idx)} style={{ background: "rgba(211,47,47,0.1)", color: "#D32F2F", border: "1px solid rgba(211,47,47,0.3)", padding: "6px 12px", borderRadius: "var(--radius-sm)", cursor: "pointer" }}>
                    <Trash2 size={14} />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {activeSubTab === "hero" && (
        <div className="glass-card" style={{ padding: "32px", borderRadius: "var(--radius-lg)", display: "flex", flexDirection: "column", gap: "20px" }}>
          <h4 style={{ fontSize: "1.2rem", fontWeight: 800, marginBottom: "8px", display: "flex", alignItems: "center", gap: "8px" }}>
            <Images size={20} color="var(--primary)" />
            معرض صور وفيديو الهيرو الرئيسي (Carousel & Video Background)
          </h4>

          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(260px, 1fr))", gap: "16px" }}>
            {[
              ["العربية", "", "rtl"],
              ["English", "En", "ltr"],
              ["Français", "Fr", "ltr"],
            ].map(([label, suffix, dir]) => (
              <div key={label} style={{ display: "grid", gap: "8px", padding: "16px", border: "1px solid var(--border-color)", borderRadius: "var(--radius-md)" }}>
                <strong>{label}</strong>
                <input type="text" className="input-field" dir={dir} placeholder="العنوان الرئيسي / Main title" value={heroInfo?.[`title${suffix}`] || ""} onChange={(e) => setHeroInfo({ ...heroInfo, [`title${suffix}`]: e.target.value })} />
                <textarea className="input-field" dir={dir} rows={4} placeholder="الوصف / Description" value={heroInfo?.[`subtitle${suffix}`] || ""} onChange={(e) => setHeroInfo({ ...heroInfo, [`subtitle${suffix}`]: e.target.value })} />
                <input type="text" className="input-field" dir={dir} placeholder="الشارة / Badge" value={heroInfo?.[`badge${suffix}`] || ""} onChange={(e) => setHeroInfo({ ...heroInfo, [`badge${suffix}`]: e.target.value })} />
              </div>
            ))}
          </div>

          <div>
            <label style={{ display: "block", fontSize: "0.88rem", fontWeight: 800, marginBottom: "6px", color: "var(--text-main)" }}>
              🎥 رابط فيديو خلفية الهيرو (Direct MP4 URL or YouTube Link)
            </label>
            <input 
              type="text" 
              className="input-field" 
              placeholder="أدخل رابط فيديو خلفية الهيرو (مثال: https://...mp4 أو YouTube link)"
              value={heroInfo?.bgVideo || ""}
              onChange={(e) => {
                const updated = { ...heroInfo, bgVideo: e.target.value };
                setHeroInfo(updated);
                triggerSaveNotification();
              }}
            />
          </div>

          <div style={{ borderTop: "1px solid var(--border-color)", paddingTop: "16px" }}>
            <label style={{ display: "block", fontSize: "0.88rem", fontWeight: 800, marginBottom: "8px" }}>معرض صور السلايدر الرئيسي (Carousel Gallery):</label>
            
            <div style={{ marginBottom: "16px" }}>
              <ImageUploaderInput 
                label="إضافة صورة جديدة لسلايدر الهيرو (رابط أو رفع ملف من جهازك)"
                value={newGalleryImgUrl}
                onChange={(val) => setNewGalleryImgUrl(val)}
              />
              {newGalleryImgUrl && (
                <button onClick={handleAddGalleryImage} className="btn-primary" style={{ padding: "8px 20px", marginTop: "10px" }}><Plus size={16} /> إضافة الصورة للمعرض</button>
              )}
            </div>

            <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(200px, 1fr))", gap: "16px" }}>
              {heroGalleryList.map((imgUrl, i) => (
                <div key={i} style={{ position: "relative", borderRadius: "var(--radius-md)", overflow: "hidden", height: "140px", border: "1px solid var(--border-color)" }}>
                  <img src={imgUrl} alt={"gallery-" + i} style={{ width: "100%", height: "100%", objectFit: "cover" }} />
                  <button onClick={() => handleDeleteGalleryImage(i)} style={{ position: "absolute", top: "8px", right: "8px", background: "rgba(211, 47, 47, 0.9)", color: "#FFF", border: "none", borderRadius: "50%", width: "28px", height: "28px", display: "flex", alignItems: "center", justifyContent: "center", cursor: "pointer" }} title="حذف الصورة">
                    <Trash2 size={14} />
                  </button>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

    </div>
  );
}
