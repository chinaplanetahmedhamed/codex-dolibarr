import React, { useState } from 'react';
import { 
  Plus, 
  Edit3, 
  Trash2, 
  Camera
} from 'lucide-react';
import ServiceFullEditor from './ServiceFullEditor';

export default function ServicesTab({ servicesData, setServicesData }) {
  const [editingServiceId, setEditingServiceId] = useState(null);
  const [isCreatingNew, setIsCreatingNew] = useState(false);

  const handleOpenAdd = () => {
    setIsCreatingNew(true);
    setEditingServiceId(null);
  };

  const handleOpenEdit = (srvId) => {
    setEditingServiceId(srvId);
    setIsCreatingNew(false);
  };

  const handleDelete = (srvId) => {
    if (window.confirm('هل أنت تأكد من رغبتك في حذف هذه الخدمة من الداتابيز؟')) {
      const updated = servicesData.filter(s => s.id !== srvId);
      setServicesData(updated);
    }
  };

  const handleSaveService = (savedData) => {
    if (isCreatingNew) {
      setServicesData([...servicesData, savedData]);
    } else {
      const updated = servicesData.map(s => s.id === savedData.id ? { ...savedData } : s);
      setServicesData(updated);
    }
    setEditingServiceId(null);
    setIsCreatingNew(false);
  };

  // Render Full Page CMS Editor if editing or creating
  if (isCreatingNew || editingServiceId) {
    const currentSrv = servicesData.find(s => s.id === editingServiceId);
    return (
      <ServiceFullEditor 
        service={currentSrv}
        onSave={handleSaveService}
        onCancel={() => { setEditingServiceId(null); setIsCreatingNew(false); }}
      />
    );
  }

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '28px' }}>
      
      {/* Header */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '16px' }}>
        <div>
          <h3 style={{ fontSize: '1.25rem', fontWeight: 800 }}>إدارة وتعديل الخدمات المستقلة (Services Manager)</h3>
          <p style={{ color: 'var(--text-muted)', fontSize: '0.9rem' }}>اضغط على أي خدمة لفتح محرر الصفحة المستقلة التفاعلي وإضافة الصور والـ Gallery والمعرض المنسق.</p>
        </div>

        <button onClick={handleOpenAdd} className="btn-primary">
          <Plus size={18} />
          <span>إضافة خدمة جديدة ومعرض صور جديد</span>
        </button>
      </div>

      {/* Services Live Cards */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(320px, 1fr))', gap: '24px' }}>
        {servicesData.map((srv) => (
          <div key={srv.id} className="glass-card" style={{ padding: '24px', borderRadius: 'var(--radius-md)', display: 'flex', flexDirection: 'column', justifyContent: 'space-between' }}>
            <div>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '12px' }}>
                <span className="badge badge-red">{srv.badge}</span>
                <span style={{ fontSize: '0.78rem', color: 'var(--text-muted)', fontFamily: 'var(--font-en)' }}>ID: {srv.id}</span>
              </div>

              <h4 style={{ fontSize: '1.2rem', fontWeight: 800, marginBottom: '4px' }}>{srv.title}</h4>
              <div style={{ fontSize: '0.82rem', color: 'var(--text-muted)', fontFamily: 'var(--font-en)', marginBottom: '14px' }}>{srv.subtitle}</div>

              <p style={{ fontSize: '0.9rem', color: 'var(--text-muted)', lineHeight: 1.5, marginBottom: '16px' }}>
                {srv.description}
              </p>

              <div style={{ fontSize: '0.82rem', background: 'var(--bg-main)', padding: '10px', borderRadius: 'var(--radius-sm)', border: '1px solid var(--border-color)', marginBottom: '16px', display: 'flex', justifyContent: 'space-between' }}>
                <span>معرض الصور: <strong>{srv.gallery ? srv.gallery.length : 3} صور</strong></span>
                <Camera size={16} color="var(--primary)" />
              </div>
            </div>

            <div style={{ display: 'flex', gap: '10px', borderTop: '1px solid var(--border-color)', paddingTop: '16px' }}>
              <button 
                onClick={() => handleOpenEdit(srv.id)}
                className="btn-primary" 
                style={{ flex: 1, justifyContent: 'center', fontSize: '0.88rem' }}
              >
                <Edit3 size={16} />
                <span>فتح محرر الصفحة والمعرض</span>
              </button>

              <button 
                onClick={() => handleDelete(srv.id)}
                className="btn-outline" 
                style={{ padding: '8px 12px', color: '#D32F2F', borderColor: 'rgba(211, 47, 47, 0.3)' }}
                title="حذف الخدمة"
              >
                <Trash2 size={16} />
              </button>
            </div>
          </div>
        ))}
      </div>

    </div>
  );
}
