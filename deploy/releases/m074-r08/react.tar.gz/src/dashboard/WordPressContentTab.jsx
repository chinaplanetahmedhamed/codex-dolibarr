import React from "react";
import { BookOpen, ExternalLink, MapPinned, ShieldCheck } from "lucide-react";

const WORDPRESS_ADMIN_URL = import.meta.env.VITE_WORDPRESS_ADMIN_URL || "https://cms.chinaplanet.org/wp-admin/";

export default function WordPressContentTab({ postsCount = 0 }) {
  const postsUrl = new URL("edit.php", WORDPRESS_ADMIN_URL).toString();
  const guideUrl = new URL("edit.php?post_type=china_guide", WORDPRESS_ADMIN_URL).toString();

  return (
    <section style={{ display: "grid", gap: "20px" }}>
      <div className="glass-card" style={{ padding: "28px" }}>
        <div style={{ display: "flex", gap: "12px", alignItems: "flex-start" }}>
          <span style={{ width: "44px", height: "44px", borderRadius: "12px", background: "rgba(211,47,47,.12)", color: "var(--primary)", display: "grid", placeItems: "center", flexShrink: 0 }}><ShieldCheck size={22} /></span>
          <div>
            <h2 style={{ marginBottom: "8px" }}>النشر من WordPress</h2>
            <p style={{ color: "var(--text-muted)", lineHeight: 1.8 }}>WordPress هو مصدر المقالات ودليل الصين. بعد النشر أو التحديث، تُحدّث واجهة React تلقائياً عبر Webhook آمن. لوحة React تبقى لتعديل الصفحة الرئيسية والخدمات والهوية.</p>
          </div>
        </div>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(260px, 1fr))", gap: "18px" }}>
        <a href={postsUrl} target="_blank" rel="noopener noreferrer" className="glass-card" style={{ padding: "24px", textDecoration: "none", color: "inherit", display: "grid", gap: "12px" }}>
          <BookOpen color="var(--primary)" />
          <h3>إدارة مقالات المدونة</h3>
          <p style={{ color: "var(--text-muted)" }}>{postsCount} مقال معتمد ظاهر حالياً في React.</p>
          <span style={{ color: "var(--primary)", fontWeight: 800, display: "flex", gap: "7px", alignItems: "center" }}>فتح WordPress <ExternalLink size={16} /></span>
        </a>
        <a href={guideUrl} target="_blank" rel="noopener noreferrer" className="glass-card" style={{ padding: "24px", textDecoration: "none", color: "inherit", display: "grid", gap: "12px" }}>
          <MapPinned color="var(--primary)" />
          <h3>إدارة دليل الصين</h3>
          <p style={{ color: "var(--text-muted)" }}>المدن، أنواع الأماكن، وبيانات كل مكان تُدار كبيانات منظمة مستقلة عن المدونة.</p>
          <span style={{ color: "var(--primary)", fontWeight: 800, display: "flex", gap: "7px", alignItems: "center" }}>فتح دليل الصين <ExternalLink size={16} /></span>
        </a>
      </div>
    </section>
  );
}
