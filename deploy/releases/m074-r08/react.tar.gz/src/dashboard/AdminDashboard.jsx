import React, { useState } from "react";
import { BookOpen, FileText, Globe, LogOut, Save, Sliders } from "lucide-react";
import WordPressContentTab from "./WordPressContentTab";
import ServicesTab from "./ServicesTab";
import SiteEditorTab from "./SiteEditorTab";

const MENU_ITEMS = [
  { id: "site-editor", label: "تعديل الموقع الشامل", icon: Sliders },
  { id: "services-mgr", label: "الخدمات", icon: FileText },
  { id: "blog-mgr", label: "محتوى WordPress", icon: BookOpen },
];

export default function AdminDashboard({
  servicesData,
  setServicesData,
  blogPosts,
  siteInfo,
  setSiteInfo,
  teamMembers,
  setTeamMembers,
  customSections,
  setCustomSections,
  heroInfo,
  setHeroInfo,
  sectorsInfo,
  setSectorsInfo,
  onSave,
  onLogout,
  onExitDashboard,
  saveState,
  contentReady,
  lastSavedAt,
}) {
  const initialTab = window.location.hash.match(/^#\/admin\/(.+)$/)?.[1] || "site-editor";
  const [activeTab, setActiveTab] = useState(MENU_ITEMS.some((item) => item.id === initialTab) ? initialTab : "site-editor");

  const changeTab = (tabId) => {
    setActiveTab(tabId);
    window.location.hash = `#/admin/${tabId}`;
  };

  return (
    <div style={{ minHeight: "100vh", display: "flex", background: "var(--bg-main)" }}>
      <aside className="hide-mobile" style={{ width: "280px", background: "var(--secondary)", color: "#fff", borderLeft: "1px solid rgba(255,255,255,.08)", display: "flex", flexDirection: "column", justifyContent: "space-between", padding: "24px 16px", flexShrink: 0 }}>
        <div>
          <div style={{ padding: "0 8px 24px", borderBottom: "1px solid rgba(255,255,255,.1)", marginBottom: "24px" }}>
            <div style={{ display: "flex", alignItems: "center", gap: "10px" }}>
              <div style={{ width: "42px", height: "42px", borderRadius: "12px", background: "var(--primary)", display: "grid", placeItems: "center" }}><Globe size={22} /></div>
              <div>
                <div style={{ fontSize: "1.1rem", fontWeight: 800 }}>{siteInfo?.siteNameAr || "كوكب الصين"}</div>
                <div style={{ fontSize: ".72rem", color: "#94A3B8" }}>لوحة تحرير الموقع</div>
              </div>
            </div>
          </div>

          <nav style={{ display: "flex", flexDirection: "column", gap: "6px" }}>
            {MENU_ITEMS.map(({ id, label, icon: Icon }) => (
              <button type="button" key={id} onClick={() => changeTab(id)} style={{ display: "flex", alignItems: "center", gap: "10px", padding: "14px 16px", borderRadius: "12px", background: activeTab === id ? "var(--primary)" : "transparent", color: activeTab === id ? "#fff" : "#CBD5E1", border: 0, fontWeight: activeTab === id ? 800 : 600, cursor: "pointer", textAlign: "right" }}>
                <Icon size={20} /> {label}
              </button>
            ))}
          </nav>
        </div>

        <div style={{ borderTop: "1px solid rgba(255,255,255,.1)", paddingTop: "16px", display: "grid", gap: "8px" }}>
          <button type="button" onClick={onExitDashboard} style={{ padding: "10px 14px", background: "transparent", color: "#CBD5E1", border: 0, textAlign: "right", cursor: "pointer" }}><Globe size={16} style={{ verticalAlign: "middle", marginLeft: "8px" }} />عرض الموقع</button>
          <button type="button" onClick={onLogout} style={{ padding: "10px 14px", background: "rgba(211,47,47,.15)", color: "#FF8A80", border: "1px solid rgba(211,47,47,.3)", borderRadius: "10px", textAlign: "right", cursor: "pointer", fontWeight: 800 }}><LogOut size={16} style={{ verticalAlign: "middle", marginLeft: "8px" }} />تسجيل الخروج</button>
        </div>
      </aside>

      <main style={{ flex: 1, minWidth: 0, padding: "clamp(18px, 3vw, 32px)", overflowY: "auto" }}>
        <header style={{ display: "flex", justifyContent: "space-between", alignItems: "center", flexWrap: "wrap", gap: "14px", marginBottom: "26px", padding: "16px 18px", background: "var(--bg-card)", border: "1px solid var(--border-color)", borderRadius: "16px" }}>
          <div>
            <strong>تعديلات الموقع</strong>
            <div style={{ color: "var(--text-muted)", fontSize: ".8rem", marginTop: "4px" }}>{lastSavedAt ? `آخر نشر: ${new Date(lastSavedAt).toLocaleString("ar-EG")}` : "لم يُنشر محتوى مخصص بعد"}</div>
          </div>
          <div style={{ display: "flex", gap: "10px", flexWrap: "wrap" }}>
            <button type="button" className="btn-outline" onClick={onExitDashboard}><Globe size={17} />عرض الموقع</button>
            <button type="button" className="btn-primary" onClick={onSave} disabled={!contentReady || saveState === "saving"} style={{ opacity: !contentReady || saveState === "saving" ? .7 : 1 }}><Save size={17} />{!contentReady ? "جاري تحميل المحتوى..." : saveState === "saving" ? "جاري الحفظ..." : saveState === "saved" ? "تم الحفظ والنشر" : "حفظ ونشر التعديلات"}</button>
          </div>
          {saveState === "error" && <div role="alert" style={{ width: "100%", color: "#DC2626", fontWeight: 700 }}>تعذر الحفظ. تحقق من الجلسة وإعداد التخزين ثم أعد المحاولة.</div>}
        </header>

        <div className="show-mobile-only" style={{ display: "flex", gap: "8px", overflowX: "auto", marginBottom: "18px" }}>
          {MENU_ITEMS.map(({ id, label }) => <button type="button" key={id} className={activeTab === id ? "btn-primary" : "btn-outline"} onClick={() => changeTab(id)} style={{ whiteSpace: "nowrap" }}>{label}</button>)}
        </div>

        {activeTab === "site-editor" && <SiteEditorTab siteInfo={siteInfo} setSiteInfo={setSiteInfo} teamMembers={teamMembers} setTeamMembers={setTeamMembers} customSections={customSections} setCustomSections={setCustomSections} heroInfo={heroInfo} setHeroInfo={setHeroInfo} sectorsInfo={sectorsInfo} setSectorsInfo={setSectorsInfo} />}
        {activeTab === "services-mgr" && <ServicesTab servicesData={servicesData} setServicesData={setServicesData} />}
        {activeTab === "blog-mgr" && <WordPressContentTab postsCount={blogPosts?.length || 0} />}
      </main>
    </div>
  );
}
