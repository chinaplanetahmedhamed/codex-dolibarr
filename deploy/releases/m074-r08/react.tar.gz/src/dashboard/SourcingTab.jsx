import React from 'react';
import { Search, Send, Clock, CheckCircle2, DollarSign, User } from 'lucide-react';

export default function SourcingTab({ sourcingRequests, setSourcingRequests }) {
  const handleUpdateStatus = (reqId, newStatus) => {
    const updated = sourcingRequests.map(r => {
      if (r.id === reqId) {
        return { ...r, status: newStatus };
      }
      return r;
    });
    setSourcingRequests(updated);
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '28px' }}>
      
      <div>
        <h3 style={{ fontSize: '1.25rem', fontWeight: 800 }}>إدارة طلبات البحث والتسعير الواردة من العملاء</h3>
        <p style={{ color: 'var(--text-muted)', fontSize: '0.9rem' }}>دراسة المواصفات، البحث عن المصانع وتحديد أسعار التكلفة واصل للمستورد.</p>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(320px, 1fr))', gap: '24px' }}>
        {sourcingRequests.map((req) => (
          <div key={req.id} className="glass-card" style={{ padding: '24px', borderRadius: 'var(--radius-md)' }}>
            
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '14px' }}>
              <span style={{ fontWeight: 900, fontSize: '1.1rem', fontFamily: 'var(--font-en)' }}>{req.id}</span>
              <span className="badge badge-gold" style={{ fontSize: '0.78rem' }}>أولوية: {req.urgency || 'عادي'}</span>
            </div>

            <h4 style={{ fontSize: '1.1rem', fontWeight: 800, marginBottom: '6px' }}>{req.productName}</h4>
            
            <div style={{ fontSize: '0.85rem', color: 'var(--text-muted)', marginBottom: '14px' }}>
              العميل: <strong>{req.clientName}</strong> ({req.company || 'فرد'}) - {req.country}<br />
              الكمية المطلوبة: {req.quantity} | السعر المستهدف: {req.targetPriceUSD}
            </div>

            <div style={{ background: 'var(--bg-main)', padding: '12px', borderRadius: 'var(--radius-sm)', border: '1px solid var(--border-color)', marginBottom: '16px', fontSize: '0.85rem' }}>
              <strong>ملاحظات العميل:</strong> {req.notes}
            </div>

            <div style={{ marginBottom: '16px' }}>
              <div style={{ fontSize: '0.8rem', color: 'var(--text-muted)', marginBottom: '6px' }}>الحالة الحالية:</div>
              <div style={{ fontWeight: 800, color: 'var(--primary)', fontSize: '0.92rem' }}>{req.status}</div>
            </div>

            <div style={{ display: 'flex', gap: '8px', borderTop: '1px solid var(--border-color)', paddingTop: '16px' }}>
              <button 
                onClick={() => handleUpdateStatus(req.id, 'تم التواصل واختيار المصنع وجاري إعداد العرض النهائي')} 
                className="btn-primary" 
                style={{ flex: 1, padding: '8px', fontSize: '0.82rem', justifyContent: 'center' }}
              >
                تقديم عرض سعر
              </button>
              <button 
                onClick={() => handleUpdateStatus(req.id, 'مستوفي - تم الاتفاق وبدء الإنتاج بالمصنع')} 
                className="btn-outline" 
                style={{ padding: '8px', fontSize: '0.82rem' }}
              >
                تأكيد الاتفاق
              </button>
            </div>

          </div>
        ))}
      </div>

    </div>
  );
}
