import ImageUploaderInput from "../components/ImageUploaderInput";
import React, { useState } from 'react';
import { 
  ArrowRight, 
  Save, 
  Check, 
  Sparkles, 
  Globe, 
  Bold, 
  Italic, 
  Heading1, 
  List, 
  Search
} from 'lucide-react';

export default function BlogPostEditor({ post, blogCategories, onSave, onCancel }) {
  const categoriesList = blogCategories && blogCategories.length ? blogCategories : ['دليل كانطون', 'نصائح الاستيراد', 'الشحن والجمرك', 'أسواق جوانزو', 'دراسات حالة'];

  const [formData, setFormData] = useState({
    id: post?.id || `post-${Date.now()}`,
    slug: post?.slug || `post-${Date.now()}`,
    title: post?.title || '',
    category: post?.category || categoriesList[0],
    author: post?.author || 'فريق كوكب الصين',
    date: post?.date || new Date().toISOString().split('T')[0],
    readTime: post?.readTime || '5 دقائق',
    image: post?.image || '/images/hero.webp',
    excerpt: post?.excerpt || '',
    metaTitle: post?.metaTitle || post?.title || '',
    metaDescription: post?.metaDescription || post?.excerpt || '',
    keywords: post?.keywords || 'استيراد من الصين, جوانزو, مصانع الصين',
    content: post?.content || ''
  });

  const [savedSuccess, setSavedSuccess] = useState(false);

  // Formatting helpers for rich text
  const applyFormatting = (prefix, suffix = '') => {
    setFormData(prev => ({
      ...prev,
      content: prev.content + `${prefix}نص منسق${suffix}`
    }));
  };

  const handleTitleChange = (val) => {
    const autoSlug = val.trim().toLowerCase().replace(/[^\w\u0621-\u064A\s-]/g, '').replace(/\s+/g, '-');
    setFormData(prev => ({
      ...prev,
      title: val,
      slug: prev.slug === `post-${prev.id}` || !prev.slug ? autoSlug : prev.slug,
      metaTitle: prev.metaTitle ? prev.metaTitle : val
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!formData.title || !formData.content) {
      alert('يرجى ملء عنوان المقال ومحتوى المقال الرئيسي');
      return;
    }

    onSave(formData);
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 2500);
  };

  // Live SEO Quality Scores
  const titleLen = formData.metaTitle.length;
  const descLen = formData.metaDescription.length;
  const isTitleOk = titleLen >= 40 && titleLen <= 65;
  const isDescOk = descLen >= 120 && descLen <= 165;

  return (
    <div style={{ background: 'var(--bg-main)', minHeight: '100vh', padding: '32px' }} className="animate-fade-in">
      
      {/* Top Bar */}
      <div 
        style={{
          display: 'flex',
          justify: 'space-between',
          alignItems: 'center',
          background: 'var(--bg-card)',
          padding: '20px 28px',
          borderRadius: 'var(--radius-lg)',
          boxShadow: 'var(--shadow-md)',
          border: '1px solid var(--border-color)',
          marginBottom: '32px'
        }}
      >
        <div style={{ display: 'flex', alignItems: 'center', gap: '16px' }}>
          <button 
            type="button"
            onClick={onCancel}
            className="btn-outline"
            style={{ padding: '8px 16px', fontSize: '0.88rem' }}
          >
            <ArrowRight size={18} />
            <span>العودة للمقالات</span>
          </button>
          <div>
            <h2 style={{ fontSize: '1.4rem', fontWeight: 800 }}>
              {post ? `محرر المقال: ${formData.title || post.title}` : 'إنشاء مقال وبوست جديد للمدونة'}
            </h2>
            <div style={{ fontSize: '0.8rem', color: 'var(--text-muted)' }}>محرر المقالات والـ SEO الكامل لمحركات البحث Google</div>
          </div>
        </div>

        <div style={{ display: 'flex', gap: '12px' }}>
          <button 
            type="button" 
            onClick={handleSubmit} 
            className={savedSuccess ? "btn-secondary" : "btn-primary"}
            style={{ padding: '10px 24px' }}
          >
            {savedSuccess ? (
              <>
                <Check size={18} color="#10B981" />
                <span>تم تحديث مسودة المقال. استخدم زر النشر الرئيسي لإظهاره في الموقع.</span>
              </>
            ) : (
              <>
                <Save size={18} />
                <span>حفظ المقال في المسودة</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* Main Editor Grid */}
      <form onSubmit={handleSubmit} style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(340px, 1fr))', gap: '32px' }}>
        
        {/* Right Column: Article Details & Rich Content */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: '28px' }}>
          
          {/* Card 1: Article Main Info */}
          <div className="glass-card" style={{ padding: '28px', borderRadius: 'var(--radius-lg)' }}>
            <h3 style={{ fontSize: '1.15rem', fontWeight: 800, marginBottom: '20px', display: 'flex', alignItems: 'center', gap: '8px' }}>
              <Sparkles size={20} color="var(--primary)" />
              1. معلومات المقال الرئيسية
            </h3>

            <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
              <div>
                <label style={{ display: 'block', fontSize: '0.88rem', fontWeight: 700, marginBottom: '6px' }}>عنوان المقال الرئيسي *</label>
                <input 
                  type="text" 
                  className="input-field" 
                  placeholder="مثال: دليل المستورد العربي الشامل لمعرض كانطون"
                  value={formData.title}
                  onChange={(e) => handleTitleChange(e.target.value)}
                  required
                />
              </div>

              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: '12px' }}>
                <div>
                  <label style={{ display: 'block', fontSize: '0.88rem', fontWeight: 700, marginBottom: '6px' }}>التصنيف / القسم (Category)</label>
                  <select 
                    className="input-field"
                    value={formData.category}
                    onChange={(e) => setFormData({ ...formData, category: e.target.value })}
                  >
                    {categoriesList.map((cat) => (
                      <option key={cat} value={cat}>{cat}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label style={{ display: 'block', fontSize: '0.88rem', fontWeight: 700, marginBottom: '6px' }}>اسم الكاتب / المستشار</label>
                  <input 
                    type="text" 
                    className="input-field" 
                    value={formData.author}
                    onChange={(e) => setFormData({ ...formData, author: e.target.value })}
                  />
                </div>
              </div>

              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: '12px' }}>
                <div>
                  <label style={{ display: 'block', fontSize: '0.88rem', fontWeight: 700, marginBottom: '6px' }}>وقت القراءة التقديري</label>
                  <input 
                    type="text" 
                    className="input-field" 
                    placeholder="مثال: 7 دقائق"
                    value={formData.readTime}
                    onChange={(e) => setFormData({ ...formData, readTime: e.target.value })}
                  />
                </div>

                <div>
                  <ImageUploaderInput 
                    label="🖼️ صورة المقال البارزة (رابط أو رفع من جهازك)"
                    value={formData.image}
                    onChange={(val) => setFormData({ ...formData, image: val })}
                  />
                </div>
              </div>

              <div>
                <label style={{ display: 'block', fontSize: '0.88rem', fontWeight: 700, marginBottom: '6px' }}>الملخص البارز (Excerpt)</label>
                <textarea 
                  className="input-field" 
                  rows={2}
                  placeholder="ملخص مقروء يظهر في كروت المقالات بالمدونة..."
                  value={formData.excerpt}
                  onChange={(e) => setFormData({ ...formData, excerpt: e.target.value })}
                />
              </div>

            </div>
          </div>

          {/* Card 2: Article Body Content (Rich Text) */}
          <div className="glass-card" style={{ padding: '28px', borderRadius: 'var(--radius-lg)' }}>
            <h3 style={{ fontSize: '1.15rem', fontWeight: 800, marginBottom: '14px' }}>
              2. محتوى المقال الكامل (Article Content Editor)
            </h3>

            <div 
              style={{
                display: 'flex',
                gap: '6px',
                background: 'var(--bg-main)',
                padding: '8px',
                borderRadius: 'var(--radius-sm)',
                border: '1px solid var(--border-color)',
                marginBottom: '10px',
                flexWrap: 'wrap'
              }}
            >
              <button 
                type="button" 
                onClick={() => applyFormatting('**', '**')} 
                className="btn-outline" 
                style={{ padding: '4px 10px', fontSize: '0.82rem' }}
              >
                <Bold size={14} /> <strong>خط عريض</strong>
              </button>

              <button 
                type="button" 
                onClick={() => applyFormatting('*', '*')} 
                className="btn-outline" 
                style={{ padding: '4px 10px', fontSize: '0.82rem' }}
              >
                <Italic size={14} /> <em>مائل</em>
              </button>

              <button 
                type="button" 
                onClick={() => applyFormatting('### ')} 
                className="btn-outline" 
                style={{ padding: '4px 10px', fontSize: '0.82rem' }}
              >
                <Heading1 size={14} /> <span>عنوان فقرة H3</span>
              </button>

              <button 
                type="button" 
                onClick={() => applyFormatting('\n- ')} 
                className="btn-outline" 
                style={{ padding: '4px 10px', fontSize: '0.82rem' }}
              >
                <List size={14} /> <span>قائمة نقطية</span>
              </button>
            </div>

            <textarea 
              className="input-field" 
              rows={12}
              placeholder="اكتب المقال التفصيلي هنا..."
              value={formData.content}
              onChange={(e) => setFormData({ ...formData, content: e.target.value })}
              style={{ lineHeight: 1.8, fontSize: '1rem' }}
              required
            />
          </div>

        </div>

        {/* Left Column: SEO Suite & Search Engines Live Preview */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: '28px' }}>
          
          {/* Card 3: Search Engine Optimization (SEO) */}
          <div className="glass-card" style={{ padding: '28px', borderRadius: 'var(--radius-lg)' }}>
            <h3 style={{ fontSize: '1.15rem', fontWeight: 800, marginBottom: '20px', display: 'flex', alignItems: 'center', gap: '8px' }}>
              <Globe size={20} color="var(--primary)" />
              3. إعدادات السيو والظهور في محرك البحث Google (SEO Suite)
            </h3>

            <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
              
              <div>
                <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '6px' }}>
                  <label style={{ fontSize: '0.88rem', fontWeight: 700 }}>عنوان البحث (Meta Title)</label>
                  <span style={{ fontSize: '0.78rem', color: isTitleOk ? '#10B981' : '#F59E0B', fontWeight: 700 }}>
                    {titleLen} / 60 حرف {isTitleOk ? '✓ ممتاز' : '(موصى بـ 50-60 حرف)'}
                  </span>
                </div>
                <input 
                  type="text" 
                  className="input-field" 
                  value={formData.metaTitle}
                  onChange={(e) => setFormData({ ...formData, metaTitle: e.target.value })}
                />
              </div>

              <div>
                <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '6px' }}>
                  <label style={{ fontSize: '0.88rem', fontWeight: 700 }}>وصف البحث (Meta Description)</label>
                  <span style={{ fontSize: '0.78rem', color: isDescOk ? '#10B981' : '#F59E0B', fontWeight: 700 }}>
                    {descLen} / 160 حرف {isDescOk ? '✓ ممتاز' : '(موصى بـ 140-160 حرف)'}
                  </span>
                </div>
                <textarea 
                  className="input-field" 
                  rows={3}
                  value={formData.metaDescription}
                  onChange={(e) => setFormData({ ...formData, metaDescription: e.target.value })}
                />
              </div>

              <div>
                <label style={{ display: 'block', fontSize: '0.88rem', fontWeight: 700, marginBottom: '6px' }}>الكلمات المفتاحية (Focus Keywords)</label>
                <input 
                  type="text" 
                  className="input-field" 
                  placeholder="مفصولة بفاصلة: معرض كانطون, استيراد من جوانزو"
                  value={formData.keywords}
                  onChange={(e) => setFormData({ ...formData, keywords: e.target.value })}
                />
              </div>

              <div>
                <label style={{ display: 'block', fontSize: '0.88rem', fontWeight: 700, marginBottom: '6px' }}>الرابط الدائم الفريد (URL Slug)</label>
                <input 
                  type="text" 
                  className="input-field" 
                  value={formData.slug}
                  onChange={(e) => setFormData({ ...formData, slug: e.target.value })}
                  style={{ fontFamily: 'var(--font-en)', direction: 'ltr', textAlign: 'left' }}
                />
              </div>

            </div>
          </div>

          {/* Card 4: Google Live Search Snippet Preview */}
          <div className="glass-card" style={{ padding: '28px', borderRadius: 'var(--radius-lg)' }}>
            <h3 style={{ fontSize: '1.05rem', fontWeight: 800, marginBottom: '16px', display: 'flex', alignItems: 'center', gap: '8px' }}>
              <Search size={18} color="var(--primary)" />
              معاينة مظهر المقال في نتائج بحث Google:
            </h3>

            <div 
              style={{
                background: '#FFFFFF',
                color: '#1A0DAB',
                padding: '16px',
                borderRadius: 'var(--radius-md)',
                boxShadow: '0 2px 8px rgba(0,0,0,0.08)',
                border: '1px solid #E2E8F0',
                fontFamily: 'arial, sans-serif'
              }}
            >
              <div style={{ fontSize: '0.8rem', color: '#202124', marginBottom: '2px', display: 'flex', alignItems: 'center', gap: '6px' }}>
                <span style={{ background: '#F1F5F9', padding: '2px 6px', borderRadius: '4px', fontSize: '0.72rem', color: '#475569' }}>chinaplanet.org</span>
                <span style={{ color: '#5F6368', fontSize: '0.78rem' }}>https://chinaplanet.org/blog/{formData.slug}</span>
              </div>
              <div style={{ fontSize: '1.15rem', fontWeight: 600, color: '#1A0DAB', marginBottom: '4px', cursor: 'pointer', lineHeight: 1.3 }}>
                {formData.metaTitle || formData.title || 'عنوان المقال في محرك البحث'}
              </div>
              <div style={{ fontSize: '0.88rem', color: '#4D5156', lineHeight: 1.5 }}>
                {formData.metaDescription || formData.excerpt || 'وصف المقال المتوافق مع معايير السيو والظهور في محرك البحث Google.'}
              </div>
            </div>
          </div>

        </div>

      </form>

    </div>
  );
}
