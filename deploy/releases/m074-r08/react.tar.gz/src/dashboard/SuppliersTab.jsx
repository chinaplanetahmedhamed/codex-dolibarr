import React from 'react';
import { Building2, Star, CheckCircle, MapPin, Phone, ExternalLink } from 'lucide-react';

export default function SuppliersTab() {
  const suppliers = [
    {
      id: "SUP-GZ-101",
      name: "Guangzhou ShengDa Laser & Automation Co., Ltd.",
      city: "Guangzhou, Guangdong 🇨🇳",
      specialty: "ماكينات ومعدات تقطيع وحفر بالليزر CNC",
      rating: 4.9,
      moq: "1 وحدة",
      verificationStatus: "مصنع معتمد وزيارة ميدانية مسجلة",
      contactWeChat: "Shengda_Laser_GZ"
    },
    {
      id: "SUP-FS-302",
      name: "Foshan GoldMedal Ceramic & Building Materials",
      city: "Foshan, Guangdong 🇨🇳",
      specialty: "بورسلين، سيراميك، وألواح رخام صناعي",
      rating: 4.8,
      moq: "1 حاوية 20ft",
      verificationStatus: "مصنع معتمد مع تراخيص تصدير عربية",
      contactWeChat: "Foshan_Ceramics_Export"
    },
    {
      id: "SUP-NB-884",
      name: "Ningbo Precision Motor & Auto Parts Industry",
      city: "Ningbo, Zhejiang 🇨🇳",
      specialty: "قطع غيار السيارات، أنظمة فرامل ومساعدين",
      rating: 4.95,
      moq: "200 قطعة",
      verificationStatus: "فحص جودة ISO9001 + شهادة CE",
      contactWeChat: "Ningbo_Auto_Parts"
    }
  ];

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '28px' }}>
      
      <div>
        <h3 style={{ fontSize: '1.25rem', fontWeight: 800 }}>دليل المصانع والموردين المعتمدين بالصين</h3>
        <p style={{ color: 'var(--text-muted)', fontSize: '0.9rem' }}>قاعدة بيانات المصانع الحقيقية التي تم التحقق من تراخيصها وزيارتها ميدانياً.</p>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(320px, 1fr))', gap: '24px' }}>
        {suppliers.map((sup) => (
          <div key={sup.id} className="glass-card" style={{ padding: '24px', borderRadius: 'var(--radius-md)' }}>
            
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '12px' }}>
              <span className="badge badge-blue" style={{ fontFamily: 'var(--font-en)' }}>{sup.id}</span>
              <div style={{ display: 'flex', alignItems: 'center', gap: '4px', color: '#F59E0B', fontWeight: 800, fontSize: '0.9rem' }}>
                <Star size={16} fill="#F59E0B" /> {sup.rating}
              </div>
            </div>

            <h4 style={{ fontSize: '1.05rem', fontWeight: 800, marginBottom: '6px' }}>{sup.name}</h4>
            
            <div style={{ fontSize: '0.85rem', color: 'var(--text-muted)', marginBottom: '14px', display: 'flex', alignItems: 'center', gap: '6px' }}>
              <MapPin size={14} color="var(--primary)" /> {sup.city}
            </div>

            <div style={{ background: 'var(--bg-main)', padding: '12px', borderRadius: 'var(--radius-sm)', border: '1px solid var(--border-color)', marginBottom: '16px', fontSize: '0.85rem' }}>
              <div><strong>التخصص:</strong> {sup.specialty}</div>
              <div style={{ marginTop: '4px' }}><strong>أقل كمية طلب (MOQ):</strong> {sup.moq}</div>
            </div>

            <div style={{ fontSize: '0.82rem', color: '#10B981', fontWeight: 700, display: 'flex', alignItems: 'center', gap: '6px', marginBottom: '16px' }}>
              <CheckCircle size={16} /> {sup.verificationStatus}
            </div>

            <button 
              onClick={() => alert(`بيانات التواصل المباشرة للمورد ${sup.name}: WeChat: ${sup.contactWeChat}`)}
              className="btn-outline" 
              style={{ width: '100%', justifyContent: 'center', fontSize: '0.88rem' }}
            >
              عرض معلومات الاتصال المباشرة
            </button>

          </div>
        ))}
      </div>

    </div>
  );
}
