import React, { useState } from 'react';
import { 
  ArrowRight, 
  Save, 
  Image as ImageIcon, 
  Plus, 
  Trash2, 
  Bold, 
  Italic, 
  List, 
  Heading1, 
  Sparkles, 
  Check
} from 'lucide-react';

export default function ServiceFullEditor({ service, onSave, onCancel }) {
  const [formData, setFormData] = useState({
    id: service?.id || `service-${Date.now()}`,
    title: service?.title || '',
    titleEn: service?.titleEn || '',
    titleFr: service?.titleFr || '',
    subtitle: service?.subtitle || '',
    badge: service?.badge || 'خدمة مميزة',
    icon: service?.icon || 'ShieldCheck',
    image: service?.image || '/images/inspection.webp',
    gallery: service?.gallery && service?.gallery.length 
      ? [...service.gallery] 
      : ['/images/inspection.webp', '/images/hero.webp', '/images/warehouse.webp'],
    description: service?.description || '',
    descriptionEn: service?.descriptionEn || '',
    descriptionFr: service?.descriptionFr || '',
    fullOverview: service?.fullOverview || service?.description || '',
    fullOverviewEn: service?.fullOverviewEn || '',
    fullOverviewFr: service?.fullOverviewFr || '',
    pricingInfo: service?.pricingInfo || '',
    pricingInfoEn: service?.pricingInfoEn || '',
    pricingInfoFr: service?.pricingInfoFr || '',
    features: service?.features && service?.features.length ? [...service.features] : ['', '', '', ''],
    steps: service?.steps && service?.steps.length ? service.steps.map(s => ({ ...s })) : [
      { step: 1, title: 'الدراسة والتحليل الفني', desc: 'مراجعة كافة متطلبات الصفقة والمواصفات الفنية.' },
      { step: 2, title: 'التنفيذ الميداني بالصين', desc: 'فريق عمل جوانزو يبدأ التنفيذ في الموقع المحدد.' },
      { step: 3, title: 'الفحص والتوثيق الفوتوغرافي', desc: 'إلتقاط صور وفيديوهات عالية الدقة وإعداد التقرير.' },
      { step: 4, title: 'التسليم والتأكيد النهائي', desc: 'تزويد المستورد بكافة الوثائق واعتماد التسليم.' }
    ]
  });

  const [newGalleryUrl, setNewGalleryUrl] = useState('');
  const [savedSuccess, setSavedSuccess] = useState(false);

  // Rich Text Helpers (appends markdown tags to fullOverview)
  const applyFormatting = (prefix, suffix = '') => {
    setFormData(prev => ({
      ...prev,
      fullOverview: prev.fullOverview + `${prefix}نص منسق${suffix}`
    }));
  };

  const handleAddGalleryImage = () => {
    if (newGalleryUrl.trim()) {
      setFormData(prev => ({
        ...prev,
        gallery: [...prev.gallery, newGalleryUrl.trim()]
      }));
      setNewGalleryUrl('');
    }
  };

  const handleRemoveGalleryImage = (index) => {
    setFormData(prev => ({
      ...prev,
      gallery: prev.gallery.filter((_, i) => i !== index)
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!formData.title || !formData.description) {
      alert('يرجى ملء عنوان الخدمة والوصف الرئيسي');
      return;
    }

    onSave(formData);
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 2500);
  };

  return (
    <div style={{ background: 'var(--bg-main)', minHeight: '100vh', padding: '32px' }} className="animate-fade-in">
      
      {/* Editor Top Bar */}
      <div 
        style={{
          display: 'flex',
          justify: 'space-between',
          alignItems: 'center',
          background: 'var(--bg-card)',
          padding: '20px 28px',
          borderRadius: 'var(--radius-lg)',
          boxShadow: 'var(--shadow-md)',
          border: '1px solid var(--border-color)',
          marginBottom: '32px'
        }}
      >
        <div style={{ display: 'flex', alignItems: 'center', gap: '16px' }}>
          <button 
            type="button"
            onClick={onCancel}
            className="btn-outline"
            style={{ padding: '8px 16px', fontSize: '0.88rem' }}
          >
            <ArrowRight size={18} />
            <span>العودة لوحة التحكم</span>
          </button>
          <div>
            <h2 style={{ fontSize: '1.4rem', fontWeight: 800 }}>
              {service ? `محرر صفحة الخدمة: ${formData.title || service.title}` : 'إنشاء صفحة خدمة جديدة'}
            </h2>
            <div style={{ fontSize: '0.8rem', color: 'var(--text-muted)' }}>تعديل الصور، معرض المعاينة، النصوص المنسقة، ومراحل التنفيذ</div>
          </div>
        </div>

        <div style={{ display: 'flex', gap: '12px' }}>
          <button 
            type="button" 
            onClick={handleSubmit} 
            className={savedSuccess ? "btn-secondary" : "btn-primary"}
            style={{ padding: '10px 24px' }}
          >
            {savedSuccess ? (
              <>
                <Check size={18} color="#10B981" />
                <span>تم تحديث مسودة الخدمة. استخدم زر النشر الرئيسي لإظهارها في الموقع.</span>
              </>
            ) : (
              <>
                <Save size={18} />
                <span>حفظ واعتماد التعديلات</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* Editor Layout Grid */}
      <form onSubmit={handleSubmit} style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(340px, 1fr))', gap: '32px' }}>
        
        {/* Right Column: Basic Info & Main Image & Gallery */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: '28px' }}>
          
          {/* Card 1: Basic Information */}
          <div className="glass-card" style={{ padding: '28px', borderRadius: 'var(--radius-lg)' }}>
            <h3 style={{ fontSize: '1.15rem', fontWeight: 800, marginBottom: '20px', display: 'flex', alignItems: 'center', gap: '8px' }}>
              <Sparkles size={20} color="var(--primary)" />
              1. البيانات الأساسية للخدمة
            </h3>

            <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
              <div>
                <label style={{ display: 'block', fontSize: '0.88rem', fontWeight: 700, marginBottom: '6px' }}>عنوان الخدمة الرئيسي *</label>
                <input 
                  type="text" 
                  className="input-field" 
                  placeholder="مثال: مراقبة الجودة وفحص المنتجات"
                  value={formData.title}
                  onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                  required
                />
              </div>

              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: '12px' }}>
                <div>
                  <label style={{ display: 'block', fontSize: '0.88rem', fontWeight: 700, marginBottom: '6px' }}>عنوان الخدمة بالإنجليزية</label>
                  <input type="text" className="input-field" value={formData.titleEn} onChange={(e) => setFormData({ ...formData, titleEn: e.target.value })} dir="ltr" />
                </div>
                <div>
                  <label style={{ display: 'block', fontSize: '0.88rem', fontWeight: 700, marginBottom: '6px' }}>عنوان الخدمة بالفرنسية</label>
                  <input type="text" className="input-field" value={formData.titleFr} onChange={(e) => setFormData({ ...formData, titleFr: e.target.value })} dir="ltr" />
                </div>
              </div>

              <div>
                <label style={{ display: 'block', fontSize: '0.88rem', fontWeight: 700, marginBottom: '6px' }}>العنوان الفرعي الإنجليزي</label>
                <input 
                  type="text" 
                  className="input-field" 
                  placeholder="Quality Inspection & Testing"
                  value={formData.subtitle}
                  onChange={(e) => setFormData({ ...formData, subtitle: e.target.value })}
                />
              </div>

              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: '12px' }}>
                <div>
                  <label style={{ display: 'block', fontSize: '0.88rem', fontWeight: 700, marginBottom: '6px' }}>شارة الخدمة (Badge)</label>
                  <input 
                    type="text" 
                    className="input-field" 
                    placeholder="الأكثر طلباً"
                    value={formData.badge}
                    onChange={(e) => setFormData({ ...formData, badge: e.target.value })}
                  />
                </div>

                <div>
                  <label style={{ display: 'block', fontSize: '0.88rem', fontWeight: 700, marginBottom: '6px' }}>أيقونة الخدمة</label>
                  <select 
                    className="input-field"
                    value={formData.icon}
                    onChange={(e) => setFormData({ ...formData, icon: e.target.value })}
                  >
                    <option value="ShieldCheck">🛡️ مراقبة الجودة (ShieldCheck)</option>
                    <option value="Building2">🏢 تدقيق المصانع (Building2)</option>
                    <option value="Search">🔍 البحث عن المنتجات (Search)</option>
                    <option value="Warehouse">🏭 مستودع جوانزو (Warehouse)</option>
                    <option value="Truck">🚚 شحن ولوجستيات (Truck)</option>
                    <option value="CircleDollarSign">💰 الإشراف المالي (CircleDollarSign)</option>
                  </select>
                </div>
              </div>

              <div>
                <label style={{ display: 'block', fontSize: '0.88rem', fontWeight: 700, marginBottom: '6px' }}>الوصف المختصر *</label>
                <textarea 
                  className="input-field" 
                  rows={3}
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  required
                />
              </div>

              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: '12px' }}>
                <div>
                  <label style={{ display: 'block', fontSize: '0.88rem', fontWeight: 700, marginBottom: '6px' }}>الوصف المختصر بالإنجليزية</label>
                  <textarea className="input-field" rows={3} value={formData.descriptionEn} onChange={(e) => setFormData({ ...formData, descriptionEn: e.target.value })} dir="ltr" />
                </div>
                <div>
                  <label style={{ display: 'block', fontSize: '0.88rem', fontWeight: 700, marginBottom: '6px' }}>الوصف المختصر بالفرنسية</label>
                  <textarea className="input-field" rows={3} value={formData.descriptionFr} onChange={(e) => setFormData({ ...formData, descriptionFr: e.target.value })} dir="ltr" />
                </div>
              </div>

              <div>
                <label style={{ display: 'block', fontSize: '0.88rem', fontWeight: 700, marginBottom: '6px' }}>بيانات التكلفة والرسوم الشفافة</label>
                <input 
                  type="text" 
                  className="input-field" 
                  placeholder="تبدأ رسوم الفحص الميداني من $150 لكل يوم عمل..."
                  value={formData.pricingInfo}
                  onChange={(e) => setFormData({ ...formData, pricingInfo: e.target.value })}
                />
              </div>

            </div>
          </div>

          {/* Card 2: Cover Image & Photo Gallery Manager */}
          <div className="glass-card" style={{ padding: '28px', borderRadius: 'var(--radius-lg)' }}>
            <h3 style={{ fontSize: '1.15rem', fontWeight: 800, marginBottom: '20px', display: 'flex', alignItems: 'center', gap: '8px' }}>
              <ImageIcon size={20} color="var(--primary)" />
              2. صورة الغلاف ومعرض صور الخدمة (Gallery)
            </h3>

            {/* Main Cover Image Input & Preview */}
            <div style={{ marginBottom: '24px' }}>
              <label style={{ display: 'block', fontSize: '0.88rem', fontWeight: 700, marginBottom: '6px' }}>صورة الغلاف الرئيسية</label>
              <input 
                type="text" 
                className="input-field" 
                placeholder="/images/inspection.webp أو رابط صورة مباشر"
                value={formData.image}
                onChange={(e) => setFormData({ ...formData, image: e.target.value })}
                style={{ marginBottom: '10px' }}
              />

              {formData.image && (
                <div style={{ borderRadius: 'var(--radius-md)', overflow: 'hidden', height: '180px', border: '1px solid var(--border-color)' }}>
                  <img src={formData.image} alt="Cover Preview" style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
                </div>
              )}
            </div>

            {/* Multi-Photo Gallery Section */}
            <div style={{ borderTop: '1px solid var(--border-color)', paddingTop: '18px' }}>
              <label style={{ display: 'block', fontSize: '0.88rem', fontWeight: 700, marginBottom: '8px' }}>إضافة صور لمعرض الخدمة (Gallery Photos)</label>

              <div style={{ display: 'flex', gap: '8px', marginBottom: '16px' }}>
                <input 
                  type="text" 
                  className="input-field" 
                  placeholder="أدخل رابط صورة جديدة للمعرض (/images/... أو URL)"
                  value={newGalleryUrl}
                  onChange={(e) => setNewGalleryUrl(e.target.value)}
                />
                <button 
                  type="button"
                  onClick={handleAddGalleryImage} 
                  className="btn-primary"
                  style={{ padding: '0 16px', whiteSpace: 'nowrap' }}
                >
                  <Plus size={16} /> إضافة صورة
                </button>
              </div>

              {/* Gallery Grid Preview */}
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '10px' }}>
                {formData.gallery.map((imgUrl, i) => (
                  <div key={i} style={{ position: 'relative', height: '90px', borderRadius: 'var(--radius-sm)', overflow: 'hidden', border: '1px solid var(--border-color)' }}>
                    <img src={imgUrl} alt={`Gallery ${i}`} style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
                    <button 
                      type="button"
                      onClick={() => handleRemoveGalleryImage(i)}
                      style={{ position: 'absolute', top: '4px', left: '4px', background: 'rgba(211, 47, 47, 0.85)', color: '#FFF', border: 'none', borderRadius: '50%', width: '24px', height: '24px', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center' }}
                    >
                      <Trash2 size={12} />
                    </button>
                  </div>
                ))}
              </div>
            </div>

          </div>

        </div>

        {/* Left Column: Rich Text Overview & Steps & Features */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: '28px' }}>
          
          {/* Card 3: Rich Text Editor for Full Overview */}
          <div className="glass-card" style={{ padding: '28px', borderRadius: 'var(--radius-lg)' }}>
            <h3 style={{ fontSize: '1.15rem', fontWeight: 800, marginBottom: '14px' }}>
              3. محرر النصوص المنسق للنظرة العامة (Rich Text Editor)
            </h3>

            {/* Rich Text Toolbar Buttons */}
            <div 
              style={{
                display: 'flex',
                gap: '6px',
                background: 'var(--bg-main)',
                padding: '8px',
                borderRadius: 'var(--radius-sm)',
                border: '1px solid var(--border-color)',
                marginBottom: '10px',
                flexWrap: 'wrap'
              }}
            >
              <button 
                type="button" 
                onClick={() => applyFormatting('**', '**')} 
                className="btn-outline" 
                style={{ padding: '4px 10px', fontSize: '0.82rem' }}
                title="خط عريض Bold"
              >
                <Bold size={14} /> <strong>خط عريض</strong>
              </button>

              <button 
                type="button" 
                onClick={() => applyFormatting('*', '*')} 
                className="btn-outline" 
                style={{ padding: '4px 10px', fontSize: '0.82rem' }}
                title="خط مائل Italic"
              >
                <Italic size={14} /> <em>مائل</em>
              </button>

              <button 
                type="button" 
                onClick={() => applyFormatting('### ')} 
                className="btn-outline" 
                style={{ padding: '4px 10px', fontSize: '0.82rem' }}
                title="عنوان رئيسي H2"
              >
                <Heading1 size={14} /> <span>عنوان بارز</span>
              </button>

              <button 
                type="button" 
                onClick={() => applyFormatting('\n- ')} 
                className="btn-outline" 
                style={{ padding: '4px 10px', fontSize: '0.82rem' }}
                title="قائمة نقطية"
              >
                <List size={14} /> <span>قائمة نقطية</span>
              </button>
            </div>

            <textarea 
              className="input-field" 
              rows={8}
              placeholder="اكتب النظرة العامة والشرح التفصيلي للخدمة..."
              value={formData.fullOverview}
              onChange={(e) => setFormData({ ...formData, fullOverview: e.target.value })}
              style={{ lineHeight: 1.7, fontSize: '0.98rem' }}
            />
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: '12px', marginTop: '12px' }}>
              <textarea className="input-field" rows={6} placeholder="Detailed overview in English" value={formData.fullOverviewEn} onChange={(e) => setFormData({ ...formData, fullOverviewEn: e.target.value })} dir="ltr" />
              <textarea className="input-field" rows={6} placeholder="Présentation détaillée en français" value={formData.fullOverviewFr} onChange={(e) => setFormData({ ...formData, fullOverviewFr: e.target.value })} dir="ltr" />
            </div>
          </div>

          {/* Card 4: Execution Steps 1 to 4 */}
          <div className="glass-card" style={{ padding: '28px', borderRadius: 'var(--radius-lg)' }}>
            <h3 style={{ fontSize: '1.15rem', fontWeight: 800, marginBottom: '16px' }}>
              4. مراحل وتفاصيل التنفيذ الـ 4
            </h3>

            <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
              {formData.steps.map((st, i) => (
                <div key={i} style={{ background: 'var(--bg-main)', padding: '14px', borderRadius: 'var(--radius-md)', border: '1px solid var(--border-color)' }}>
                  <div style={{ fontWeight: 800, fontSize: '0.85rem', color: 'var(--primary)', marginBottom: '6px' }}>المرحلة 0{i + 1}:</div>
                  <input 
                    type="text" 
                    className="input-field" 
                    placeholder="عنوان المرحلة"
                    value={st.title}
                    onChange={(e) => {
                      const newSteps = [...formData.steps];
                      newSteps[i].title = e.target.value;
                      setFormData({ ...formData, steps: newSteps });
                    }}
                    style={{ marginBottom: '8px', fontWeight: 700 }}
                  />
                  <textarea 
                    className="input-field" 
                    rows={2}
                    placeholder="شرح تفاصيل هذه المرحلة..."
                    value={st.desc}
                    onChange={(e) => {
                      const newSteps = [...formData.steps];
                      newSteps[i].desc = e.target.value;
                      setFormData({ ...formData, steps: newSteps });
                    }}
                  />
                </div>
              ))}
            </div>
          </div>

          {/* Card 5: Features List */}
          <div className="glass-card" style={{ padding: '28px', borderRadius: 'var(--radius-lg)' }}>
            <h3 style={{ fontSize: '1.15rem', fontWeight: 800, marginBottom: '16px' }}>
              5. مميزات ونقاط القوة في الخدمة
            </h3>

            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: '10px' }}>
              {formData.features.map((feat, i) => (
                <input 
                  key={i}
                  type="text" 
                  className="input-field" 
                  placeholder={`ميزة رقم ${i + 1}`}
                  value={feat}
                  onChange={(e) => {
                    const newFeats = [...formData.features];
                    newFeats[i] = e.target.value;
                    setFormData({ ...formData, features: newFeats });
                  }}
                />
              ))}
            </div>
          </div>

        </div>

      </form>

    </div>
  );
}
