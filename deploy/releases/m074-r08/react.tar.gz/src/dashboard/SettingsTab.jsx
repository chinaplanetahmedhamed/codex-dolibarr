import React, { useState } from 'react';
import { Settings, Save, RefreshCw, Globe, DollarSign, Building, Check } from 'lucide-react';

export default function SettingsTab() {
  const [rates, setRates] = useState({
    USD_RMB: 7.24,
    USD_EGP: 50.00,
    USD_SAR: 3.75,
    USD_AED: 3.67
  });

  const [saved, setSaved] = useState(false);

  const handleSave = (e) => {
    e.preventDefault();
    setSaved(true);
    setTimeout(() => setSaved(false), 3000);
  };

  return (
    <div style={{ maxWidth: '720px' }}>
      
      <div style={{ marginBottom: '28px' }}>
        <h3 style={{ fontSize: '1.25rem', fontWeight: 800 }}>إعدادات النظام وأسعار صرف العملات</h3>
        <p style={{ color: 'var(--text-muted)', fontSize: '0.9rem' }}>التحكم بالأسعار التقديرية للحاسبة وأسعار الصرف الحية للشركاء.</p>
      </div>

      <form onSubmit={handleSave} className="glass-card" style={{ padding: '32px', borderRadius: 'var(--radius-md)', display: 'flex', flexDirection: 'column', gap: '20px' }}>
        
        <h4 style={{ fontSize: '1.05rem', fontWeight: 800, display: 'flex', alignItems: 'center', gap: '8px' }}>
          <DollarSign size={20} color="var(--primary)" />
          أسعار صرف العملات التقديرية (مقابل الدولار الأمريكي $1 USD):
        </h4>

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: '16px' }}>
          <div>
            <label style={{ display: 'block', fontSize: '0.85rem', fontWeight: 700, marginBottom: '6px' }}>اليوان الصيني (RMB ¥)</label>
            <input 
              type="number" 
              step="0.01"
              className="input-field" 
              value={rates.USD_RMB}
              onChange={(e) => setRates({ ...rates, USD_RMB: Number(e.target.value) })}
            />
          </div>

          <div>
            <label style={{ display: 'block', fontSize: '0.85rem', fontWeight: 700, marginBottom: '6px' }}>الريال السعودي (SAR)</label>
            <input 
              type="number" 
              step="0.01"
              className="input-field" 
              value={rates.USD_SAR}
              onChange={(e) => setRates({ ...rates, USD_SAR: Number(e.target.value) })}
            />
          </div>

          <div>
            <label style={{ display: 'block', fontSize: '0.85rem', fontWeight: 700, marginBottom: '6px' }}>الجنيه المصري (EGP)</label>
            <input 
              type="number" 
              step="0.01"
              className="input-field" 
              value={rates.USD_EGP}
              onChange={(e) => setRates({ ...rates, USD_EGP: Number(e.target.value) })}
            />
          </div>

          <div>
            <label style={{ display: 'block', fontSize: '0.85rem', fontWeight: 700, marginBottom: '6px' }}>الدرهم الإماراتي (AED)</label>
            <input 
              type="number" 
              step="0.01"
              className="input-field" 
              value={rates.USD_AED}
              onChange={(e) => setRates({ ...rates, USD_AED: Number(e.target.value) })}
            />
          </div>
        </div>

        <div style={{ borderTop: '1px solid var(--border-color)', paddingTop: '20px', marginTop: '10px' }}>
          <h4 style={{ fontSize: '1.05rem', fontWeight: 800, marginBottom: '12px', display: 'flex', alignItems: 'center', gap: '8px' }}>
            <Building size={20} color="var(--primary)" />
            بيانات الفرع الرئيسي بجوانزو:
          </h4>
          <div style={{ fontSize: '0.88rem', color: 'var(--text-muted)', lineHeight: 1.6 }}>
            مكتب رقم 1011-1012، مبنى 132-1، شارع دونغ فنغ شي، حي يويشيو، مدينة جوانزو، مقاطعة غوانغدونغ، الصين.<br />
            الهاتف المباشر: +8613480652510 | البريد: info@chinaplanet.org
          </div>
        </div>

        <button type="submit" className={saved ? "btn-secondary" : "btn-primary"} style={{ padding: '12px', justifyContent: 'center', marginTop: '10px' }}>
          {saved ? (
            <>
              <Check size={18} color="#10B981" />
              <span>تم حفظ الإعدادات والتحديث بنجاح!</span>
            </>
          ) : (
            <>
              <Save size={18} />
              <span>حفظ الإعدادات الفورية</span>
            </>
          )}
        </button>

      </form>

    </div>
  );
}
