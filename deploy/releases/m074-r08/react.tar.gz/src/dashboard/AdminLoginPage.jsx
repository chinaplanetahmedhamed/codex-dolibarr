import React, { useState } from "react";
import { ArrowRight, Lock, LogIn, Mail, ShieldCheck } from "lucide-react";

export default function AdminLoginPage({ onLogin, onGoHome }) {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [errorMessage, setErrorMessage] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = async (event) => {
    event.preventDefault();
    setErrorMessage("");
    setIsSubmitting(true);
    try {
      await onLogin(email, password);
    } catch (error) {
      setErrorMessage(error?.message || "تعذر تسجيل الدخول.");
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <main style={{ minHeight: "100vh", background: "linear-gradient(135deg, #0F172A, #1E293B)", color: "#fff", display: "grid", placeItems: "center", padding: "88px 20px 30px", position: "relative" }}>
      <button type="button" onClick={onGoHome} className="btn-outline" style={{ position: "absolute", top: "24px", right: "24px", color: "#fff", borderColor: "rgba(255,255,255,.25)" }}>
        <ArrowRight size={18} /> العودة للموقع
      </button>

      <section className="glass-card animate-fade-in" style={{ width: "100%", maxWidth: "440px", padding: "36px", borderRadius: "24px", border: "1px solid rgba(255,255,255,.15)", background: "rgba(15,23,42,.82)" }}>
        <div style={{ textAlign: "center", marginBottom: "28px" }}>
          <div style={{ background: "rgba(183,28,28,.18)", width: "64px", height: "64px", borderRadius: "50%", border: "1px solid var(--primary)", display: "grid", placeItems: "center", margin: "0 auto 16px" }}>
            <ShieldCheck size={32} color="var(--primary)" />
          </div>
          <h1 style={{ fontSize: "1.45rem", fontWeight: 900, marginBottom: "6px" }}>لوحة تحرير موقع كوكب الصين</h1>
          <p style={{ fontSize: ".86rem", color: "#94A3B8" }}>دخول الموظفين المصرح لهم فقط</p>
        </div>

        {errorMessage && <div role="alert" style={{ background: "rgba(211,47,47,.2)", border: "1px solid #D32F2F", color: "#FF8A80", padding: "12px 16px", borderRadius: "12px", fontSize: ".86rem", fontWeight: 800, marginBottom: "20px", textAlign: "center" }}>{errorMessage}</div>}

        <form onSubmit={handleSubmit} style={{ display: "flex", flexDirection: "column", gap: "18px" }}>
          <label style={{ display: "grid", gap: "6px", fontSize: ".85rem", fontWeight: 700 }}>
            البريد الإلكتروني
            <span style={{ position: "relative" }}>
              <input type="email" required autoComplete="username" className="input-field" value={email} onChange={(event) => setEmail(event.target.value)} style={{ paddingRight: "42px", background: "rgba(255,255,255,.05)", color: "#fff", borderColor: "rgba(255,255,255,.2)" }} />
              <Mail size={18} color="#94A3B8" style={{ position: "absolute", right: "14px", top: "50%", transform: "translateY(-50%)" }} />
            </span>
          </label>

          <label style={{ display: "grid", gap: "6px", fontSize: ".85rem", fontWeight: 700 }}>
            كلمة المرور
            <span style={{ position: "relative" }}>
              <input type="password" required autoComplete="current-password" className="input-field" value={password} onChange={(event) => setPassword(event.target.value)} style={{ paddingRight: "42px", background: "rgba(255,255,255,.05)", color: "#fff", borderColor: "rgba(255,255,255,.2)" }} />
              <Lock size={18} color="#94A3B8" style={{ position: "absolute", right: "14px", top: "50%", transform: "translateY(-50%)" }} />
            </span>
          </label>

          <button type="submit" disabled={isSubmitting} className="btn-primary" style={{ width: "100%", justifyContent: "center", padding: "14px", marginTop: "8px", opacity: isSubmitting ? .7 : 1 }}>
            <LogIn size={20} /> {isSubmitting ? "جاري التحقق..." : "دخول لوحة التحرير"}
          </button>
        </form>
      </section>
    </main>
  );
}
