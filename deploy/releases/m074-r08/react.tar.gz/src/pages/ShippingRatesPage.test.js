import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';

const source = await readFile(new URL('./ShippingRatesPage.jsx', import.meta.url), 'utf8');
const styles = await readFile(new URL('../index.css', import.meta.url), 'utf8');

test('shipping page exposes Arabic, English and French customer copy', () => {
  assert.match(source, /const COPY =/);
  assert.match(source, /ar:/);
  assert.match(source, /en:/);
  assert.match(source, /fr:/);
});

test('shipping booking is explicitly a request and has accessible status feedback', () => {
  assert.match(source, /لا يؤكد مساحة أو حجزاً/);
  assert.match(source, /does not confirm space or a carrier booking/);
  assert.match(source, /role="status"/);
  assert.match(source, /aria-live="polite"/);
  assert.match(source, /terms_accepted/);
});

test('selecting a published price reveals and focuses the booking form', () => {
  assert.match(source, /const selectRate=/);
  assert.match(source, /className="shipping-rate-price"/);
  assert.match(source, /onClick=\{\(\)=>selectRate\(rate\)\}/);
  assert.match(source, /form\.scrollIntoView\(\{behavior:reduceMotion\?'auto':'smooth',block:'start'\}\)/);
  assert.match(source, /nameInputRef\.current\?\.focus\(\{preventScroll:true\}\)/);
  assert.match(source, /<form ref=\{bookingFormRef\}/);
  assert.match(styles, /\.shipping-booking-card[^}]*scroll-margin-top:/);
});

test('public search is limited to supported FCL container types', () => {
  for (const container of ['20GP', '40GP', '40HQ']) assert.match(source, new RegExp(`<option>${container}<\\/option>`));
  assert.doesNotMatch(source, /<option>LCL<\/option>/);
});

test('customer chooses dependent country, POL and POD options instead of typing ports', () => {
  assert.match(source, /fetchShippingRouteOptions/);
  assert.match(source, /destinationCountry/);
  assert.match(source, /loadingPorts/);
  assert.match(source, /destinationPorts/);
  assert.match(source, /<select required aria-label=\{text\.pol\}/);
  assert.match(source, /<select required aria-label=\{text\.pod\}/);
  assert.doesNotMatch(source, /<input required maxLength="80" value=\{filters\.pol\}/);
  assert.doesNotMatch(source, /<input required maxLength="80" value=\{filters\.pod\}/);
});

test('Alexandria is one search option while every result card identifies its exact terminal', () => {
  assert.match(source, /publicShippingDestination\(filters\.country_code,route\.pod\)/);
  assert.match(source, /className="shipping-terminal"/);
  assert.match(source, /terminalLabel\(rate\.country_code,rate\.pod,text\.terminalNotSpecified\)/);
  assert.match(source, /المحطة غير محددة/);
  assert.match(source, /Terminal not specified/);
  assert.match(styles, /\.shipping-rate-grid \.shipping-terminal/);
});

test('Palestine uses the exact approved customer label in every public locale', () => {
  assert.match(source, /PS:\s*\{\s*ar:\s*'فلسطين',\s*en:\s*'Palestine',\s*fr:\s*'Palestine'\s*\}/);
  assert.match(source, /COUNTRY_LABEL_OVERRIDES\[country\.code\]\?\.\[locale\]/);
  assert.doesNotMatch(source, /Israel|إسرائيل|Israël/);
});

test('exact route search shows a public historical price reference chart', () => {
  assert.match(source, /fetchShippingRateTrend/);
  assert.match(source, /ShippingPriceTrendChart/);
  assert.match(source, /reference_only|مرجع تاريخي فقط/);
  assert.match(source, /role="img"/);
  assert.doesNotMatch(source, /cost_price|supplier_cost|base_margin/);
});

test('grouped Alexandria search requests trend data and renders terminal series separately', () => {
  assert.match(source, /fetchShippingRateTrend\(filters\)/);
  assert.match(source, /groupShippingTrendByCurrency\(trend\)/);
  assert.match(source, /trendGroupedIntro/);
  assert.match(source, /terminalName\(series\.pod\)/);
  assert.match(source, /TREND_COLORS/);
  assert.match(source, /groupedDestination=trend\.grouped_destination===true/);
  assert.match(source, /groupedDestination\?text\.trendGroupedIntro:text\.trendIntro/);
  assert.doesNotMatch(source, /visibleSeries>1\?text\.trendGroupedIntro/);
  assert.doesNotMatch(source, /groupedDestination\?Promise\.resolve\(\{points:\[\]\}\)/);
  assert.doesNotMatch(source, /!isGroupedShippingDestination\(filters\.country_code,filters\.pod\).*ShippingPriceTrendChart/);
});

test('historical trend waits for at least three distinct public points', () => {
  assert.match(source, /new Set\(series\.points\.map/);
  assert.match(source, /size>=3/);
});

test('rate cards expose only public inclusions, exclusions and confirmation gaps', () => {
  assert.match(source, /rate\.included/);
  assert.match(source, /rate\.excluded/);
  assert.match(source, /rate\.transit_time\|\|text\.confirmReview/);
  assert.match(source, /rate\.free_time\|\|text\.confirmReview/);
});
