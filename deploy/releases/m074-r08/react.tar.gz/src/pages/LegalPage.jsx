import React from 'react';
import { Building2, FileText, LockKeyhole, ShieldCheck } from 'lucide-react';
import SEOHead from '../components/SEOHead';
import PageHero from '../components/PageHero';
import { useI18n } from '../i18n/I18nContext';

const COPY = {
  ar: {
    updated: 'آخر تحديث: 29 أغسطس 2026',
    privacy: {
      badge: 'الخصوصية وحماية البيانات', title: 'سياسة خصوصية موقع كوكب الصين', description: 'نوضح هنا البيانات التي نستقبلها عند إرسال طلب عام، ولماذا نستخدمها، وكيف نحمي حدودها.',
      sections: [
        ['من يدير الطلب', 'China Planet هي العلامة العامة للموقع. يحدد عرض العمل أو العقد أو الفاتورة الكيان القانوني المتعاقد، وقد يكون Vision Trading Ltd. أو الكيان المذكور صراحة في المستند.'],
        ['البيانات التي نستقبلها', 'قد نستقبل الاسم، الشركة، الهاتف أو واتساب، البريد، دولة الوصول، المنتج، الكمية، وصف البضاعة والملاحظات التي ترسلها. تسجل الخوادم بيانات تقنية محدودة للحماية ومنع الإساءة.'],
        ['الغرض والمشاركة', 'نستخدم البيانات لمراجعة الطلب والرد ومنع التكرار والإساءة وتسليم الطلب بأمان إلى فريق ChinaPlanetOS/Dolibarr. لا ننشر بياناتك ولا نعرض الموردين أو التكلفة أو الملاحظات الداخلية في الموقع العام.'],
        ['الاحتفاظ والحقوق', 'نحتفظ بالطلب بقدر ما يلزم للمتابعة والالتزامات التجارية والقانونية. يمكنك طلب التصحيح أو الحذف عندما يسمح القانون عبر info@chinaplanet.org. لا ترسل أسرار المورد أو وثائق هوية أو بيانات دفع داخل النموذج العام.'],
      ],
    },
    terms: {
      badge: 'شروط استخدام الموقع', title: 'شروط الطلبات والأسعار العامة', description: 'الموقع يساعدك على الاستكشاف وإرسال طلب مراجعة؛ ولا ينشئ تلقائياً حجزاً أو عقداً أو طلب بيع معتمداً.',
      sections: [
        ['الطلبات العامة', 'إرسال نموذج توريد أو تسعير أو شحن يعني طلب مراجعة فقط. لا يصبح الطلب عرضاً ملزماً أو حجز ناقل أو أمر بيع إلا بمستند مكتوب ومعتمد من الكيان المتعاقد والعميل.'],
        ['الأسعار والشحن', 'الأسعار المنشورة مؤشرات تجارية ضمن المسار والحاوية وفترة الصلاحية المعروضة. الرسوم المحلية في المنشأ والوجهة والجمارك والضرائب والخدمات غير المذكورة صراحة ليست مشمولة. وقت العبور والـfree time يخضعان لتأكيد الناقل والميناء.'],
        ['الكتالوج ومخطط الحاوية', 'بيانات المنتجات تأتي من WooCommerce. لا تُستخدم التعبئة في الحساب إلا إذا كان عدد القطع وحجم الكرتون مكتملين. المخطط تقديري للحجم والحمولة وليس خطة رص أو تثبيت أو توزيع أحمال محاور.'],
        ['الهوية ونطاق الخدمة', 'China Planet علامة التسويق والتواصل العام. يحدد عرض العمل اسم الكيان القانوني المتعاقد ونطاق الخدمة والرسوم والمسؤوليات والقانون المطبق قبل التنفيذ.'],
      ],
    },
  },
  en: {
    updated: 'Last updated: 29 August 2026',
    privacy: { badge: 'Privacy and data protection', title: 'China Planet website privacy policy', description: 'This page explains what a public request collects, why it is used and how its boundaries are protected.', sections: [
      ['Who handles the request', 'China Planet is the public-facing brand. The written proposal, contract or invoice identifies the contracting legal entity, which may be Vision Trading Ltd. or the entity expressly named in that document.'],
      ['Data we receive', 'We may receive your name, company, phone or WhatsApp, email, destination, product, quantity, cargo description and notes. Limited technical logs support security and abuse prevention.'],
      ['Purpose and sharing', 'We use the data to review and answer the request, prevent abuse and deliver it securely to the ChinaPlanetOS/Dolibarr team. We do not publish your data or expose suppliers, costs or internal notes in the public website.'],
      ['Retention and your choices', 'Requests are retained as needed for follow-up and business or legal obligations. You may request correction or deletion where applicable at info@chinaplanet.org. Do not send supplier secrets, identity documents or payment data through a public form.'],
    ] },
    terms: { badge: 'Website terms', title: 'Terms for public requests and rates', description: 'The website supports discovery and review requests; it does not automatically create a booking, contract or approved sales order.', sections: [
      ['Public requests', 'A sourcing, quotation or shipping form creates a review request only. It becomes binding only through a written document approved by both the named contracting entity and the customer.'],
      ['Rates and shipping', 'Published rates are commercial indications for the displayed route, equipment and validity. Origin and destination local charges, customs, taxes and unlisted services are excluded. Transit time and free time require carrier and port confirmation.'],
      ['Catalogue and container planner', 'Product data comes from WooCommerce. Packing is calculated only when pieces per carton and carton volume are complete. The planner is a volume and payload estimate, not a stowage, securing or axle-load plan.'],
      ['Identity and scope', 'China Planet is the public marketing and communication brand. The proposal identifies the contracting legal entity, service scope, fees, responsibilities and applicable terms before work begins.'],
    ] },
  },
  fr: {
    updated: 'Dernière mise à jour : 29 août 2026',
    privacy: { badge: 'Confidentialité et données', title: 'Politique de confidentialité du site China Planet', description: "Cette page explique les données reçues lors d'une demande publique, leur usage et leur protection.", sections: [
      ['Responsable de la demande', "China Planet est la marque publique. L'offre, le contrat ou la facture précise l'entité juridique contractante, qui peut être Vision Trading Ltd. ou l'entité expressément désignée."],
      ['Données reçues', "Nous pouvons recevoir le nom, la société, le téléphone ou WhatsApp, l'e-mail, la destination, le produit, la quantité, la description et les remarques. Des journaux techniques limités servent à la sécurité."],
      ['Finalité et partage', "Les données servent à étudier la demande, répondre, prévenir les abus et la transmettre de façon sécurisée à ChinaPlanetOS/Dolibarr. Elles ne sont pas publiées et le site n'expose ni fournisseurs, ni coûts, ni notes internes."],
      ['Conservation et droits', "Les demandes sont conservées pour le suivi et les obligations commerciales ou légales. Vous pouvez demander rectification ou suppression, lorsque possible, à info@chinaplanet.org. N'envoyez pas de secrets fournisseur, pièce d'identité ou données de paiement dans un formulaire public."],
    ] },
    terms: { badge: "Conditions d'utilisation", title: 'Conditions des demandes et tarifs publics', description: "Le site permet de découvrir les services et d'envoyer une demande à étudier ; il ne crée pas automatiquement une réservation, un contrat ou une commande validée.", sections: [
      ['Demandes publiques', "Un formulaire d'achat, de devis ou de transport crée uniquement une demande d'étude. Un engagement nécessite un document écrit accepté par le client et l'entité contractante désignée."],
      ['Tarifs et transport', "Les tarifs publiés sont indicatifs pour la route, l'équipement et la validité affichés. Les frais locaux origine/destination, douanes, taxes et services non cités sont exclus. Transit et franchise nécessitent confirmation."],
      ['Catalogue et planificateur', "Les produits proviennent de WooCommerce. Le calcul exige un nombre de pièces et un volume carton complets. Il s'agit d'une estimation de volume et charge, pas d'un plan d'arrimage ou de répartition par essieu."],
      ['Identité et périmètre', "China Planet est la marque publique de communication. L'offre précise l'entité juridique contractante, le périmètre, les frais, responsabilités et conditions applicables avant exécution."],
    ] },
  },
};

export default function LegalPage({ kind = 'privacy', onGoHome }) {
  const { locale } = useI18n();
  const copy = COPY[locale] || COPY.ar;
  const page = copy[kind] || copy.privacy;
  return <main className="marketing-page legal-page">
    <SEOHead title={`${page.title} | China Planet`} description={page.description} locale={locale} />
    <PageHero badge={page.badge} title={page.title} description={page.description} onGoHome={onGoHome} />
    <section className="container legal-content">
      <div className="legal-updated"><ShieldCheck size={18} />{copy.updated}</div>
      <div className="legal-grid">{page.sections.map(([title, body], index) => {
        const Icon = index === 0 ? Building2 : index === 1 ? FileText : LockKeyhole;
        return <article key={title}><Icon size={22} /><div><h2>{title}</h2><p>{body}</p></div></article>;
      })}</div>
    </section>
  </main>;
}
