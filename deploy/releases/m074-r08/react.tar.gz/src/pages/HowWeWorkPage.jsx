import React from 'react';
import { CheckCircle2, ClipboardCheck, FileSearch, Handshake, PackageCheck, SearchCheck, Ship } from 'lucide-react';
import ContactCtaSection from '../components/ContactCtaSection';
import PageHero from '../components/PageHero';
import SEOHead from '../components/SEOHead';
import { useI18n } from '../i18n/I18nContext';

const PROCESS_ICONS = [FileSearch, SearchCheck, Handshake, ClipboardCheck, CheckCircle2, PackageCheck, Ship];

const PROCESS_COPY = {
  ar: [
    ['الاستشارة وفهم الطلب', 'نراجع المنتج والكمية والبلد المستهدف والميزانية والمواصفات المتاحة.'],
    ['البحث واختيار الموردين', 'نحدد موردين مناسبين ونقارن القدرة والعروض وشروط التعامل.'],
    ['التفاوض واعتماد العرض', 'نتفاوض على المواصفات والسعر والمدة والدفع، ثم يعتمد العميل العرض المناسب.'],
    ['العينة والعقد', 'ننظم العينة عند الحاجة ونثبت الشروط الفنية والتجارية ونقاط الموافقة.'],
    ['متابعة الإنتاج', 'نتابع مراحل التنفيذ والمواعيد والملاحظات المتفق على توثيقها.'],
    ['الفحص والتجميع', 'يُنفذ الفحص ضمن النطاق، ثم تُجمع الطرود وتُجهز مستندات الشحنة.'],
    ['الشحن والمتابعة', 'ننسق وسيلة الشحن المناسبة ونشارك التحديثات والمستندات المتاحة.'],
  ],
  en: [
    ['Consultation and requirements', 'We review the product, quantity, destination, budget and available specifications.'],
    ['Supplier sourcing and selection', 'We identify suitable suppliers and compare capability, quotations and terms.'],
    ['Negotiation and offer approval', 'We negotiate specifications, price, lead time and payment before the client approves an offer.'],
    ['Sample and agreement', 'When needed, we organize a sample and document technical, commercial and approval terms.'],
    ['Production follow-up', 'We monitor agreed production stages, milestones and documented observations.'],
    ['Inspection and consolidation', 'Inspection is performed within scope, then packages are consolidated and shipping documents prepared.'],
    ['Shipping and follow-up', 'We coordinate the suitable shipping method and share available updates and documents.'],
  ],
  fr: [
    ['Conseil et compréhension du besoin', 'Nous examinons le produit, la quantité, la destination, le budget et les spécifications disponibles.'],
    ['Recherche et sélection des fournisseurs', 'Nous identifions les fournisseurs adaptés et comparons leurs capacités, offres et conditions.'],
    ["Négociation et validation de l'offre", "Nous négocions les spécifications, le prix, le délai et le paiement avant validation par le client."],
    ['Échantillon et accord', "Si nécessaire, nous organisons un échantillon et documentons les conditions techniques et commerciales."],
    ['Suivi de production', 'Nous suivons les étapes, les délais et les observations convenues.'],
    ['Inspection et groupage', "Le contrôle est réalisé selon le périmètre convenu, puis les colis sont groupés et les documents préparés."],
    ['Transport et suivi', 'Nous coordonnons le mode de transport adapté et partageons les mises à jour et documents disponibles.'],
  ],
};

export default function HowWeWorkPage({ onGoHome, onOpenQuoteModal, onOpenContact, siteInfo }) {
  const { locale, t } = useI18n();
  const processSteps = PROCESS_ICONS.map((icon, index) => ({ icon, title: PROCESS_COPY[locale][index][0], text: PROCESS_COPY[locale][index][1] }));
  return (
    <main className="marketing-page">
      <SEOHead title={`${t('nav.howWeWork')} | China Planet`} description={t('work.description')} locale={locale} />
      <PageHero
        badge={t('work.badge')}
        title={t('work.title')}
        description={t('work.description')}
        onGoHome={onGoHome}
      />
      <section style={{ padding: '82px 0', background: 'var(--bg-card)' }}>
        <div className="container process-page-grid">
          {processSteps.map(({ icon: Icon, title, text }, index) => (
            <article className="glass-card process-page-step" key={title}>
              <div className="process-page-step-head">
                <div className="process-page-step-icon"><Icon size={25} /></div>
                <strong>{String(index + 1).padStart(2, '0')}</strong>
              </div>
              <h2>{title}</h2>
              <p>{text}</p>
            </article>
          ))}
        </div>
      </section>
      <section style={{ padding: '70px 0', background: 'var(--bg-main)' }}>
        <div className="container process-note-panel">
          <h2>{t('work.costTitle')}</h2>
          <p>{t('work.costText')}</p>
        </div>
      </section>
      <ContactCtaSection onOpenQuoteModal={onOpenQuoteModal} onOpenContact={onOpenContact} siteInfo={siteInfo} />
    </main>
  );
}
