import React from 'react';
import AboutTrustSection from '../components/AboutTrustSection';
import ContactCtaSection from '../components/ContactCtaSection';
import PageHero from '../components/PageHero';
import SEOHead from '../components/SEOHead';
import TeamSection from '../components/TeamSection';
import EvidenceSection from '../components/EvidenceSection';
import { useI18n } from '../i18n/I18nContext';

export default function AboutPage({ onGoHome, onOpenQuoteModal, onOpenContact, teamMembers, siteInfo }) {
  const { locale, t } = useI18n();
  return (
    <main className="marketing-page">
      <SEOHead title={`${t('about.badge')} | China Planet & Vision Trading`} description={t('about.description')} image="/images/founder/ahmed-hamed-20260413.webp" locale={locale} />
      <PageHero
        badge={t('about.badge')}
        title={t('about.title')}
        description={t('about.description')}
        onGoHome={onGoHome}
      />
      <AboutTrustSection onOpenQuoteModal={onOpenQuoteModal} />
      <EvidenceSection />
      <TeamSection onOpenQuoteModal={onOpenQuoteModal} teamMembers={teamMembers} siteInfo={siteInfo} showContactCta={false} />
      <ContactCtaSection onOpenQuoteModal={onOpenQuoteModal} onOpenContact={onOpenContact} siteInfo={siteInfo} />
    </main>
  );
}
