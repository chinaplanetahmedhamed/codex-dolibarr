import React from 'react';
import { Building2, Mail, MapPin, MessageSquare, Phone } from 'lucide-react';
import PageHero from '../components/PageHero';
import SEOHead from '../components/SEOHead';
import { useI18n } from '../i18n/I18nContext';

export default function ContactPage({ onGoHome, onOpenQuoteModal, siteInfo }) {
  const { locale, t } = useI18n();
  const phone = siteInfo?.whatsappNumber || '+8613480652510';
  const email = siteInfo?.email || 'info@chinaplanet.org';
  const egyptOfficeAddress = siteInfo?.egyptOfficeAddress || '26 شارع السيدة امنه، سيدي جابر، شارع المشير، ميزان شركه البرمجيات، الاسكندرية';
  const egyptOfficeMapUrl = siteInfo?.egyptOfficeMapUrl || 'https://maps.app.goo.gl/GiGbBYBfSFWKKvva6?g_st=ic';
  const egyptOfficePhone = siteInfo?.egyptOfficePhone || '01096722199';
  const egyptOfficeContactName = siteInfo?.egyptOfficeContactName || 'معاذ محمد';
  return (
    <main className="marketing-page">
      <SEOHead title={`${t('nav.contact')} | China Planet`} description={t('contact.description')} locale={locale} />
      <PageHero
        badge={t('contact.badge')}
        title={t('contact.title')}
        description={t('contact.description')}
        onGoHome={onGoHome}
      >
        <div style={{ display: 'flex', justifyContent: 'center', gap: '12px', flexWrap: 'wrap', marginTop: '25px' }}>
          <button type="button" className="btn-primary" onClick={onOpenQuoteModal}><MessageSquare size={18} /> {t('cta.start')}</button>
          <a className="btn-outline contact-hero-outline" href={`https://wa.me/${phone.replace(/[^0-9]/g, '')}`} target="_blank" rel="noreferrer" style={{ textDecoration: 'none' }}><Phone size={18} /> {t('contact.whatsapp')}</a>
        </div>
      </PageHero>
      <section style={{ padding: '82px 0', background: 'var(--bg-card)' }}>
        <div className="container contact-page-grid">
          <article className="glass-card contact-office-card">
            <div className="contact-office-icon"><MapPin size={27} /></div>
            <div className="badge badge-red">{t('contact.chinaMain')}</div>
            <h2>{t('contact.chinaTitle')}</h2>
            <p>{siteInfo?.chinaOfficeAddress}</p>
            {siteInfo?.chinaOfficeAddressZh && <p lang="zh-CN" className="contact-chinese-address">{siteInfo.chinaOfficeAddressZh}</p>}
          </article>
          <article className="glass-card contact-office-card">
            <div className="contact-office-icon"><Building2 size={27} /></div>
            <div className="badge badge-gold">{t('contact.egyptRegional')}</div>
            <h2>{t('contact.egyptTitle')}</h2>
            <p>{egyptOfficeAddress}</p>
            <p><strong>{t('contact.manager')}</strong> {egyptOfficeContactName}</p>
            <p><strong>{t('contact.phone')}</strong> <a href={`tel:${egyptOfficePhone.replace(/[^0-9+]/g, '')}`}>{egyptOfficePhone}</a></p>
            <a href={egyptOfficeMapUrl} target="_blank" rel="noreferrer" className="contact-office-map-link">
              <MapPin size={17} /> {t('contact.openMap')}
            </a>
          </article>
        </div>
        <div className="container contact-direct-grid">
          <a className="contact-direct-item" href={`https://wa.me/${phone.replace(/[^0-9]/g, '')}`} target="_blank" rel="noreferrer">
            <Phone size={21} /><span>{t('contact.whatsappPhone')}</span><strong>{phone}</strong>
          </a>
          <a className="contact-direct-item" href={`mailto:${email}`}>
            <Mail size={21} /><span>{t('contact.email')}</span><strong>{email}</strong>
          </a>
          <a className="contact-direct-item" href={`tel:${egyptOfficePhone.replace(/[^0-9+]/g, '')}`}>
            <Phone size={21} /><span>مكتب مصر — {egyptOfficeContactName}</span><strong>{egyptOfficePhone}</strong>
          </a>
          <a className="contact-direct-item" href={egyptOfficeMapUrl} target="_blank" rel="noreferrer">
            <MapPin size={21} /><span>{t('contact.egyptLocation')}</span><strong>{t('contact.openGoogle')}</strong>
          </a>
        </div>
      </section>
    </main>
  );
}
