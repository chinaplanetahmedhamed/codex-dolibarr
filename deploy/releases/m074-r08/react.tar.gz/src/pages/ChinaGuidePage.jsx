import React, { useEffect, useMemo, useState } from "react";
import { AlertTriangle, ArrowLeft, ArrowRight, Building2, LoaderCircle, MapPin, RefreshCw, Search } from "lucide-react";
import SEOHead from "../components/SEOHead";
import AppLink from "../components/AppLink";
import { localizedField, useI18n } from "../i18n/I18nContext";
import { calculateChinaGuideFacets } from "../lib/chinaGuideFilters";

export default function ChinaGuidePage({ places = [], cities = [], types = [], status = "loading", onRetry, onGoHome, onSelectPlace }) {
  const { direction, isRtl, locale, t } = useI18n();
  const [cityId, setCityId] = useState("all");
  const [typeId, setTypeId] = useState("all");
  const [search, setSearch] = useState("");
  const [visibleLimit, setVisibleLimit] = useState(24);

  useEffect(() => { window.scrollTo({ top: 0, behavior: "smooth" }); }, []);

  const facets = useMemo(() => calculateChinaGuideFacets(places, {
    cityId,
    typeId,
    search,
    locale,
    getSearchText: (place) => `${localizedField(place, 'title', locale, place.title)} ${place.city} ${place.type} ${place.address || ""}`,
  }), [places, cityId, typeId, search, locale]);
  const {
    filtered,
    cityCounts,
    typeCounts,
    allCitiesCount,
    allTypesCount,
  } = facets;

  useEffect(() => { setVisibleLimit(24); }, [cityId, typeId, search]);

  return (
    <div dir={direction} style={{ minHeight: "100vh", background: "var(--bg-main)", paddingBottom: "80px" }}>
      <SEOHead
        title={`${t('guide.title')} | China Planet`}
        description={t('guide.description')}
        locale={locale}
      />

      <div style={{ background: "var(--secondary)", color: "#fff", padding: "22px 0" }}>
        <div className="container" style={{ display: "flex", justifyContent: "space-between", alignItems: "center", gap: "16px", flexWrap: "wrap" }}>
          <button type="button" onClick={onGoHome} style={{ background: "none", border: 0, color: "#fff", cursor: "pointer", fontWeight: 800, display: "flex", gap: "8px", alignItems: "center" }}><ArrowRight size={18} style={{ transform: isRtl ? 'none' : 'rotate(180deg)' }} />{t('common.backHome')}</button>
          <span style={{ color: "#94A3B8" }}>{t('guide.independent')}</span>
        </div>
      </div>

      <section style={{ background: "linear-gradient(135deg, #0F172A, #1E293B)", color: "#fff", padding: "64px 0" }}>
        <div className="container" style={{ maxWidth: "900px", textAlign: "center" }}>
          <div className="badge badge-gold" style={{ display: "inline-flex", marginBottom: "14px" }}><MapPin size={15} />{t('guide.badge')}</div>
          <h1 style={{ fontSize: "clamp(2rem, 4vw, 3.2rem)", marginBottom: "16px" }}>{t('guide.title')}</h1>
          <p style={{ color: "#CBD5E1", fontSize: "1.05rem", lineHeight: 1.8 }}>{t('guide.description')}</p>
        </div>
      </section>

      <section className="container" style={{ padding: "42px 0 14px" }}>
        <div style={{ display: "flex", justifyContent: "space-between", gap: "14px", alignItems: "end", marginBottom: "20px", flexWrap: "wrap" }}>
          <div><span className="badge badge-red" style={{ marginBottom: "9px" }}>{t('guide.chooseCity')}</span><h2 style={{ fontSize: "1.7rem" }}>{t('guide.cities')}</h2></div>
          {cityId !== "all" && <button type="button" className="btn-outline" onClick={() => setCityId("all")}>{t('guide.allCities')}</button>}
        </div>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(230px, 1fr))", gap: "18px" }} aria-busy={status === "loading"}>
          {status === "loading" ? Array.from({ length: 4 }, (_, index) => (
            <div className="guide-city-skeleton loading-shimmer" key={`city-skeleton-${index}`} aria-hidden="true" />
          )) : cities.map((city) => {
            const selected = String(city.id) === cityId;
            return (
              <button
                type="button"
                key={city.id}
                aria-pressed={selected}
                onClick={() => setCityId(selected ? "all" : String(city.id))}
                style={{ position: "relative", minHeight: "210px", borderRadius: "18px", overflow: "hidden", border: selected ? "3px solid var(--primary)" : "1px solid var(--border-color)", padding: 0, textAlign: isRtl ? "right" : "left", cursor: "pointer", background: "#0F172A", boxShadow: selected ? "0 12px 28px rgba(211,47,47,.25)" : "var(--shadow-md)" }}
              >
                <img src={city.image || "/images/hero.webp"} alt={locale === 'ar' ? `مدينة ${city.nameAr || city.name}` : city.name} loading="lazy" decoding="async" style={{ position: "absolute", inset: 0, width: "100%", height: "100%", objectFit: "cover", opacity: .72 }} />
                <span style={{ position: "absolute", inset: 0, background: "linear-gradient(180deg, rgba(15,23,42,.05), rgba(15,23,42,.96))" }} />
                <span style={{ position: "absolute", inset: 0, padding: "18px", display: "flex", flexDirection: "column", justifyContent: "flex-end", color: "#fff" }}>
                  <strong style={{ fontSize: "1.35rem", lineHeight: 1.3 }}>{locale === 'ar' ? (city.nameAr || city.name) : city.name} {locale === 'ar' && <small style={{ fontSize: ".8rem", color: "#CBD5E1" }}>{city.name}</small>}</strong>
                  <span style={{ color: "#E2E8F0", fontSize: ".82rem", lineHeight: 1.55, marginTop: "6px" }}>{city.description}</span>
                  <span style={{ color: "#FCA5A5", fontWeight: 800, marginTop: "8px" }}>{t('guide.placeCount', { count: cityCounts.get(String(city.id)) || 0 })}</span>
                </span>
              </button>
            );
          })}
        </div>
      </section>

      <section className="container" style={{ paddingTop: "28px", position: "relative", zIndex: 2 }}>
        <div className="glass-card" style={{ padding: "24px", display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(220px, 1fr))", gap: "14px" }}>
          <label style={{ display: "grid", gap: "7px", fontWeight: 800 }}>{t('guide.city')}
            <select className="input-field" value={cityId} onChange={(event) => setCityId(event.target.value)} disabled={status !== "ready"}>
              <option value="all">{t('guide.allCities')} ({allCitiesCount})</option>
              {cities.map((city) => <option key={city.id} value={city.id}>{city.name} ({cityCounts.get(String(city.id)) || 0})</option>)}
            </select>
          </label>
          <label style={{ display: "grid", gap: "7px", fontWeight: 800 }}>{t('guide.placeType')}
            <select className="input-field" value={typeId} onChange={(event) => setTypeId(event.target.value)} disabled={status !== "ready"}>
              <option value="all">{t('common.all')} ({allTypesCount})</option>
              {types.map((type) => <option key={type.id} value={type.id}>{type.name} ({typeCounts.get(String(type.id)) || 0})</option>)}
            </select>
          </label>
          <label style={{ display: "grid", gap: "7px", fontWeight: 800 }}>{t('guide.search')}
            <span style={{ position: "relative" }}><Search size={18} style={{ position: "absolute", [isRtl ? 'right' : 'left']: "14px", top: "50%", transform: "translateY(-50%)", color: "var(--text-muted)" }} /><input className="input-field" value={search} onChange={(event) => setSearch(event.target.value)} placeholder={t('guide.searchPlaceholder')} disabled={status !== "ready"} style={{ width: "100%", [isRtl ? 'paddingRight' : 'paddingLeft']: "42px" }} /></span>
          </label>
        </div>
      </section>

      <section className="container" style={{ paddingTop: "42px" }}>
        <div style={{ display: "flex", justifyContent: "space-between", gap: "14px", alignItems: "center", marginBottom: "22px", flexWrap: "wrap" }}>
          <h2 style={{ fontSize: "1.4rem" }}>{status === "loading" ? t('guide.loading') : t('guide.placeCount', { count: filtered.length })}</h2>
          <span style={{ color: "var(--text-muted)", fontSize: ".86rem" }}>{t('guide.openHint')}</span>
        </div>

        {status === "loading" ? (
          <div aria-live="polite" aria-busy="true">
            <div className="guide-loading-panel">
              <div className="guide-loading-orbit" aria-hidden="true"><LoaderCircle size={30} /></div>
              <div>
                <strong>{t('guide.loadingStep')}</strong>
                <p>{t('guide.loadingHint')}</p>
              </div>
              <div className="guide-loading-rail" aria-hidden="true"><span /></div>
            </div>
            <div className="guide-skeleton-grid" aria-hidden="true">
              {Array.from({ length: 6 }, (_, index) => (
                <div className="guide-skeleton-card" key={`place-skeleton-${index}`}>
                  <div className="guide-skeleton-image loading-shimmer" />
                  <div className="guide-skeleton-copy">
                    <span className="skeleton-line loading-shimmer skeleton-line-wide" />
                    <span className="skeleton-line loading-shimmer" />
                    <span className="skeleton-line loading-shimmer skeleton-line-short" />
                  </div>
                </div>
              ))}
            </div>
          </div>
        ) : status === "error" ? (
          <div className="glass-card guide-error-panel" role="alert">
            <AlertTriangle size={34} />
            <strong>{t('guide.error')}</strong>
            <p>{t('guide.errorHint')}</p>
            <button type="button" className="btn-primary" onClick={onRetry}><RefreshCw size={17} />{t('guide.retry')}</button>
          </div>
        ) : (
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(280px, 1fr))", gap: "20px" }}>
            {filtered.slice(0, visibleLimit).map((place) => (
              <article key={place.id} className="glass-card" style={{ overflow: "hidden", display: "flex", flexDirection: "column" }}>
                <div style={{ height: "170px", position: "relative", overflow: "hidden", background: "#E2E8F0" }}>
                  <img src={place.image || "/images/hero.webp"} alt={localizedField(place, 'title', locale, place.title)} loading="lazy" decoding="async" style={{ width: "100%", height: "100%", objectFit: "cover" }} />
                  <span style={{ position: "absolute", inset: 0, background: "linear-gradient(180deg, transparent, rgba(15,23,42,.75))" }} />
                  <span className="badge badge-red" style={{ position: "absolute", top: "12px", [isRtl ? 'right' : 'left']: "12px" }}><Building2 size={14} />{place.type || t('guide.defaultType')}</span>
                  <span style={{ position: "absolute", bottom: "12px", [isRtl ? 'right' : 'left']: "14px", color: "#fff", display: "flex", gap: "6px", alignItems: "center", fontWeight: 800 }}><MapPin size={15} />{place.city}</span>
                </div>
                <div style={{ padding: "20px", display: "flex", flexDirection: "column", gap: "12px", flex: 1 }}>
                  <div>
                    <h3 style={{ fontSize: "1.08rem", lineHeight: 1.55 }}>{localizedField(place, 'title', locale, place.title)}</h3>
                    <div style={{ color: "var(--text-muted)", marginTop: "5px", fontSize: ".85rem" }}>{[place.city, place.type].filter(Boolean).join(" • ")}</div>
                  </div>
                  {place.excerpt && <p style={{ color: "var(--text-muted)", lineHeight: 1.7 }}>{localizedField(place, 'excerpt', locale, place.excerpt)}</p>}
                  {place.address && <div style={{ display: "flex", gap: "7px", color: "var(--text-muted)", fontSize: ".88rem" }}><MapPin size={16} />{place.address}</div>}
                  <AppLink to={`/china-guide/${encodeURIComponent(place.slug || place.id)}`} onNavigate={() => onSelectPlace(place.slug || place.id)} className="btn-outline" style={{ marginTop: "auto", justifyContent: "center", textDecoration: "none" }}>{t('guide.details')} <ArrowLeft size={16} style={{ transform: isRtl ? 'none' : 'rotate(180deg)' }} /></AppLink>
                </div>
              </article>
            ))}
          </div>
        )}

        {status === "ready" && filtered.length > visibleLimit && (
          <div style={{ textAlign: "center", marginTop: "28px" }}>
            <button type="button" className="btn-primary" onClick={() => setVisibleLimit((current) => current + 24)}>{t('common.loadMore', { count: filtered.length - visibleLimit })}</button>
          </div>
        )}

        {status === "ready" && filtered.length === 0 && <div className="glass-card" style={{ padding: "32px", textAlign: "center" }}>{t('guide.empty')}</div>}
      </section>
    </div>
  );
}
