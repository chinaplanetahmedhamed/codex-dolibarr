import React, { useState, useMemo } from 'react';
import { Search, ShoppingBag, Plus, Building2, ArrowRight, Check, Package, Eye, ChevronLeft, ChevronDown, Folder, FolderOpen, Filter } from 'lucide-react';
import AddToCartModal from '../components/AddToCartModal';
import ProductDetailsModal from '../components/ProductDetailsModal';
import CartDrawer from '../components/CartDrawer';
import { useI18n } from '../i18n/I18nContext';
import { catalogDiscoveryTerms, isUncategorizedCategory, localizeCatalogCategory, matchesCatalogQuery } from '../lib/catalogSearch';

function decodeHtmlEntities(str) {
  if (!str) return '';
  return str
    .replace(/&amp;/g, '&')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"')
    .replace(/&#039;/g, "'")
    .replace(/&nbsp;/g, ' ');
}

function CategoryTreeItem({ category, depth, selectedCategoryId, expandedByParent, onSelect, onToggle, isRtl }) {
  const hasChildren = category.children.length > 0;
  const parentKey = category.parentId || 'root';
  const isExpanded = expandedByParent[parentKey] === category.id;
  const isActive = selectedCategoryId === category.id;

  return (
    <div>
      <button
        type="button"
        data-category-id={category.id}
        aria-expanded={hasChildren ? isExpanded : undefined}
        onClick={() => {
          onSelect(category.id);
          if (hasChildren) onToggle(parentKey, category.id);
        }}
        style={{
          width: '100%',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          gap: '8px',
          padding: '9px 10px',
          [isRtl ? 'paddingRight' : 'paddingLeft']: `${10 + depth * 14}px`,
          border: 'none',
          borderRadius: 'var(--radius-sm)',
          background: isActive ? 'var(--primary-light)' : 'transparent',
          color: isActive ? 'var(--primary)' : 'var(--text-main)',
          fontWeight: isActive ? 900 : 700,
          fontSize: depth === 0 ? '0.9rem' : '0.82rem',
          cursor: 'pointer',
          textAlign: isRtl ? 'right' : 'left'
        }}
      >
        <span style={{ minWidth: 0, display: 'flex', alignItems: 'center', gap: '8px' }}>
          {category.image ? (
            <img src={category.image} alt="" style={{ width: depth === 0 ? '24px' : '18px', height: depth === 0 ? '24px' : '18px', borderRadius: '4px', objectFit: 'cover', flexShrink: 0, border: '1px solid var(--border-color)' }} />
          ) : isExpanded ? (
            <FolderOpen size={depth === 0 ? 17 : 14} color="var(--primary)" />
          ) : (
            <Folder size={depth === 0 ? 17 : 14} color="var(--text-muted)" />
          )}
          <span style={{ overflow: 'hidden', textOverflow: 'ellipsis' }}>{category.name}</span>
        </span>

        <span style={{ display: 'flex', alignItems: 'center', gap: '5px', flexShrink: 0 }}>
          <span style={{ minWidth: '25px', fontSize: '0.72rem', color: isActive ? 'var(--primary)' : 'var(--text-muted)', background: 'var(--bg-main)', padding: '2px 5px', borderRadius: '4px', textAlign: 'center' }}>
            {category.count}
          </span>
          {hasChildren && (isExpanded ? <ChevronDown size={15} /> : <ChevronLeft size={15} />)}
        </span>
      </button>

      {hasChildren && isExpanded && (
        <div style={{ display: 'flex', flexDirection: 'column', gap: '2px', marginTop: '2px', [isRtl ? 'borderRight' : 'borderLeft']: depth === 0 ? '2px solid var(--border-color)' : 'none' }}>
          {category.children.map((child) => (
            <CategoryTreeItem
              key={child.id}
              category={child}
              depth={depth + 1}
              selectedCategoryId={selectedCategoryId}
              expandedByParent={expandedByParent}
              onSelect={onSelect}
              onToggle={onToggle}
              isRtl={isRtl}
            />
          ))}
        </div>
      )}
    </div>
  );
}

export default function ProductsCatalogPage({ 
  siteInfo,
  catalogProducts,
  catalogCategories,
  status = 'loading',
  onGoHome, 
  cartItems,
  onAddToCart,
  onRemoveCartItem,
  onSubmitCartOrder,
  onClearCart
}) {
  const { isRtl, locale, t } = useI18n();
  const [selectedCategoryId, setSelectedCategoryId] = useState('all');
  const [expandedByParent, setExpandedByParent] = useState({});
  const [searchQuery, setSearchQuery] = useState('');
  const [detailProduct, setDetailProduct] = useState(null);
  const [modalProduct, setModalProduct] = useState(null);
  const [cartDrawerOpen, setCartDrawerOpen] = useState(false);

  // Items per page & pagination state
  const [itemsPerPage, setItemsPerPage] = useState(20);
  const [currentPage, setCurrentPage] = useState(1);

  const categoryModel = useMemo(() => {
    const sourceCategories = Array.isArray(catalogCategories) && catalogCategories.length > 0
      ? catalogCategories.filter((category) => !isUncategorizedCategory(category))
      : Array.from(new Map((catalogProducts || []).map((product) => {
        const id = String(product.category || `fallback-${product.categoryName}`);
        return [id, { id, parentId: null, name: decodeHtmlEntities(product.categoryName || 'قسم عام'), count: 0, image: product.categoryImage || product.image || '' }];
      })).values());
    const byId = new Map(sourceCategories.map((category) => [String(category.id), {
      ...category,
      id: String(category.id),
      parentId: category.parentId ? String(category.parentId) : null,
      name: localizeCatalogCategory(decodeHtmlEntities(category.name || 'قسم عام'), locale),
      children: [],
    }]));

    if (!catalogCategories?.length) {
      (catalogProducts || []).forEach((product) => {
        const node = byId.get(String(product.category || `fallback-${product.categoryName}`));
        if (node) node.count += 1;
      });
    }

    const roots = [];
    byId.forEach((category) => {
      const parent = category.parentId ? byId.get(category.parentId) : null;
      if (parent) parent.children.push(category);
      else roots.push(category);
    });
    const sortTree = (items) => items
      .sort((a, b) => a.name.localeCompare(b.name, locale))
      .map((item) => ({ ...item, children: sortTree(item.children) }));
    return { roots: sortTree(roots), byId, total: byId.size };
  }, [catalogCategories, catalogProducts, locale]);

  const selectedCategoryIds = useMemo(() => {
    if (selectedCategoryId === 'all') return null;
    const selected = categoryModel.byId.get(selectedCategoryId);
    if (!selected) return new Set([selectedCategoryId]);
    const ids = new Set();
    const collect = (category) => {
      ids.add(category.id);
      category.children.forEach(collect);
    };
    collect(selected);
    return ids;
  }, [categoryModel, selectedCategoryId]);

  const toggleCategory = (parentKey, categoryId) => {
    setExpandedByParent((current) => ({
      ...current,
      [parentKey]: current[parentKey] === categoryId ? null : categoryId,
    }));
  };

  // Filter products by main category, sub category, and search query
  const filteredProducts = (catalogProducts || []).filter(prod => {
    const mainName = decodeHtmlEntities(prod.categoryName);
    const subName = decodeHtmlEntities(prod.subCategoryName);
    const titleClean = decodeHtmlEntities(prod.title);

    const productCategoryIds = Array.isArray(prod.categoryIds) && prod.categoryIds.length > 0
      ? prod.categoryIds.map(String)
      : [String(prod.category || '')];
    const matchesCategory = !selectedCategoryIds || productCategoryIds.some((id) => selectedCategoryIds.has(id));
    const matchesSearch = matchesCatalogQuery({
      ...prod,
      title: titleClean,
      categoryName: mainName,
      subCategoryName: subName,
    }, searchQuery);
    return matchesCategory && matchesSearch;
  });

  // Calculate Paginated Products Slice
  const totalItemsCount = filteredProducts.length;
  const effectivePerPage = itemsPerPage === 'all' ? totalItemsCount : parseInt(itemsPerPage, 10);
  const totalPages = Math.ceil(totalItemsCount / effectivePerPage) || 1;
  const safeCurrentPage = Math.min(currentPage, totalPages);

  const paginatedProducts = useMemo(() => {
    if (itemsPerPage === 'all') return filteredProducts;
    const startIndex = (safeCurrentPage - 1) * effectivePerPage;
    return filteredProducts.slice(startIndex, startIndex + effectivePerPage);
  }, [filteredProducts, safeCurrentPage, effectivePerPage, itemsPerPage]);

  const handleCategorySelect = (categoryId) => {
    setSelectedCategoryId(categoryId);
    setCurrentPage(1); // Reset page to 1 on category change
  };

  const selectedCategory = selectedCategoryId === 'all' ? null : categoryModel.byId.get(selectedCategoryId);
  const discoveryTerms = catalogDiscoveryTerms(searchQuery);

  const bannerBgStyle = siteInfo?.catalogBannerBgImage ? {
    backgroundImage: `linear-gradient(135deg, rgba(15, 23, 42, 0.88) 0%, rgba(30, 41, 59, 0.92) 100%), url(${siteInfo.catalogBannerBgImage})`,
    backgroundSize: 'cover',
    backgroundPosition: 'center'
  } : {
    background: 'linear-gradient(135deg, #0F172A 0%, #1E293B 100%)'
  };

  return (
    <div className="products-catalog-page" style={{ minHeight: '100vh', background: 'var(--bg-main)', paddingBottom: '60px' }}>
      
      {/* Top Banner Header (Dynamically Managed from CMS Site Editor with Custom Background Image) */}
      <div 
        className="products-catalog-hero"
        style={{ 
          ...bannerBgStyle,
          color: '#FFFFFF', 
          padding: '40px 0 50px 0', 
          borderBottom: '1px solid var(--border-color)', 
          position: 'relative' 
        }}
      >
        <div className="container">
          
          <div className="products-catalog-top-actions" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '16px', marginBottom: '24px' }}>
            <button onClick={onGoHome} className="btn-outline" style={{ color: '#FFF', borderColor: 'rgba(255, 255, 255, 0.2)' }}>
              <ArrowRight size={18} style={{ transform: isRtl ? 'none' : 'rotate(180deg)' }} />
              <span>{t('products.back')}</span>
            </button>

            {/* Floating Cart Launcher Button */}
            <button 
              onClick={() => setCartDrawerOpen(true)}
              className="btn-primary"
              style={{ borderRadius: '9999px', padding: '10px 22px', display: 'flex', alignItems: 'center', gap: '8px', position: 'relative' }}
            >
              <ShoppingBag size={20} />
              <span>{t('products.cart')}</span>
              {cartItems && cartItems.length > 0 && (
                <span style={{ background: '#FFF', color: '#B71C1C', borderRadius: '50%', width: '22px', height: '22px', fontSize: '0.78rem', fontWeight: 900, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                  {cartItems.length}
                </span>
              )}
            </button>
          </div>

          <div className="products-catalog-hero-copy" style={{ maxWidth: '780px' }}>
            <div className="badge badge-gold" style={{ marginBottom: '14px' }}>
              <Building2 size={14} />
              <span>{locale === 'ar' && siteInfo?.catalogBadgeText ? siteInfo.catalogBadgeText : t('products.badge')}</span>
            </div>
            <h1 style={{ fontSize: 'clamp(1.8rem, 4vw, 2.8rem)', fontWeight: 900, lineHeight: 1.25, marginBottom: '16px' }}>
              {locale === 'ar' && siteInfo?.catalogBannerTitle ? siteInfo.catalogBannerTitle : t('products.title')}
            </h1>
            <p style={{ fontSize: '1rem', color: '#94A3B8', lineHeight: 1.7, marginBottom: '28px' }}>
              {locale === 'ar' && siteInfo?.catalogBannerSubtitle ? siteInfo.catalogBannerSubtitle : t('products.description')}
            </p>

            {/* Search Input Bar */}
            <div className="products-catalog-search" style={{ background: 'rgba(255, 255, 255, 0.1)', backdropFilter: 'blur(12px)', padding: '8px 16px', borderRadius: '9999px', border: '1px solid rgba(255, 255, 255, 0.2)', display: 'flex', alignItems: 'center', gap: '10px', maxWidth: '520px' }}>
              <Search size={20} color="#94A3B8" />
              <input 
                type="text" 
                aria-label={t('products.search')}
                placeholder={t('products.search')}
                value={searchQuery}
                onChange={(e) => { setSearchQuery(e.target.value); setCurrentPage(1); }}
                style={{ flex: 1, border: 'none', background: 'transparent', outline: 'none', color: '#FFF', fontSize: '0.92rem', fontWeight: 600 }}
              />
            </div>
            {discoveryTerms.length > 0 && <p className="products-search-expansion" role="status">{t('products.searchExpanded', { terms: discoveryTerms.join(', ') })}</p>}
          </div>

        </div>
      </div>

      {/* Main Container - 2 Column Layout (Sticky Fixed Sidebar + Products Grid) */}
      <div className="container" style={{ marginTop: '36px' }}>
        
        <div className="products-catalog-layout" style={{ display: 'grid', gridTemplateColumns: '300px 1fr', gap: '28px', alignItems: 'start' }}>
          
          {/* STICKY FIXED SIDEBAR - NO HOVER TRANSFORM TO GUARANTEE STICKY POSITIONING */}
          <aside 
            className="products-catalog-sidebar"
            aria-busy={status === 'loading'}
            style={{ 
              position: 'sticky', 
              top: '100px',
              alignSelf: 'flex-start',
              background: 'var(--bg-card)',
              border: '1px solid var(--border-color)',
              borderRadius: 'var(--radius-lg)',
              padding: '20px', 
              boxShadow: 'var(--shadow-sm)',
              maxHeight: 'calc(100vh - 120px)',
              overflowY: 'auto',
              zIndex: 90
            }}
          >
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: '8px', marginBottom: '16px', borderBottom: '1px solid var(--border-color)', paddingBottom: '12px' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '8px', fontWeight: 800, fontSize: '1.05rem', color: 'var(--text-main)' }}>
                <Filter size={18} color="var(--primary)" />
                <span>{t('products.mainCategories', { count: categoryModel.roots.length })}</span>
              </div>
              <span style={{ fontSize: '0.72rem', color: 'var(--text-muted)' }}>{t('products.categoriesCount', { count: categoryModel.total })}</span>
            </div>

            {/* Main Categories Accordion List */}
            <div style={{ display: 'flex', flexDirection: 'column', gap: '4px' }}>
              <button
                type="button"
                onClick={() => handleCategorySelect('all')}
                style={{
                  width: '100%',
                  padding: '9px 10px',
                  border: 'none',
                  borderRadius: 'var(--radius-sm)',
                  background: selectedCategoryId === 'all' ? 'var(--primary)' : 'var(--bg-main)',
                  color: selectedCategoryId === 'all' ? '#FFF' : 'var(--text-main)',
                  fontWeight: 900,
                  cursor: 'pointer',
                  textAlign: isRtl ? 'right' : 'left'
                }}
              >
                {t('products.allProducts', { count: catalogProducts.length })}
              </button>

              {categoryModel.roots.map((category) => (
                <CategoryTreeItem
                  key={category.id}
                  category={category}
                  depth={0}
                  selectedCategoryId={selectedCategoryId}
                  expandedByParent={expandedByParent}
                  onSelect={handleCategorySelect}
                  onToggle={toggleCategory}
                  isRtl={isRtl}
                />
              ))}
            </div>

          </aside>

          {/* LEFT COLUMN: PRODUCTS GRID WITH ITEMS PER PAGE CONTROL & PAGINATION */}
          <main className="products-catalog-results" style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
            
            {/* Active Filter Title Banner & Items Per Page Selector */}
            <div className="products-catalog-toolbar" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '12px', background: 'var(--bg-card)', padding: '14px 20px', borderRadius: 'var(--radius-md)', border: '1px solid var(--border-color)' }}>
              <div>
                <div style={{ fontSize: '1.05rem', fontWeight: 800, color: 'var(--text-main)' }}>
                  {selectedCategoryId === 'all'
                    ? t('products.available', { count: filteredProducts.length })
                    : t('products.category', { name: selectedCategory?.name || t('products.unknown'), count: filteredProducts.length })}
                </div>
                {totalItemsCount > 0 && itemsPerPage !== 'all' && (
                  <div style={{ fontSize: '0.78rem', color: 'var(--text-muted)', marginTop: '2px' }}>
                    {t('products.range', { from: ((safeCurrentPage - 1) * effectivePerPage) + 1, to: Math.min(safeCurrentPage * effectivePerPage, totalItemsCount), total: totalItemsCount })}
                  </div>
                )}
              </div>

              {/* Items Per Page Selector Dropdown */}
              <div className="products-catalog-page-size" style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                <label style={{ fontSize: '0.82rem', fontWeight: 700, color: 'var(--text-muted)' }}>{t('products.perPage')}</label>
                <select 
                  className="input-field"
                  disabled={status === 'loading'}
                  style={{ width: 'auto', padding: '6px 12px', fontSize: '0.82rem', fontWeight: 800 }}
                  value={itemsPerPage}
                  onChange={(e) => {
                    setItemsPerPage(e.target.value === 'all' ? 'all' : parseInt(e.target.value, 10));
                    setCurrentPage(1);
                  }}
                >
                  <option value={20}>{t('products.itemUnit', { count: 20 })}</option>
                  <option value={40}>{t('products.itemUnit', { count: 40 })}</option>
                  <option value={60}>{t('products.itemUnit', { count: 60 })}</option>
                  <option value={100}>{t('products.itemUnit', { count: 100 })}</option>
                  <option value="all">{t('products.showAll', { count: totalItemsCount })}</option>
                </select>

                {selectedCategoryId !== 'all' && (
                  <button 
                    onClick={() => handleCategorySelect('all')}
                    style={{ background: 'none', border: 'none', color: '#D32F2F', fontSize: '0.82rem', fontWeight: 800, cursor: 'pointer', marginRight: '6px' }}
                  >
                    {t('products.clearFilter')}
                  </button>
                )}
              </div>
            </div>

            {/* Products Grid */}
            {status === 'loading' ? (
              <div aria-live="polite" aria-busy="true">
                <div className="guide-loading-panel">
                  <div className="guide-loading-orbit" aria-hidden="true"><Package size={28} /></div>
                  <div><strong>{t('loading.catalog')}</strong><p>{t('products.loadingHint')}</p></div>
                  <div className="guide-loading-rail" aria-hidden="true"><span /></div>
                </div>
                <div className="guide-skeleton-grid" aria-hidden="true">
                  {Array.from({ length: 6 }, (_, index) => (
                    <div className="guide-skeleton-card" key={`product-skeleton-${index}`}>
                      <div className="product-skeleton-image loading-shimmer" />
                      <div className="guide-skeleton-copy">
                        <span className="skeleton-line loading-shimmer skeleton-line-wide" />
                        <span className="skeleton-line loading-shimmer" />
                        <span className="skeleton-line loading-shimmer skeleton-line-short" />
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            ) : paginatedProducts.length === 0 ? (
              <div className="glass-card" style={{ padding: '60px 20px', textAlign: 'center', color: 'var(--text-muted)' }}>
                <Package size={48} style={{ opacity: 0.3, marginBottom: '12px' }} />
                <h3 style={{ fontSize: '1.2rem', fontWeight: 800, marginBottom: '6px' }}>
                  {catalogProducts.length === 0 ? t('products.emptyCatalog') : t('products.noMatches')}
                </h3>
                <p style={{ fontSize: '0.9rem' }}>
                  {catalogProducts.length === 0 
                    ? t('products.emptyHelp')
                    : t('products.noMatchesHelp')}
                </p>
              </div>
            ) : (
              <div className="products-catalog-grid" style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(280px, 1fr))', gap: '24px' }}>
                {paginatedProducts.map(product => {
                  const isAlreadyInCart = cartItems && cartItems.some(item => item.id === product.id);
                  const cleanTitle = decodeHtmlEntities(product.title);
                  const cleanMainCat = decodeHtmlEntities(product.categoryName);
                  const cleanSubCat = decodeHtmlEntities(product.subCategoryName);

                  return (
                    <div 
                      key={product.id} 
                      className="glass-card"
                      onClick={() => setDetailProduct(product)}
                      style={{
                        borderRadius: 'var(--radius-lg)',
                        overflow: 'hidden',
                        display: 'flex',
                        flexDirection: 'column',
                        justifyContent: 'space-between',
                        cursor: 'pointer'
                      }}
                    >
                      <div>
                        {/* Image Container */}
                        <div className="products-catalog-card-image" style={{ position: 'relative', height: '220px', overflow: 'hidden', background: '#0F172A' }}>
                          <img src={product.image || '/images/hero.webp'} alt={cleanTitle} style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
                          <span className="badge badge-gold" style={{ position: 'absolute', top: '12px', right: '12px', background: 'rgba(15, 23, 42, 0.85)', color: '#FFF' }}>
                            {cleanMainCat} {cleanSubCat ? `➔ ${cleanSubCat}` : ''}
                          </span>
                          <span style={{ position: 'absolute', bottom: '12px', left: '12px', background: 'rgba(15, 23, 42, 0.75)', backdropFilter: 'blur(4px)', color: '#FFF', padding: '4px 10px', borderRadius: '9999px', fontSize: '0.75rem', display: 'flex', alignItems: 'center', gap: '4px' }}>
                            <Eye size={14} /> {t('products.preview')}
                          </span>
                        </div>

                        {/* Product Details */}
                        <div style={{ padding: '20px' }}>
                          <h3 style={{ fontSize: '1.05rem', fontWeight: 800, color: 'var(--text-main)', marginBottom: '8px', lineHeight: 1.4 }}>
                            {cleanTitle}
                          </h3>
                          
                          <p style={{ fontSize: '0.84rem', color: 'var(--text-muted)', lineHeight: 1.6, marginBottom: '14px', display: '-webkit-box', WebkitLineClamp: 2, WebkitBoxOrient: 'vertical', overflow: 'hidden' }}>
                            {product.description}
                          </p>

                          {product.specs && !product.specs.includes('مزامن') && !product.specs.includes('WooCommerce') && (
                            <div style={{ fontSize: '0.78rem', color: 'var(--text-main)', background: 'var(--bg-main)', padding: '8px 10px', borderRadius: 'var(--radius-sm)', border: '1px solid var(--border-color)', marginBottom: '16px' }}>
                              ⚡ <span style={{ fontWeight: 700 }}>{t('products.specs')}</span> {product.specs}
                            </div>
                          )}

                          <div style={{ fontSize: '0.82rem', fontWeight: 800, color: 'var(--primary)', marginBottom: '4px' }}>
                            {t('products.quantity', { value: product.moq || t('products.byRequest') })}
                          </div>
                        </div>
                      </div>

                      {/* Product Action Button */}
                      <div style={{ padding: '0 20px 20px 20px' }}>
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            setModalProduct(product);
                          }}
                          className={isAlreadyInCart ? 'btn-outline' : 'btn-primary'}
                          style={{ width: '100%', justifyContent: 'center', padding: '10px 16px', borderRadius: '9999px', fontSize: '0.88rem' }}
                        >
                          {isAlreadyInCart ? (
                            <>
                              <Check size={16} color="var(--accent-green)" />
                              <span>{t('products.inCart')}</span>
                            </>
                          ) : (
                            <>
                              <Plus size={16} />
                              <span>{t('products.add')}</span>
                            </>
                          )}
                        </button>
                      </div>

                    </div>
                  );
                })}
              </div>
            )}

            {/* Pagination Bar */}
            {totalPages > 1 && itemsPerPage !== 'all' && (
              <div className="products-catalog-pagination" style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', gap: '8px', marginTop: '20px' }}>
                <button
                  disabled={safeCurrentPage === 1}
                  onClick={() => setCurrentPage(prev => Math.max(prev - 1, 1))}
                  className="btn-outline"
                  style={{ padding: '8px 14px', fontSize: '0.85rem', opacity: safeCurrentPage === 1 ? 0.5 : 1 }}
                >
                  <ArrowRight size={16} />
                  <span>{t('products.previous')}</span>
                </button>

                {Array.from({ length: totalPages }, (_, i) => i + 1)
                  .filter(p => p === 1 || p === totalPages || Math.abs(p - safeCurrentPage) <= 2)
                  .map((p, idx, arr) => (
                    <React.Fragment key={p}>
                      {idx > 0 && arr[idx - 1] !== p - 1 && <span style={{ color: 'var(--text-muted)' }}>...</span>}
                      <button
                        onClick={() => setCurrentPage(p)}
                        style={{
                          width: '36px',
                          height: '36px',
                          borderRadius: '8px',
                          border: p === safeCurrentPage ? 'none' : '1px solid var(--border-color)',
                          background: p === safeCurrentPage ? 'var(--primary)' : 'var(--bg-card)',
                          color: p === safeCurrentPage ? '#FFF' : 'var(--text-main)',
                          fontWeight: 800,
                          fontSize: '0.88rem',
                          cursor: 'pointer'
                        }}
                      >
                        {p}
                      </button>
                    </React.Fragment>
                  ))}

                <button
                  disabled={safeCurrentPage === totalPages}
                  onClick={() => setCurrentPage(prev => Math.min(prev + 1, totalPages))}
                  className="btn-outline"
                  style={{ padding: '8px 14px', fontSize: '0.85rem', opacity: safeCurrentPage === totalPages ? 0.5 : 1 }}
                >
                  <span>{t('products.next')}</span>
                  <ChevronLeft size={16} />
                </button>
              </div>
            )}

          </main>

        </div>

      </div>

      {/* Product Details Full Modal */}
      <ProductDetailsModal 
        isOpen={!!detailProduct}
        product={detailProduct}
        onClose={() => setDetailProduct(null)}
        onAddToCartClick={(prod) => setModalProduct(prod)}
      />

      {/* Add To Cart Quantity & Comment Modal */}
      <AddToCartModal 
        isOpen={!!modalProduct}
        product={modalProduct}
        onClose={() => setModalProduct(null)}
        onConfirm={(itemData) => {
          onAddToCart(itemData);
          setCartDrawerOpen(true);
        }}
      />

      {/* Cart Drawer */}
      <CartDrawer 
        isOpen={cartDrawerOpen}
        onClose={() => setCartDrawerOpen(false)}
        cartItems={cartItems || []}
        onRemoveItem={onRemoveCartItem}
        onSubmitOrder={onSubmitCartOrder}
        onClearCart={onClearCart}
      />

    </div>
  );
}
