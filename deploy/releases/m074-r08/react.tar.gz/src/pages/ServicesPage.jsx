import React from 'react';
import ContactCtaSection from '../components/ContactCtaSection';
import PageHero from '../components/PageHero';
import SEOHead from '../components/SEOHead';
import ServicesSection from '../components/ServicesSection';
import { useI18n } from '../i18n/I18nContext';

export default function ServicesPage({ servicesData, onSelectService, onGoHome, onOpenQuoteModal, onOpenContact, siteInfo }) {
  const { locale, t } = useI18n();
  return (
    <main className="marketing-page">
      <SEOHead title={`${t('nav.services')} | China Planet`} description={t('services.description')} locale={locale} />
      <PageHero
        badge={t('services.badge')}
        title={t('services.title')}
        description={t('services.description')}
        onGoHome={onGoHome}
      />
      <ServicesSection servicesData={servicesData} onSelectService={onSelectService} />
      <ContactCtaSection onOpenQuoteModal={onOpenQuoteModal} onOpenContact={onOpenContact} siteInfo={siteInfo} />
    </main>
  );
}
