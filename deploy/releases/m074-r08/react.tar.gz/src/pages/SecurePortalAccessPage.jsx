import React from "react";
import { ArrowRight, ExternalLink, LockKeyhole, MessageSquare, ShieldCheck } from "lucide-react";

export default function SecurePortalAccessPage({ customerCenterUrl, staffPortalUrl, onGoHome, onOpenQuoteModal }) {
  return (
    <main style={{ minHeight: "100vh", padding: "150px 20px 80px", background: "linear-gradient(135deg, #0F172A, #1E293B)", color: "#fff" }}>
      <div style={{ width: "100%", maxWidth: "760px", margin: "0 auto" }}>
        <button type="button" onClick={onGoHome} className="btn-outline" style={{ color: "#fff", borderColor: "rgba(255,255,255,.25)", marginBottom: "24px" }}>
          <ArrowRight size={17} /> العودة للموقع
        </button>

        <section style={{ padding: "clamp(26px, 5vw, 48px)", borderRadius: "24px", background: "rgba(255,255,255,.07)", border: "1px solid rgba(255,255,255,.14)", backdropFilter: "blur(18px)" }}>
          <div style={{ width: "64px", height: "64px", borderRadius: "18px", display: "grid", placeItems: "center", background: "rgba(211,47,47,.2)", color: "#FF8A80", marginBottom: "20px" }}>
            <LockKeyhole size={32} />
          </div>
          <div className="badge badge-gold" style={{ marginBottom: "12px" }}><ShieldCheck size={15} /> دخول آمن</div>
          <h1 style={{ fontSize: "clamp(1.8rem, 5vw, 2.7rem)", fontWeight: 900, marginBottom: "14px" }}>تم نقل الحسابات إلى ChinaPlanetOS</h1>
          <p style={{ color: "#CBD5E1", lineHeight: 1.8, marginBottom: "28px" }}>
            لم يعد هذا الموقع يستخدم كلمات مرور محفوظة داخل المتصفح. العملاء والموظفون يدخلون فقط عبر البوابة المؤمنة لإدارة الطلبات والشحنات والمستندات.
          </p>

          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(220px, 1fr))", gap: "14px" }}>
            {customerCenterUrl ? (
              <a className="btn-primary" href={customerCenterUrl} rel="noreferrer" style={{ textDecoration: "none", justifyContent: "center", padding: "14px" }}>
                دخول العملاء <ExternalLink size={17} />
              </a>
            ) : (
              <button type="button" className="btn-primary" onClick={onOpenQuoteModal} style={{ justifyContent: "center", padding: "14px" }}>
                اطلب تفعيل حسابك <MessageSquare size={17} />
              </button>
            )}
            {staffPortalUrl && (
              <a className="btn-secondary" href={staffPortalUrl} rel="noreferrer" style={{ textDecoration: "none", justifyContent: "center", padding: "14px" }}>
                دخول فريق العمل <ExternalLink size={17} />
              </a>
            )}
          </div>
        </section>
      </div>
    </main>
  );
}
