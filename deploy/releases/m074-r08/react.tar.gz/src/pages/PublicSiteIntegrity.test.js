import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';

const app = await readFile(new URL('../App.jsx', import.meta.url), 'utf8');
const navbar = await readFile(new URL('../components/Navbar.jsx', import.meta.url), 'utf8');
const footer = await readFile(new URL('../components/Footer.jsx', import.meta.url), 'utf8');
const quoteModal = await readFile(new URL('../components/QuoteModal.jsx', import.meta.url), 'utf8');
const stats = await readFile(new URL('../components/StatsBar.jsx', import.meta.url), 'utf8');
const trust = await readFile(new URL('../components/AboutTrustSection.jsx', import.meta.url), 'utf8');
const b2b = await readFile(new URL('./B2BPage.jsx', import.meta.url), 'utf8');
const cartDrawer = await readFile(new URL('../components/CartDrawer.jsx', import.meta.url), 'utf8');

test('returning customers are linked to Customer Center without recreating ERP operations', () => {
  assert.match(app, /erp\.visiontrading\.biz\/custom\/chinaplanetcustomercenter\//);
  assert.match(navbar, /customerCenterUrl/);
  assert.match(footer, /customerCenterUrl/);
  assert.doesNotMatch(app, /Dolibarr.*password|customer.*password/i);
});

test('guided importer intake has localized privacy protection and accessible labels', () => {
  assert.match(quoteModal, /role="dialog" aria-modal="true"/);
  assert.match(quoteModal, /privacyHint:/);
  assert.match(quoteModal, /لا تُدخل كلمات مرور/);
  assert.match(quoteModal, /Do not enter passwords/);
  assert.match(quoteModal, /Ne saisissez aucun mot de passe/);
  for (const id of ['client-name', 'phone', 'email', 'country', 'product', 'quantity', 'service', 'notes']) {
    assert.match(quoteModal, new RegExp(`htmlFor="quote-${id}"`));
    assert.match(quoteModal, new RegExp(`id="quote-${id}"`));
  }
  assert.match(quoteModal, /localizePath\('\/privacy', locale\)/);
});

test('public language and trust claims match verifiable website evidence', () => {
  assert.match(stats, /AR · EN · FR/);
  assert.doesNotMatch(stats, /AR · EN · 中文/);
  assert.doesNotMatch(trust, /750|1\.1M|1,100,000/);
  assert.match(trust, /Redacted records/);
});

test('footer exposes an automatic, localized and direction-stable release indicator', () => {
  assert.match(footer, /useReleaseVersion/);
  assert.match(footer, /footer\.versionLabel/);
  assert.match(footer, /dir="ltr"/);
  assert.match(footer, /releaseVersion\.label/);
  assert.doesNotMatch(footer, /M\d{3}-R\d{2}/);
});

test('B2B keeps the published price contract per piece without carton conversion', () => {
  assert.match(b2b, /choice\.price \?\? choice\.unitPrice/);
  assert.match(b2b, /text\.perPiece/);
  assert.doesNotMatch(b2b, /text\.perCarton/);
});

test('B2B quote list preserves incomplete rows and keeps a partial container drawing safe', () => {
  assert.match(b2b, /lineId = createLineId\(\)/);
  assert.match(b2b, /verified && !verified\.calculationReady/);
  assert.match(b2b, /calculationReadyCount > 0/);
  assert.match(b2b, /No line is calculation-ready yet/);
  assert.match(b2b, /لن يدخل في الرسم أو حساب الحجم والوزن/);
  assert.match(b2b, /n'entre pas dans le dessin, le volume ou le poids/);
  assert.match(b2b, /missingFields\.join/);
});

test('B2B intake uses a localized ISO country selector, consent link and accessible carton controls', () => {
  assert.match(b2b, /Intl\.DisplayNames/);
  assert.match(b2b, /COUNTRY_CODES\.map/);
  assert.match(b2b, /localizePath\('\/privacy', locale\)/);
  assert.match(b2b, /aria-label=\{`\$\{text\.decreaseCartons\}/);
  assert.match(b2b, /aria-label=\{`\$\{text\.increaseCartons\}/);
  assert.match(b2b, /consentAcceptedAt/);
});

test('legacy product quote cart submits the complete v2 identity and consent fields', () => {
  assert.match(cartDrawer, /freezeB2bSubmission/);
  assert.match(cartDrawer, /frozenSubmission\.idempotencyKey/);
  assert.match(cartDrawer, /cart-country/);
  assert.match(cartDrawer, /localizePath\('\/privacy'/);
});
