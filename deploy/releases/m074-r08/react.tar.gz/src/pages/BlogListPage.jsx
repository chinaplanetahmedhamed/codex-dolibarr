import React, { useState, useEffect } from 'react';
import { 
  BookOpen, 
  Search, 
  Calendar, 
  Clock, 
  ArrowLeft, 
  ArrowRight,
  Globe
} from 'lucide-react';
import SEOHead from '../components/SEOHead';
import AppLink from '../components/AppLink';
import { localizedField, useI18n } from '../i18n/I18nContext';

export default function BlogListPage({ blogPosts, blogCategories, contentStatus = 'loading', onSelectPost, onGoHome }) {
  const { isRtl, locale, t } = useI18n();
  const activePosts = Array.isArray(blogPosts) ? blogPosts : [];
  const categoriesList = blogCategories && blogCategories.length ? ['__all', ...blogCategories] : ['__all', 'دليل كانطون', 'نصائح الاستيراد', 'الشحن والجمرك', 'أسواق جوانزو'];

  const [selectedCategory, setSelectedCategory] = useState('__all');
  const [searchTerm, setSearchTerm] = useState('');

  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, []);

  const filtered = activePosts.filter(p => {
    const title = localizedField(p, 'title', locale, p.title || '');
    const excerpt = localizedField(p, 'excerpt', locale, p.excerpt || '');
    const matchesCat = selectedCategory === '__all' || p.category === selectedCategory;
    const matchesSearch = title.toLowerCase().includes(searchTerm.toLowerCase()) || excerpt.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesCat && matchesSearch;
  });

  const featuredPost = activePosts[0];

  return (
    <div style={{ background: 'var(--bg-main)', minHeight: '100vh', paddingBottom: '80px' }} className="animate-fade-in">
      
      {/* Dynamic SEO for Blog Listing */}
      <SEOHead 
        title={`${t('blog.title')} | China Planet`}
        description={t('blog.description')}
        locale={locale}
      />

      {/* Top Standalone Page Navigation Bar */}
      <div 
        style={{
          background: 'var(--secondary)',
          color: '#FFFFFF',
          padding: '20px 0',
          borderBottom: '1px solid rgba(255, 255, 255, 0.1)'
        }}
      >
        <div className="container" style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: '16px' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '10px', fontSize: '0.9rem', color: '#94A3B8' }}>
            <AppLink
              to="/"
              onNavigate={onGoHome}
              style={{ background: 'none', border: 'none', color: '#FFF', fontWeight: 700, cursor: 'pointer', display: 'flex', alignItems: 'center', gap: '6px', textDecoration: 'none' }}
            >
              <ArrowRight size={18} style={{ transform: isRtl ? 'none' : 'rotate(180deg)' }} />
              <span>{t('common.backHome')}</span>
            </AppLink>
            <span>/</span>
            <span style={{ color: 'var(--primary-light)', fontWeight: 700 }}>{t('blog.label')}</span>
          </div>

          <div className="badge badge-gold" style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
            <Globe size={14} />
            <span>{t('blog.office')}</span>
          </div>
        </div>
      </div>

      {/* Blog Standalone Page Hero Header */}
      <section 
        style={{
          background: 'linear-gradient(135deg, #0F172A 0%, #1E293B 100%)',
          color: '#FFFFFF',
          padding: '70px 0 60px 0',
          position: 'relative',
          borderBottom: '1px solid rgba(255, 255, 255, 0.1)'
        }}
      >
        <div className="container" style={{ textAlign: 'center', maxWidth: '800px' }}>
          <div className="badge badge-gold" style={{ marginBottom: '14px', margin: '0 auto 14px auto', display: 'inline-flex' }}>
            <BookOpen size={14} />
            <span>{t('blog.badge')}</span>
          </div>

          <h1 style={{ fontSize: 'clamp(2.2rem, 4vw, 3.2rem)', fontWeight: 900, marginBottom: '20px', lineHeight: 1.2 }}>
            {t('blog.title')}
          </h1>

          <p style={{ color: '#94A3B8', fontSize: '1.1rem', lineHeight: 1.7, marginBottom: '36px' }}>
            {t('blog.description')}
          </p>

          {/* Search Bar */}
          <div style={{ position: 'relative', maxWidth: '560px', margin: '0 auto' }}>
            <Search size={20} style={{ position: 'absolute', [isRtl ? 'right' : 'left']: '18px', top: '50%', transform: 'translateY(-50%)', color: '#94A3B8' }} />
            <input 
              type="text" 
              className="input-field" 
              placeholder={t('blog.search')}
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              style={{
                [isRtl ? 'paddingRight' : 'paddingLeft']: '48px',
                [isRtl ? 'paddingLeft' : 'paddingRight']: '20px',
                height: '52px',
                borderRadius: '9999px',
                background: 'rgba(255, 255, 255, 0.1)',
                border: '1px solid rgba(255, 255, 255, 0.2)',
                color: '#FFF',
                fontSize: '1rem'
              }}
            />
          </div>
        </div>
      </section>

      {/* Featured Main Post Banner */}
      {featuredPost && (
        <section style={{ padding: '60px 0 40px 0' }}>
          <div className="container">
            <AppLink
              to={`/blog/${encodeURIComponent(featuredPost.slug || featuredPost.id)}`}
              onNavigate={() => onSelectPost(featuredPost.slug || featuredPost.id)}
              className="glass-card"
              style={{
                borderRadius: 'var(--radius-lg)',
                overflow: 'hidden',
                display: 'grid',
                gridTemplateColumns: 'repeat(auto-fit, minmax(320px, 1fr))',
                gap: '0',
                cursor: 'pointer',
                border: '1px solid var(--border-color)',
                color: 'inherit',
                textDecoration: 'none'
              }}
            >
              <div style={{ height: '360px', overflow: 'hidden', position: 'relative' }}>
                <img src={featuredPost.image || '/images/hero.webp'} alt={localizedField(featuredPost, 'title', locale, featuredPost.title)} decoding="async" style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
                <span className="badge badge-red" style={{ position: 'absolute', top: '20px', [isRtl ? 'right' : 'left']: '20px' }}>{t('blog.featured')}</span>
              </div>

              <div style={{ padding: '40px', display: 'flex', flexDirection: 'column', justifyContent: 'center' }}>
                <div style={{ display: 'flex', gap: '16px', fontSize: '0.82rem', color: 'var(--text-muted)', marginBottom: '12px' }}>
                  <span style={{ color: 'var(--primary)', fontWeight: 800 }}>{featuredPost.category}</span>
                  <span>•</span>
                  <span>{featuredPost.date}</span>
                  <span>•</span>
                  <span>{featuredPost.readTime}</span>
                </div>

                <h2 style={{ fontSize: '1.8rem', fontWeight: 800, marginBottom: '14px', lineHeight: 1.3 }}>
                  {localizedField(featuredPost, 'title', locale, featuredPost.title)}
                </h2>

                <p style={{ color: 'var(--text-muted)', fontSize: '1rem', lineHeight: 1.7, marginBottom: '24px' }}>
                  {localizedField(featuredPost, 'excerpt', locale, featuredPost.excerpt)}
                </p>

                <div style={{ display: 'flex', alignItems: 'center', gap: '8px', color: 'var(--primary)', fontWeight: 800 }}>
                  <span>{t('common.readMore')}</span>
                  <ArrowLeft size={18} style={{ transform: isRtl ? 'none' : 'rotate(180deg)' }} />
                </div>
              </div>
            </AppLink>
          </div>
        </section>
      )}

      {/* Category Pills & Articles Grid */}
      <section style={{ padding: '40px 0' }}>
        <div className="container">
          
          {/* Category Filter Tabs */}
          <div style={{ display: 'flex', gap: '10px', overflowX: 'auto', paddingBottom: '16px', marginBottom: '36px' }}>
            {categoriesList.map((cat) => (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                style={{
                  padding: '8px 20px',
                  borderRadius: '9999px',
                  border: 'none',
                  background: selectedCategory === cat ? 'linear-gradient(135deg, #D32F2F 0%, #B71C1C 100%)' : 'var(--bg-card)',
                  color: selectedCategory === cat ? '#FFF' : 'var(--text-main)',
                  fontWeight: 700,
                  fontSize: '0.9rem',
                  cursor: 'pointer',
                  whiteSpace: 'nowrap',
                  boxShadow: 'var(--shadow-sm)'
                }}
              >
                {cat === '__all' ? t('common.all') : cat}
              </button>
            ))}
          </div>

          {/* Posts Grid */}
          {contentStatus === 'loading' && (
            <div className="guide-loading-panel" aria-live="polite" aria-busy="true">
              <div className="guide-loading-orbit" aria-hidden="true"><BookOpen size={28} /></div>
              <div><strong>{t('loading.posts')}</strong><p>{t('blog.loadingHint')}</p></div>
              <div className="guide-loading-rail" aria-hidden="true"><span /></div>
            </div>
          )}

          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(320px, 1fr))', gap: '32px' }} aria-busy={contentStatus === 'loading'}>
            {contentStatus === 'loading' ? Array.from({ length: 6 }, (_, index) => (
              <div className="guide-skeleton-card" key={`post-skeleton-${index}`} aria-hidden="true">
                <div className="blog-skeleton-image loading-shimmer" />
                <div className="guide-skeleton-copy">
                  <span className="skeleton-line loading-shimmer skeleton-line-short" />
                  <span className="skeleton-line loading-shimmer skeleton-line-wide" />
                  <span className="skeleton-line loading-shimmer" />
                </div>
              </div>
            )) : filtered.map((post) => (
              <AppLink
                key={post.id}
                to={`/blog/${encodeURIComponent(post.slug || post.id)}`}
                onNavigate={() => onSelectPost(post.slug || post.id)}
                className="glass-card"
                style={{
                  borderRadius: 'var(--radius-lg)',
                  overflow: 'hidden',
                  display: 'flex',
                  flexDirection: 'column',
                  justifyContent: 'space-between',
                  cursor: 'pointer',
                  transition: 'all 0.3s ease',
                  color: 'inherit',
                  textDecoration: 'none'
                }}
              >
                <div>
                  <div style={{ height: '200px', overflow: 'hidden', position: 'relative' }}>
                    <img src={post.image || '/images/hero.webp'} alt={localizedField(post, 'title', locale, post.title)} loading="lazy" decoding="async" style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
                    <span className="badge badge-gold" style={{ position: 'absolute', top: '14px', [isRtl ? 'right' : 'left']: '14px' }}>{post.category}</span>
                  </div>

                  <div style={{ padding: '24px' }}>
                    <div style={{ display: 'flex', gap: '12px', fontSize: '0.78rem', color: 'var(--text-muted)', marginBottom: '10px' }}>
                      <span style={{ display: 'flex', alignItems: 'center', gap: '4px' }}><Calendar size={12} /> {post.date}</span>
                      <span style={{ display: 'flex', alignItems: 'center', gap: '4px' }}><Clock size={12} /> {post.readTime}</span>
                    </div>

                    <h3 style={{ fontSize: '1.2rem', fontWeight: 800, marginBottom: '10px', lineHeight: 1.4 }}>
                      {localizedField(post, 'title', locale, post.title)}
                    </h3>

                    <p style={{ fontSize: '0.92rem', color: 'var(--text-muted)', lineHeight: 1.6 }}>
                      {localizedField(post, 'excerpt', locale, post.excerpt)}
                    </p>
                  </div>
                </div>

                <div style={{ padding: '16px 24px', borderTop: '1px solid var(--border-color)', display: 'flex', alignItems: 'center', justifyContent: 'space-between', color: 'var(--primary)', fontWeight: 800, fontSize: '0.88rem' }}>
                  <span>{t('common.viewDetails')}</span>
                  <ArrowLeft size={16} style={{ transform: isRtl ? 'none' : 'rotate(180deg)' }} />
                </div>

              </AppLink>
            ))}
          </div>

          {contentStatus !== 'loading' && filtered.length === 0 && (
            <div className="glass-card" style={{ padding: '32px', textAlign: 'center', color: 'var(--text-muted)' }}>
              {t('blog.empty')}
            </div>
          )}

        </div>
      </section>

    </div>
  );
}
