import React from 'react';
import ContactCtaSection from '../components/ContactCtaSection';
import FaqSection from '../components/FaqSection';
import PageHero from '../components/PageHero';
import SEOHead from '../components/SEOHead';
import { useI18n } from '../i18n/I18nContext';

export default function FaqPage({ onGoHome, onOpenQuoteModal, onOpenContact, siteInfo }) {
  const { locale, t } = useI18n();
  return (
    <main className="marketing-page">
      <SEOHead title={`${t('nav.faq')} | China Planet`} description={t('faq.description')} locale={locale} />
      <PageHero
        badge={t('faq.badge')}
        title={t('faq.title')}
        description={t('faq.description')}
        onGoHome={onGoHome}
      />
      <FaqSection onOpenQuoteModal={onOpenQuoteModal} />
      <ContactCtaSection onOpenQuoteModal={onOpenQuoteModal} onOpenContact={onOpenContact} siteInfo={siteInfo} />
    </main>
  );
}
