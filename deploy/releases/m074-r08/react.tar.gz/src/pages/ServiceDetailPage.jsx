import React, { useState, useEffect, useMemo } from 'react';
import { 
  ShieldCheck, 
  Building2, 
  Search, 
  Warehouse, 
  Truck, 
  CircleDollarSign, 
  BriefcaseBusiness,
  FileCheck2,
  Check, 
  ArrowRight, 
  ArrowLeft, 
  PhoneCall, 
  MessageSquare,
  Sparkles,
  Camera,
  Eye,
  X
} from 'lucide-react';
import { SERVICES_DATA as DEFAULT_SERVICES } from '../data/mockData';
import SEOHead from '../components/SEOHead';
import { useI18n } from '../i18n/I18nContext';
import { localizeService } from '../i18n/serviceCopy';

export default function ServiceDetailPage({ serviceId, onOpenQuoteModal, onGoBack, onNavigateService, servicesData }) {
  const { isRtl, locale, t } = useI18n();
  const copy = locale === 'fr'
    ? { independent: 'Services spécialisés', approved: 'Service proposé par le bureau de Guangzhou 🇨🇳', request: 'Demander ce service', whatsapp: 'Consultation technique sur WhatsApp', zoom: "Agrandir l'image", office: 'Bureau direct de Guangzhou – Chine', overview: 'Présentation détaillée du service', gallery: "Galerie et mise en œuvre sur le terrain", steps: "Étapes d'exécution et de supervision :", stage: 'Étape', why: 'Pourquoi choisir China Planet pour ce service ?', cost: 'Coût du service', transparent: 'Tarification transparente', priceFallback: "Tarification personnalisée selon le périmètre, le volume et le lieu d'intervention.", quote: 'Obtenir un devis personnalisé gratuit', others: 'Autres services China Planet :' }
    : locale === 'en'
      ? { independent: 'Specialized services', approved: 'Service delivered by our Guangzhou office 🇨🇳', request: 'Request this service', whatsapp: 'Technical consultation on WhatsApp', zoom: 'Enlarge image', office: 'Direct Guangzhou office – China', overview: 'Detailed service overview', gallery: 'Gallery and on-site implementation', steps: 'Implementation and supervision steps:', stage: 'Stage', why: 'Why choose China Planet for this service?', cost: 'Service cost', transparent: 'Transparent pricing', priceFallback: 'Custom pricing based on scope, shipment volume and on-site location.', quote: 'Get a free custom quotation', others: 'Other China Planet services:' }
      : { independent: 'الخدمات المستقلة', approved: 'خدمة معتمدة من مكتب جوانزو 🇨🇳', request: 'طلب هذه الخدمة وتأكيد الموعد', whatsapp: 'استشارة فنية عبر الواتساب', zoom: 'تكبير الصورة', office: 'مكتب جوانزو المباشر – الصين', overview: 'نظرة عامة تفصيلية على الخدمة', gallery: 'معرض الصور التوضيحية والتنفيذ الميداني', steps: 'خطوات التنفيذ والإشراف الفني:', stage: 'مرحلة', why: 'لماذا تختار كوكب الصين لهذه الخدمة؟', cost: 'تكلفة الخدمة', transparent: 'الشفافية وسعر التكلفة', priceFallback: 'رسوم مخصصة وشفافة تعتمد على نطاق الخدمة وحجم الشحنة والموقع الميداني.', quote: 'احصل على عرض سعر مخصص مجاناً', others: 'باقي خدمات كوكب الصين:' };
  const activeList = useMemo(() => (servicesData && servicesData.length ? servicesData : DEFAULT_SERVICES).map((item) => localizeService(item, locale)), [servicesData, locale]);
  const service = activeList.find(s => s.id === serviceId) || activeList[0];

  const [activePreviewImage, setActivePreviewImage] = useState(service.image || '/images/inspection.webp');
  const [lightboxImage, setLightboxImage] = useState(null);

  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
    setActivePreviewImage(service.image || '/images/inspection.webp');
  }, [serviceId, service.image]);

  const getIcon = (iconName) => {
    switch (iconName) {
      case 'ShieldCheck': return <ShieldCheck size={32} color="#FFF" />;
      case 'Building2': return <Building2 size={32} color="#FFF" />;
      case 'Search': return <Search size={32} color="#FFF" />;
      case 'Warehouse': return <Warehouse size={32} color="#FFF" />;
      case 'Truck': return <Truck size={32} color="#FFF" />;
      case 'CircleDollarSign': return <CircleDollarSign size={32} color="#FFF" />;
      case 'BriefcaseBusiness': return <BriefcaseBusiness size={32} color="#FFF" />;
      case 'FileCheck2': return <FileCheck2 size={32} color="#FFF" />;
      default: return <ShieldCheck size={32} color="#FFF" />;
    }
  };

  const relatedServices = activeList.filter(s => s.id !== service.id);
  const galleryList = service.gallery && service.gallery.length ? service.gallery : [service.image || '/images/inspection.webp', '/images/hero.webp', '/images/warehouse.webp'];

  return (
    <div style={{ background: 'var(--bg-main)', minHeight: '100vh', paddingBottom: '80px' }} className="animate-fade-in">
      <SEOHead
        title={`${service.title} | China Planet`}
        description={service.description}
        image={service.image || '/images/inspection.webp'}
        locale={locale}
      />
      
      {/* Breadcrumb Navigation Header */}
      <div 
        style={{
          background: 'var(--secondary)',
          color: '#FFFFFF',
          padding: '24px 0',
          borderBottom: '1px solid rgba(255, 255, 255, 0.1)'
        }}
      >
        <div className="container" style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: '16px' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '10px', fontSize: '0.9rem', color: '#94A3B8' }}>
            <button 
              onClick={onGoBack}
              style={{ background: 'none', border: 'none', color: '#FFF', fontWeight: 700, cursor: 'pointer', display: 'flex', alignItems: 'center', gap: '6px' }}
            >
              <ArrowRight size={18} style={{ transform: isRtl ? 'none' : 'rotate(180deg)' }} />
              <span>{t('common.backHome')}</span>
            </button>
            <span>/</span>
            <span>{copy.independent}</span>
            <span>/</span>
            <span style={{ color: 'var(--primary-light)', fontWeight: 700 }}>{service.title}</span>
          </div>

          <div className="badge badge-gold">
            {copy.approved}
          </div>
        </div>
      </div>

      {/* Service Page Hero Header */}
      <section 
        style={{
          position: 'relative',
          padding: '60px 0',
          background: 'radial-gradient(circle at 10% 20%, rgba(211, 47, 47, 0.08) 0%, transparent 40%)',
          borderBottom: '1px solid var(--border-color)'
        }}
      >
        <div className="container">
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(320px, 1fr))', gap: '40px', alignItems: 'center' }}>
            
            <div>
              <div style={{ display: 'flex', alignItems: 'center', gap: '12px', marginBottom: '16px' }}>
                <div style={{ width: '56px', height: '56px', borderRadius: '16px', background: 'var(--primary)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                  {getIcon(service.icon)}
                </div>
                <div>
                  <span className="badge badge-red">{service.badge}</span>
                  <div style={{ fontSize: '0.85rem', color: 'var(--text-muted)', fontFamily: 'var(--font-en)', marginTop: '2px' }}>{service.subtitle}</div>
                </div>
              </div>

              <h1 style={{ fontSize: 'clamp(2rem, 3.5vw, 2.8rem)', fontWeight: 900, color: 'var(--text-main)', marginBottom: '16px', lineHeight: 1.2 }}>
                {service.title}
              </h1>

              <p style={{ fontSize: '1.1rem', color: 'var(--text-muted)', lineHeight: 1.7, marginBottom: '28px', maxWidth: '580px' }}>
                {service.description}
              </p>

              <div style={{ display: 'flex', flexWrap: 'wrap', gap: '14px' }}>
                <button 
                  onClick={onOpenQuoteModal} 
                  className="btn-primary"
                  style={{ padding: '13px 26px', fontSize: '1rem' }}
                >
                  <PhoneCall size={18} />
                  <span>{copy.request}</span>
                </button>

                <a 
                  href="https://wa.me/8613480652510"
                  target="_blank"
                  rel="noreferrer"
                  className="btn-outline"
                  style={{ padding: '13px 22px', fontSize: '0.95rem', textDecoration: 'none' }}
                >
                  <MessageSquare size={18} color="#10B981" />
                  <span>{copy.whatsapp}</span>
                </a>
              </div>
            </div>

            {/* Service Cover Image + Interactive Gallery Thumbnails */}
            <div>
              <div style={{ borderRadius: 'var(--radius-lg)', overflow: 'hidden', boxShadow: 'var(--shadow-lg)', border: '1px solid var(--border-color)', position: 'relative', height: '360px', marginBottom: '12px' }}>
                <img 
                  src={activePreviewImage} 
                  alt={service.title}
                  decoding="async"
                  style={{ width: '100%', height: '100%', objectFit: 'cover', display: 'block', transition: 'all 0.3s ease' }}
                />
                <div style={{ position: 'absolute', inset: 0, background: 'linear-gradient(to top, rgba(15, 23, 42, 0.8) 0%, transparent 60%)' }} />
                
                <button 
                  onClick={() => setLightboxImage(activePreviewImage)}
                  style={{ position: 'absolute', top: '16px', left: '16px', background: 'rgba(0,0,0,0.6)', color: '#FFF', border: 'none', borderRadius: '50%', width: '38px', height: '38px', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center' }}
                  title={copy.zoom}
                >
                  <Eye size={18} />
                </button>

                <div style={{ position: 'absolute', bottom: '16px', right: '20px', color: '#FFF' }}>
                  <div style={{ fontSize: '0.8rem', opacity: 0.8 }}>{copy.office}</div>
                  <div style={{ fontSize: '1.1rem', fontWeight: 800 }}>Guangzhou Quality Hub & Office</div>
                </div>
              </div>

              {/* Gallery Thumbnails List */}
              {galleryList.length > 1 && (
                <div style={{ display: 'flex', gap: '10px', overflowX: 'auto', paddingBottom: '4px' }}>
                  {galleryList.map((gImg, idx) => (
                    <div 
                      key={idx}
                      onClick={() => setActivePreviewImage(gImg)}
                      style={{
                        width: '80px',
                        height: '60px',
                        borderRadius: 'var(--radius-sm)',
                        overflow: 'hidden',
                        cursor: 'pointer',
                        border: activePreviewImage === gImg ? '2px solid var(--primary)' : '1px solid var(--border-color)',
                        opacity: activePreviewImage === gImg ? 1 : 0.6,
                        transition: 'all 0.2s ease',
                        flexShrink: 0
                      }}
                    >
                      <img src={gImg} alt={`Thumb ${idx}`} style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
                    </div>
                  ))}
                </div>
              )}
            </div>

          </div>
        </div>
      </section>

      {/* Main Service Content Grid */}
      <section style={{ padding: '60px 0' }}>
        <div className="container">
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(320px, 1fr))', gap: '40px' }}>
            
            {/* Main Content Column */}
            <div style={{ display: 'flex', flexDirection: 'column', gap: '36px' }}>
              
              {/* Full Overview Section */}
              <div className="glass-card" style={{ padding: '32px', borderRadius: 'var(--radius-lg)' }}>
                <h2 style={{ fontSize: '1.4rem', fontWeight: 800, marginBottom: '16px', display: 'flex', alignItems: 'center', gap: '10px' }}>
                  <Sparkles size={22} color="var(--primary)" />
                  {copy.overview}
                </h2>
                <div style={{ fontSize: '1.02rem', color: 'var(--text-main)', lineHeight: 1.8, whiteSpace: 'pre-line' }}>
                  {service.fullOverview || service.description}
                </div>
              </div>

              {/* Multi-Photo Gallery Showcase Section */}
              <div className="glass-card" style={{ padding: '32px', borderRadius: 'var(--radius-lg)' }}>
                <h2 style={{ fontSize: '1.4rem', fontWeight: 800, marginBottom: '20px', display: 'flex', alignItems: 'center', gap: '10px' }}>
                  <Camera size={22} color="var(--primary)" />
                  {copy.gallery}
                </h2>

                <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(180px, 1fr))', gap: '16px' }}>
                  {galleryList.map((gPhoto, i) => (
                    <div 
                      key={i}
                      onClick={() => setLightboxImage(gPhoto)}
                      style={{
                        borderRadius: 'var(--radius-md)',
                        overflow: 'hidden',
                        height: '140px',
                        position: 'relative',
                        cursor: 'pointer',
                        boxShadow: 'var(--shadow-sm)',
                        border: '1px solid var(--border-color)'
                      }}
                    >
                      <img src={gPhoto} alt={`Gallery item ${i}`} style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
                      <div style={{ position: 'absolute', inset: 0, background: 'rgba(0,0,0,0.2)', opacity: 0, transition: 'opacity 0.2s ease', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#FFF' }} className="hover:opacity-100">
                        <Eye size={22} />
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Execution Workflow Steps (Side-by-Side Grid Layout) */}
              {service.steps && (
                <div className="glass-card" style={{ padding: '32px', borderRadius: 'var(--radius-lg)' }}>
                  <h2 style={{ fontSize: '1.4rem', fontWeight: 800, marginBottom: '24px' }}>
                    {copy.steps}
                  </h2>

                  <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(260px, 1fr))', gap: '20px' }}>
                    {service.steps.map((st, i) => (
                      <div 
                        key={i}
                        style={{
                          display: 'flex',
                          flexDirection: 'column',
                          gap: '12px',
                          padding: '20px',
                          borderRadius: 'var(--radius-md)',
                          background: 'var(--bg-main)',
                          border: '1px solid var(--border-color)',
                          boxShadow: 'var(--shadow-sm)'
                        }}
                      >
                        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                          <div 
                            style={{
                              width: '40px',
                              height: '40px',
                              borderRadius: '50%',
                              background: 'var(--primary)',
                              color: '#FFF',
                              fontWeight: 900,
                              display: 'flex',
                              alignItems: 'center',
                              justifyContent: 'center',
                              flexShrink: 0,
                              fontFamily: 'var(--font-en)'
                            }}
                          >
                            0{i + 1}
                          </div>
                          <span style={{ fontSize: '0.75rem', color: 'var(--primary)', fontWeight: 800, background: 'var(--primary-light)', padding: '2px 8px', borderRadius: '9999px' }}>
                            {copy.stage} {i + 1}
                          </span>
                        </div>

                        <div>
                          <h3 style={{ fontSize: '1.05rem', fontWeight: 800, marginBottom: '6px' }}>{st.title}</h3>
                          <p style={{ fontSize: '0.9rem', color: 'var(--text-muted)', lineHeight: 1.6 }}>{st.desc}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Key Features & Benefits */}
              {service.features && (
                <div className="glass-card" style={{ padding: '32px', borderRadius: 'var(--radius-lg)' }}>
                  <h2 style={{ fontSize: '1.4rem', fontWeight: 800, marginBottom: '20px' }}>
                    {copy.why}
                  </h2>

                  <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(240px, 1fr))', gap: '16px' }}>
                    {service.features.map((feat, i) => (
                      <div 
                        key={i}
                        style={{
                          padding: '14px 18px',
                          borderRadius: 'var(--radius-sm)',
                          background: 'var(--bg-main)',
                          border: '1px solid var(--border-color)',
                          display: 'flex',
                          alignItems: 'center',
                          gap: '10px'
                        }}
                      >
                        <Check size={20} color="#10B981" style={{ flexShrink: 0 }} />
                        <span style={{ fontWeight: 700, fontSize: '0.92rem' }}>{feat}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

            </div>

            {/* Side Card Column: Pricing & Instant Order Form */}
            <div style={{ display: 'flex', flexDirection: 'column', gap: '28px' }}>
              
              {/* Pricing Structure Box */}
              <div 
                style={{
                  background: 'linear-gradient(135deg, #0F172A 0%, #1E293B 100%)',
                  color: '#FFFFFF',
                  padding: '28px',
                  borderRadius: 'var(--radius-lg)',
                  boxShadow: 'var(--shadow-lg)'
                }}
              >
                <div className="badge badge-gold" style={{ marginBottom: '12px' }}>{copy.cost}</div>
                <h3 style={{ fontSize: '1.2rem', fontWeight: 800, marginBottom: '12px' }}>{copy.transparent}</h3>
                <p style={{ fontSize: '0.92rem', color: '#94A3B8', lineHeight: 1.6, marginBottom: '20px' }}>
                  {service.pricingInfo || copy.priceFallback}
                </p>

                <button 
                  onClick={onOpenQuoteModal}
                  className="btn-primary" 
                  style={{ width: '100%', justifyContent: 'center', padding: '12px', fontSize: '0.98rem' }}
                >
                  {copy.quote}
                </button>
              </div>

              {/* Related Services Navigator Box */}
              <div className="glass-card" style={{ padding: '24px', borderRadius: 'var(--radius-lg)' }}>
                <h3 style={{ fontSize: '1.1rem', fontWeight: 800, marginBottom: '16px' }}>{copy.others}</h3>
                
                <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
                  {relatedServices.map((rel) => (
                    <button
                      key={rel.id}
                      onClick={() => onNavigateService(rel.id)}
                      style={{
                        padding: '12px',
                        borderRadius: 'var(--radius-sm)',
                        background: 'var(--bg-main)',
                        border: '1px solid var(--border-color)',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'space-between',
                        cursor: 'pointer',
                        textAlign: 'right',
                        transition: 'all 0.2s ease'
                      }}
                    >
                      <div>
                        <div style={{ fontWeight: 700, fontSize: '0.9rem', color: 'var(--text-main)' }}>{rel.title}</div>
                        <div style={{ fontSize: '0.78rem', color: 'var(--text-muted)' }}>{rel.subtitle}</div>
                      </div>
                      <ArrowLeft size={16} color="var(--primary)" />
                    </button>
                  ))}
                </div>
              </div>

            </div>

          </div>
        </div>
      </section>

      {/* Photo Lightbox Popup */}
      {lightboxImage && (
        <div style={{ position: 'fixed', inset: 0, zIndex: 3000, background: 'rgba(0,0,0,0.85)', backdropFilter: 'blur(10px)', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '20px' }}>
          <div style={{ position: 'relative', maxWidth: '90vw', maxHeight: '90vh' }}>
            <button 
              onClick={() => setLightboxImage(null)}
              style={{ position: 'absolute', top: '-40px', left: '0', background: 'none', border: 'none', color: '#FFF', cursor: 'pointer' }}
            >
              <X size={32} />
            </button>
            <img src={lightboxImage} alt="Expanded Preview" style={{ maxWidth: '100%', maxHeight: '85vh', borderRadius: 'var(--radius-md)', objectFit: 'contain' }} />
          </div>
        </div>
      )}

    </div>
  );
}
