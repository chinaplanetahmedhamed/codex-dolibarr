import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  AlertTriangle,
  Box,
  CheckCircle2,
  ChevronLeft,
  ChevronRight,
  Container,
  LoaderCircle,
  Minus,
  PackageCheck,
  Plus,
  Search,
  Send,
  ShoppingCart,
  Trash2,
  Weight,
} from 'lucide-react';
import B2BContainerVisual from '../components/B2BContainerVisual';
import SEOHead from '../components/SEOHead';
import { trackGoogleEvent } from '../lib/googleAnalytics';
import { useI18n } from '../i18n/I18nContext';
import { calculateB2bPlan, fetchB2bCatalog, submitB2bRequest } from '../lib/api';
import { declaredUnitsAttribute, packingReadiness, sanitizePlannerDraft } from '../lib/b2bPacking';
import { COUNTRY_CODES } from '../lib/countryCodes';
import { localizePath } from '../lib/navigation';

const DRAFT_KEY = 'cp_b2b_planner_draft_v2';

const COPY = {
  ar: {
    seoTitle: 'مخطط طلبات الجملة والحاويات | كوكب الصين',
    seoDescription: 'اختر منتجات الجملة بالكرتون واحصل على تقدير تحميل 20GP أو 40HQ قبل مراجعة فريق كوكب الصين.',
    badge: 'من الكتالوج إلى خطة الشحن', title: 'جهّز طلب الجملة واحسب تحميل الحاوية',
    subtitle: 'اختر المنتجات وعدد الكراتين. يحسب النظام الحجم والوزن وخطة التحميل من بيانات التعبئة المسجلة في نظام كوكب الصين.',
    estimate: 'النتيجة تقديرية وتحتاج مراجعة تشغيلية قبل اعتماد الحجز أو السعر.',
    search: 'ابحث باسم المنتج أو SKU', allCategories: 'جميع التصنيفات', results: 'منتج',
    loading: 'جاري تحميل كتالوج الجملة...', retry: 'إعادة المحاولة', unavailable: 'تعذر تحميل كتالوج الجملة حالياً.',
    variation: 'اختر المواصفة', cartons: 'عدد الكراتين', add: 'أضف لقائمة عرض السعر', update: 'تحديث الخطة',
    unitsCarton: 'قطعة/كرتون', cbmCarton: 'م³/كرتون', packingReady: 'بيانات التعبئة مكتملة', packingMissing: 'بيانات التعبئة تحتاج استكمال',
    quote: 'السعر بعد المراجعة', publicPrice: 'سعر القطعة المنشور', perPiece: 'للقطعة',
    missingValue: 'غير متاح', declaredUnits: 'مذكور في الخيار فقط — غير معتمد للحساب', reviewPacking: 'ستتم مراجعة التعبئة', packingReason: 'سيبقى هذا المنتج في الطلب، لكنه لن يدخل في الرسم أو حساب الحجم والوزن حتى يؤكد فريقنا بيانات التعبئة.',
    planTitle: 'خطة الطلب والحاوية', emptyTitle: 'ابدأ بإضافة منتج', emptyText: 'ستظهر هنا الكراتين والإجماليات وتقدير التحميل.',
    auto: 'اختيار الحاوية تلقائياً', calculating: 'جاري حساب الخطة...', calculationError: 'تعذر حساب الخطة. راجع الكميات وحاول مرة أخرى.',
    totalCartons: 'إجمالي الكراتين', calculatedCartons: 'كراتين داخلة في حساب التحميل', totalUnits: 'إجمالي القطع', knownUnits: 'إجمالي القطع المعروفة', totalCbm: 'الحجم المحسوب', grossWeight: 'الوزن الإجمالي', knownGrossWeight: 'الوزن الإجمالي المعروف',
    remainingCbm: 'المساحة المتبقية', remainingPayload: 'الحمولة المتبقية', placed: 'كرتون موضوع',
    visual: 'عرض الحاوية ثلاثي الأبعاد', visualHelp: 'اسحب لتدوير الحاوية، وقرّب بإصبعين أو استخدم أزرار العرض.', viewControls: 'أدوات العرض ثلاثي الأبعاد', rotateLeft: 'تدوير لليسار', rotateRight: 'تدوير لليمين', reset: 'إعادة ضبط العرض', zoomIn: 'تكبير', zoomOut: 'تصغير', aggregateVisual: 'هذا الرسم يمثل الحجم الإجمالي ككتلة تقديرية. أضف طول وعرض وارتفاع الكرتون في CMS لرؤية توزيع كل كرتون بدقة.', aggregateBlock: 'كتلة حجم إجمالية تقديرية', excluded: 'منتجات خارج حساب التحميل لعدم اكتمال بيانات التعبئة',
    contactTitle: 'أرسل الطلب للمراجعة', contactText: 'لن يتم تأكيد طلب أو تحصيل مبلغ. يستلم فريقنا الطلب لمراجعة السعر والتعبئة والشحن.',
    name: 'الاسم الكامل', company: 'الشركة', phone: 'الهاتف / واتساب', email: 'البريد الإلكتروني', country: 'بلد الوصول', notes: 'ملاحظات أو متطلبات إضافية',
    consentPrefix: 'أوافق على استخدام بياناتي للتواصل بخصوص هذا الطلب وفق ', privacy: 'سياسة الخصوصية', consentSuffix: '.', submit: 'إرسال طلب المراجعة', submitting: 'جاري إرسال الطلب...',
    successTitle: 'تم استلام طلبك', reference: 'رقم المرجع', successText: 'احتفظ بهذا الرقم. سيتواصل الفريق معك بعد مراجعة المنتجات والتحميل.',
    required: 'أكمل الاسم والهاتف والبريد وبلد الوصول والموافقة قبل الإرسال.', requestError: 'تعذر إرسال الطلب حالياً. حاول مرة أخرى أو تواصل معنا مباشرة.', chooseCountry: 'اختر بلد الوصول', pieces: 'القطع', lineCbm: 'الحجم', lineWeight: 'الوزن', lineTotal: 'الإجمالي', pendingReview: 'بانتظار مراجعة بيانات التعبئة/السعر', noDrawing: 'لا توجد سطور مكتملة للحساب بعد. الطلب جاهز للإرسال للمراجعة بدون رسم حاوية.',
    previous: 'السابق', next: 'التالي', pagination: 'صفحات كتالوج الجملة', remove: 'حذف', increaseCartons: 'زيادة عدد الكراتين', decreaseCartons: 'تقليل عدد الكراتين', containerLabel: 'نوع الحاوية', planNotReady: 'يجب اكتمال حساب الخطة قبل إرسال الطلب.', disclaimer: 'لا يمثل الرسم مخطط تثبيت بضائع أو توزيع أحمال محاور.',
  },
  en: {
    seoTitle: 'Wholesale & Container Planner | China Planet', seoDescription: 'Select wholesale products by carton and estimate 20GP or 40HQ loading before operational review.',
    badge: 'From catalogue to shipment plan', title: 'Build your wholesale request and estimate container loading',
    subtitle: 'Choose products and carton quantities. The estimate uses packing data maintained in the China Planet system.',
    estimate: 'The result is an estimate and requires operational review before price or booking confirmation.',
    search: 'Search product name or SKU', allCategories: 'All categories', results: 'products', loading: 'Loading wholesale catalogue...', retry: 'Try again', unavailable: 'The wholesale catalogue is currently unavailable.',
    variation: 'Select option', cartons: 'Cartons', add: 'Add to quote list', update: 'Update plan', unitsCarton: 'units/carton', cbmCarton: 'm³/carton', packingReady: 'Packing data complete', packingMissing: 'Packing data needs completion',
    quote: 'Price after review', publicPrice: 'Published piece price', perPiece: 'per piece', missingValue: 'Not available', declaredUnits: 'Shown in the option only — not verified for calculation', reviewPacking: 'Packing will be reviewed', packingReason: 'This product stays in the request but is excluded from the drawing, volume and weight calculations until our team confirms its packing data.', planTitle: 'Request & container plan', emptyTitle: 'Add your first product', emptyText: 'Cartons, totals and the loading estimate will appear here.',
    auto: 'Choose container automatically', calculating: 'Calculating plan...', calculationError: 'The plan could not be calculated. Review quantities and try again.',
    totalCartons: 'Total cartons', calculatedCartons: 'Cartons included in loading', totalUnits: 'Total units', knownUnits: 'Known total units', totalCbm: 'Calculated volume', grossWeight: 'Gross weight', knownGrossWeight: 'Known gross weight', remainingCbm: 'Remaining volume', remainingPayload: 'Remaining payload', placed: 'cartons placed',
    visual: 'Interactive 3D container view', visualHelp: 'Drag to rotate. Pinch or use the view buttons to zoom.', viewControls: '3D view controls', rotateLeft: 'Rotate left', rotateRight: 'Rotate right', reset: 'Reset view', zoomIn: 'Zoom in', zoomOut: 'Zoom out', aggregateVisual: 'This visual represents total volume as an estimated block. Add carton length, width and height in the CMS to see every carton placed accurately.', aggregateBlock: 'estimated aggregate volume block', excluded: 'Products excluded from loading calculation because packing data is incomplete',
    contactTitle: 'Send for review', contactText: 'No order is confirmed and no payment is taken. Our team reviews pricing, packing and shipping.',
    name: 'Full name', company: 'Company', phone: 'Phone / WhatsApp', email: 'Email', country: 'Destination country', notes: 'Notes or additional requirements', consentPrefix: 'I agree to be contacted about this request under the ', privacy: 'Privacy Policy', consentSuffix: '.', submit: 'Send review request', submitting: 'Sending request...',
    successTitle: 'Request received', reference: 'Reference', successText: 'Keep this reference. Our team will contact you after reviewing the products and loading plan.', required: 'Complete name, phone, email, destination country and consent.', requestError: 'The request could not be sent. Try again or contact us directly.', chooseCountry: 'Choose destination country', pieces: 'Pieces', lineCbm: 'CBM', lineWeight: 'Weight', lineTotal: 'Total', pendingReview: 'Packing/price review pending', noDrawing: 'No line is calculation-ready yet. You can still send the complete request for review without a container drawing.',
    previous: 'Previous', next: 'Next', pagination: 'B2B catalog pages', remove: 'Remove', increaseCartons: 'Increase cartons', decreaseCartons: 'Decrease cartons', containerLabel: 'Container type', planNotReady: 'Complete a valid loading calculation before sending the request.', disclaimer: 'The visual is not a cargo-securing or axle-load plan.',
  },
  fr: {
    seoTitle: 'Planificateur B2B et conteneur | China Planet', seoDescription: 'Sélectionnez vos produits par carton et estimez le chargement 20GP ou 40HQ avant validation.',
    badge: 'Du catalogue au plan de transport', title: 'Préparez votre demande B2B et estimez le chargement', subtitle: 'Choisissez les produits et les cartons. Le calcul utilise les données d’emballage enregistrées par China Planet.',
    estimate: 'Cette estimation nécessite une validation opérationnelle avant confirmation du prix ou du transport.', search: 'Produit ou SKU', allCategories: 'Toutes les catégories', results: 'produits', loading: 'Chargement du catalogue B2B...', retry: 'Réessayer', unavailable: 'Le catalogue B2B est indisponible.',
    variation: 'Choisir une option', cartons: 'Cartons', add: 'Ajouter à la liste de devis', update: 'Mettre à jour', unitsCarton: 'unités/carton', cbmCarton: 'm³/carton', packingReady: 'Emballage complet', packingMissing: 'Emballage à compléter', quote: 'Prix après vérification', publicPrice: 'Prix publié par pièce', perPiece: 'par pièce', missingValue: 'Indisponible', declaredUnits: "Indiqué dans l'option uniquement — non vérifié pour le calcul", reviewPacking: "Emballage à vérifier", packingReason: "Ce produit reste dans la demande mais n'entre pas dans le dessin, le volume ou le poids avant confirmation des données d'emballage.",
    planTitle: 'Demande et conteneur', emptyTitle: 'Ajoutez un premier produit', emptyText: 'Les cartons, totaux et estimations apparaîtront ici.', auto: 'Choix automatique du conteneur', calculating: 'Calcul en cours...', calculationError: 'Le plan ne peut pas être calculé. Vérifiez les quantités.',
    totalCartons: 'Total cartons', calculatedCartons: 'Cartons inclus dans le chargement', totalUnits: 'Total unités', knownUnits: 'Total unités connues', totalCbm: 'Volume calculé', grossWeight: 'Poids brut', knownGrossWeight: 'Poids brut connu', remainingCbm: 'Volume restant', remainingPayload: 'Charge restante', placed: 'cartons placés', visual: 'Vue 3D interactive du conteneur', visualHelp: 'Faites glisser pour pivoter. Pincez ou utilisez les boutons pour zoomer.', viewControls: 'Commandes de la vue 3D', rotateLeft: 'Pivoter à gauche', rotateRight: 'Pivoter à droite', reset: 'Réinitialiser la vue', zoomIn: 'Zoom avant', zoomOut: 'Zoom arrière', aggregateVisual: 'Cette vue représente le volume total sous forme de bloc estimatif. Ajoutez les dimensions du carton dans le CMS pour afficher chaque carton avec précision.', aggregateBlock: 'bloc estimatif du volume total', excluded: 'Produits exclus du calcul faute de données d’emballage',
    contactTitle: 'Envoyer pour validation', contactText: 'Aucune commande ni paiement ne sont confirmés. Notre équipe vérifie prix, emballage et transport.', name: 'Nom complet', company: 'Société', phone: 'Téléphone / WhatsApp', email: 'E-mail', country: 'Pays de destination', notes: 'Notes ou exigences', consentPrefix: "J’accepte d’être contacté au sujet de cette demande selon la ", privacy: 'Politique de confidentialité', consentSuffix: '.', submit: 'Envoyer la demande', submitting: 'Envoi...', successTitle: 'Demande reçue', reference: 'Référence', successText: 'Conservez cette référence. Notre équipe vous contactera après vérification.', required: 'Complétez le nom, téléphone, e-mail, pays et consentement.', requestError: 'Impossible d’envoyer la demande. Réessayez ou contactez-nous.', chooseCountry: 'Choisir le pays de destination', pieces: 'Pièces', lineCbm: 'Volume', lineWeight: 'Poids', lineTotal: 'Total', pendingReview: 'Vérification emballage/prix en attente', noDrawing: 'Aucune ligne ne peut encore être calculée. Vous pouvez néanmoins envoyer la demande complète sans dessin du conteneur.', previous: 'Précédent', next: 'Suivant', pagination: 'Pages du catalogue B2B', remove: 'Supprimer', increaseCartons: 'Augmenter les cartons', decreaseCartons: 'Réduire les cartons', containerLabel: 'Type de conteneur', planNotReady: "Attendez la vérification de la liste avant l'envoi.", disclaimer: 'Le visuel ne constitue pas un plan d’arrimage ni de charge par essieu.',
  },
};

function readDraft() {
  try {
    const parsed = JSON.parse(sessionStorage.getItem(DRAFT_KEY) || '[]');
    return sanitizePlannerDraft(parsed);
  } catch { return []; }
}

function createLineId() { return globalThis.crypto?.randomUUID?.() || `line-${Date.now()}-${Math.random().toString(16).slice(2)}`; }
function variationLabel(variation, parentName = '') {
  if (!variation) return '';
  if (typeof variation.variantLabel === 'string' && variation.variantLabel.trim()) return variation.variantLabel.trim();
  if (typeof variation.label === 'string' && variation.label.trim()) return variation.label.trim();
  if (typeof variation.formattedLabel === 'string' && variation.formattedLabel.trim()) return variation.formattedLabel.trim();

  if (variation.attributes) {
    let attrArray = [];
    if (Array.isArray(variation.attributes)) {
      attrArray = variation.attributes;
    } else if (typeof variation.attributes === 'object') {
      attrArray = Object.entries(variation.attributes).map(([key, val]) => ({
        name: key.replace(/^attribute_/, '').replace(/^pa_/, ''),
        value: val,
      }));
    }

    const parts = attrArray
      .map((item) => {
        if (!item) return '';
        if (typeof item === 'string') return item.trim();
        const val = item.value || item.option || item.slug || '';
        const name = item.name || item.attribute || '';
        if (name && val) {
          const cleanVal = String(val).replace(/-/g, ' ').replace(/\s+/g, ' ').trim();
          const cleanName = String(name).replace(/-/g, ' ').replace(/\s+/g, ' ').trim();
          return `${cleanName}: ${cleanVal}`;
        }
        return String(val || name).replace(/-/g, ' ').replace(/\s+/g, ' ').trim();
      })
      .filter(Boolean);

    if (parts.length > 0) return parts.join(' / ');
  }

  const varName = variation.name || '';
  if (varName) {
    if (parentName) {
      const cleanParent = parentName.trim();
      if (varName.startsWith(`${cleanParent} - `)) return varName.slice(cleanParent.length + 3).trim();
      if (varName.startsWith(`${cleanParent} – `)) return varName.slice(cleanParent.length + 3).trim();
      if (varName !== cleanParent) return varName.replace(cleanParent, '').replace(/^[–\-\s]+/, '').trim();
    } else {
      const dashIndex = varName.indexOf(' - ');
      if (dashIndex !== -1) return varName.slice(dashIndex + 3).trim();
      const enDashIndex = varName.indexOf(' – ');
      if (enDashIndex !== -1) return varName.slice(enDashIndex + 3).trim();
    }
  }

  return varName || '';
}
function formatNumber(value, digits = 1) { return Number(value || 0).toLocaleString(undefined, { maximumFractionDigits: digits }); }
function formatMoney(value, currency) {
  if (!Number.isFinite(Number(value))) return '';
  try { return new Intl.NumberFormat(undefined, { style: 'currency', currency: currency || 'USD', maximumFractionDigits: 2 }).format(Number(value)); }
  catch { return `${formatNumber(value, 2)} ${currency || ''}`.trim(); }
}

function ProductCard({ product, text, onAdd }) {
  const [variationId, setVariationId] = useState(product.variations?.length ? '' : 0);
  const selectedVariation = product.variations?.find((item) => String(item.id) === String(variationId));
  const choice = selectedVariation || product;
  const [cartons, setCartons] = useState(1);
  const packing = choice.packing || {};
  const readiness = packingReadiness(packing);
  const declaredUnits = declaredUnitsAttribute(choice);
  const publishedPiecePrice = choice.price ?? choice.unitPrice;
  const image = choice.image || product.images?.[0] || '/images/warehouse.webp';
  const hasSelectedChoice = !product.variations?.length || Boolean(selectedVariation);
  const canAdd = hasSelectedChoice;

  useEffect(() => { setCartons(1); }, [variationId]);

  return (
    <article className="b2b-product-card">
      <div className="b2b-product-image"><img src={image} alt={product.name} loading="lazy" /></div>
      <div className="b2b-product-body">
        <div className="b2b-product-meta"><span>{product.sku || `#${product.id}`}</span><span className={readiness.ready ? 'is-ready' : 'is-warning'}>{readiness.ready ? text.packingReady : text.packingMissing}</span></div>
        <h3>{product.name}</h3>
        {product.description && <p className="b2b-product-description">{product.description}</p>}
        {product.variations?.length > 0 && (
          <label className="b2b-field"><span>{text.variation}</span><select value={variationId} onChange={(event) => setVariationId(event.target.value)}><option value="">{text.variation}</option>{product.variations.map((variation) => <option key={variation.id} value={variation.id}>{variationLabel(variation, product.name) || variation.name}</option>)}</select></label>
        )}
        <div className="b2b-pack-facts">
          <span><PackageCheck size={15} /> {readiness.unitsPerCarton ? formatNumber(readiness.unitsPerCarton, 0) : text.missingValue} {text.unitsCarton}</span>
          <span><Box size={15} /> {readiness.cbmPerCarton ? formatNumber(readiness.cbmPerCarton, 3) : text.missingValue} {text.cbmCarton}</span>
        </div>
        {!readiness.ready && hasSelectedChoice && <div className="b2b-packing-review" role="note"><AlertTriangle size={16} /><span>{text.packingReason}{declaredUnits ? ` ${formatNumber(declaredUnits, 0)} ${text.unitsCarton}: ${text.declaredUnits}.` : ''}</span></div>}
        <div className="b2b-price">{publishedPiecePrice == null || publishedPiecePrice === '' ? text.quote : <><small>{text.publicPrice}</small> {formatMoney(publishedPiecePrice, product.currency)} <small>{text.perPiece}</small></>}</div>
        {hasSelectedChoice ? <div className="b2b-add-row">
          <label><span>{text.cartons}</span><input type="number" min="1" max="2000" value={cartons} onChange={(event) => setCartons(Math.min(2000, Math.max(1, Number(event.target.value) || 1)))} /></label>
          <button type="button" className="b2b-primary-button" disabled={!canAdd} onClick={() => onAdd(product, selectedVariation, cartons)}><Plus size={17} />{text.add}</button>
        </div> : null}
      </div>
    </article>
  );
}

function Metric({ icon: Icon, label, value }) {
  return <div className="b2b-metric"><Icon size={18} /><span>{label}<strong>{value}</strong></span></div>;
}

export default function B2BPage() {
  const { locale, isRtl } = useI18n();
  const text = COPY[locale] || COPY.ar;
  const [products, setProducts] = useState([]);
  const [categories, setCategories] = useState([]);
  const [containers, setContainers] = useState([]);
  const [pagination, setPagination] = useState({ page: 1, total: 0, totalPages: 1 });
  const [page, setPage] = useState(1);
  const [searchInput, setSearchInput] = useState('');
  const [search, setSearch] = useState('');
  const [category, setCategory] = useState('');
  const [catalogState, setCatalogState] = useState('loading');
  const [catalogError, setCatalogError] = useState('');
  const [reloadKey, setReloadKey] = useState(0);
  const [lines, setLines] = useState(readDraft);
  const [container, setContainer] = useState('auto');
  const [plan, setPlan] = useState(null);
  const [verifiedLines, setVerifiedLines] = useState([]);
  const [planState, setPlanState] = useState('idle');
  const [planError, setPlanError] = useState('');
  const [customer, setCustomer] = useState({ name: '', company: '', phone: '', email: '', country: '', notes: '', consent: false, consentAcceptedAt: '' });
  const [submitState, setSubmitState] = useState('idle');
  const [submitError, setSubmitError] = useState('');
  const [reference, setReference] = useState('');
  const submitKeyRef = useRef('');
  const submitFingerprintRef = useRef('');
  const countryNames = useMemo(() => {
    try { return new Intl.DisplayNames([locale], { type: 'region' }); } catch { return null; }
  }, [locale]);

  useEffect(() => {
    const timer = window.setTimeout(() => { setPage(1); setSearch(searchInput.trim()); }, 450);
    return () => window.clearTimeout(timer);
  }, [searchInput]);

  useEffect(() => {
    let active = true;
    setCatalogState('loading'); setCatalogError('');
    fetchB2bCatalog({ page, perPage: 24, search, category }).then((payload) => {
      if (!active) return;
      setProducts(Array.isArray(payload.products) ? payload.products : []);
      setCategories(Array.isArray(payload.categories) ? payload.categories : []);
      setContainers(Array.isArray(payload.containers) ? payload.containers.filter((item) => item.enabled !== false && Number(item.enabled) !== 0) : []);
      setPagination(payload.pagination || { page, total: 0, totalPages: 1 });
      setCatalogState('ready');
    }).catch((error) => { if (active) { setCatalogState('error'); setCatalogError(error.message || text.unavailable); } });
    return () => { active = false; };
  }, [page, search, category, reloadKey, text.unavailable]);

  useEffect(() => { try { sessionStorage.setItem(DRAFT_KEY, JSON.stringify(lines)); } catch { /* Draft persistence is optional. */ } }, [lines]);

  useEffect(() => {
    if (!lines.length) { setPlan(null); setVerifiedLines([]); setPlanState('idle'); setPlanError(''); return undefined; }
    let active = true;
    setPlanState('loading'); setPlanError('');
    const timer = window.setTimeout(() => {
      calculateB2bPlan({ lines: lines.map(({ lineId, productId, variationId, cartons }) => ({ lineId, productId, variationId, cartons })), container })
        .then((payload) => { if (active) { setPlan(payload.plan || null); setVerifiedLines(Array.isArray(payload.lines) ? payload.lines : []); setPlanState('ready'); } })
        .catch((error) => { if (active) { setPlan(null); setVerifiedLines([]); setPlanState('error'); setPlanError(error.message || text.calculationError); } });
    }, 500);
    return () => { active = false; window.clearTimeout(timer); };
  }, [lines, container, text.calculationError]);

  const totals = plan?.totals || {};
  const totalCartons = Number(totals.cartons || 0);
  const calculatedCartons = Number(totals.calculated_cartons ?? totalCartons);
  const knownUnits = Number(totals.units || 0);
  const unitsComplete = totals.units_complete !== false;
  const weightComplete = totals.weight_complete !== false && Number(totals.missing_weight_cartons || 0) === 0;
  const excludedCount = (plan?.excludedItems || []).length;
  const calculationReadyCount = Number(plan?.calculationReadyLines || 0);
  const selectedContainer = plan?.container;
  const visualMode = plan?.visual_mode || plan?.visualMode || '';
  const usesAggregateVisual = visualMode === 'aggregate_volume' || visualMode === 'hybrid_volume';
  const lineCount = useMemo(() => lines.reduce((sum, line) => sum + Number(line.cartons || 0), 0), [lines]);

  const addLine = (product, variation, cartons) => {
    const variationId = variation?.id || 0;
    const packing = variation?.packing || product.packing || {};
    const lineId = createLineId();
    const next = {
      lineId, productId: product.id, variationId, cartons: Math.min(2000, Math.max(1, Number(cartons) || 1)),
      name: product.name, variantLabel: variationLabel(variation, product.name), sku: variation?.sku || product.sku || '', image: variation?.image || product.images?.[0] || '',
      unitsPerCarton: packing.unitsPerCarton, cbmPerCarton: packing.cbmPerCarton, packing,
    };
    setLines((current) => [...current, next].slice(0, 100));
    setReference(''); setSubmitState('idle');
  };

  const setLineCartons = (lineId, cartons) => setLines((current) => current.map((line) => line.lineId === lineId ? { ...line, cartons: Math.min(2000, Math.max(1, Number(cartons) || 1)) } : line));
  const removeLine = (lineId) => setLines((current) => current.filter((line) => line.lineId !== lineId));
  const updateCustomer = (key, value) => setCustomer((current) => ({ ...current, [key]: value }));
  const updateConsent = (checked) => setCustomer((current) => ({ ...current, consent: checked, consentAcceptedAt: checked ? new Date().toISOString() : '' }));

  const submitRequest = async (event) => {
    event.preventDefault(); setSubmitError('');
    if (customer.name.trim().length < 2 || customer.phone.trim().length < 6 || !customer.email.includes('@') || !/^[A-Z]{2}$/.test(customer.country) || !customer.consent) { setSubmitError(text.required); return; }
    if (planState !== 'ready') { setSubmitError(text.planNotReady); return; }
    setSubmitState('loading');
    try {
      const request = { lines: lines.map(({ lineId, productId, variationId, cartons }) => ({ lineId, productId, variationId, cartons })), container, customer, locale };
      const fingerprint = JSON.stringify(request);
      if (submitFingerprintRef.current !== fingerprint) {
        submitFingerprintRef.current = fingerprint;
        submitKeyRef.current = globalThis.crypto?.randomUUID?.() || `b2b-${Date.now()}-${Math.random().toString(16).slice(2)}`;
      }
      const payload = await submitB2bRequest(request, submitKeyRef.current);
      trackGoogleEvent('generate_lead');
      setReference(payload.request_ref || ''); setSubmitState('success'); setLines([]); setPlan(null); setVerifiedLines([]);
    } catch (error) { setSubmitState('error'); setSubmitError(error.message || text.requestError); }
  };

  return (
    <main className="b2b-page" dir={isRtl ? 'rtl' : 'ltr'}>
      <SEOHead title={text.seoTitle} description={text.seoDescription} locale={locale} />
      <section className="b2b-hero">
        <div className="container"><span className="b2b-eyebrow"><Container size={18} />{text.badge}</span><h1>{text.title}</h1><p>{text.subtitle}</p><div className="b2b-estimate-note"><AlertTriangle size={18} />{text.estimate}</div></div>
      </section>

      <section className="container b2b-workspace">
        <div className="b2b-catalog-column">
          <div className="b2b-toolbar">
            <label className="b2b-search"><Search size={19} /><input aria-label={text.search} value={searchInput} onChange={(event) => setSearchInput(event.target.value)} placeholder={text.search} /></label>
            <select aria-label={text.allCategories} value={category} onChange={(event) => { setCategory(event.target.value); setPage(1); }}><option value="">{text.allCategories}</option>{categories.map((item) => <option key={item.id} value={item.slug}>{item.name} ({item.count})</option>)}</select>
            <span className="b2b-result-count">{formatNumber(pagination.total, 0)} {text.results}</span>
          </div>

          {catalogState === 'loading' ? <div className="b2b-state"><LoaderCircle className="spin" size={34} /><p>{text.loading}</p></div> : catalogState === 'error' ? <div className="b2b-state is-error"><AlertTriangle size={34} /><p>{catalogError || text.unavailable}</p><button type="button" onClick={() => setReloadKey((value) => value + 1)}>{text.retry}</button></div> : <>
            <div className="b2b-product-grid">{products.map((product) => <ProductCard key={product.id} product={product} text={text} onAdd={addLine} />)}</div>
            {pagination.totalPages > 1 && <nav className="b2b-pagination" aria-label={text.pagination}><button type="button" disabled={page <= 1} onClick={() => setPage((value) => Math.max(1, value - 1))}>{isRtl ? <ChevronRight size={18} /> : <ChevronLeft size={18} />}{text.previous}</button><span>{page} / {pagination.totalPages}</span><button type="button" disabled={page >= pagination.totalPages} onClick={() => setPage((value) => value + 1)}>{text.next}{isRtl ? <ChevronLeft size={18} /> : <ChevronRight size={18} />}</button></nav>}
          </>}
        </div>

        <aside className="b2b-plan-column">
          <div className="b2b-plan-card">
            <div className="b2b-plan-heading"><div><span>{text.planTitle}</span><strong>{lineCount}</strong></div><ShoppingCart size={24} /></div>
            {!lines.length && submitState !== 'success' ? <div className="b2b-empty"><Box size={42} /><h2>{text.emptyTitle}</h2><p>{text.emptyText}</p></div> : <>
              {lines.length > 0 && <div className="b2b-lines">{lines.map((line) => {
                const displayVariant = line.variantLabel || (line.variationId ? variationLabel(line, line.name) : '');
                const verified = verifiedLines.find((item) => item.lineId === line.lineId);
                const pieces = verified?.requestedPieces;
                const cbm = verified?.totalCbm;
                const weight = verified?.totalGrossWeightKg;
                const total = verified?.price?.unitPrice != null && pieces != null ? Number(verified.price.unitPrice) * pieces : null;
                return <div className={`b2b-line ${verified && !verified.calculationReady ? 'is-incomplete' : ''}`} key={line.lineId}>{line.image ? <img src={line.image} alt="" /> : <Box size={28} />}<div><strong>{line.name}</strong>{displayVariant ? <small className="b2b-line-variant">{displayVariant}</small> : null}<small>{line.sku}</small><div className="b2b-line-facts"><span>{text.pieces}: {pieces ?? '—'}</span><span>{text.lineCbm}: {cbm == null ? '—' : `${formatNumber(cbm, 3)} m³`}</span><span>{text.lineWeight}: {weight == null ? '—' : `${formatNumber(weight, 1)} kg`}</span><span>{text.lineTotal}: {total == null ? text.quote : formatMoney(total, verified?.price?.currency)}</span></div>{verified && !verified.calculationReady && <small className="b2b-line-warning">{text.pendingReview}: {verified.missingFields.join(', ')}</small>}</div><div className="b2b-line-quantity"><button type="button" onClick={() => setLineCartons(line.lineId, line.cartons - 1)} aria-label={`${text.decreaseCartons}: ${line.name}`}><Minus size={14} /></button><input aria-label={`${text.cartons}: ${line.name}`} type="number" min="1" max="2000" value={line.cartons} onChange={(event) => setLineCartons(line.lineId, event.target.value)} /><button type="button" onClick={() => setLineCartons(line.lineId, line.cartons + 1)} aria-label={`${text.increaseCartons}: ${line.name}`}><Plus size={14} /></button></div><button type="button" className="b2b-remove" onClick={() => removeLine(line.lineId)} aria-label={`${text.remove} ${line.name}`}><Trash2 size={17} /></button></div>;
              })}</div>}

              {lines.length > 0 && <label className="b2b-field b2b-container-select"><span>{text.containerLabel}</span><select value={container} onChange={(event) => setContainer(event.target.value)}><option value="auto">{text.auto}</option>{containers.map((item) => <option key={item.id} value={item.id}>{item.label || item.name || item.id}</option>)}</select></label>}
              {planState === 'loading' && <div className="b2b-plan-status"><LoaderCircle className="spin" size={20} />{text.calculating}</div>}
              {planState === 'error' && <div className="b2b-plan-status is-error"><AlertTriangle size={20} />{planError}</div>}
              {plan && <>
                {calculationReadyCount > 0 ? <><div className={`b2b-plan-result ${plan.ok ? 'is-success' : 'is-warning'}`}><span>{selectedContainer?.label || selectedContainer?.name || selectedContainer?.id}</span>{plan.ok ? <CheckCircle2 size={20} /> : <AlertTriangle size={20} />}</div><B2BContainerVisual plan={plan} label={text.visual} labels={text} /></> : <div className="b2b-plan-status is-warning"><AlertTriangle size={20} />{text.noDrawing}</div>}
                {usesAggregateVisual && <div className="b2b-visual-notice"><AlertTriangle size={17} /><span>{text.aggregateVisual}</span></div>}
                <div className="b2b-metrics"><Metric icon={Box} label={text.totalCartons} value={formatNumber(totalCartons, 0)} />{calculatedCartons !== totalCartons && <Metric icon={PackageCheck} label={text.calculatedCartons} value={formatNumber(calculatedCartons, 0)} />}<Metric icon={PackageCheck} label={unitsComplete ? text.totalUnits : text.knownUnits} value={knownUnits > 0 || unitsComplete ? formatNumber(knownUnits, 0) : '—'} /><Metric icon={Container} label={text.totalCbm} value={`${formatNumber(totals.cbm, 2)} m³`} /><Metric icon={Weight} label={weightComplete ? text.grossWeight : text.knownGrossWeight} value={`${formatNumber(totals.gross_weight, 1)} kg`} /><Metric icon={Container} label={text.remainingCbm} value={`${formatNumber(totals.remaining_cbm, 2)} m³`} /><Metric icon={Weight} label={text.remainingPayload} value={`${formatNumber(totals.remaining_payload, 0)} kg`} /></div>
                <p className="b2b-disclaimer">{text.disclaimer}</p>
                {excludedCount > 0 && <div className="b2b-excluded"><AlertTriangle size={18} /><span>{excludedCount} — {text.excluded}</span></div>}
              </>}
            </>}
          </div>

          {(lines.length > 0 || submitState === 'success') && <div className="b2b-request-card">
            {submitState === 'success' ? <div className="b2b-success" role="status"><CheckCircle2 size={48} /><h2>{text.successTitle}</h2><p>{text.successText}</p><strong>{text.reference}: {reference}</strong></div> : <form onSubmit={submitRequest}>
              <h2>{text.contactTitle}</h2><p>{text.contactText}</p>
              <div className="b2b-form-grid"><label><span>{text.name} *</span><input value={customer.name} onChange={(event) => updateCustomer('name', event.target.value)} required /></label><label><span>{text.company}</span><input value={customer.company} onChange={(event) => updateCustomer('company', event.target.value)} /></label><label><span>{text.phone} *</span><input type="tel" value={customer.phone} onChange={(event) => updateCustomer('phone', event.target.value)} required /></label><label><span>{text.email} *</span><input type="email" value={customer.email} onChange={(event) => updateCustomer('email', event.target.value)} required /></label><label className="is-full"><span>{text.country} *</span><select required aria-label={text.country} value={customer.country} onChange={(event) => updateCustomer('country', event.target.value)}><option value="">{text.chooseCountry}</option>{COUNTRY_CODES.map((code) => <option key={code} value={code}>{countryNames?.of(code) || code}</option>)}</select></label><label className="is-full"><span>{text.notes}</span><textarea rows="3" value={customer.notes} onChange={(event) => updateCustomer('notes', event.target.value)} /></label></div>
              <label className="b2b-consent"><input type="checkbox" checked={customer.consent} onChange={(event) => updateConsent(event.target.checked)} /><span>{text.consentPrefix}<a href={localizePath('/privacy', locale)}>{text.privacy}</a>{text.consentSuffix}</span></label>
              {submitError && <div className="b2b-form-error" role="alert"><AlertTriangle size={18} />{submitError}</div>}
              <button className="b2b-submit" type="submit" disabled={submitState === 'loading' || planState !== 'ready'}>{submitState === 'loading' ? <LoaderCircle className="spin" size={19} /> : <Send size={19} />}{submitState === 'loading' ? text.submitting : text.submit}</button>
            </form>}
          </div>}
        </aside>
      </section>
    </main>
  );
}
