import React, { useEffect } from 'react';
import { 
  ArrowRight, 
  Calendar, 
  Clock, 
  User
} from 'lucide-react';
import SEOHead from '../components/SEOHead';
import AppLink from '../components/AppLink';
import { localizedField, useI18n } from '../i18n/I18nContext';

export default function BlogPostDetailPage({ postId, blogPosts, onGoBack, onSelectPost, onOpenQuoteModal }) {
  const { isRtl, locale, t } = useI18n();
  const activePosts = Array.isArray(blogPosts) ? blogPosts : [];
  const post = activePosts.find(p => p.id === postId || p.slug === postId);

  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [postId]);

  if (!post) {
    return <main style={{ minHeight: '70vh', display: 'grid', placeItems: 'center', padding: '120px 20px' }}><div className="glass-card" style={{ padding: '32px', textAlign: 'center' }}><h1 style={{ marginBottom: '12px' }}>{t('blog.loading')}</h1><button className="btn-outline" onClick={onGoBack}>{t('common.backBlog')}</button></div></main>;
  }

  const relatedPosts = activePosts.filter(p => p.id !== post.id);

  return (
    <div style={{ background: 'var(--bg-main)', minHeight: '100vh', paddingBottom: '80px' }} className="animate-fade-in">
      
      {/* Inject SEO Dynamic Meta Tags for this post */}
      <SEOHead 
        title={`${localizedField(post, 'title', locale, post.title)} | China Planet`}
        description={localizedField(post, 'metaDescription', locale, post.metaDescription || post.excerpt)}
        keywords={post.keywords}
        image={post.image}
        type="article"
        author={post.author}
        locale={locale}
      />

      {/* Header Breadcrumbs */}
      <div style={{ background: 'var(--secondary)', color: '#FFFFFF', padding: '24px 0', borderBottom: '1px solid rgba(255, 255, 255, 0.1)' }}>
        <div className="container" style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: '16px' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '10px', fontSize: '0.9rem', color: '#94A3B8' }}>
            <AppLink
              to="/blog"
              onNavigate={onGoBack}
              style={{ background: 'none', border: 'none', color: '#FFF', fontWeight: 700, cursor: 'pointer', display: 'flex', alignItems: 'center', gap: '6px', textDecoration: 'none' }}
            >
              <ArrowRight size={18} style={{ transform: isRtl ? 'none' : 'rotate(180deg)' }} />
              <span>{t('common.backBlog')}</span>
            </AppLink>
            <span>/</span>
            <span>{post.category}</span>
            <span>/</span>
            <span style={{ color: 'var(--primary-light)', fontWeight: 700 }}>{localizedField(post, 'title', locale, post.title)}</span>
          </div>

          <span className="badge badge-gold">{post.category}</span>
        </div>
      </div>

      {/* Post Hero Section */}
      <section style={{ padding: '60px 0', borderBottom: '1px solid var(--border-color)' }}>
        <div className="container" style={{ maxWidth: '900px' }}>
          
          <div style={{ display: 'flex', gap: '16px', fontSize: '0.85rem', color: 'var(--text-muted)', marginBottom: '16px', flexWrap: 'wrap' }}>
            <span style={{ display: 'flex', alignItems: 'center', gap: '6px' }}><Calendar size={14} color="var(--primary)" /> {post.date}</span>
            <span style={{ display: 'flex', alignItems: 'center', gap: '6px' }}><Clock size={14} color="var(--primary)" /> {post.readTime}</span>
            <span style={{ display: 'flex', alignItems: 'center', gap: '6px' }}><User size={14} color="var(--primary)" /> {post.author}</span>
          </div>

          <h1 style={{ fontSize: 'clamp(2rem, 3.5vw, 2.8rem)', fontWeight: 900, marginBottom: '20px', lineHeight: 1.3 }}>
            {localizedField(post, 'title', locale, post.title)}
          </h1>

          <p style={{ fontSize: '1.15rem', color: 'var(--text-muted)', lineHeight: 1.7, marginBottom: '32px' }}>
            {localizedField(post, 'excerpt', locale, post.excerpt)}
          </p>

          {/* Featured Image */}
          <div style={{ borderRadius: 'var(--radius-lg)', overflow: 'hidden', height: '420px', boxShadow: 'var(--shadow-lg)', border: '1px solid var(--border-color)' }}>
            <img src={post.image || '/images/hero.webp'} alt={localizedField(post, 'title', locale, post.title)} decoding="async" style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
          </div>

        </div>
      </section>

      {/* Post Article Body */}
      <section style={{ padding: '60px 0' }}>
        <div className="container" style={{ maxWidth: '900px' }}>
          
          <div className="glass-card" style={{ padding: '40px', borderRadius: 'var(--radius-lg)', marginBottom: '40px' }}>
            {localizedField(post, 'contentHtml', locale, post.contentHtml) ? (
              <div className="article-content" style={{ fontSize: '1.1rem', lineHeight: 1.9, color: 'var(--text-main)' }} dangerouslySetInnerHTML={{ __html: localizedField(post, 'contentHtml', locale, post.contentHtml) }} />
            ) : (
              <div style={{ fontSize: '1.1rem', lineHeight: 1.9, color: 'var(--text-main)', whiteSpace: 'pre-line' }}>{localizedField(post, 'content', locale, post.content)}</div>
            )}
          </div>

          {/* Author Callout Banner */}
          <div 
            style={{
              background: 'linear-gradient(135deg, #0F172A 0%, #1E293B 100%)',
              color: '#FFFFFF',
              padding: '32px',
              borderRadius: 'var(--radius-lg)',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'space-between',
              flexWrap: 'wrap',
              gap: '20px',
              marginBottom: '60px'
            }}
          >
            <div>
              <div className="badge badge-gold" style={{ marginBottom: '8px' }}>{t('blog.consultBadge')}</div>
              <h3 style={{ fontSize: '1.3rem', fontWeight: 800, marginBottom: '6px' }}>{t('blog.consultTitle')}</h3>
              <p style={{ color: '#94A3B8', fontSize: '0.92rem' }}>{t('blog.consultText')}</p>
            </div>

            <button onClick={onOpenQuoteModal} className="btn-primary" style={{ padding: '12px 24px' }}>
              {t('blog.consultButton')}
            </button>
          </div>

          {/* Related Articles */}
          {relatedPosts.length > 0 && (
            <div>
              <h3 style={{ fontSize: '1.4rem', fontWeight: 800, marginBottom: '24px' }}>{t('blog.related')}</h3>
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))', gap: '24px' }}>
                {relatedPosts.slice(0, 2).map((rel) => (
                  <AppLink
                    key={rel.id}
                    to={`/blog/${encodeURIComponent(rel.slug || rel.id)}`}
                    onNavigate={() => onSelectPost(rel.slug || rel.id)}
                    className="glass-card"
                    style={{ padding: '20px', borderRadius: 'var(--radius-md)', cursor: 'pointer', color: 'inherit', textDecoration: 'none' }}
                  >
                    <div className="badge badge-red" style={{ marginBottom: '10px' }}>{rel.category}</div>
                    <h4 style={{ fontSize: '1.05rem', fontWeight: 800, marginBottom: '8px' }}>{localizedField(rel, 'title', locale, rel.title)}</h4>
                    <p style={{ fontSize: '0.85rem', color: 'var(--text-muted)', lineHeight: 1.5 }}>{localizedField(rel, 'excerpt', locale, rel.excerpt)}</p>
                  </AppLink>
                ))}
              </div>
            </div>
          )}

        </div>
      </section>

    </div>
  );
}
