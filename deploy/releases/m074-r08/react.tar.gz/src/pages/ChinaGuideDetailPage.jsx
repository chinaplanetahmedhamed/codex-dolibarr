import React, { useEffect, useState } from "react";
import { ArrowRight, Building2, Globe2, MapPin, Navigation, Phone, Tags } from "lucide-react";
import SEOHead from "../components/SEOHead";
import { fetchChinaGuidePlace } from "../lib/api";
import { localizedField, useI18n } from "../i18n/I18nContext";

export default function ChinaGuideDetailPage({ slug, initialPlace, onGoBack, onOpenQuoteModal }) {
  const { direction, isRtl, locale, t } = useI18n();
  const [place, setPlace] = useState(initialPlace || null);
  const [status, setStatus] = useState("loading");

  useEffect(() => {
    let active = true;
    setStatus("loading");
    fetchChinaGuidePlace(slug)
      .then((payload) => {
        if (!active) return;
        setPlace(payload);
        setStatus("ready");
      })
      .catch(() => { if (active) setStatus("error"); });
    window.scrollTo({ top: 0, behavior: "smooth" });
    return () => { active = false; };
  }, [slug]);

  if (!place && status === "loading") {
    return <main style={{ minHeight: "70vh", display: "grid", placeItems: "center", padding: "120px 20px" }}><div className="glass-card" style={{ padding: "34px" }}>{t('guide.loadingPlace')}</div></main>;
  }

  if (!place || status === "error") {
    return <main style={{ minHeight: "70vh", display: "grid", placeItems: "center", padding: "120px 20px" }}><div className="glass-card" style={{ padding: "34px", textAlign: "center" }}><h1 style={{ marginBottom: "12px" }}>{t('guide.loadError')}</h1><button type="button" className="btn-outline" onClick={onGoBack}>{t('guide.back')}</button></div></main>;
  }

  const hasPlaceFacts = Boolean(
    place.address
    || place.addressZh
    || place.phone
    || place.website
    || place.mapUrl
    || place.tags?.length > 0
  );

  return (
    <div dir={direction} style={{ minHeight: "100vh", background: "var(--bg-main)", paddingBottom: "80px" }}>
      <SEOHead
        title={`${localizedField(place, 'title', locale, place.title)} | ${t('nav.chinaGuide')}`}
        description={localizedField(place, 'metaDescription', locale, place.metaDescription || place.excerpt || t('guide.description'))}
        image={place.image}
        locale={locale}
        type="article"
      />

      <div style={{ background: "var(--secondary)", color: "#fff", padding: "22px 0" }}>
        <div className="container" style={{ display: "flex", alignItems: "center", gap: "10px", flexWrap: "wrap" }}>
          <button type="button" onClick={onGoBack} style={{ background: "none", border: 0, color: "#fff", cursor: "pointer", fontWeight: 800, display: "flex", gap: "8px", alignItems: "center" }}><ArrowRight size={18} style={{ transform: isRtl ? 'none' : 'rotate(180deg)' }} />{t('nav.chinaGuide')}</button>
          <span style={{ color: "#64748B" }}>/</span>
          <span style={{ color: "#CBD5E1" }}>{place.city}</span>
          <span style={{ color: "#64748B" }}>/</span>
          <span style={{ color: "#FCA5A5" }}>{place.type}</span>
        </div>
      </div>

      <section style={{ position: "relative", minHeight: "420px", display: "grid", alignItems: "end", overflow: "hidden", background: "#0F172A" }}>
        <img src={place.image || "/images/hero.webp"} alt={place.title} style={{ position: "absolute", inset: 0, width: "100%", height: "100%", objectFit: "cover", opacity: .56 }} />
        <div style={{ position: "absolute", inset: 0, background: "linear-gradient(180deg, rgba(15,23,42,.2), rgba(15,23,42,.96))" }} />
        <div className="container" style={{ position: "relative", zIndex: 1, color: "#fff", paddingBottom: "54px", maxWidth: "1000px" }}>
          <div style={{ display: "flex", gap: "9px", flexWrap: "wrap", marginBottom: "16px" }}>
            {place.city && <span className="badge badge-red"><MapPin size={14} />{place.city}</span>}
            {place.type && <span className="badge badge-gold"><Building2 size={14} />{place.type}</span>}
          </div>
          <h1 style={{ fontSize: "clamp(2rem, 4vw, 3.1rem)", maxWidth: "900px", lineHeight: 1.35 }}>{localizedField(place, 'title', locale, place.title)}</h1>
          {place.excerpt && <p style={{ color: "#CBD5E1", fontSize: "1.05rem", lineHeight: 1.8, maxWidth: "850px", marginTop: "16px" }}>{localizedField(place, 'excerpt', locale, place.excerpt)}</p>}
        </div>
      </section>

      <section className="container" style={{ maxWidth: "1000px", paddingTop: "48px", display: "grid", gridTemplateColumns: "minmax(0, 1fr)", gap: "24px" }}>
        {hasPlaceFacts && (
          <div className="glass-card" style={{ padding: "24px", display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(220px, 1fr))", gap: "16px" }}>
            {place.address && <div style={{ display: "flex", gap: "10px", alignItems: "flex-start" }}><MapPin size={19} color="var(--primary)" /><div><strong>{t('guide.address')}</strong><p style={{ color: "var(--text-muted)", marginTop: "5px", lineHeight: 1.6 }}>{place.address}</p></div></div>}
            {place.addressZh && place.addressZh !== place.address && <div style={{ display: "flex", gap: "10px", alignItems: "flex-start" }}><MapPin size={19} color="var(--primary)" /><div><strong>{t('guide.addressChinese')}</strong><p lang="zh-CN" dir="ltr" style={{ color: "var(--text-muted)", marginTop: "5px", lineHeight: 1.6 }}>{place.addressZh}</p></div></div>}
            {place.phone && <div style={{ display: "flex", gap: "10px" }}><Phone size={19} color="var(--primary)" /><div><strong>{t('guide.phone')}</strong><p style={{ color: "var(--text-muted)", marginTop: "5px" }}>{place.phone}</p></div></div>}
            {place.tags?.length > 0 && <div style={{ display: "flex", gap: "10px" }}><Tags size={19} color="var(--primary)" /><div><strong>{t('guide.tags')}</strong><p style={{ color: "var(--text-muted)", marginTop: "5px" }}>{place.tags.join(locale === 'ar' ? "، " : ", ")}</p></div></div>}
            {place.website && <a href={place.website} target="_blank" rel="noopener noreferrer" style={{ display: "flex", gap: "10px", color: "var(--primary)", fontWeight: 800 }}><Globe2 size={19} />{t('guide.website')}</a>}
            {place.mapUrl && <a href={place.mapUrl} target="_blank" rel="noopener noreferrer" style={{ display: "flex", gap: "10px", color: "var(--primary)", fontWeight: 800 }}><Navigation size={19} />{/^https:\/\/(?:uri\.|surl\.)?amap\.com\//i.test(place.mapUrl) ? t('guide.amap') : t('guide.map')}</a>}
          </div>
        )}

        <article className="glass-card" style={{ padding: "clamp(24px, 4vw, 42px)" }}>
          {localizedField(place, 'contentHtml', locale, place.contentHtml) ? (
            <div className="article-content" style={{ fontSize: "1.06rem", lineHeight: 1.95 }} dangerouslySetInnerHTML={{ __html: localizedField(place, 'contentHtml', locale, place.contentHtml) }} />
          ) : (
            <div style={{ textAlign: "center", padding: "28px", color: "var(--text-muted)" }}>{t('guide.noDetails')}</div>
          )}
        </article>

        <div style={{ padding: "30px", color: "#fff", borderRadius: "var(--radius-lg)", background: "linear-gradient(135deg, #0F172A, #1E293B)", display: "flex", alignItems: "center", justifyContent: "space-between", gap: "18px", flexWrap: "wrap" }}>
          <div><h2 style={{ fontSize: "1.35rem", marginBottom: "7px" }}>{t('guide.helpTitle')}</h2><p style={{ color: "#94A3B8" }}>{t('guide.helpText')}</p></div>
          <button type="button" className="btn-primary" onClick={onOpenQuoteModal}>{t('guide.helpButton')}</button>
        </div>
      </section>
    </div>
  );
}
