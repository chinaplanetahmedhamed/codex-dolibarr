import React, { lazy, Suspense, useEffect, useState } from "react";
import Navbar from "./components/Navbar";
import Hero from "./components/Hero";
import StatsBar from "./components/StatsBar";
import ServicesSection from "./components/ServicesSection";
import ProductsCarouselSection from "./components/ProductsCarouselSection";
import SectorsGuideSection from "./components/SectorsGuideSection";
import ChinaGuideSection from "./components/ChinaGuideSection";
import ChinaGuideHomeSection from "./components/ChinaGuideHomeSection";
import CustomerJourneySection from "./components/CustomerJourneySection";
import AboutTrustSection from "./components/AboutTrustSection";
import FaqSection from "./components/FaqSection";
import CustomSectionsView from "./components/CustomSectionsView";
import QuoteModal from "./components/QuoteModal";
import CartDrawer from "./components/CartDrawer";
import Footer from "./components/Footer";
import InteractiveCosmicBg from "./components/InteractiveCosmicBg";
import SEOHead from "./components/SEOHead";
import GlobalLoadingBar from "./components/GlobalLoadingBar";

import ContactCtaSection from "./components/ContactCtaSection";

import {
  SERVICES_DATA as DEFAULT_SERVICES,
  INITIAL_BLOG_POSTS,
  INITIAL_CATALOG_PRODUCTS,
} from "./data/mockData";
import { DEFAULT_TEAM_MEMBERS, LEGACY_GENERIC_TEAM_NAMES } from "./data/teamData";
import { useAppNavigation } from "./hooks/useAppNavigation";
import { useCatalogData } from "./hooks/useCatalogData";
import { useSiteContentAdmin } from "./hooks/useSiteContentAdmin";
import { useWordPressContent } from "./hooks/useWordPressContent";
import { trackMetaEvent } from "./lib/metaPixel";
import { trackGoogleEvent } from "./lib/googleAnalytics";
import { useI18n } from "./i18n/I18nContext";

const ServiceDetailPage = lazy(() => import("./pages/ServiceDetailPage"));
const BlogListPage = lazy(() => import("./pages/BlogListPage"));
const BlogPostDetailPage = lazy(() => import("./pages/BlogPostDetailPage"));
const ChinaGuidePage = lazy(() => import("./pages/ChinaGuidePage"));
const ChinaGuideDetailPage = lazy(() => import("./pages/ChinaGuideDetailPage"));
const ProductsCatalogPage = lazy(() => import("./pages/ProductsCatalogPage"));
const B2BPage = lazy(() => import("./pages/B2BPage"));
const ShippingRatesPage = lazy(() => import("./pages/ShippingRatesPage"));
const SecurePortalAccessPage = lazy(() => import("./pages/SecurePortalAccessPage"));
const AboutPage = lazy(() => import("./pages/AboutPage"));
const ServicesPage = lazy(() => import("./pages/ServicesPage"));
const HowWeWorkPage = lazy(() => import("./pages/HowWeWorkPage"));
const FaqPage = lazy(() => import("./pages/FaqPage"));
const ContactPage = lazy(() => import("./pages/ContactPage"));
const LegalPage = lazy(() => import("./pages/LegalPage"));
const AdminDashboard = lazy(() => import("./dashboard/AdminDashboard"));
const AdminLoginPage = lazy(() => import("./dashboard/AdminLoginPage"));

const DEFAULT_CATEGORIES = ["دليل كانطون", "نصائح الاستيراد", "الشحن والجمرك", "أسواق جوانزو", "دراسات حالة"];
const CUSTOMER_CENTER_URL = import.meta.env.VITE_CUSTOMER_CENTER_URL || "https://erp.visiontrading.biz/custom/chinaplanetcustomercenter/";
const STAFF_PORTAL_URL = import.meta.env.VITE_STAFF_PORTAL_URL || "";
const ENABLE_DEMO_CONTENT = import.meta.env.DEV || import.meta.env.VITE_ENABLE_DEMO_CONTENT === "true";

const DEFAULT_SITE_INFO = {
  siteNameAr: "كوكب الصين",
  siteNameEn: "China Planet",
  legalName: "Vision Trading Ltd.",
  guangzhouPhone: "+8613480652510",
  whatsappNumber: "+8613480652510",
  email: "info@chinaplanet.org",
  chinaOfficeAddress: "مكتب 1012، مبنى 132-1، طريق دونغفنغ الغربي، منطقة يويشيو، جوانزو 510000، الصين",
  chinaOfficeAddressZh: "广州市越秀区东风西路132-1号园景中心，1012室",
  egyptOfficeAddress: "26 شارع السيدة امنه، سيدي جابر، شارع المشير، ميزان شركه البرمجيات، الاسكندرية",
  egyptOfficeMapUrl: "https://maps.app.goo.gl/GiGbBYBfSFWKKvva6?g_st=ic",
  egyptOfficePhone: "01096722199",
  egyptOfficeContactName: "معاذ محمد",
  announcementPrefix: "مكتب جوانزو",
  announcementText: "China Planet وVision Trading – إدارة التوريد من الصين للأسواق العربية منذ 2007",
};

const DEFAULT_HERO_INFO = {
  title: "مكتبك التجاري في الصين لإدارة التوريد من المصنع حتى الشحن",
  subtitle: "كوكب الصين وVision Trading يساعدان المستورد العربي في البحث عن المورد، التفاوض، فحص الجودة، تجميع الطلبات وترتيب الشحن من جوانزو منذ 2007.",
  badge: "China Planet × Vision Trading | جوانزو منذ 2007 🇨🇳",
  bgVideo: "",
  gallery: ["/images/hero.webp", "/images/warehouse.webp", "/images/inspection.webp"],
};

const DEFAULT_SECTORS_INFO = {
  badge: "قطاعات التوريد من الصين",
  title: "نبحث عن المورد المناسب وفق المنتج والمواصفات والسوق المستهدف",
  subtitle: "لا نبيع وعودًا بقوائم مصانع جاهزة؛ نراجع المورد والعرض ونطاق الفحص لكل طلب قبل التنفيذ.",
  sectorsList: [
    { title: "الآلات والمعدات الصناعية", badge: "توريد حسب المواصفات", desc: "خطوط التعبئة والتغليف، معدات CNC والليزر ومعدات المصانع.", suppliersCount: "بحث وتدقيق حسب الطلب" },
    { title: "الإلكترونيات والحلول الذكية", badge: "مراجعة فنية", desc: "إضاءة وشاشات وحلول اتصال ومكونات إلكترونية حسب المواصفات.", suppliersCount: "فحص العينة والمواصفات" },
    { title: "مواد البناء والديكور", badge: "مطابقة متطلبات الوجهة", desc: "سيراميك ورخام وألمنيوم وتشطيبات ومستلزمات مشاريع.", suppliersCount: "مراجعة التعبئة والشهادات" },
    { title: "الأثاث والتجهيزات", badge: "مشاريع وتوريد تجاري", desc: "أثاث مكتبي وفندقي وسكني وتصنيع حسب الطلب.", suppliersCount: "تنسيق العينات والإنتاج" },
    { title: "التعبئة والمنتجات البلاستيكية", badge: "مقاسات وقوالب مخصصة", desc: "عبوات وقوالب حقن وحلول تغليف للاستخدام التجاري والصناعي.", suppliersCount: "فحص الخامة والتعبئة" },
    { title: "الأدوات والأجهزة المنزلية", badge: "طلب تجاري", desc: "أدوات منزلية وأجهزة ومنتجات تجزئة وفق الكمية والسوق.", suppliersCount: "تجميع وشحن متعدد الموردين" },
  ],
};

const DEFAULT_SITE_CONTENT = {
  servicesData: DEFAULT_SERVICES,
  siteInfo: DEFAULT_SITE_INFO,
  teamMembers: DEFAULT_TEAM_MEMBERS,
  legacyGenericTeamNames: LEGACY_GENERIC_TEAM_NAMES,
  customSections: [],
  heroInfo: DEFAULT_HERO_INFO,
  sectorsInfo: DEFAULT_SECTORS_INFO,
};

function CatalogUnavailable({ onOpenQuoteModal }) {
  const { t } = useI18n();
  return (
    <section style={{ padding: "54px 20px", background: "var(--bg-card)", textAlign: "center" }}>
      <div className="container glass-card" style={{ maxWidth: "760px", padding: "30px", margin: "0 auto" }}>
        <h2 style={{ fontSize: "1.4rem", fontWeight: 900, marginBottom: "8px" }}>{t('catalogUpdating.title')}</h2>
        <p style={{ color: "var(--text-muted)", marginBottom: "18px" }}>{t('catalogUpdating.text')}</p>
        <button type="button" className="btn-primary" onClick={onOpenQuoteModal}>{t('catalogUpdating.button')}</button>
      </div>
    </section>
  );
}

function PageLoading() {
  const { t } = useI18n();
  return (
    <main className="page-loading" aria-live="polite">
      <span className="page-loading-spinner" aria-hidden="true" />
      <strong>{t('loading.page')}</strong>
    </main>
  );
}

function SectionLoading({ label }) {
  const { t } = useI18n();
  return (
    <section className="section-data-loading" aria-live="polite" aria-busy="true">
      <div className="container">
        <div className="guide-loading-panel">
          <span className="page-loading-spinner" aria-hidden="true" />
          <div><strong>{t(label)}</strong><p>{t('loading.sectionHint')}</p></div>
          <div className="guide-loading-rail" aria-hidden="true"><span /></div>
        </div>
      </div>
    </section>
  );
}

export default function App() {
  const { locale, t } = useI18n();
  const [theme, setTheme] = useState(() => localStorage.getItem("cp_theme") || "light");
  const [quoteModalOpen, setQuoteModalOpen] = useState(false);
  const [quoteContext, setQuoteContext] = useState({});
  const [cartDrawerOpen, setCartDrawerOpen] = useState(false);
  const [cartItems, setCartItems] = useState(() => {
    try {
      const saved = localStorage.getItem("cp_cart_items");
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });
  const {
    initialRoute,
    isProductsView,
    isB2bView,
    isShippingRatesView,
    isBlogView,
    isChinaGuideView,
    isAdminView,
    isSecureAccessView,
    isAboutView,
    isServicesView,
    isHowWeWorkView,
    isFaqView,
    isContactView,
    isPrivacyView,
    isTermsView,
    selectedPostId,
    selectedGuideSlug,
    selectedServiceId,
    activeNavTab,
    navigate,
    navigateTab,
  } = useAppNavigation();
  const {
    products: catalogProducts,
    categories: catalogCategories,
    status: catalogStatus,
  } = useCatalogData({
    initialRoute,
    demoEnabled: ENABLE_DEMO_CONTENT,
    demoProducts: INITIAL_CATALOG_PRODUCTS,
  });
  const {
    servicesData,
    setServicesData,
    siteInfo,
    setSiteInfo,
    teamMembers,
    setTeamMembers,
    customSections,
    setCustomSections,
    heroInfo,
    setHeroInfo,
    sectorsInfo,
    setSectorsInfo,
    adminUser,
    adminSessionStatus,
    contentSaveState,
    contentLoadStatus,
    lastSavedAt,
    handleAdminLogin,
    handleAdminLogout,
    handleSaveSiteContent,
  } = useSiteContentAdmin({
    isAdminView,
    defaults: DEFAULT_SITE_CONTENT,
  });
  const {
    posts: blogPosts,
    categories: blogCategories,
    postsStatus: wordpressContentStatus,
    guidePlaces,
    guideCities,
    guideTypes,
    guideStatus,
    retryGuide,
  } = useWordPressContent({
    initialRoute,
    demoEnabled: ENABLE_DEMO_CONTENT,
    demoPosts: INITIAL_BLOG_POSTS,
    defaultCategories: DEFAULT_CATEGORIES,
  });
  useEffect(() => {
    try { localStorage.setItem("cp_theme", theme); } catch { /* Preferences are optional. */ }
    document.documentElement.setAttribute("data-theme", theme);
  }, [theme]);

  useEffect(() => {
    try { localStorage.setItem("cp_cart_items", JSON.stringify(cartItems)); } catch { /* Cart persistence is optional. */ }
  }, [cartItems]);

  const handleAddToCart = (productWithQty) => {
    const productId = productWithQty.wooProductId
      || productWithQty.sourceProductId
      || productWithQty.id;
    const eventParameters = {
      content_ids: productId ? [String(productId)] : [],
      content_name: productWithQty.title || 'catalog_product',
      content_category: productWithQty.subCategoryName || productWithQty.categoryName || 'catalog',
      content_type: 'product',
      num_items: 1,
      cartons: Number(productWithQty.cartonsCount) || undefined,
      units: Number(productWithQty.totalUnits) || undefined,
    };
    trackMetaEvent('AddToCart', eventParameters);
    trackMetaEvent('AddToQuoteCart', eventParameters, { custom: true });
    trackGoogleEvent('add_to_quote_cart');

    setCartItems((current) => {
      const existingIndex = current.findIndex((item) => item.id === productWithQty.id);
      if (existingIndex < 0) return [...current, productWithQty];
      return current.map((item, index) => index === existingIndex ? productWithQty : item);
    });
  };

  const openQuote = (initialRequest = {}) => {
    setQuoteContext(initialRequest && typeof initialRequest === "object" ? initialRequest : {});
    setQuoteModalOpen(true);
  };

  const pageOwnsSeo = Boolean(
    selectedPostId
    || selectedGuideSlug
    || selectedServiceId
    || isBlogView
    || isChinaGuideView
    || isAboutView
    || isServicesView
    || isHowWeWorkView
    || isFaqView
    || isContactView
    || isPrivacyView
    || isTermsView
    || isB2bView
    || isShippingRatesView
  );

  return (
    <div style={{ minHeight: "100vh", display: "flex", flexDirection: "column" }}>
      <GlobalLoadingBar />
      {!pageOwnsSeo && <SEOHead
        title={isProductsView ? t('seo.productsTitle') : t('seo.homeTitle')}
        description={isProductsView ? t('seo.productsDescription') : t('seo.homeDescription')}
        noIndex={isAdminView || isSecureAccessView}
        locale={locale}
      />}
      <InteractiveCosmicBg cosmicSettings={siteInfo.cosmicBg} />

      {!isSecureAccessView && !isAdminView && (
        <Navbar
          currentTab={activeNavTab}
          setCurrentTab={navigateTab}
          theme={theme}
          toggleTheme={() => setTheme((value) => value === "light" ? "dark" : "light")}
          onOpenQuoteModal={openQuote}
          onSelectService={(serviceId) => { navigate(serviceId ? `/service/${serviceId}` : "/"); }}
          servicesData={servicesData}
          siteInfo={siteInfo}
          cartCount={isB2bView ? 0 : cartItems.length}
          onOpenCart={isB2bView ? undefined : () => setCartDrawerOpen(true)}
          customerCenterUrl={CUSTOMER_CENTER_URL}
        />
      )}

      <Suspense fallback={<PageLoading />}>
      {isAdminView ? (
        adminSessionStatus === "checking" ? (
          <main style={{ minHeight: "100vh", display: "grid", placeItems: "center", background: "var(--bg-main)" }}>جاري التحقق من جلسة الدخول...</main>
        ) : adminUser ? (
          <AdminDashboard
            servicesData={servicesData} setServicesData={setServicesData}
            blogPosts={blogPosts}
            siteInfo={siteInfo} setSiteInfo={setSiteInfo}
            teamMembers={teamMembers} setTeamMembers={setTeamMembers}
            customSections={customSections} setCustomSections={setCustomSections}
            heroInfo={heroInfo} setHeroInfo={setHeroInfo}
            sectorsInfo={sectorsInfo} setSectorsInfo={setSectorsInfo}
            onSave={handleSaveSiteContent}
            onLogout={handleAdminLogout}
            onExitDashboard={() => { navigate("/"); }}
            saveState={contentSaveState}
            contentReady={contentLoadStatus === "ready"}
            lastSavedAt={lastSavedAt}
          />
        ) : (
          <AdminLoginPage onLogin={handleAdminLogin} onGoHome={() => { navigate("/"); }} />
        )
      ) : isSecureAccessView ? (
        <SecurePortalAccessPage customerCenterUrl={CUSTOMER_CENTER_URL} staffPortalUrl={STAFF_PORTAL_URL} onGoHome={() => { navigate("/"); }} onOpenQuoteModal={openQuote} />
      ) : selectedPostId ? (
        <BlogPostDetailPage postId={selectedPostId} blogPosts={blogPosts} contentStatus={wordpressContentStatus} onGoBack={() => { navigate("/blog"); }} onSelectPost={(id) => { navigate(`/blog/${encodeURIComponent(id)}`); }} onOpenQuoteModal={openQuote} />
      ) : selectedGuideSlug ? (
        <main style={{ flex: 1, paddingTop: "var(--site-header-offset)" }}>
          <ChinaGuideDetailPage slug={selectedGuideSlug} initialPlace={guidePlaces.find((place) => place.slug === selectedGuideSlug)} onGoBack={() => { navigate("/china-guide"); }} onOpenQuoteModal={openQuote} />
        </main>
      ) : isB2bView ? (
        <B2BPage onOpenQuoteModal={openQuote} />
      ) : isShippingRatesView ? (
        <ShippingRatesPage />
      ) : isProductsView ? (
        <main style={{ flex: 1, paddingTop: "var(--site-header-offset)" }}>
          <ProductsCatalogPage siteInfo={siteInfo} catalogProducts={catalogProducts} catalogCategories={catalogCategories} status={catalogStatus} onGoHome={() => { navigate("/"); }} cartItems={cartItems} onAddToCart={handleAddToCart} onRemoveCartItem={(id) => setCartItems((items) => items.filter((item) => item.id !== id))} onSubmitCartOrder={() => {}} onClearCart={() => setCartItems([])} />
        </main>
      ) : isChinaGuideView ? (
        <main style={{ flex: 1, paddingTop: "var(--site-header-offset)" }}>
          <ChinaGuidePage places={guidePlaces} cities={guideCities} types={guideTypes} status={guideStatus} onRetry={retryGuide} onGoHome={() => { navigate("/"); }} onSelectPlace={(slug) => { navigate(`/china-guide/${encodeURIComponent(slug)}`); }} />
        </main>
      ) : isBlogView ? (
        <main style={{ flex: 1, paddingTop: "var(--site-header-offset)" }}>
          <BlogListPage blogPosts={blogPosts} blogCategories={blogCategories} contentStatus={wordpressContentStatus} onSelectPost={(id) => { navigate(`/blog/${encodeURIComponent(id)}`); }} onGoHome={() => { navigate("/"); }} />
        </main>
      ) : isAboutView ? (
        <AboutPage onGoHome={() => navigate("/")} onOpenQuoteModal={openQuote} onOpenContact={() => navigate("/contact")} teamMembers={teamMembers} siteInfo={siteInfo} />
      ) : isServicesView ? (
        <ServicesPage servicesData={servicesData} onSelectService={(id) => navigate(`/service/${id}`)} onGoHome={() => navigate("/")} onOpenQuoteModal={openQuote} onOpenContact={() => navigate("/contact")} siteInfo={siteInfo} />
      ) : isHowWeWorkView ? (
        <HowWeWorkPage onGoHome={() => navigate("/")} onOpenQuoteModal={openQuote} onOpenContact={() => navigate("/contact")} siteInfo={siteInfo} />
      ) : isFaqView ? (
        <FaqPage onGoHome={() => navigate("/")} onOpenQuoteModal={openQuote} onOpenContact={() => navigate("/contact")} siteInfo={siteInfo} />
      ) : isContactView ? (
        <ContactPage onGoHome={() => navigate("/")} onOpenQuoteModal={openQuote} siteInfo={siteInfo} />
      ) : isPrivacyView || isTermsView ? (
        <LegalPage kind={isTermsView ? "terms" : "privacy"} onGoHome={() => navigate("/")} />
      ) : selectedServiceId ? (
        <main style={{ flex: 1, paddingTop: "var(--site-header-offset)" }}>
          <ServiceDetailPage serviceId={selectedServiceId} servicesData={servicesData} onGoBack={() => { navigate("/"); }} onOpenQuoteModal={openQuote} />
        </main>
      ) : (
        <main style={{ flex: 1, paddingTop: "var(--site-header-offset)" }}>
          <Hero onOpenQuoteModal={openQuote} heroInfo={heroInfo} />
          <StatsBar />
          <CustomSectionsView sections={customSections} positionFilter="top" onOpenQuoteModal={openQuote} />
          <section id="services"><ServicesSection servicesData={servicesData} limit={3} compact onSelectService={(id) => { navigate(`/service/${id}`); }} onViewAllServices={() => navigate("/services")} /></section>
          <CustomerJourneySection compact onViewAll={() => navigate("/how-we-work")} onOpenQuoteModal={openQuote} customerCenterUrl={CUSTOMER_CENTER_URL} />
          {catalogProducts.length > 0 ? (
            <ProductsCarouselSection catalogProducts={catalogProducts} onViewAllProducts={() => { navigate("/products"); }} onAddToCart={handleAddToCart} />
          ) : catalogStatus === "loading" ? <SectionLoading label="loading.catalog" /> : <CatalogUnavailable onOpenQuoteModal={openQuote} />}
          <SectorsGuideSection sectorsInfo={sectorsInfo} limit={3} compact onViewAllProducts={() => { navigate("/products"); }} />
          <ChinaGuideHomeSection
            places={guidePlaces}
            cities={guideCities}
            status={guideStatus}
            onOpenGuide={() => navigate("/china-guide")}
            onSelectPlace={(slug) => navigate(`/china-guide/${encodeURIComponent(slug)}`)}
          />
          <AboutTrustSection compact onOpenQuoteModal={openQuote} onViewAll={() => navigate("/about")} />
          <CustomSectionsView sections={customSections} positionFilter="middle" onOpenQuoteModal={openQuote} />
          {wordpressContentStatus === "loading" ? <SectionLoading label="loading.posts" /> : <ChinaGuideSection blogPosts={blogPosts} limit={2} compact onOpenBlog={() => { navigate("/blog"); }} onSelectPost={(id) => { navigate(`/blog/${encodeURIComponent(id)}`); }} />}
          <CustomSectionsView sections={customSections} positionFilter="bottom" onOpenQuoteModal={openQuote} />
          <FaqSection limit={3} compact onOpenQuoteModal={openQuote} onViewAll={() => navigate("/faq")} />
          <ContactCtaSection onOpenQuoteModal={openQuote} onOpenContact={() => navigate("/contact")} siteInfo={siteInfo} />
        </main>
      )}
      </Suspense>

      <CartDrawer isOpen={cartDrawerOpen} onClose={() => setCartDrawerOpen(false)} cartItems={cartItems} onRemoveItem={(id) => setCartItems((items) => items.filter((item) => item.id !== id))} onSubmitOrder={() => {}} onClearCart={() => setCartItems([])} />
      {!isSecureAccessView && !isAdminView && <Footer siteInfo={siteInfo} customerCenterUrl={CUSTOMER_CENTER_URL} />}
      <QuoteModal isOpen={quoteModalOpen} initialRequest={quoteContext} onClose={() => { setQuoteModalOpen(false); setQuoteContext({}); }} />
    </div>
  );
}
