export const CHINAPLANETOS_RELEASE = Object.freeze({
  schemaVersion: 1,
  releaseId: 'M072-R01',
});
