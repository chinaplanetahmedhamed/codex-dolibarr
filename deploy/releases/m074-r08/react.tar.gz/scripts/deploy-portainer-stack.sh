#!/usr/bin/env bash

set -euo pipefail

required_variables=(
  PORTAINER_URL
  PORTAINER_API_KEY
  PORTAINER_ENDPOINT_ID
  PORTAINER_STACK_ID
  IMAGE_TAG
  B2B_API_SECRET
  DOLIBARR_API_BASE_URL
  DOLIBARR_ALLOWED_HOST
  DOLIBARR_API_KEY
  TRUSTED_PROXY_HOPS
  STACK_FILE
  HEALTHCHECK_URL
)

for variable_name in "${required_variables[@]}"; do
  if [[ -z "${!variable_name:-}" ]]; then
    echo "Missing required deployment variable: ${variable_name}" >&2
    exit 1
  fi
done

if [[ ! -f "${STACK_FILE}" ]]; then
  echo "Stack file not found: ${STACK_FILE}" >&2
  exit 1
fi

case "${IMAGE_TAG}" in
  *[!a-zA-Z0-9._-]*|'')
    echo "IMAGE_TAG contains unsupported characters." >&2
    exit 1
    ;;
esac

temporary_directory="$(mktemp -d)"
trap 'rm -rf "${temporary_directory}"' EXIT

stack_response="${temporary_directory}/stack.json"
update_payload="${temporary_directory}/update.json"
update_response="${temporary_directory}/update-response.json"

curl --fail-with-body --silent --show-error \
  --header "X-API-Key: ${PORTAINER_API_KEY}" \
  "${PORTAINER_URL%/}/api/stacks/${PORTAINER_STACK_ID}" \
  > "${stack_response}"

jq \
  --arg stack_file "$(<"${STACK_FILE}")" \
  --arg image_tag "${IMAGE_TAG}" \
  --arg b2b_api_secret "${B2B_API_SECRET}" \
  --arg dolibarr_api_base_url "${DOLIBARR_API_BASE_URL}" \
  --arg dolibarr_allowed_host "${DOLIBARR_ALLOWED_HOST}" \
  --arg dolibarr_api_key "${DOLIBARR_API_KEY}" \
  --arg trusted_proxy_hops "${TRUSTED_PROXY_HOPS}" \
  '{
    stackFileContent: $stack_file,
    env: ((.Env // [])
      | map(select(
          .name != "IMAGE_TAG"
          and .name != "B2B_API_SECRET"
          and .name != "DOLIBARR_API_BASE_URL"
          and .name != "DOLIBARR_ALLOWED_HOST"
          and .name != "DOLIBARR_API_KEY"
          and .name != "TRUSTED_PROXY_HOPS"
        ))
      + [
          {name: "IMAGE_TAG", value: $image_tag},
          {name: "B2B_API_SECRET", value: $b2b_api_secret},
          {name: "DOLIBARR_API_BASE_URL", value: $dolibarr_api_base_url},
          {name: "DOLIBARR_ALLOWED_HOST", value: $dolibarr_allowed_host},
          {name: "DOLIBARR_API_KEY", value: $dolibarr_api_key},
          {name: "TRUSTED_PROXY_HOPS", value: $trusted_proxy_hops}
        ]),
    prune: false,
    pullImage: true
  }' \
  "${stack_response}" \
  > "${update_payload}"

echo "Updating Portainer stack ${PORTAINER_STACK_ID}..."
curl --fail-with-body --silent --show-error \
  --request PUT \
  --header "X-API-Key: ${PORTAINER_API_KEY}" \
  --header "Content-Type: application/json" \
  --data-binary "@${update_payload}" \
  "${PORTAINER_URL%/}/api/stacks/${PORTAINER_STACK_ID}?endpointId=${PORTAINER_ENDPOINT_ID}" \
  > "${update_response}"

echo "Waiting for ${HEALTHCHECK_URL}..."
for attempt in $(seq 1 30); do
  health_response="$(curl --fail --silent --show-error --max-time 10 "${HEALTHCHECK_URL}" || true)"
  if [[ -n "${health_response}" ]]; then
    deployed_sha="$(jq -r '.deploySha // empty' <<<"${health_response}" 2>/dev/null || true)"
    if [[ "${deployed_sha}" == "${IMAGE_TAG}" ]]; then
      echo "Deployment ${IMAGE_TAG} is healthy and verified."
      exit 0
    fi
  fi

  if [[ "${attempt}" -lt 30 ]]; then
    sleep 5
  fi
done

echo "Deployment health check did not verify image ${IMAGE_TAG} within 150 seconds." >&2
exit 1
